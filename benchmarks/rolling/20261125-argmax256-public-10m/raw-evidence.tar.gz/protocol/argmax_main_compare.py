"""Acquisition for the two registered 4T scheduled Join regressions."""

from __future__ import annotations

import argparse
import asyncio
import importlib.metadata
import json
import os
import platform
import re
import subprocess
import sys
import time
from pathlib import Path

import psutil
from packaging.requirements import Requirement

from benchmarks.native_release_identity import verify_package_files
from scripts.benchmark_suite.catalog import engine_cases
from scripts.benchmark_suite.measure import measure_case
from scripts.benchmark_suite.process import install
from scripts.benchmark_suite.release import load_release
from scripts.sparse_changelog_ci import _paging, _siblings, interval
from scripts.toolkit import linear_percentile, sha256_file, write_json

ROOT = Path(__file__).resolve().parents[1]
MAIN = "596e28832c9829972a5311ef0a4c3d88f4885564"
ROWS = 10_000_000
SIDES = ("baseline", "candidate")


def verify_build(release, source, expected):
    git = lambda *args: subprocess.check_output(
        ["git", "-C", source, *args], text=True
    ).strip()
    if git("status", "--porcelain") or git("rev-parse", "HEAD") != expected:
        raise ValueError("source worktree does not identify the registered commit")
    if release["git_sha"] != expected or release["cargo_lock_sha256"] != sha256_file(
        source / "Cargo.lock"
    ):
        raise ValueError("source checkout differs from the sealed release build")
    return {
        "sha": expected,
        "tree": git("rev-parse", "HEAD^{tree}"),
        "release": release,
    }


async def observe_cpus(output, selected=None):
    before = _paging()
    psutil.cpu_percent(percpu=True)
    await asyncio.sleep(3 if selected is None else 1)
    busy = psutil.cpu_percent(percpu=True)
    after = _paging()
    preflight = selected is None
    if preflight:
        available = sorted(os.sched_getaffinity(0))
        # Bind the one-thread worker to one core and monitor its SMT sibling.
        groups = {tuple(sorted((cpu, *_siblings(cpu)))) for cpu in available}
        least = sorted(groups, key=lambda group: (max(busy[i] for i in group), group))
        selected = sorted(
            min(i for i in group if i in available) for group in least[:1]
        )
        if len(selected) != 1:
            raise RuntimeError("one physical core is required")
    free = psutil.virtual_memory().available
    stats = [
        interval((before, after), busy, free, (i, *_siblings(i)), preflight=preflight)
        for i in selected
    ]
    with (output / "resources.jsonl").open("a") as log:
        log.write(
            json.dumps({"epoch": time.time(), "preflight": preflight, "cores": stats})
            + "\n"
        )
    if not all(row["suitable"] for row in stats):
        raise RuntimeError(f"host resource envelope failed: {stats}")
    return selected


def locked_versions():
    versions = {}
    for line in (ROOT / "benchmarks/requirements.lock").read_text().splitlines():
        if not re.match(r"^[A-Za-z0-9].*==", line):
            continue
        req = Requirement(line.rstrip(" " + chr(92)))
        if req.marker and not req.marker.evaluate():
            continue
        version = importlib.metadata.version(req.name)
        if version not in req.specifier:
            raise ValueError(f"wrong version of {req.name}")
        versions[req.name] = version
    return versions


async def run(args):
    selected = (
        row
        for row in engine_cases(ROWS)
        if row["id"] == f"engines/{ROWS}/calc-flow-stream-1t/{args.scenario}"
    )
    (case,) = selected
    if "variant" in case:
        raise ValueError("expected the scheduled default managed workload")
    releases = dict(
        zip(
            SIDES,
            (load_release(manifest) for manifest in (args.baseline, args.candidate)),
            strict=True,
        )
    )
    identity = {
        "baseline": verify_build(releases["baseline"], ROOT, MAIN),
        "candidate": verify_build(
            releases["candidate"], args.candidate_source, args.sha
        ),
    }
    if releases["baseline"]["native_sha256"] == releases["candidate"]["native_sha256"]:
        raise ValueError("expected independent native builds")
    for key in ("cargo_lock_sha256", "rustc", "python", "python_executable", "command"):
        # The output directory is the last argument; the build flags must match.
        a, b = (r[key] for r in releases.values())
        if (a[:-1] != b[:-1]) if key == "command" else (a != b):
            raise ValueError(f"release build identity differs at {key}")
    write_json(
        args.output / "qualification.json",
        {
            "builds": identity,
            "scenario": case,
            "controller_sha256": sha256_file(Path(__file__)),
            "bench_lock_sha256": sha256_file(ROOT / "benchmarks/requirements.lock"),
            "python": sys.version,
            "uname": tuple(platform.uname()),
            "dependencies": locked_versions(),
        },
        exclusive=True,
    )
    sites = {}
    for side, release in releases.items():
        endpoint = "argmax" if side == "candidate" else "main"
        proof = json.loads((ROOT / "target" / ("setup-" + endpoint) / "site-proof.json").read_text())
        if proof["build"]["release"] != release or proof["python_locks"] != locked_versions():
            raise ValueError("pre-qualified environment or release differs from registered arm")
        if proof["environment"]["native_sha256"] != release["native_sha256"] or proof["environment"]["executable"] != sys.executable:
            raise ValueError("pre-qualified loaded native or interpreter differs")
        site = Path(proof["site"])
        verify_package_files(Path(release["wheel_path"]), site)
        sites[side] = (site, ROOT)
    cpus = await observe_cpus(args.output)
    os.sched_setaffinity(0, set(cpus))
    async with asyncio.TaskGroup() as group:
        task = group.create_task(
            measure_case(
                case, "interleaved", sites, releases, args.output / "measurement"
            )
        )
        while not task.done():
            await observe_cpus(args.output, cpus)
    row = task.result()
    write_json(args.output / "samples.json", row)
    if row["status"] != "ok":
        raise ValueError(f"scheduled public case failed: {row.get('error')}")
    import math
    expected = {"passed": True, "rows": ROWS, "finite_rows": ROWS}
    worker_files = list((args.output / "measurement").rglob("*.completed.json"))
    checks = {"prepare": [], "sample": []}
    for path in worker_files:
        record = json.loads(path.read_text())
        result = record.get("response", {})
        item = result.get("warmup", result)
        if isinstance(item, dict) and "seconds" in item and "correctness" in item:
            checks[record["operation"]].append(item["correctness"])
    # Per-request files carry context/response; named samples are also persisted in row evidence.
    if (
        len(checks["prepare"]) != 4
        or len(checks["sample"]) != 40
        or any({k: check.get(k) for k in expected} != expected or check["max_abs_error"] != 0.0 for items in checks.values() for check in items)
    ):
        raise ValueError("missing full, exact output for a warmup or formal execution")
    if len(row["evidence"]) != 2:
        raise ValueError("confirmation rounds missing")
    for evidence in row["evidence"]:
        if evidence["environment"]["cpu_affinity"] != cpus:
            raise ValueError("affinity changed")
        for side in SIDES:
            if len(evidence["samples"][side]) != 10:
                raise ValueError("incomplete sample inventory")
    stats = {
        **row["result"],
        "base_p95": linear_percentile([s for r in row["baseline"] for s in r], 0.95),
        "oracle_checked_executions": 44,
        "largest_reported_absolute_error": max(c["max_abs_error"] for items in checks.values() for c in items),
        "cpus": cpus,
    }
    write_json(args.output / "result.json", stats)
    print(json.dumps(stats), flush=True)


def main():
    p = argparse.ArgumentParser()
    p.add_argument("scenario", choices=("argmax256",))
    for name in ("baseline", "candidate", "candidate-source", "output"):
        p.add_argument("--" + name, type=Path, required=True)
    p.add_argument("--sha", required=True)
    args = p.parse_args()
    args.output.mkdir(parents=True, exist_ok=False)
    start = time.monotonic()
    write_json(
        args.output / "started.json",
        {
            "epoch": time.time(),
            "sha": args.sha,
            "scenario": args.scenario,
            "budget": 190,
        },
    )
    state = {"state": "completed"}
    try:
        asyncio.run(asyncio.wait_for(run(args), timeout=160))
    except BaseException as exc:
        state = {"state": "stopped", "error": repr(exc)}
        raise
    finally:
        write_json(
            args.output / "outcome.json", {**state, "elapsed": time.monotonic() - start}
        )


if __name__ == "__main__":
    main()
