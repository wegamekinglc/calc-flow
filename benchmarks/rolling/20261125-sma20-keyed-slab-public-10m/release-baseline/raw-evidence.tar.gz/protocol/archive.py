"""Package the pre-registered public one-thread rolling SMA20 comparison."""
from __future__ import annotations
import hashlib
import io
import json
import sys
import tarfile
import zipfile
from pathlib import Path

from scripts.benchmark_suite.report import comparison, table
from scripts.toolkit import linear_percentile, sha256_file, write_json

R=Path(__file__).resolve().parent
BUILDS=R.parents[2]/"main-src"/"target"/"products"
kind=sys.argv[1]; mode=sys.argv[2]
assert kind=="sma" and mode in ("main","release")
case="sma20"
OBS=R/f"observed-{kind}-{mode}"
name=f"benchmarks/rolling/20261125-sma20-keyed-slab-public-10m"
DEST=R/"publications"/name
if mode=="release":DEST=DEST/"release-baseline"
DEST.mkdir(parents=True,exist_ok=True)
reg=R/"protocol.json"
binding=R/"candidate.json"
read=lambda p:json.loads(p.read_text())
plan=read(reg); bound=read(binding); outcome=read(OBS/"outcome.json");res=read(OBS/"result.json") if (OBS/"result.json").is_file() else None
source_sha=plan["release"]["sha"] if mode=="release" else plan["parent"]["sha"]
files={}
for p in OBS.rglob("*"):
    if p.is_file() and "site" not in p.relative_to(OBS).parts:
        files["observation/"+p.relative_to(OBS).as_posix()]=p
cn=mode+"_compare.py"
outer=R/f"elapsed-{kind}-{mode}.txt"
assert 0 < float(outer.read_text()) <= 180
files["observation/controller-wall-seconds.txt"]=outer
for p in [R/cn,R.parent/"setup_argmax.py",reg,binding,R/"archive.py",R/"wheel-binding.json",R/f"log-sma-{mode}.txt"]:
    files["protocol/"+p.name]=p
assert sha256_file(R/cn)==bound["controller_sha256"][mode]
wheels={}
for arm,dirname,sha in (("baseline","release-1114" if mode=="release" else "round8-main",source_sha),("candidate","round8-"+kind,bound["sha"])):
    loc=BUILDS/dirname;m=read(loc/"release.json");wh=loc/m["wheel"]
    assert m["git_sha"]==sha and sha256_file(wh)==m["wheel_sha256"] and m["git_clean"]
    with zipfile.ZipFile(wh) as z:
        members={p:hashlib.sha256(z.read(p)).hexdigest() for p in z.namelist() if not p.endswith("/")}
    wheels[arm]={**{k:m[k] for k in ("wheel_sha256","native_sha256","git_sha","source_sha256","cargo_lock_sha256","rustc","python")},"members":members}
    for f in ("release.json","build.json","build.log","build-driver.log"):
        files[f"builds/{arm}/{f}"]=loc/f
write_json(DEST/"wheel-identities.json",wheels)
resources=[json.loads(l) for l in (OBS/"resources.jsonl").read_text().splitlines()] if (OBS/"resources.jsonl").exists() else []
states=[v for r in resources for v in r['cores']];bad=[v for v in states if not v['suitable']]
checks=[read(p) for p in (OBS/"measurement").rglob("*.completed.json")]
child_only=[]
for p in (OBS/"measurement").rglob("worker-request-*.json"):
    if not p.with_name(p.name.replace("worker-request-","request-").replace(".json",".completed.json")).is_file():
        response=read(p).get("response") or {}
        if isinstance(response,dict) and ("warmup" in response or "seconds" in response):
            child_only.append(str(p.relative_to(OBS)))

warm=sum(c.get("operation")=="prepare" for c in checks);formal=sum(c.get("operation")=="sample" for c in checks)
charge={"controller_wall_including_interpreter_seconds":float(outer.read_text()),"worker_results_without_controller_acceptance":child_only,"intervals":len(resources),"bad_intervals":sum(not all(v['suitable'] for v in r['cores']) for r in resources),"completed_warmups":warm,"completed_formal_single_arm_samples":formal}
write_json(DEST/"result.json",{"result":res,"outcome":outcome,"resources":charge})
raw=DEST/"raw-evidence.tar.gz"
digests={}
with tarfile.open(raw,"w:gz",compresslevel=9) as tar:
    for name,p in sorted(files.items()):
        b=p.read_bytes();h=tarfile.TarInfo(name);h.size=len(b);h.mode=0o644;h.mtime=0;tar.addfile(h,io.BytesIO(b));digests[name]={"bytes":len(b),"sha256":hashlib.sha256(b).hexdigest()}
with tarfile.open(raw,"r:gz") as tar:
    assert sorted(tar.getnames())==sorted(files)
    for m in tar:
        assert tar.extractfile(m).read()==files[m.name].read_bytes()
write_json(DEST/"receipt.json",{"sha256":sha256_file(raw),"original_members":len(files),"members":digests})
lines=["# Public ten-million-row rolling SMA20", "", f"The scheduled managed single-thread SMA20 workload consumed ten batches of one million rows with 64 keys. The timed interval begins with ready source enqueue and ends with complete Arrow delivery and concatenation. Baseline {source_sha} and candidate {bound['sha']} used independent portable release wheels, the same compiler, interpreter, locked Python dependencies and thread settings. The candidate routes distinct UTF-8 keys during multi-entity rolling slab admission. [Wheel identities](wheel-identities.json)", ""]
if mode=="release":
    lines+=["This comparison tests the complete candidate product against the unmodified 11.14 release. Each native product uses its original Cargo.lock. Versions of form_urlencoded, url and libz-sys changed, and the core added a direct edge to the already-locked smallvec. The main comparison uses matching Cargo.lock.",""]
if mode=="main":
    lines += [f"The baseline is the exact registered main {plan['parent']['sha']}. The candidate's immediate parent is {bound['parent']}; the four intervening files are evidence reports. The archive records their exact paths.", ""]
if res:
    row=read(OBS/"samples.json");statistics=comparison(row)
    assert res['round_intervals']==statistics['round_intervals'] and res['verdict']==statistics['verdict']
    assert res['base_p95']==linear_percentile([s for r in row['baseline'] for s in r],0.95)
    assert warm==4 and formal==40 and not bad
    results=[c["response"].get("warmup",c["response"])["correctness"] for c in checks if c["operation"] in {"prepare","sample"}]
    assert len(results)==44 and all(v["passed"] and v["rows"]==10_000_000 and v["finite_rows"]==9_998_784 for v in results)
    lines+=[table(["Clock","Baseline","Candidate"], [["P50",f"{1000*res['base_p50']:.3f} ms",f"{1000*res['head_p50']:.3f} ms"], ["P95",f"{1000*res['base_p95']:.3f} ms",f"{1000*res['head_p95']:.3f} ms"]]),"",table(["Round","Paired median","Exact interval"],[[str(i),f"{v['median']:+.2f}%",f"[{v['low']:+.2f}%, {v['high']:+.2f}%]"] for i,v in enumerate(res['round_intervals'],1)]),"",f"The maintained verdict was **{res['verdict']}**. Two rounds each completed ten alternating AB/BA pairs after four excluded warmups. Every invocation validated all ten million ordered sequence identities and rolling means outside timing against the independent per-key NumPy oracle. The leading nineteen rows per key require missing results; each run contains 9,998,784 finite outputs and 1,216 warmup values. The largest observed absolute error was {res['largest_reported_absolute_error']:.4g}.",""]
else:
    detail=f"The stop interval recorded {bad[-1]['major_faults']} major faults, {bad[-1]['swap_pages']} swapped pages and {bad[-1]['sibling_busy']:.1f}% sibling utilization." if bad else "The stored outcome preserves the stop reason."
    lines += [f"The acquisition stopped after {warm} completed warmups and {formal} formal single-arm samples. {detail} No paired verdict was established. The original archive retains any worker-local responses completed during cancellation.",""]
lines+=[f"The Linux WSL2 host exposed 32 logical CPUs and 16 SMT groups. Each worker used one Tokio thread and one physical core, chosen during the three-second preflight. Each one-second interval checked every selected core's SMT sibling, host utilization, memory, swap and major faults. This run recorded {len(resources)} intervals and took {outcome['elapsed']:.3f} seconds within the controller and {float(outer.read_text()):.2f} seconds including interpreter startup and exit, against the 180-second limit. [Result and resources](result.json)","",f"Each independent comparison reserved 180 seconds including installation, identity qualification, each worker startup, fixture construction, full correctness verification, sampling and shutdown. Release builds were accounted separately. The [original evidence archive](raw-evidence.tar.gz) contains every recorded worker response, condition, qualification record, build manifest and build log. Its [receipt](receipt.json) includes a hash and byte count for each original file.",""]
if res:
    lines+=["To reproduce the verdict from the archive on the harness checkout, extract it at the checkout root, then run","","\u0060\u0060\u0060bash","python - <<'PY'","import json","from pathlib import Path","from scripts.benchmark_suite.report import comparison","print(comparison(json.loads(Path('observation/samples.json').read_text())))","PY","\u0060\u0060\u0060",""]
if mode=="main":lines+=["[Whole-product comparison against 11.14](release-baseline/README.md)",""]
(DEST/"README.md").write_text("\n".join(lines))
print(DEST.relative_to(R/"publications"), len(files), sha256_file(raw))
