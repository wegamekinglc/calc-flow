"""Preserve completed P3 raw bytes and source identities without native execution."""

from __future__ import annotations

import gzip
import hashlib
import io
import json
import shutil
import subprocess
import tarfile
from pathlib import Path

BASE = Path(__file__).resolve().parent
ROOT = BASE.parents[1]
SOURCE = ROOT / "target/worktrees/ta-arroyo-p3-measured"
STAGE = BASE / "archive-stage"


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def copy(path, name):
    target = STAGE / name
    target.parent.mkdir(parents=True, exist_ok=True)
    shutil.copyfile(path, target)


def main():
    STAGE.mkdir(exist_ok=False)
    for folder in (
        "acquisition",
        "acquisition-outer",
        "completed-audit",
        "review-e8b",
        "build-audit",
    ):
        for path in sorted((BASE / folder).rglob("*")):
            if path.is_file():
                copy(path, path.relative_to(BASE))
    for name in (
        "collect-p3.py",
        "test_collect_p3.py",
        "controller-review.json",
        "controller-metadata-red.log",
        "controller-metadata-green.log",
        "controller-focused-final.log",
        "controller-quiet-red.log",
        "controller-quiet-green.log",
        "controller-ruff-final.log",
        "build-preflight.json",
        "build-live.json",
        "build-terminal.json",
        "build-final-audit.json",
        "build-controller.log",
        "cache-copy.json",
        "start-release.py",
        "build-candidate.py",
        "baseline-compatibility.json",
        "preparation.json",
        "terminal-summary.json",
        "audit-acquisition.py",
        "archive-acquisition.py",
    ):
        copy(BASE / name, "controller-and-build/" + name)
    for path in sorted((BASE / "candidate-release").iterdir()):
        if path.is_file() and path.suffix != ".whl":
            copy(path, "candidate-release/" + path.name)
    baseline_receipt = (
        ROOT / "target/ta-arroyo-p2-performance/candidate-final-release/build.json"
    )
    copy(baseline_receipt, "baseline-release/build.json")
    copy(
        ROOT / "target/ta-arroyo-p2-performance/final-approval-52c5e6dc.md",
        "baseline-release/final-approval-52c5e6dc.md",
    )
    copy(
        ROOT / "target/ta-arroyo-p2-performance/collect-final.py",
        "controller-and-build/borrowed-owned-phase.py",
    )
    post = json.loads((BASE / "acquisition-outer/postseals.json").read_text())
    for name, digest in post["before"]["common_helpers"].items():
        assert sha(SOURCE / name) == digest
        copy(SOURCE / name, "common-harness/" + name)
    patch = subprocess.check_output(
        ["git", "diff", "7ac64990", "8b5c13109b3d2cfc10802e91a5bacc3fd9aa3624", "--"],
        cwd=SOURCE,
    )
    (STAGE / "candidate.patch").write_bytes(patch)
    changed = subprocess.check_output(
        ["git", "diff", "--name-only", "7ac64990", "8b5c1310", "--"],
        cwd=SOURCE,
        text=True,
    ).splitlines()
    for name in changed:
        if (SOURCE / name).is_file():
            copy(SOURCE / name, "candidate-source-delta/" + name)
    baseline_patch = subprocess.check_output(
        ["git", "diff", "cc6e33e0", "52c5e6dc", "--"], cwd=SOURCE
    )
    (STAGE / "baseline-release/main-integration.patch").write_bytes(baseline_patch)
    for name in (
        "Cargo.toml",
        "Cargo.lock",
        "rust-toolchain.toml",
        ".cargo/config.toml",
    ):
        if (SOURCE / name).is_file():
            copy(SOURCE / name, "source-provenance/" + name)
    manifest = {
        "schema": "calc-flow.p3-performance-archive.v1",
        "candidate_source": "8b5c13109b3d2cfc10802e91a5bacc3fd9aa3624",
        "candidate_tree": "4e56b71ff6d9d13ddcf6b838174132acc4ae8dbd",
        "baseline_actual_source": "cc6e33e00acd6a8f1feba7a7776f208c29e71638",
        "baseline_not_relabelled": True,
        "cases": 3,
        "pairs_per_case": 30,
        "arm_samples": 180,
        "native_probes_or_retries": 0,
        "byte_policy": "Raw reports, stdout/stderr, receipts, source/controller/helper texts, Cargo JSON and pre/post seals are copied byte-for-byte. samples.csv is a new LF view. No original raw CSV was normalized or replaced.",
        "not_embedded": "Wheel/native/Cargo cache bytes remain under target with exact hashes in original build receipts; no source native .so was generated. Unit allocation evidence is separate from sampled process RSS; timed wheels expose no actual shared-tape byte/credit/fallback counter.",
        "files": {
            str(path.relative_to(STAGE)): {
                "sha256": sha(path),
                "bytes": path.stat().st_size,
            }
            for path in sorted(STAGE.rglob("*"))
            if path.is_file()
        },
    }
    (STAGE / "manifest.json").write_text(
        json.dumps(manifest, indent=2, sort_keys=True) + "\n"
    )
    archive = BASE / "p3-20261108-raw.tar.gz"
    with archive.open("xb") as stream:
        with gzip.GzipFile(filename="", mode="wb", fileobj=stream, mtime=0) as zipped:
            with tarfile.open(fileobj=zipped, mode="w|") as tar:
                for path in sorted(STAGE.rglob("*")):
                    if path.is_file():
                        content = path.read_bytes()
                        info = tarfile.TarInfo(str(path.relative_to(STAGE)))
                        info.mode, info.mtime, info.size = 0o644, 0, len(content)
                        tar.addfile(info, io.BytesIO(content))
    with tarfile.open(archive, "r:gz") as tar:
        assert json.loads(tar.extractfile("manifest.json").read()) == manifest
        for name, values in manifest["files"].items():
            data = tar.extractfile(name).read()
            assert (
                len(data) == values["bytes"]
                and hashlib.sha256(data).hexdigest() == values["sha256"]
            )
    digest = {
        "original_target_name": archive.name,
        "published_name": "raw.tar.gz",
        "sha256": sha(archive),
        "bytes": archive.stat().st_size,
        "git_blob_sha1": subprocess.check_output(
            ["git", "hash-object", str(archive)], text=True
        ).strip(),
        "manifest_sha256": sha(STAGE / "manifest.json"),
        "manifest_file_count": len(manifest["files"]),
        "every_archive_member_revalidated": True,
    }
    (BASE / "archive-digest.json").write_text(
        json.dumps(digest, indent=2, sort_keys=True) + "\n"
    )
    print(json.dumps(digest, indent=2))


if __name__ == "__main__":
    main()
