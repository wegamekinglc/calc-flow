"""One frozen P3 three-case acquisition; no build, probe or retry."""

from __future__ import annotations

import argparse
import asyncio
import hashlib
import importlib.util
import json
import os
import signal
import subprocess
import sys
import time
from contextlib import suppress
from pathlib import Path

BOOT_STARTED = time.monotonic()

ROOT = Path(__file__).resolve().parents[2]
BASE = Path(__file__).resolve().parent
SOURCE = ROOT / "target/worktrees/ta-arroyo-p3-measured"
BASELINE = ROOT / "target/ta-arroyo-p2-performance/candidate-final-release/build.json"
CANDIDATE = BASE / "candidate-release/build.json"
EXPECTED = "8b5c13109b3d2cfc10802e91a5bacc3fd9aa3624"
BORROWED = ROOT / "target/ta-arroyo-p2-performance/collect-final.py"
BORROWED_SHA = "0258656e7514e565cb41109ba523e1bae241dbaa139bfa0ee9db5d82830e1583"
PHASE_SECONDS = 600.0
CLEANUP_SECONDS = 70.0
PYTHON = ROOT / ".venv/bin/python"
OUTPUT = BASE / "acquisition"
AUDIT = BASE / "acquisition-outer"


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def write(path, value):
    path.write_text(json.dumps(value, indent=2, allow_nan=False) + "\n")


def require(condition, message):
    if not condition:
        raise ValueError(message)


def initialize():
    global profile, generic, psutil, ownership, harness_identity
    sys.path.insert(0, str(SOURCE))
    import psutil

    from scripts import profile_warm_stream as profile
    from scripts.benchmark_suite import sum_state as generic
    from scripts.release_performance import harness_identity

    require(sha(BORROWED) == BORROWED_SHA, "reviewed ownership helper drift")
    spec = importlib.util.spec_from_file_location("p3_owned_phase", BORROWED)
    ownership = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(ownership)
    ownership.PHASE_SECONDS = PHASE_SECONDS
    ownership.CLEANUP_SECONDS = CLEANUP_SECONDS


def fixed_config(indicator, *, large=False):
    return {
        "history_rows": 600000 if large else 1000,
        "append_rows": 1000 if large else 1024,
        "append_entities": 1000 if large else 1,
        "entities": 10000 if large else 1,
        "window": 60,
        "fast_window": 20,
        "history_segment_rows": 1000,
        "indicator": indicator,
    }


def expected_configs():
    return [
        fixed_config("dual_sma_spread"),
        fixed_config("rolling_mean"),
        fixed_config("dual_sma_spread", large=True),
    ]


def validate_complete(reports, resources):
    cases = [case for report in reports for case in report["cases"]]
    require(len(cases) == 3, "exactly three cases required")
    wanted = sorted(json.dumps(config, sort_keys=True) for config in expected_configs())
    actual = sorted(json.dumps(case["config"], sort_keys=True) for case in cases)
    require(actual == wanted, "fixed case selection differs or contains duplicates")
    return cases


def commands():
    common = [
        "/usr/bin/taskset",
        "-c",
        "0,2",
        str(PYTHON),
        "-m",
        "scripts.profile_warm_stream",
        "compare",
        "--baseline-build",
        str(BASELINE),
        "--candidate-build",
        str(CANDIDATE),
        "--samples",
        "30",
        "--seed",
        "20260905",
        "--gc-modes",
        "normal",
        "--window",
        "60",
        "--fast-window",
        "20",
        "--history-segment-rows",
        "1000",
    ]
    return [
        common
        + [
            "--output",
            str(OUTPUT / "t1-c1.json"),
            "--history-rows",
            "1000",
            "--append-rows",
            "1024",
            "--append-entities",
            "1",
            "--entities",
            "1",
            "--indicators",
            "dual_sma_spread",
            "rolling_mean",
        ],
        common
        + [
            "--output",
            str(OUTPUT / "t2.json"),
            "--history-rows",
            "600000",
            "--append-rows",
            "1000",
            "--append-entities",
            "1000",
            "--entities",
            "10000",
            "--indicators",
            "dual_sma_spread",
        ],
    ]


def matrix_preflight():
    cases = []
    for large, indicators in (
        (False, ["dual_sma_spread", "rolling_mean"]),
        (True, ["dual_sma_spread"]),
    ):
        config = fixed_config(indicators[0], large=large)
        args = argparse.Namespace(
            history_rows=[config["history_rows"]],
            append_rows=[config["append_rows"]],
            append_entities=[config["append_entities"]],
            indicators=indicators,
            gc_modes=["normal"],
            entities=config["entities"],
            window=60,
            fast_window=20,
            history_segment_rows=1000,
            seed=20260905,
        )
        cases.extend(profile.matrix_cases(args))
    return cases


def require_deadline(deadline, label):
    if time.monotonic() > deadline:
        raise TimeoutError(f"absolute {label} deadline exceeded")


def require_postseals(before, after, deadline):
    require(before == after, "source/build/native/full-helper postseal drift")
    require_deadline(deadline, "postseal")


def tracked_files(source):
    names = (
        subprocess.check_output(
            ["git", "ls-files", "-z", "--", *profile.SOURCE_PATHS, "vendor", ".cargo"],
            cwd=source,
        )
        .decode()
        .split("\0")
    )
    return {name: sha(source / name) for name in sorted(set(names) - {""})}


async def seals():
    manifests = await profile._compatible_builds((BASELINE, CANDIDATE))
    source = await profile.source_identity(SOURCE)
    helpers = {
        **harness_identity(),
        **profile._new_report([], [], 30)["harness_sha256"],
    }
    return {
        "source_identity": source,
        "builds": manifests,
        "source_files": {
            m["source"]: tracked_files(Path(m["source"])) for m in manifests
        },
        "common_helpers": helpers,
        "build_receipt_hashes": {str(p): sha(p) for p in (BASELINE, CANDIDATE)},
        "controller": sha(Path(__file__)),
        "ownership": sha(BORROWED),
        "baseline_equivalence_proof": sha(BASE / "baseline-compatibility.json"),
        "baseline_final_approval": sha(
            ROOT / "target/ta-arroyo-p2-performance/final-approval-52c5e6dc.md"
        ),
        "taskset": sha(Path("/usr/bin/taskset")),
        "thread_environment": {key: os.environ.get(key) for key in generic.THREAD_ENV},
    }


def measurement_roots():
    baseline = json.loads(BASELINE.read_text())
    return (
        SOURCE,
        Path(baseline["source"]),
        BASE,
        Path(baseline["wheel"]).parent,
        ROOT / "target/ta-arroyo-p2-performance/candidate-final-cargo",
        PYTHON.parent.parent,
    )


def warm_measurement(process, roots):
    argv = process.info["cmdline"] or []
    if any(
        value in ("scripts.profile_warm_stream", "scripts.benchmark_suite.decay_warm")
        or value.replace("\\", "/").split("/")[-1]
        in ("profile_warm_stream.py", "decay_warm.py")
        or "pytest" in value
        for value in argv
    ):
        return True
    if "_worker" not in argv:
        return False
    environment = process.environ()
    paths = [process.cwd(), argv[0], environment.get("VIRTUAL_ENV", "")]
    paths.extend(environment.get("PYTHONPATH", "").split(os.pathsep))
    return any(
        value
        and Path(value).is_absolute()
        and any(Path(value).is_relative_to(root) for root in roots)
        for value in paths
    )


def quiet_guard(exclude=()):
    excluded = {os.getpid(), *exclude}
    roots = measurement_roots()
    bad = []
    for process in psutil.process_iter(["pid", "name", "cmdline", "status", "exe"]):
        if process.pid in excluded:
            continue
        try:
            if any(parent.pid in excluded for parent in process.parents()):
                continue
            measuring = warm_measurement(process, roots)
            compiling = process.info["name"] in (
                "cc1",
                "cc1plus",
                "clang",
                "clang++",
                "g++",
            )
            if generic.competing_process(process, roots) or measuring or compiling:
                bad.append(process.info)
        except psutil.Error:
            continue
    require(not bad, f"competing compiler/measurement: {bad}")


def sample_resources(process, workers):
    peak = generic.process_tree_rss(process)
    try:
        descendants = psutil.Process(process.pid).children(recursive=True)
    except psutil.NoSuchProcess:
        descendants = []
    for child in descendants:
        try:
            argv = child.cmdline()
            if "scripts.profile_warm_stream" not in argv or "_worker" not in argv:
                continue
            record = workers.setdefault(
                str(child.pid),
                {
                    "pid": child.pid,
                    "created": child.create_time(),
                    "sample_count": 0,
                    "sampled_process_tree_peak_rss": None,
                    "last_sampled_process_cpu_seconds": None,
                },
            )
            rss = generic.process_tree_rss(child)
            if rss <= 0:
                continue
            record["sample_count"] += 1
            record["sampled_process_tree_peak_rss"] = max(
                record["sampled_process_tree_peak_rss"] or 0, rss
            )
            cpu = child.cpu_times()
            record["last_sampled_process_cpu_seconds"] = cpu.user + cpu.system
        except psutil.Error:
            continue
    return peak


async def invoke(command, index, acquire):
    directory = OUTPUT / f"command-{index}"
    directory.mkdir(exist_ok=False)
    write(
        directory / "command.json",
        {
            "argv": command,
            "cwd": str(SOURCE),
            "environment": {k: os.environ.get(k) for k in generic.THREAD_ENV},
        },
    )
    process, error, cleanup_error, peak = None, None, None, None
    resources = {}
    started = time.monotonic()
    try:
        with (
            (directory / "stdout.log").open("wb") as stdout,
            (directory / "stderr.log").open("wb") as stderr,
        ):
            process = generic.start_invocation(
                command, dict(os.environ), stdout, stderr
            )
            while process.poll() is None:
                require_deadline(acquire, "acquisition")
                peak = max(peak or 0, sample_resources(process, resources))
                quiet_guard([process.pid])
                await asyncio.sleep(min(0.02, max(0, acquire - time.monotonic())))
            require_deadline(acquire, "acquisition after normal process return")
            require(
                process.returncode == 0,
                f"compare command {index} exited {process.returncode}",
            )
    except BaseException as caught:
        error = repr(caught)
        if process is not None and process.poll() is None:
            with suppress(ProcessLookupError):
                process.send_signal(signal.SIGINT)
            # Existing compare finally owns both worker closes; outer owns the hard cap.
            while (
                process.poll() is None
                and time.monotonic() < acquire + CLEANUP_SECONDS - 5
            ):
                await asyncio.sleep(0.02)
        raise
    finally:
        try:
            generic.settle_invocation(process)
        except BaseException as caught:
            cleanup_error = repr(caught)
            if error is None:
                raise
        finally:
            write(
                directory / "receipt.json",
                {
                    "pid": process.pid if process else None,
                    "exit_code": process.returncode if process else None,
                    "reaped": process is not None and process.returncode is not None,
                    "wall_seconds": time.monotonic() - started,
                    "sampled_process_tree_peak_rss": peak,
                    "worker_resources": resources,
                    "rss_poll_seconds": 0.02,
                    "resource_note": (
                        "Sampled peaks can miss short allocations; CPU is last "
                        "sampled process CPU, not an exact complete-lifetime total."
                    ),
                    "error": error,
                    "cleanup_error": cleanup_error,
                },
            )
    return resources


def validate_worker_resources(cases, resources):
    seen = []
    for case in cases:
        profile._require_worker_receipts(case["worker_receipts"])
        for receipt in case["worker_receipts"]:
            pid = receipt["pid"]
            require(pid not in seen, "duplicate worker PID across cases")
            seen.append(pid)
            record = resources.get(str(pid))
            require(
                record is not None and record["sample_count"] > 0,
                "worker RSS unmeasured",
            )
            require(
                record["sampled_process_tree_peak_rss"] > 0, "worker RSS unavailable"
            )
    require(
        len(seen) == 6 and set(map(str, seen)) == set(resources),
        "exactly six normal sampled workers required",
    )


def validate_results(reports, resources):
    cases = validate_complete(reports, resources)
    for report in reports:
        require(
            report["contract"] == "paired-warm-stream-v1"
            and report["sample_pairs"] == 30,
            "warm contract or sample count drift",
        )
        require(
            report["callback_profiling"] is False and report["worker_threads"] is None,
            "profiling/scheduler mode changed",
        )
        require(report["comparison_kind"] == "engine", "engine comparison required")
        for environment in report["environments"]:
            require(
                environment["cpu_affinity"] == [0, 2]
                and environment["tokio_worker_threads"] == "4",
                "fixed affinity/Tokio policy changed",
            )
    require(
        reports[0]["environments"] == reports[1]["environments"],
        "cross-command worker environment drift",
    )
    for case in cases:
        config = case["config"]
        require(case["collect_gc"] is False, "normal GC required")
        profile._validate_starts(case["start"], config)
        expected = {
            "engine": "streaming",
            "numerical_profile": "stable_v1",
            "windows": [20, 60] if config["indicator"] == "dual_sma_spread" else [60],
            "min_periods": 1,
            "datafusion": {
                "batch_size": 8192,
                "target_partitions": 1,
                "parallelism_mode": "fixed",
                "enable_rolling_rewrite": True,
            },
        }
        require(
            case["start"][0]["plan_identity"]["preflight"] == expected,
            "actual lowered plan policy changed",
        )
        require(
            len(case["samples"]) == 2
            and all(len(side) == 30 for side in case["samples"]),
            "all 30 pairs required",
        )
        for index, pair in enumerate(zip(*case["samples"], strict=True)):
            for sample in pair:
                profile._validate_sample(
                    sample, config["history_rows"] + index * config["append_rows"]
                )
            profile._validate_pair_digest(
                pair[0]["correctness"]["float64_digest"],
                pair[1]["correctness"]["float64_digest"],
                config,
                "sample",
            )
        require(
            len(case["terminal"]) == 2
            and all(t["state"] == "completed" for t in case["terminal"]),
            "native lifecycle incomplete",
        )
        for key, value in profile._case_summary(
            case["samples"], config["append_rows"]
        ).items():
            require(case[key] == value, f"maintained statistic mismatch: {key}")
    validate_worker_resources(cases, resources)
    return cases


async def child():
    protocol = json.loads((AUDIT / "protocol.json").read_text())
    acquire, deadline = (
        protocol["acquire_deadline_monotonic"],
        protocol["total_deadline_monotonic"],
    )
    before = await seals()
    require(
        before["source_identity"]["git_sha"] == EXPECTED
        and before["source_identity"]["git_clean"],
        "frozen candidate source drift",
    )
    require(
        before["builds"][1]["source"] == str(SOURCE)
        and before["builds"][1]["git_sha"] == EXPECTED,
        "wrong candidate build",
    )
    require(
        before["builds"][0]["git_sha"] == "cc6e33e00acd6a8f1feba7a7776f208c29e71638",
        "wrong baseline build",
    )
    quiet_guard()
    matrix = matrix_preflight()
    validate_complete(
        [
            {
                "cases": [
                    {"config": config} for config, mode in matrix if mode == "normal"
                ]
            }
        ],
        {},
    )
    require(len(matrix) == 3, "matrix introduced extra workloads")
    require({0, 2}.issubset(os.sched_getaffinity(0)), "fixed CPUs unavailable")
    write(
        AUDIT / "preflight.json",
        {
            "seals": before,
            "matrix": matrix,
            "available_memory_bytes": psutil.virtual_memory().available,
            "load_average": os.getloadavg(),
            "affinity": sorted(os.sched_getaffinity(0)),
        },
    )
    require_deadline(acquire, "setup")
    OUTPUT.mkdir(exist_ok=False)
    resources = {}
    for index, command in enumerate(commands(), 1):
        quiet_guard()
        resources.update(await invoke(command, index, acquire))
    reports = [
        json.loads((OUTPUT / name).read_text()) for name in ("t1-c1.json", "t2.json")
    ]
    validate_results(reports, resources)
    write(OUTPUT / "worker-resources.json", resources)
    after = await seals()
    require_postseals(before, after, deadline)
    write(
        AUDIT / "postseals.json",
        {
            "before": before,
            "after": after,
            "passed": True,
            "completed_monotonic": time.monotonic(),
            "deadline_monotonic": deadline,
        },
    )


def main():
    initialize()
    fixed = generic.environment(4)
    os.environ.update({key: fixed[key] for key in generic.THREAD_ENV})
    if sys.argv[1:] == ["--child"]:
        asyncio.run(child())
        return
    started = BOOT_STARTED
    require(not OUTPUT.exists(), "acquisition output already exists")
    AUDIT.mkdir(exist_ok=False)
    requested = {}
    for number in (signal.SIGINT, signal.SIGTERM):
        signal.signal(
            number,
            lambda value, _frame: requested.setdefault(
                "reason", f"parent signal {value}"
            ),
        )
    command = [str(PYTHON), str(Path(__file__).resolve()), "--child"]
    write(
        AUDIT / "protocol.json",
        {
            "started_monotonic": started,
            "phase_seconds": PHASE_SECONDS,
            "cleanup_seconds": CLEANUP_SECONDS,
            "acquire_deadline_monotonic": started + 530,
            "total_deadline_monotonic": started + 600,
            "commands": commands(),
            "cases": expected_configs(),
            "samples_per_case": 30,
            "compare_commands": 2,
            "workloads": 3,
            "controller_sha256": sha(Path(__file__)),
            "borrowed_ownership_sha256": sha(BORROWED),
        },
    )
    require_deadline(started + 530, "initialization")
    with (AUDIT / "console.log").open("wb") as log:
        process = subprocess.Popen(
            command,
            cwd=SOURCE,
            stdout=log,
            stderr=subprocess.STDOUT,
            start_new_session=True,
        )
        tracked = {}
        try:
            result = ownership.monitor(process, started, AUDIT, requested, tracked)
        except BaseException as error:
            result = {
                **ownership.settle_after_error(process, started, tracked),
                "error": repr(error),
                "accepted_outer_completion": False,
            }
    if result["accepted_outer_completion"]:
        try:
            require(
                json.loads((AUDIT / "postseals.json").read_text())["passed"],
                "postseals missing",
            )
            require_deadline(started + 600, "final acceptance")
        except Exception as error:
            result.update(accepted_outer_completion=False, error=repr(error))
    result["elapsed_seconds"] = time.monotonic() - started
    write(AUDIT / "receipt.json", result)
    if time.monotonic() > started + PHASE_SECONDS:
        result.update(
            accepted_outer_completion=False,
            error="absolute deadline during terminal receipt write",
        )
        write(AUDIT / "receipt.json", result)
    print(json.dumps(result), flush=True)
    raise SystemExit(0 if result["accepted_outer_completion"] else 1)


if __name__ == "__main__":
    main()
