"""Own only the final P2 four-case process group under its remaining budget."""

from __future__ import annotations

import asyncio
import hashlib
import json
import os
import signal
import subprocess
import sys
import time
from contextlib import suppress
from pathlib import Path

import psutil

ROOT = Path(__file__).resolve().parents[2]
PHASE_SECONDS = 574.654709
CLEANUP_SECONDS = 70.0
PYTHON = ROOT / ".venv/bin/python"
BASELINE = (
    ROOT / "target/weekly-review-20261107/pr556-repair/candidate-v2-release/build.json"
)


def write(path, value):
    path.write_text(json.dumps(value, indent=2) + "\n")


def owned(group, tracked):
    try:
        descendants = psutil.Process(group).children(recursive=True)
    except psutil.NoSuchProcess:
        descendants = []
    for process in descendants:
        try:
            tracked[process.pid] = process.create_time()
        except psutil.NoSuchProcess:
            continue
    for process in psutil.process_iter(["pid", "create_time"]):
        try:
            if os.getpgid(process.pid) == group:
                tracked[process.pid] = process.info["create_time"]
        except (ProcessLookupError, psutil.NoSuchProcess):
            continue
    remaining = []
    for pid, created in tracked.items():
        try:
            process = psutil.Process(pid)
            if process.create_time() == created:
                remaining.append({"pid": pid, "status": process.status()})
        except psutil.NoSuchProcess:
            continue
    return remaining


def signal_tree(group, tracked, number):
    with suppress(ProcessLookupError):
        os.killpg(group, number)
    for item in owned(group, tracked):
        try:
            if os.getpgid(item["pid"]) != group:
                os.kill(item["pid"], number)
        except ProcessLookupError:
            continue


def monitor(process, started, audit, requested, tracked):
    total = started + PHASE_SECONDS
    acquire = total - CLEANUP_SECONDS
    events = []
    sent = set()
    reason = None
    remaining = []
    while True:
        code = process.poll()
        remaining = owned(process.pid, tracked)
        now = time.monotonic()
        if code is not None and not remaining:
            break
        reason = reason or requested.get("reason")
        if code is not None and remaining:
            reason = reason or "owned descendants remained after collector exit"
        if now >= acquire:
            reason = reason or "acquisition cap"
        if reason and "cancel" not in sent:
            if code is None:
                with suppress(ProcessLookupError):
                    process.send_signal(signal.SIGINT)
            events.append(
                {
                    "action": "cancel collector",
                    "at_seconds": now - started,
                    "reason": reason,
                }
            )
            sent.add("cancel")
        if code is not None and remaining and "terminate" not in sent:
            signal_tree(process.pid, tracked, signal.SIGTERM)
            events.append(
                {"action": "terminate orphaned owned tree", "at_seconds": now - started}
            )
            sent.add("terminate")
        if now >= total - 5 and "terminate" not in sent:
            signal_tree(process.pid, tracked, signal.SIGTERM)
            events.append(
                {"action": "terminate owned tree", "at_seconds": now - started}
            )
            sent.add("terminate")
        if now >= total - 3 and "kill" not in sent:
            signal_tree(process.pid, tracked, signal.SIGKILL)
            events.append({"action": "kill owned tree", "at_seconds": now - started})
            sent.add("kill")
        if now >= total:
            break
        write(
            audit / "live.json",
            {"collector_pid": process.pid, "owned": remaining, "events": events},
        )
        boundaries = [total]
        if "cancel" not in sent:
            boundaries.append(acquire)
        if "terminate" not in sent:
            boundaries.append(total - 5)
        if "kill" not in sent:
            boundaries.append(total - 3)
        time.sleep(max(0, min(0.1, min(boundaries) - time.monotonic())))
    code = process.poll()
    remaining = owned(process.pid, tracked)
    elapsed = time.monotonic() - started
    return {
        "collector_pid": process.pid,
        "exit_code": code,
        "collector_reaped": code is not None,
        "remaining_owned": remaining,
        "observed_owned_pids": sorted(tracked),
        "cancel_reason": reason,
        "events": events,
        "elapsed_seconds": elapsed,
        "accepted_outer_completion": code == 0
        and not remaining
        and reason is None
        and elapsed <= PHASE_SECONDS,
    }


def settle_after_error(process, started, tracked):
    deadline = started + PHASE_SECONDS
    failures = []
    while True:
        try:
            signal_tree(process.pid, tracked, signal.SIGKILL)
        except OSError as error:
            failures.append(repr(error))
        code = process.poll()
        remaining = owned(process.pid, tracked)
        now = time.monotonic()
        if (code is not None and not remaining) or now >= deadline:
            return {
                "exit_code": code,
                "collector_reaped": code is not None,
                "remaining_owned": remaining,
                "cleanup_signal_errors": failures,
                "cleanup_deadline_monotonic": deadline,
                "elapsed_seconds": now - started,
            }
        time.sleep(min(0.1, deadline - now))


async def seal_snapshot(source, candidate):
    from scripts import profile_warm_stream as profile
    from scripts.release_performance import harness_identity

    helpers = {
        **harness_identity(),
        **profile._new_report([], [], 30)["harness_sha256"],
    }
    return {
        "source_identity": await profile.source_identity(source),
        "builds": await profile._compatible_builds((BASELINE, candidate)),
        "common_helpers": helpers,
        "build_receipt_hashes": {
            str(path): hashlib.sha256(path.read_bytes()).hexdigest()
            for path in (BASELINE, candidate)
        },
    }


def require_postseals(before, after, deadline):
    if before != after:
        raise ValueError("source/build/native/common-helper postseals changed")
    if time.monotonic() > deadline:
        raise TimeoutError("absolute phase deadline exceeded during postseals")


async def child(source, candidate, output, expected, audit):
    sys.path.insert(0, str(source))

    before = await seal_snapshot(source, candidate)
    identity = before["source_identity"]
    if identity["git_sha"] != expected or identity["git_clean"] is not True:
        raise ValueError("final source is not the locked clean revision")
    builds = before["builds"]
    if Path(builds[1]["source"]) != source or builds[1]["git_sha"] != expected:
        raise ValueError("candidate receipt does not identify final source")
    competing = []
    for process in psutil.process_iter(["pid", "name", "cmdline"]):
        name, argv = process.info["name"], process.info["cmdline"] or []
        compiler = name in {
            "cargo",
            "rustc",
            "maturin",
            "cc1plus",
            "cc1",
            "clang",
            "clang++",
            "g++",
        }
        measuring = name.startswith("python") and any(
            "pytest" in arg
            or "scripts.benchmark_suite." in arg
            or "scripts.profile_warm_stream" in arg
            for arg in argv
        )
        if compiler or measuring:
            competing.append(process.info)
    write(
        audit / "preflight.json",
        {
            "source_identity": identity,
            "builds": builds,
            "seals": before,
            "competing": competing,
            "available_memory_bytes": psutil.virtual_memory().available,
            "load_average": os.getloadavg(),
            "affinity": psutil.Process().cpu_affinity(),
        },
    )
    if competing:
        raise ValueError("competing compiler or benchmark at final preflight")
    argv = [
        str(PYTHON),
        "-m",
        "scripts.benchmark_suite.decay_warm",
        "--baseline-build",
        str(BASELINE),
        "--candidate-build",
        str(candidate),
        "--output",
        str(output),
        "--budget-seconds",
        str(PHASE_SECONDS),
    ]
    from scripts.benchmark_suite.process import _complete_owned

    collector = await asyncio.create_subprocess_exec(*argv, cwd=source)
    try:
        code = await collector.wait()
    except BaseException:
        with suppress(ProcessLookupError):
            collector.send_signal(signal.SIGINT)
        await _complete_owned(asyncio.create_task(collector.wait()))
        raise
    if code:
        raise RuntimeError(f"final collector exited {code}")
    deadline = json.loads((audit / "protocol.json").read_text())[
        "total_deadline_monotonic"
    ]
    after = await seal_snapshot(source, candidate)
    record = {
        "before": before,
        "after": after,
        "completed_monotonic": time.monotonic(),
        "deadline_monotonic": deadline,
        "passed": False,
    }
    try:
        require_postseals(before, after, deadline)
    except BaseException as error:
        record["error"] = repr(error)
        write(audit / "postseals.json", record)
        raise
    record["passed"] = True
    write(audit / "postseals.json", record)


def main():
    child_mode = sys.argv[1] == "--child"
    values = sys.argv[2:] if child_mode else sys.argv[1:]
    source, candidate, output = (Path(value).resolve() for value in values[:3])
    expected = values[3]
    audit = output.parent / f"{output.name}-outer"
    if child_mode:
        asyncio.run(child(source, candidate, output, expected, audit))
        return
    started = time.monotonic()
    if output.exists():
        raise ValueError("final collection output already exists")
    audit.mkdir(parents=True, exist_ok=False)
    requested = {}
    for number in (signal.SIGINT, signal.SIGTERM):
        signal.signal(
            number,
            lambda value, _frame: requested.setdefault(
                "reason", f"parent signal {value}"
            ),
        )
    argv = [
        str(PYTHON),
        str(Path(__file__).resolve()),
        "--child",
        str(source),
        str(candidate),
        str(output),
        expected,
    ]
    write(
        audit / "protocol.json",
        {
            "phase_seconds": PHASE_SECONDS,
            "acquisition_seconds": PHASE_SECONDS - CLEANUP_SECONDS,
            "cleanup_seconds": CLEANUP_SECONDS,
            "started_monotonic": started,
            "acquire_deadline_monotonic": started + PHASE_SECONDS - CLEANUP_SECONDS,
            "total_deadline_monotonic": started + PHASE_SECONDS,
            "outer_is_authoritative_cap": True,
            "adapter_is_secondary_timer": True,
            "argv": argv,
            "controller_sha256": hashlib.sha256(
                Path(__file__).read_bytes()
            ).hexdigest(),
        },
    )
    with (audit / "console.log").open("wb") as log:
        process = subprocess.Popen(
            argv, stdout=log, stderr=subprocess.STDOUT, start_new_session=True
        )
        tracked = {}
        try:
            result = monitor(process, started, audit, requested, tracked)
        except BaseException as error:
            result = {
                **settle_after_error(process, started, tracked),
                "error": repr(error),
                "collector_pid": process.pid,
                "observed_owned_pids": sorted(tracked),
                "accepted_outer_completion": False,
            }
    if result["accepted_outer_completion"]:
        try:
            postseals = json.loads((audit / "postseals.json").read_text())
            if postseals.get("passed") is not True:
                raise ValueError("successful outer completion requires postseals")
            if time.monotonic() > started + PHASE_SECONDS:
                raise TimeoutError("absolute phase deadline exceeded before acceptance")
            result["postseals_verified_inside_phase"] = True
        except Exception as error:
            result["accepted_outer_completion"] = False
            result["error"] = repr(error)
    result["elapsed_seconds"] = time.monotonic() - started
    write(audit / "receipt.json", result)
    print(json.dumps(result), flush=True)
    raise SystemExit(0 if result["accepted_outer_completion"] else 1)


if __name__ == "__main__":
    main()
