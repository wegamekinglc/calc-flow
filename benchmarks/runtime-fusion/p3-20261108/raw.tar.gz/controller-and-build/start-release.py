from pathlib import Path
import json,os,subprocess,sys,time
base=Path(__file__).resolve().parent
root=base.parents[1]
source=root/"target/worktrees/ta-arroyo-p3-measured"
started=time.monotonic()
(base/"build-live.json").write_text(json.dumps({"owner_pid":os.getpid(),"started_monotonic":started,"stage":"copy-quiescent-cache"},indent=2)+"\n")
subprocess.run(["cp","--reflink=auto","-a",str(root/"target/ta-arroyo-p2-performance/candidate-final-cargo"),str(base/"candidate-cargo")],check=True)
(base/"cache-copy.json").write_text(json.dumps({"source":str(root/"target/ta-arroyo-p2-performance/candidate-final-cargo"),"destination":str(base/"candidate-cargo"),"source_quiescent_verified":True,"copy_seconds":time.monotonic()-started},indent=2)+"\n")
env={**os.environ,"CARGO":str(base/"build-audit/cargo-audit-launcher"),"CARGO_TARGET_DIR":str(base/"candidate-cargo"),"CARGO_BUILD_JOBS":"2","CARGO_INCREMENTAL":"0"}
cmd=[sys.executable,str(base/"build-candidate.py"),str(source)]
allow=("CARGO","CARGO_TARGET_DIR","CARGO_BUILD_JOBS","CARGO_INCREMENTAL","RUSTFLAGS","CARGO_ENCODED_RUSTFLAGS","RUSTUP_TOOLCHAIN","CARGO_PROFILE_RELEASE_LTO","CARGO_PROFILE_RELEASE_OPT_LEVEL","CARGO_PROFILE_RELEASE_CODEGEN_UNITS","CARGO_PROFILE_RELEASE_DEBUG","PYO3_PYTHON")
record={"owner_pid":os.getpid(),"stage":"maintained-wheel-builder","argv":cmd,"environment":{k:env.get(k) for k in allow},"started_monotonic":time.monotonic()}
(base/"build-live.json").write_text(json.dumps(record,indent=2)+"\n")
with (base/"build-controller.log").open("wb") as log:
 p=subprocess.Popen(cmd,env=env,stdout=log,stderr=subprocess.STDOUT)
 record["builder_pid"]=p.pid
 (base/"build-live.json").write_text(json.dumps(record,indent=2)+"\n")
 code=p.wait()
record["exit_code"]=code
record["build_seconds"]=time.monotonic()-record["started_monotonic"]
(base/"build-terminal.json").write_text(json.dumps(record,indent=2)+"\n")
print(json.dumps(record),flush=True)
raise SystemExit(code)
