"""Run the maintained warm-wheel builder and audit its real Cargo artifacts."""
from __future__ import annotations
import argparse
import asyncio
import hashlib
import json
import os
from pathlib import Path
import sys
import time

source = Path(sys.argv[1]).resolve()
root = Path(__file__).resolve().parent
output = root / "candidate-release"
sys.path.insert(0, str(source))
from scripts import profile_warm_stream as profile

output.mkdir(exist_ok=False)
record = {"source": str(source), "pid": os.getpid(),
          "started_monotonic": time.monotonic(),
          "builds_separate_from_measurement": True,
          "environment": {name: os.environ.get(name) for name in
             ("CARGO", "CARGO_TARGET_DIR", "CARGO_BUILD_JOBS", "CARGO_INCREMENTAL", "RUSTFLAGS")}}
try:
    asyncio.run(profile.build(argparse.Namespace(
        source=source, target=root / "candidate-cargo", output=output)))
    artifact_files = []
    product = {}
    for path in sorted((root / "build-audit" / "cargo-audit").glob("*.stdout")):
        for line in path.read_text().splitlines():
            try:
                event = json.loads(line)
            except ValueError:
                continue
            if event.get("reason") != "compiler-artifact":
                continue
            name = event["target"]["name"]
            if name in ("calc_flow", "calc_flow_python"):
                product.setdefault(name, []).append(event)
                artifact_files.append(str(path))
    record["compiler_artifact_files"] = sorted(set(artifact_files))
    record["core_and_binding_artifacts"] = product
    for name in ("calc_flow", "calc_flow_python"):
        if not any(event.get("fresh") is False for event in product.get(name, [])):
            raise RuntimeError(f"no real fresh=false compiler artifact for {name}")
    manifest = asyncio.run(profile._load_build(output / "build.json"))
    if manifest["git_clean"] is not True:
        raise RuntimeError("candidate source was not clean")
    record["wheel_sha256"] = manifest["wheel_sha256"]
    record["native_sha256"] = manifest["native_sha256"]
    record["build_receipt_sha256"] = hashlib.sha256((output / "build.json").read_bytes()).hexdigest()
    record["outcome"] = "success"
except BaseException as error:
    record["outcome"] = "failure"
    record["error"] = repr(error)
    raise
finally:
    record["elapsed_seconds"] = time.monotonic() - record["started_monotonic"]
    (output / "outer-build.json").write_text(json.dumps(record, indent=2) + "\n")
