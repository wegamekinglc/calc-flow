"""Verify existing P3 evidence and write descriptive views; no native execution."""

from __future__ import annotations

import asyncio
import csv
import hashlib
import importlib.util
import json
import subprocess
from pathlib import Path

BASE = Path(__file__).resolve().parent
ROOT = BASE.parents[1]
AUDIT = BASE / "completed-audit"


def load(path):
    return json.loads(path.read_text())


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def save(name, value):
    (AUDIT / name).write_text(json.dumps(value, indent=2, sort_keys=True) + "\n")


def case_id(config):
    if config["entities"] == 10000:
        return "P3-T2"
    return "P3-C1" if config["indicator"] == "rolling_mean" else "P3-T1"


def main():
    spec = importlib.util.spec_from_file_location(
        "p3_readonly_audit", BASE / "collect-p3.py"
    )
    control = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(control)
    control.initialize()
    if AUDIT.exists():
        assert not any(AUDIT.iterdir()), "refuse to replace an existing audit"
    else:
        AUDIT.mkdir()
    reports = [load(BASE / "acquisition" / name) for name in ("t1-c1.json", "t2.json")]
    resources = load(BASE / "acquisition/worker-resources.json")
    cases = control.validate_results(reports, resources)
    post = load(BASE / "acquisition-outer/postseals.json")
    protocol = load(BASE / "acquisition-outer/protocol.json")
    outer = load(BASE / "acquisition-outer/receipt.json")
    assert post["passed"] and post["before"] == post["after"]
    assert post["deadline_monotonic"] == protocol["total_deadline_monotonic"]
    assert post["completed_monotonic"] <= post["deadline_monotonic"]
    assert protocol["phase_seconds"] == 600 and protocol["cleanup_seconds"] == 70
    assert protocol["total_deadline_monotonic"] == protocol["started_monotonic"] + 600
    assert protocol["acquire_deadline_monotonic"] == protocol["started_monotonic"] + 530
    assert (
        protocol["controller_sha256"]
        == sha(BASE / "collect-p3.py")
        == "cda80106c96e2020ccca50c02d0f27a4138d5c4f73045c5bf77017912d6bfc74"
    )
    assert (
        outer["exit_code"] == 0
        and outer["collector_reaped"]
        and outer["accepted_outer_completion"]
    )
    assert (
        not outer["remaining_owned"]
        and not outer["events"]
        and outer["cancel_reason"] is None
    )
    assert 0 < outer["elapsed_seconds"] < 530
    fresh = asyncio.run(control.seals())
    assert {
        key: value for key, value in fresh.items() if key != "thread_environment"
    } == {
        key: value
        for key, value in post["after"].items()
        if key != "thread_environment"
    }
    fixed = control.generic.environment(4)
    assert post["after"]["thread_environment"] == {
        key: fixed[key] for key in control.generic.THREAD_ENV
    }
    samples, statistics, counters, receipts = [], [], {}, []
    rows_checked = 0
    for case in cases:
        config = case["config"]
        name = case_id(config)
        summary = {
            key: case[key]
            for key in (
                "baseline",
                "candidate",
                "paired_speedup_median",
                "paired_speedup_ci95",
                "bootstrap_resamples",
                "phase_intervals",
            )
        }
        low, high = case["paired_speedup_ci95"]
        summary.update(
            case_id=name,
            config=config,
            target_qualifies=name != "P3-C1"
            and case["paired_speedup_median"] > 1.05
            and low > 1,
            confirmed_regression=high < 1 / 1.05,
        )
        statistics.append(summary)
        for index in range(30):
            for arm in (0, 1) if index % 2 == 0 else (1, 0):
                sample = case["samples"][arm][index]
                assert (
                    sample["correctness"]["passed"]
                    and sample["correctness"]["mismatched_values"] == 0
                )
                samples.append(
                    {
                        "case_id": name,
                        "pair_index": index,
                        "arm": ("baseline", "candidate")[arm],
                        "start_row": sample["start_row"],
                        "append_rows": config["append_rows"],
                        "elapsed_seconds": sample["seconds"],
                        "float64_digest": sample["correctness"]["float64_digest"],
                        "max_absolute_error": sample["correctness"][
                            "max_absolute_error"
                        ],
                        **sample["phases_seconds"],
                    }
                )
        rows_checked += 2 * (config["history_rows"] + 30 * config["append_rows"])
        assert (
            load(Path(case["worker_receipt_path"]))["workers"]
            == case["worker_receipts"]
        )
        counters[name] = {}
        for arm, terminal, receipt in zip(
            ("baseline", "candidate"),
            case["terminal"],
            case["worker_receipts"],
            strict=True,
        ):
            receipts.append(
                {
                    "case_id": name,
                    "arm": arm,
                    **receipt,
                    "resources": resources[str(receipt["pid"])],
                }
            )
            before, after = terminal["before_status"], terminal["after_status"]
            assert before["state"] == "running" and after["state"] == "completed"
            assert after["terminal_cause"] == "natural_end" and after["task_count"] == 0
            assert before["task_count"] == 7 and after["task_errors"] == 0
            assert not before["metrics_overflowed"] and not after["metrics_overflowed"]
            assert after["checkpoint"]["last_completed_epoch"] == 1
            assert (
                after["sources"]["input"]["ended"]
                and after["sinks"]["profile"]["ended"]
            )
            assert (
                after["sources"]["input"]["data_rows"]
                == config["history_rows"] + 30 * config["append_rows"]
            )
            assert (
                after["sinks"]["profile"]["delivered_rows"]
                == after["sources"]["input"]["data_rows"]
            )
            assert before["sources"]["input"]["data_rows"] == config["history_rows"]
            assert before["sources"]["input"]["data_batches"] == (
                600 if name == "P3-T2" else 1
            )
            for edge in after["edges"].values():
                assert (
                    edge["current_envelopes"]
                    == edge["current_rows"]
                    == edge["current_bytes"]
                    == 0
                )
            for phase in (before, after):
                for node in phase["operators"].values():
                    assert node["late_rows"] == node["errors"] == 0
            left = before["rolling_metrics"]["indicators__cf_rolling"]
            right = after["rolling_metrics"]["indicators__cf_rolling"]
            assert not left["overflowed"] and not right["overflowed"]
            assert left["watermark"]["started"] == (60 if name == "P3-T2" else 1)
            assert right["watermark"]["started"] == left["watermark"]["started"] + 30
            difference = {}
            for phase in ("data", "watermark", "end"):
                assert all(
                    right[phase][key] == 0
                    for key in ("failed", "cancelled", "interrupted")
                )
                assert right[phase]["started"] == right[phase]["succeeded"]
                difference[phase] = {
                    key: value - left[phase][key]
                    for key, value in right[phase].items()
                    if type(value) is int
                }
                assert all(value >= 0 for value in difference[phase].values())
            counters[name][arm] = {
                "after_minus_before": difference,
                "scope": "post-warm through native terminal handling; not a per-sample attribution",
                "warm_seconds": terminal["warm_seconds"],
                "terminal_rss_bytes": terminal["rss_bytes"],
            }
    assert (
        len(samples) == 180
        and len(receipts) == 6
        and len({r["pid"] for r in receipts}) == 6
    )
    assert rows_checked == 1386880
    passed = any(case["target_qualifies"] for case in statistics) and not any(
        case["confirmed_regression"] for case in statistics
    )
    save(
        "statistics.json",
        {
            "contract": "paired-warm-stream-v1",
            "samples": "30 advancing AB/BA pairs per case within one persistent pair; fresh pair per case",
            "cases": statistics,
            "P3_preregistered_rule_pass": passed,
            "merge_approval": False,
        },
    )
    save(
        "native-counters.json",
        {
            "cases": counters,
            "limitation": "copied_entities counts entity state copies, not actual tape rows/bytes/allocations/credits/fallback; those quantities are not exposed by the timed wheel",
        },
    )
    save("os-receipts.json", receipts)
    save(
        "identity.json",
        {
            "builds": reports[0]["builds"],
            "environments": reports[0]["environments"],
            "common_helpers": post["before"]["common_helpers"],
            "case_starts": {case_id(case["config"]): case["start"] for case in cases},
        },
    )
    save(
        "verification.json",
        {
            "status": "passed",
            "source_sha": control.EXPECTED,
            "baseline_sha": reports[0]["builds"][0]["git_sha"],
            "phase_elapsed_seconds": outer["elapsed_seconds"],
            "paired_observations": 90,
            "arm_samples": 180,
            "validated_rows_warm_plus_append_both_arms": rows_checked,
            "all_3_warm_digests_and_90_pair_digests_equal": True,
            "all_180_independent_oracles_pass": True,
            "all_start_plan_identities_equal": True,
            "all_native_jobs_completed_natural_end": True,
            "all_metrics_no_overflow_late_error": True,
            "all_terminal_tasks_edges_empty": True,
            "all_6_OS_zero_normal_reaped_and_RSS_sampled": True,
            "pre_post_source_build_native_helpers_equal_within_absolute_deadline": True,
            "posthoc_rehash_matches_postseals": True,
            "P3_preregistered_performance_rule_pass": passed,
            "no_native_probe_or_retry": True,
            "required_final_core_parity_CI_and_review": "pending at acquisition handoff; performance does not authorize merge",
        },
    )
    with (AUDIT / "samples.csv").open("w", newline="") as stream:
        writer = csv.DictWriter(
            stream, fieldnames=list(samples[0]), lineterminator="\n"
        )
        writer.writeheader()
        writer.writerows(samples)
    save(
        "source-head.json",
        {
            "source": str(control.SOURCE),
            "sha": subprocess.check_output(
                ["git", "rev-parse", "HEAD"], cwd=control.SOURCE, text=True
            ).strip(),
            "tree": subprocess.check_output(
                ["git", "rev-parse", "HEAD^{tree}"], cwd=control.SOURCE, text=True
            ).strip(),
        },
    )
    print(
        json.dumps(
            {
                "status": "passed",
                "case_count": len(cases),
                "arm_samples": len(samples),
                "validated_rows": rows_checked,
                "P3_rule_pass": passed,
            }
        )
    )


if __name__ == "__main__":
    main()
