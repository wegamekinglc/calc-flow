# FINAL MERGE HANDOFF — P2 / PR #565

**Verdict: APPROVE. No remaining must-fix finding.**

Approval applies to this exact PR head and reviewed main integration:

- Head: `52c5e6dcd626e66672d13b740b1cf7ba9425557e`
- Tree: `70918641a2079363f07c64a5adf3df45373bddab`
- Parents: measured `cc6e33e00acd6a8f1feba7a7776f208c29e71638` and
  main `a359d632b3854d2da979886b39c77c583be88d8c`
- PR: [#565](https://github.com/wegamekinglc/calc-flow/pull/565)
- Single final snapshot: 2026-11-07 23:38:03 UTC.

## Final commit and CI gate

Local HEAD/tree/parents and the clean worktree match the published identity.
GitHub independently reports the same PR head and base, open/unmerged and
mergeable. Compared with the previously reviewed integration `896b63bf`, the
only changed path is the published review document. There is no new runtime,
harness, fixture or raw-result change requiring another source/performance run.

One non-blocking connector snapshot fetched the exact head's check runs with
`per_page=100`: **total_count=33, returned=33, all completed; 32 success,
0 failed/cancelled/inconclusive/unfinished, 1 expected skipped.**

The only skip is `Publish calc-flow to crates.io` (check `128558554910`).
The checked workflow explicitly requires
`github.event_name == 'push' && github.ref_type == 'tag'`; a pull request
correctly skips publishing. Its package/external-consumer verification and
published-dependency audit both succeeded. This is not a missing required
verification result.

| Workflow           | Run         | Final result        |
|--------------------|-------------|---------------------|
| macOS CI           | 42422588449 | completed / success |
| Windows CI         | 42422588558 | completed / success |
| Rust crate release | 42422588533 | completed / success |
| Linux CI           | 42422588471 | completed / success |

Successful checks include Codacy Static Code Analysis (`128554136934`), Rust
combined coverage, Rust/Python tests, Ruff/unit tests, Python 3.9–3.14
compatibility, all four connector services, Windows parity/process cleanup,
macOS smoke, dependency policy, documentation and wheel/package verification.
No pending check or earlier head's success is used as the final gate.

## Previously completed independent review

The versioned specialist report is
`.codex/artifacts/reviews/ta-arroyo-p2-decay.md`. Its source, mathematical,
resource, checkpoint, harness and archive findings are all closed.

Final cc6 performance was independently recomputed from all 240 raw samples,
using the maintained 30 paired advancing-state appends per each of four cases:

| Case                            | Paired median speedup | 95% interval         |
|---------------------------------|-----------------------|----------------------|
| Decay W20 / append1024          | 2.507374×             | [2.349689, 2.670110] |
| Decay W1000 / append1024        | 8.706189×             | [8.381238, 8.998500] |
| Decay + Mean W1000 / append1024 | 7.900375×             | [7.550449, 8.391012] |
| Decay W1000 / append1 control   | 1.154980×             | [1.115009, 1.267761] |

The preregistered target/control rule passes. D13 Decay tolerance remains
rtol=atol1e-12; all recorded numerical/identity/order checks and 192,380
validated rows pass. Actual Rust counters expose certification, guard/reseed
and COW work rather than estimating it in Python. The single-row control's
1,000 copied samples per append and case 3's CV/P95 variation remain disclosed;
this does not promise unconditional O(N) total work or a tail-latency guarantee.

The real final build recompiled unique core/binding artifacts (`fresh=false`),
and its wheel/native bytes, build receipts, 105 helper texts and archived
source identities were verified. Eight distinct workers have normal, reaped,
OS-exit-zero receipts and completed native EOF; post-seals match inside the
absolute phase, no owned process remains. Final phase 25.354389399988577 s plus
original phase 25.345291340025142 s totals **50.69968074001372 s / 600 s**.
The independent datasets are not pooled and the old b917 archive is unchanged.

Final complete evidence SHA-256:
`1bd46cee5fd4c91811b556196a2514e7bfd150134cc11f70da2e6f4317743c33`.
Final measured native SHA-256:
`d72ce8a5444c4bbc42bd4251261b3ecd9f40b074aacc47ead3be2a65ed78c2ce`.

The 28-file main delta was independently shown to affect publishing metadata,
documentation/release tooling and cfg(test) code only. Dependencies, lockfile,
release flags and executable build inputs retain their behavior. All 23
P2 code/test/helper paths remain byte-identical to measured cc6 in the reviewed
integration. Reusing cc6 measurements is justified by release equivalence;
complete source-directory and binary hashes are not falsely claimed identical,
and no native artifact is relabeled as the integration head.

## Merge handoff

Root may complete PR metadata/ready-for-review transitions and merge using
expected head `52c5e6dcd626e66672d13b740b1cf7ba9425557e` under the user's existing
authority. If head or target-main execution changes, reassess that delta.
This reviewer performs no remote mutation or merge.

This external handoff intentionally leaves all CI-validated versioned files
unchanged. Final source, raw/statistical review, builds and timings were not
repeated; only the final identity and single current CI/workflow snapshot were
verified for this approval.
