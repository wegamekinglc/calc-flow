from __future__ import annotations

import copy
import importlib.util
import json
import tempfile
import unittest
from pathlib import Path
from unittest.mock import Mock, patch

spec = importlib.util.spec_from_file_location(
    "p3", Path(__file__).with_name("collect-p3.py")
)
p3 = importlib.util.module_from_spec(spec)
spec.loader.exec_module(p3)


def reports():
    return [{"cases": [{"config": config} for config in p3.expected_configs()]}]


class FixedMetadataTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        p3.initialize()

    def test_fixed_three_case_metadata(self):
        self.assertEqual(len(p3.validate_complete(reports(), {})), 3)

    def test_duplicate_case_is_not_a_complete_acquisition(self):
        value = reports()
        value[0]["cases"][2] = copy.deepcopy(value[0]["cases"][0])
        with self.assertRaisesRegex(ValueError, "fixed case"):
            p3.validate_complete(value, {})

    def test_actual_matrix_is_exactly_the_three_frozen_cases(self):
        matrix = p3.matrix_preflight()
        value = [
            {
                "cases": [
                    {"config": config} for config, mode in matrix if mode == "normal"
                ]
            }
        ]
        self.assertEqual(len(matrix), 3)
        self.assertEqual(len(p3.validate_complete(value, {})), 3)
        self.assertEqual(len(p3.commands()), 2)
        self.assertTrue(
            all("--worker-threads" not in command for command in p3.commands())
        )

    def test_changed_postseal_is_fatal(self):
        with self.assertRaisesRegex(ValueError, "postseal drift"):
            p3.require_postseals({"native": "old"}, {"native": "new"}, float("inf"))

    def test_postseal_just_after_absolute_cap_is_fatal(self):
        with (
            patch.object(p3.time, "monotonic", return_value=600.000001),
            self.assertRaises(TimeoutError),
        ):
            p3.require_postseals({}, {}, 600)

    def test_postseal_within_same_cap_is_accepted(self):
        with patch.object(p3.time, "monotonic", return_value=599.9):
            p3.require_postseals({"helper": "same"}, {"helper": "same"}, 600)

    def test_six_distinct_normal_workers_require_sampled_rss(self):
        cases = [
            {"worker_receipts": [self.receipt(i), self.receipt(i + 1)]}
            for i in (10, 12, 14)
        ]
        resources = {
            str(i): {"sample_count": 1, "sampled_process_tree_peak_rss": 1024}
            for i in range(10, 16)
        }
        p3.validate_worker_resources(cases, resources)
        with self.assertRaisesRegex(ValueError, "RSS unmeasured"):
            p3.validate_worker_resources(cases, {})
        cases[0]["worker_receipts"][0]["exit_code"] = 1
        with self.assertRaises(RuntimeError):
            p3.validate_worker_resources(cases, resources)

    def test_duplicate_worker_pid_across_cases_is_rejected(self):
        cases = [{"worker_receipts": [self.receipt(10), self.receipt(11)]}] * 3
        resources = {
            str(i): {"sample_count": 1, "sampled_process_tree_peak_rss": 1024}
            for i in (10, 11)
        }
        with self.assertRaisesRegex(ValueError, "duplicate worker PID"):
            p3.validate_worker_resources(cases, resources)

    @staticmethod
    def receipt(pid):
        return {"pid": pid, "exit_code": 0, "reaped": True, "close_result": "normal"}


class DeadlineTests(unittest.IsolatedAsyncioTestCase):
    @classmethod
    def setUpClass(cls):
        p3.initialize()

    async def test_normal_process_return_just_after_acquire_cap_is_rejected(self):
        process = Mock(pid=50, returncode=0)
        process.poll.return_value = 0
        with tempfile.TemporaryDirectory() as temporary:
            with (
                patch.object(p3, "OUTPUT", Path(temporary)),
                patch.object(p3.generic, "start_invocation", return_value=process),
                patch.object(p3.generic, "settle_invocation") as settle,
                patch.object(p3.time, "monotonic", side_effect=[9, 10.0001, 10.0001]),
                self.assertRaisesRegex(TimeoutError, "normal process return"),
            ):
                await p3.invoke(["/fake/executable"], 1, 10)
            settle.assert_called_once_with(process)
            receipt = json.loads(
                (Path(temporary) / "command-1/receipt.json").read_text()
            )
            self.assertIsNotNone(receipt["error"])
            self.assertEqual(receipt["exit_code"], 0)

    async def test_initialization_time_cannot_reset_the_phase_start(self):
        with tempfile.TemporaryDirectory() as temporary:
            audit = Path(temporary) / "audit"
            with (
                patch.object(p3, "BOOT_STARTED", 0),
                patch.object(p3, "initialize"),
                patch.object(p3, "OUTPUT", Path(temporary) / "missing"),
                patch.object(p3, "AUDIT", audit),
                patch.object(p3.sys, "argv", ["collect-p3.py"]),
                patch.object(p3.time, "monotonic", return_value=531),
                patch.object(p3.subprocess, "Popen") as spawn,
                patch.object(p3.signal, "signal"),
                patch.dict(p3.os.environ),
                self.assertRaisesRegex(TimeoutError, "initialization"),
            ):
                p3.main()
            spawn.assert_not_called()
            protocol = json.loads((audit / "protocol.json").read_text())
            self.assertEqual(protocol["started_monotonic"], 0)
            self.assertEqual(protocol["total_deadline_monotonic"], 600)

    def test_sparse_physical_segment_change_is_rejected(self):
        value = reports()
        value[0]["cases"][2]["config"]["history_segment_rows"] = 10000
        with self.assertRaisesRegex(ValueError, "fixed case"):
            p3.validate_complete(value, {})


if __name__ == "__main__":
    unittest.main()
