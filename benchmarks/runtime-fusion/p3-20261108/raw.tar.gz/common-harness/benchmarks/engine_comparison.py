"""Correctness-gated engine adapters with explicit, materialized timing scopes."""

from __future__ import annotations

import asyncio
import hashlib
import os
import time
from dataclasses import dataclass
from datetime import timedelta
from pathlib import Path

import numpy as np
import pyarrow as pa

from benchmarks.engine_stream import (
    dimension_events,
    run_stream,
    run_variant_stream,
    stream_dimension,
    stream_events,
    stream_plan,
)
from benchmarks.rolling_indicator_comparison import (
    FinancePythonWorker,
    TaLibMethod,
    ta_lib_expected_dual_sma_spread,
    ta_lib_expected_rolling_mean,
)
from benchmarks.warm_stream import BASE, _segment
from calc_flow import Batch, PipelineBuilder
from scripts.benchmark_suite.catalog import (
    BATCH_ROWS,
    CAPABILITIES,
    POLARS_ENGINE,
    THREADS,
    worker_thread_count,
)

# Keep comparison-engine fixture chunks independent of native stream batching.
TABLE_BATCH_ROWS = 64_000


@dataclass(frozen=True, slots=True)
class Workload:
    table: pa.Table
    dimension: pa.Table
    entities: int


def workload(count: int, *, scenario: str | None = None) -> Workload:
    if type(count) is not int or count <= 0:
        raise ValueError("rows must be a positive integer")
    entities = 64 if scenario == "interval_join" else min(64, max(1, count // 40))
    table = _segment(0, count, entities)
    sequence = table["sequence"].to_numpy()
    # Exact binary fractions keep long-running performance fixtures separate
    # from decimal accumulation stress tests. Every engine sees these bytes.
    prices = 100 + (sequence % 257) / 8 + (sequence % entities) / 8
    table = table.set_column(
        table.column_names.index("price"), table.schema.field("price"), pa.array(prices)
    )
    table = pa.Table.from_batches(table.to_batches(max_chunksize=TABLE_BATCH_ROWS))
    dimension = pa.table(
        {
            "symbol": [f"S{i:03d}" for i in range(entities)],
            "factor": np.arange(entities, dtype=np.float64) + 1,
        }
    )
    return Workload(table, dimension, entities)


def _rolling_expected(data: Workload, scenario: str) -> np.ndarray:
    prices = data.table["price"].to_numpy()
    if scenario == "sma20":
        return ta_lib_expected_rolling_mean(prices, entities=data.entities, window=20)
    return ta_lib_expected_dual_sma_spread(
        prices, entities=data.entities, fast_window=5, slow_window=20
    )


def _average_expected(prices: np.ndarray, entities: int) -> np.ndarray:
    result = np.empty(len(prices), dtype=np.float64)
    for entity in range(entities):
        series = prices[entity::entities]
        result[entity::entities] = np.cumsum(series) / np.arange(1, len(series) + 1)
    return result


def _argmax_expected(prices: np.ndarray, entities: int, window: int) -> np.ndarray:
    # The exact-eighth fixture repeats every 257 entity ticks. Precompute the
    # complete-window answers for one cycle, then handle only the warm prefix.
    from numpy.lib.stride_tricks import sliding_window_view

    result = np.empty(len(prices), dtype=np.float64)
    for entity in range(entities):
        series = prices[entity::entities]
        if not len(series):
            continue
        cycles = np.arange(-(window - 1), 257, dtype=np.int64)
        periodic = 100 + ((entity + cycles * entities) % 257) / 8 + entity / 8
        lookup = window - 1 - np.argmax(sliding_window_view(periodic, window), axis=1)
        positions = np.arange(len(series))
        values = lookup[positions % 257].astype(np.float64)
        for index in range(min(len(series), window - 1)):
            values[index] = float(index - np.argmax(series[: index + 1]))
        result[entity::entities] = values
    return result


def _cross_section_mean(prices: np.ndarray, entities: int) -> np.ndarray:
    starts = np.arange(0, len(prices), entities)
    means = np.add.reduceat(prices, starts) / np.diff(np.append(starts, len(prices)))
    return np.repeat(means, np.diff(np.append(starts, len(prices))))


def _window_sum_expected(data: Workload) -> pa.Table:
    prices = data.table["price"].to_numpy()
    sequence = data.table["sequence"].to_numpy()
    groups = (
        sequence // data.entities // 10
    ) * data.entities + sequence % data.entities
    keys, inverse = np.unique(groups, return_inverse=True)
    sums = np.bincount(inverse, weights=prices)
    starts = [BASE + timedelta(seconds=int(key // data.entities * 10)) for key in keys]
    symbols = [f"S{int(key % data.entities):03d}" for key in keys]
    return pa.table(
        {
            "symbol": pa.array(symbols),
            "window_start": pa.array(starts, type=pa.timestamp("us", tz="UTC")),
            "value": pa.array(sums),
        }
    )


def _interval_expected(data: Workload) -> pa.Table:
    table = data.table
    prices = table["price"].to_numpy()
    sequence = table["sequence"].to_numpy()
    sequence_order = np.argsort(sequence)
    chunks = []
    for offset in range(-5, 6):
        right = sequence.astype(np.int64) + offset * data.entities
        mask = (right >= 0) & (right < table.num_rows)
        positions = np.searchsorted(sequence[sequence_order], right[mask])
        chunks.append(
            pa.table(
                {
                    "sequence": sequence[mask],
                    "right_sequence": right[mask].astype(np.uint64),
                    "value": prices[mask] * prices[sequence_order[positions]],
                }
            )
        )
    return pa.concat_tables(chunks)


def _group_by_expected(data: Workload) -> pa.Table:
    prices = data.table["price"].to_numpy()
    sums = [
        float(np.sum(prices[index :: data.entities])) for index in range(data.entities)
    ]
    return pa.table({"symbol": data.dimension["symbol"], "value": sums})


def expected_output(data: Workload, scenario: str) -> pa.Table:
    table = data.table
    prices = table["price"].to_numpy()
    sequence = table["sequence"].to_numpy()
    table_oracles = {
        "interval_join": _interval_expected,
        "window_sum": _window_sum_expected,
    }
    if scenario in table_oracles:
        return table_oracles[scenario](data)
    if scenario in ("sma20", "dual_sma"):
        return table.append_column("value", pa.array(_rolling_expected(data, scenario)))
    if scenario == "average":
        return pa.table(
            {
                "sequence": table["sequence"],
                "value": _average_expected(prices, data.entities),
            }
        )
    if scenario in ("argmax64", "argmax256"):
        return pa.table(
            {
                "sequence": table["sequence"],
                "value": _argmax_expected(prices, data.entities, int(scenario[6:])),
            }
        )
    if scenario == "unique64":
        count = np.minimum(sequence // data.entities + 1, 64).astype(np.float64)
        return pa.table({"sequence": table["sequence"], "value": count})
    if scenario == "cs_mean":
        return pa.table(
            {
                "sequence": table["sequence"],
                "value": _cross_section_mean(prices, data.entities),
            }
        )
    if scenario == "asof_join":
        return pa.table({"sequence": table["sequence"], "value": prices})
    if scenario == "group_by":
        return _group_by_expected(data)
    if scenario == "filter":
        mask = sequence % 4 == 0
        return pa.table({"sequence": sequence[mask], "value": prices[mask]})
    values = (
        prices * 2 + 1
        if scenario == "projection"
        else prices * (sequence % data.entities + 1)
    )
    return pa.table({"sequence": sequence, "value": values})


def _argmax_sql(window: int) -> str:
    # array_position is one-based and chooses the oldest tied maximum. Count
    # rows, including the partial prefix, to return a lag within each entity.
    return (
        "SELECT sequence, CAST(COUNT(*) OVER trailing - "
        "CAST(array_position(array_agg(price) OVER trailing, "
        "MAX(price) OVER trailing) AS BIGINT) AS DOUBLE) AS value FROM input "
        "WINDOW trailing AS (PARTITION BY symbol ORDER BY event_time, sequence "
        f"ROWS BETWEEN {window - 1} PRECEDING AND CURRENT ROW)"
    )


def sql_query(scenario: str) -> str:
    # Closed, literal query catalog: scenario names never become SQL fragments.
    queries = {
        "projection": "SELECT sequence, price * 2 + 1 AS value FROM input",
        "filter": "SELECT sequence, price AS value FROM input WHERE sequence % 4 = 0",
        "group_by": "SELECT symbol, SUM(price) AS value FROM input GROUP BY symbol",
        "join": (
            "SELECT sequence, price * factor AS value "
            "FROM input JOIN dimension USING (symbol)"
        ),
        "interval_join": (
            "WITH offsets(event_offset) AS (VALUES "
            "(INTERVAL '-5 seconds'), (INTERVAL '-4 seconds'), "
            "(INTERVAL '-3 seconds'), (INTERVAL '-2 seconds'), "
            "(INTERVAL '-1 seconds'), (INTERVAL '0 seconds'), "
            "(INTERVAL '1 seconds'), (INTERVAL '2 seconds'), "
            "(INTERVAL '3 seconds'), (INTERVAL '4 seconds'), "
            "(INTERVAL '5 seconds')) "
            "SELECT probes.left_sequence AS sequence, "
            "reference.sequence AS right_sequence, "
            "probes.left_price * reference.price AS value "
            "FROM reference JOIN (SELECT input.sequence AS left_sequence, "
            "input.symbol AS left_symbol, input.price AS left_price, "
            "input.event_time + offsets.event_offset AS match_time "
            "FROM input CROSS JOIN offsets) AS probes "
            "ON probes.left_symbol = reference.symbol "
            "AND probes.match_time = reference.event_time"
        ),
        "sma20": (
            "SELECT event_time, sequence, symbol, price, "
            "CASE WHEN COUNT(price) OVER slow = 20 "
            "THEN AVG(price) OVER slow END AS value FROM input "
            "WINDOW slow AS (PARTITION BY symbol ORDER BY event_time, sequence "
            "ROWS BETWEEN 19 PRECEDING AND CURRENT ROW)"
        ),
        "dual_sma": (
            "SELECT event_time, sequence, symbol, price, "
            "CASE WHEN COUNT(price) OVER slow = 20 "
            "THEN AVG(price) OVER fast - AVG(price) OVER slow END AS value FROM input "
            "WINDOW slow AS (PARTITION BY symbol ORDER BY event_time, sequence "
            "ROWS BETWEEN 19 PRECEDING AND CURRENT ROW), "
            "fast AS (PARTITION BY symbol ORDER BY event_time, sequence "
            "ROWS BETWEEN 4 PRECEDING AND CURRENT ROW)"
        ),
        "average": (
            "SELECT sequence, AVG(price) OVER (PARTITION BY symbol "
            "ORDER BY event_time, sequence ROWS BETWEEN UNBOUNDED PRECEDING "
            "AND CURRENT ROW) AS value FROM input"
        ),
        "argmax64": _argmax_sql(64),
        "argmax256": _argmax_sql(256),
        "unique64": (
            "SELECT sequence, CAST(COUNT(DISTINCT price) OVER (PARTITION BY symbol "
            "ORDER BY event_time, sequence ROWS BETWEEN 63 PRECEDING "
            "AND CURRENT ROW) AS DOUBLE) AS value FROM input"
        ),
        "cs_mean": (
            "SELECT sequence, AVG(price) OVER (PARTITION BY event_time) AS value "
            "FROM input"
        ),
        "window_sum": (
            "SELECT symbol, arrow_cast(date_bin(INTERVAL '10 seconds', event_time, "
            "TIMESTAMP '1970-01-01 00:00:00'), "
            "'Timestamp(Microsecond, Some(\"UTC\"))') AS window_start, "
            "SUM(price) AS value FROM input GROUP BY symbol, window_start"
        ),
        # The maintained ASOF workload declares tolerance=0. Its backward
        # match is therefore equality at the event time, with the highest
        # reference sequence breaking ties and unmatched left rows retained.
        "asof_join": (
            "SELECT input.sequence, reference.price AS value FROM input LEFT JOIN "
            "(SELECT symbol, event_time, price, ROW_NUMBER() OVER "
            "(PARTITION BY symbol, event_time ORDER BY sequence DESC) AS position "
            "FROM reference) AS reference ON input.symbol = reference.symbol "
            "AND input.event_time = reference.event_time AND reference.position = 1"
        ),
    }
    try:
        return queries[scenario]
    except KeyError as error:
        raise ValueError("unsupported SQL benchmark scenario") from error


def _calc_flow(data: Workload, scenario: str, target_partitions: int = THREADS):
    aliases = (
        ("input", "dimension")
        if scenario == "join"
        else ("input", "reference")
        if scenario in ("interval_join", "asof_join")
        else ("input",)
    )
    plan = (
        PipelineBuilder("suite-sql")
        .with_datafusion_config(target_partitions=target_partitions, batch_size=8192)
        .sql("query", sql_query(scenario), aliases=aliases)
        .compile_batch()
    )
    inputs = {"input": Batch.from_pyarrow(data.table)}
    if scenario == "join":
        inputs["dimension"] = Batch.from_pyarrow(data.dimension)
    elif scenario in ("interval_join", "asof_join"):
        inputs["reference"] = inputs["input"]
    return lambda: plan.execute(inputs).outputs["output"].to_pyarrow()


def _datafusion(data: Workload, scenario: str, target_partitions: int = THREADS):
    from datafusion import SessionConfig, SessionContext

    batches = data.table.to_batches(max_chunksize=TABLE_BATCH_ROWS)
    dimension = data.dimension.to_batches()
    query = sql_query(scenario)

    def execute():
        context = SessionContext(
            SessionConfig()
            .with_target_partitions(target_partitions)
            .with_batch_size(8192)
        )
        context.register_record_batches("input", [batches])
        if scenario == "join":
            context.register_record_batches("dimension", [dimension])
        elif scenario in ("interval_join", "asof_join"):
            context.register_record_batches("reference", [batches])
        return pa.Table.from_batches(context.sql(query).collect())

    return execute


def _polars_window_plan(frame, value, scenario: str):
    import polars as pl

    if scenario == "average":
        return frame.select(
            "sequence",
            (value.cum_sum() / value.cum_count())
            .over("symbol", order_by=["event_time", "sequence"])
            .alias("value"),
        )
    window = 64 if scenario == "unique64" else int(scenario[6:])
    tick = pl.col("_tick")
    indexed = frame.sort("symbol", "event_time", "sequence").with_columns(
        pl.int_range(pl.len(), dtype=pl.Int64).over("symbol").alias("_tick")
    )
    if scenario == "unique64":
        return (
            indexed.rolling("_tick", period="64i", group_by="symbol", closed="right")
            .agg(
                pl.col("sequence").last(),
                value.n_unique().cast(pl.Float64).alias("value"),
            )
            .select("sequence", "value")
        )
    # The first matching maximum at/after the frame start must be in the
    # frame. This selects oldest ties without expanding every rolling group.
    maxima = indexed.with_columns(
        value.rolling_max(window, min_samples=1).over("symbol").alias("_maximum"),
        (tick - window + 1).clip(lower_bound=0).alias("_start"),
    )
    candidates = indexed.select(
        "symbol", value.alias("_maximum"), tick.alias("_candidate")
    )
    return maxima.join_asof(
        candidates,
        left_on="_start",
        right_on="_candidate",
        by=["symbol", "_maximum"],
        strategy="forward",
        check_sortedness=False,
    ).select("sequence", (tick - pl.col("_candidate")).cast(pl.Float64).alias("value"))


def _polars_plan(data: Workload, scenario: str):
    import polars as pl

    frame = pl.from_arrow(data.table).lazy()
    value = pl.col("price")
    if scenario == "projection":
        return frame.select("sequence", (value * 2 + 1).alias("value"))
    if scenario == "filter":
        return frame.filter(pl.col("sequence") % 4 == 0).select(
            "sequence", value.alias("value")
        )
    if scenario == "group_by":
        return frame.group_by("symbol").agg(value.sum().alias("value"))
    if scenario == "join":
        return frame.join(pl.from_arrow(data.dimension).lazy(), on="symbol").select(
            "sequence", (value * pl.col("factor")).alias("value")
        )
    if scenario == "interval_join":
        return pl.concat(
            [
                frame.join(
                    frame.select(
                        "symbol",
                        (pl.col("event_time") - pl.duration(seconds=offset)).alias(
                            "event_time"
                        ),
                        pl.col("sequence").alias("right_sequence"),
                        pl.col("price").alias("right_price"),
                    ),
                    on=["symbol", "event_time"],
                ).select(
                    "sequence",
                    "right_sequence",
                    (value * pl.col("right_price")).alias("value"),
                )
                for offset in range(-5, 6)
            ]
        )
    if scenario == "asof_join":
        reference = frame.select("symbol", "event_time", pl.col("price").alias("value"))
        return frame.join_asof(
            reference,
            on="event_time",
            by="symbol",
            strategy="backward",
            check_sortedness=False,
        ).select("sequence", "value")
    if scenario in ("average", "argmax64", "argmax256", "unique64"):
        return _polars_window_plan(frame, value, scenario)
    if scenario == "cs_mean":
        return frame.select("sequence", value.mean().over("event_time").alias("value"))
    if scenario == "window_sum":
        return (
            frame.with_columns(
                pl.col("event_time").dt.truncate("10s").alias("window_start")
            )
            .group_by("symbol", "window_start")
            .agg(value.sum().alias("value"))
        )
    slow = value.rolling_mean(20, min_samples=20).over(
        "symbol", order_by=["event_time", "sequence"]
    )
    indicator = (
        slow
        if scenario == "sma20"
        else value.rolling_mean(5, min_samples=5).over(
            "symbol", order_by=["event_time", "sequence"]
        )
        - slow
    )
    return frame.with_columns(indicator.alias("value"))


def _polars(data: Workload, scenario: str):
    plan = _polars_plan(data, scenario)
    return lambda: plan.collect(engine=POLARS_ENGINE).to_arrow()


def _ta_lib(data: Workload, scenario: str):
    method = TaLibMethod(
        data.table["price"].to_numpy(),
        data.entities,
        20,
        5 if scenario == "dual_sma" else None,
    )
    return lambda: data.table.append_column("value", pa.array(method.run()))


def _finance_worker(
    data: Workload, scenario: str, root: Path
) -> tuple[FinancePythonWorker, np.ndarray]:
    """Prepare a pinned legacy worker and verify its untimed output bytes."""

    python = os.environ.get("FINANCE_PYTHON_PYTHON")
    if not python:
        raise RuntimeError("FINANCE_PYTHON_PYTHON must name the Python 3.9 worker")
    root.mkdir(parents=True, exist_ok=True)
    output = root / "finance-warm.npy"
    worker = FinancePythonWorker(
        Path(python),
        rows=data.table.num_rows,
        entities=data.entities,
        window=20,
        warm_output=output,
        indicator=scenario,
    )
    try:
        identity = worker.identity
        if (
            identity.get("suite_scenario") != scenario
            or identity.get("finance_python_version") != "0.9.10"
            or not str(identity.get("python_version", "")).startswith("3.9.")
        ):
            raise RuntimeError("Finance-Python prepared a different benchmark case")
        values = np.load(output, allow_pickle=False)
        if hashlib.sha256(values.tobytes()).hexdigest() != identity.get("sha256"):
            raise RuntimeError("Finance-Python warm output checksum differs")
        return worker, values
    except BaseException:
        worker.close()
        raise


class EngineCase:
    """Own compiled plans, immutable inputs and a worker-local event loop."""

    def __init__(self, case: dict, root: Path) -> None:
        backend, scenario = case["backend"], case["scenario"]
        if scenario not in CAPABILITIES[backend]:
            raise ValueError("unsupported engine/workload combination")
        if backend == "polars-1t":
            import polars as pl

            if pl.thread_pool_size() != 1:
                raise ValueError("Polars single-thread reference requires one thread")
        self.case, self.root, self.count = case, root, 0
        self.data = workload(case["rows"], scenario=scenario)
        self.expected = expected_output(self.data, scenario)
        self.loop = None
        self.finance = None
        if backend.startswith("calc-flow-stream"):
            self.events = stream_events(
                self.data.table,
                self.data.entities,
                close_windows=scenario == "window_sum",
                batch_rows=case.get("batch_rows", BATCH_ROWS),
                checkpoint_split=case.get("checkpoint_interval_millis") is not None,
            )
            self.streams = (
                {
                    "right": dimension_events(
                        stream_dimension(self.data.dimension), self.data.table
                    ),
                    "left": self.events,
                }
                if scenario == "join"
                else (
                    {"left": self.events, "right": self.events}
                    if scenario == "interval_join"
                    else {"reference.input": self.events, "quotes.input": self.events}
                    if scenario == "asof_join"
                    else {"input": self.events}
                )
            )
            self.loop = asyncio.new_event_loop()
        elif backend == "finance-python":
            self.finance, values = _finance_worker(self.data, scenario, root)
            try:
                result = (
                    self.data.table.append_column("value", pa.array(values))
                    if scenario in ("sma20", "dual_sma")
                    else pa.table(
                        {"sequence": self.data.table["sequence"], "value": values}
                    )
                )
                self.finance_correctness = self.validate(result)
            except BaseException:
                self.finance.close()
                raise
        elif backend.startswith("calc-flow-sql"):
            self.calculate = _calc_flow(
                self.data, scenario, target_partitions=worker_thread_count(case)
            )
        elif backend == "datafusion":
            self.calculate = _datafusion(
                self.data, scenario, target_partitions=worker_thread_count(case)
            )
        else:
            factory = {
                "polars": _polars,
                "polars-1t": _polars,
                "ta-lib": _ta_lib,
            }[backend]
            self.calculate = factory(self.data, scenario)

    def _stream(self):
        self.count += 1
        # Each single-use plan starts with empty rolling state. Compilation and
        # runner startup both precede the adapter's ready-to-Arrow timer.
        if "batch_rows" in self.case:
            return self.loop.run_until_complete(
                run_variant_stream(
                    lambda: stream_plan(
                        self.case["scenario"],
                        self.data.table,
                        self.data.dimension,
                        batch_rows=self.case["batch_rows"],
                    ),
                    self.streams,
                    self.root / f"sample-{self.count}",
                    self.expected.num_rows,
                    case=self.case,
                )
            )
        plan = stream_plan(self.case["scenario"], self.data.table, self.data.dimension)
        return self.loop.run_until_complete(
            run_stream(
                plan,
                self.streams,
                self.root / f"sample-{self.count}",
                self.expected.num_rows,
                static_join=self.case["scenario"] == "join",
            )
        )

    def validate(self, result: pa.Table) -> dict:
        if set(result.column_names) != set(self.expected.column_names):
            raise ValueError("engine output columns differ from the oracle")
        if result.num_rows != self.expected.num_rows:
            raise ValueError("engine output row count differs from the oracle")
        key = (
            [("window_start", "ascending"), ("symbol", "ascending")]
            if self.case["scenario"] == "window_sum"
            else "symbol"
            if self.case["scenario"] == "group_by"
            else [("sequence", "ascending"), ("right_sequence", "ascending")]
            if self.case["scenario"] == "interval_join"
            else "sequence"
        )
        expected = self.expected.sort_by(key)
        result = result.sort_by(key)
        for name in expected.column_names:
            if name != "value" and not result[name].cast(expected[name].type).equals(
                expected[name]
            ):
                raise ValueError(f"engine output payload differs: {name}")
        actual = result["value"].to_numpy()
        reference = expected["value"].to_numpy()
        np.testing.assert_allclose(
            actual, reference, rtol=1e-10, atol=1e-10, equal_nan=True
        )
        finite = np.isfinite(reference)
        error = (
            float(np.max(np.abs(actual[finite] - reference[finite])))
            if finite.any()
            else 0.0
        )
        return {
            "passed": True,
            "rows": result.num_rows,
            "finite_rows": int(finite.sum()),
            "max_abs_error": error,
        }

    def sample(self) -> dict:
        if self.finance is not None:
            return {
                "seconds": self.finance.sample(1),
                "correctness": self.finance_correctness,
                "finance_python": self.finance.identity,
            }
        if self.loop is not None:
            streamed = self._stream()
            result, seconds = streamed[:2]
            evidence = streamed[2] if len(streamed) == 3 else None
        else:
            started = time.perf_counter_ns()
            result = self.calculate()
            seconds = (time.perf_counter_ns() - started) / 1e9
        return {
            "seconds": seconds,
            "correctness": self.validate(result),
            **(
                {"stream_evidence": evidence}
                if self.loop is not None and evidence is not None
                else {}
            ),
        }

    def finish(self) -> dict:
        return {"state": "completed"}

    def close(self) -> None:
        if self.finance is not None:
            self.finance.close()
        if self.loop is not None:
            self.loop.run_until_complete(self.loop.shutdown_asyncgens())
            self.loop.close()
