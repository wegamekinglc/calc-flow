"""Same-host, release-bound, alternating version measurements."""

from __future__ import annotations

import json
import math
from pathlib import Path

from scripts.benchmark_suite.catalog import (
    CONTRACT,
    POLARS_ENGINE,
    STREAM_EVIDENCE_FIELDS,
    THREADS,
    baseline_case_ids,
    comparison_kind,
    polars_thread_count,
    shard_cases,
    worker_thread_count,
)
from scripts.benchmark_suite.diagnostics import observe, persist
from scripts.benchmark_suite.process import ROOT, Worker, install
from scripts.benchmark_suite.provenance import harness_sha256
from scripts.benchmark_suite.report import ROUNDS, SAMPLES, comparison


def validate_environment(
    environment: dict,
    release: dict,
    *,
    polars_threads: int = THREADS,
    tokio_threads: int = THREADS,
    backend: str = "calc-flow",
) -> dict:
    if environment["native_sha256"] != release["native_sha256"]:
        raise ValueError(
            "worker loaded a different native module than the release wheel"
        )
    if environment["polars_threads"] != polars_threads or environment[
        "tokio_worker_threads"
    ] != str(tokio_threads):
        raise ValueError("worker thread configuration does not match the catalog")
    is_polars = backend in ("polars", "polars-1t")
    if is_polars and environment.get("polars_engine") != POLARS_ENGINE:
        raise ValueError("unexpected Polars collection engine")
    # This adapter setting is irrelevant to non-Polars workloads, whose release
    # workers may predate its addition to the environment report.
    excluded = ("native_sha256",) if is_polars else ("native_sha256", "polars_engine")
    return {key: value for key, value in environment.items() if key not in excluded}


def validate_sample(sample: dict) -> float:
    seconds = sample["seconds"]
    if (
        type(seconds) not in (int, float)
        or not math.isfinite(seconds)
        or seconds <= 0
        or sample["correctness"]["passed"] is not True
    ):
        raise ValueError("invalid timing or failed correctness result")
    return seconds


def validate_stream_sample(case: dict, sample: dict) -> None:
    """Require original adapter evidence for every replay-backed dimension."""

    if (
        not case.get("backend", "").startswith("calc-flow-stream")
        or "batch_rows" not in case
    ):
        return
    evidence = sample.get("stream_evidence")
    _validate_stream_dimensions(case, evidence)
    if case["checkpoint_interval_millis"] is not None:
        _validate_checkpoint_proof(case, sample, evidence)


def _validate_stream_dimensions(case: dict, evidence: object) -> None:
    if not isinstance(evidence, dict) or any(
        key not in evidence or evidence[key] != case[key]
        for key in STREAM_EVIDENCE_FIELDS
    ):
        raise ValueError("stream evidence dimensions differ from the prepared case")


def _valid_checkpoint_epochs(epochs: object) -> bool:
    return (
        isinstance(epochs, list)
        and bool(epochs)
        and all(type(epoch) is int and epoch >= 1 for epoch in epochs)
    )


def _validate_checkpoint_proof(case: dict, sample: dict, evidence: dict) -> None:
    rows = evidence.get("rows_before_checkpoint")
    if (
        not _valid_checkpoint_epochs(evidence.get("nonterminal_epochs"))
        or type(rows) is not int
        or not 0 < rows < case["rows"]
        or evidence.get("recovery") != "verified"
        or sample["seconds"] < case["checkpoint_interval_millis"] / 1000
    ):
        raise ValueError("checkpoint evidence lacks durable nonterminal recovery proof")


async def _prepare(workers: dict, releases: dict, case: dict, contexts: dict) -> dict:
    identities = {}
    for side, worker in workers.items():
        identities[side] = validate_environment(
            await worker.request(
                operation="hello",
                context={**contexts[side], "phase": "hello", "sample": None},
            ),
            releases[side],
            polars_threads=polars_thread_count(case),
            tokio_threads=worker_thread_count(case),
            backend=case["backend"],
        )
        response = await worker.request(
            operation="prepare",
            case=case,
            context={**contexts[side], "phase": "warmup", "sample": None},
        )
        if response["case"] != case:
            raise ValueError("worker prepared a different workload")
        validate_sample(response["warmup"])
        validate_stream_sample(case, response["warmup"])
    if "baseline" in identities and identities["baseline"] != identities["candidate"]:
        raise ValueError("base/head machine, dependency or thread fingerprints differ")
    return identities["candidate"]


async def _samples(workers: dict, case: dict, contexts: dict, root: Path) -> dict:
    collected = {side: [] for side in workers}
    for index in range(SAMPLES):
        order = (
            ("baseline", "candidate") if index % 2 == 0 else ("candidate", "baseline")
        )
        for side in order:
            if side not in workers:
                continue
            sample = await workers[side].request(
                operation="sample",
                context={**contexts[side], "phase": "measurement", "sample": index},
            )
            validate_sample(sample)
            validate_stream_sample(case, sample)
            collected[side].append(sample)
            persist(
                root / "partial.json",
                {"contexts": contexts, "samples": collected, "complete": False},
            )
        if len(workers) == 2:
            _check_latest_cursors(collected)
    return collected


def _check_latest_cursors(collected: dict) -> None:
    starts = [samples[-1].get("start_row") for samples in collected.values()]
    if starts[0] != starts[1]:
        raise ValueError("warm base/head sample cursors differ")


async def _round(
    case: dict,
    workers_by_side: dict,
    releases: dict,
    root: Path,
    *,
    round_index: int = 0,
) -> dict:
    workers = {}
    primary = None
    contexts = {
        side: {
            "side": side,
            "round": round_index,
            "case_id": case.get("id"),
            "release": releases[side],
        }
        for side in workers_by_side
    }
    persist(
        root / "partial.json", {"contexts": contexts, "samples": {}, "complete": False}
    )
    try:
        for side, (site, source) in workers_by_side.items():
            workers[side] = await Worker.start(
                site,
                root / side,
                source=source,
                polars_threads=polars_thread_count(case),
                tokio_threads=worker_thread_count(case),
            )
        environment = await _prepare(workers, releases, case, contexts)
        samples = await _samples(workers, case, contexts, root)
        completion = {}
        for side, worker in workers.items():
            result = await worker.request(
                operation="finish",
                context={**contexts[side], "phase": "finish", "sample": None},
            )
            if result["state"] != "completed":
                raise ValueError("benchmark worker did not complete")
            completion[side] = result
        result = {
            "environment": environment,
            "samples": samples,
            "completion": completion,
            "native_sha256": {
                side: releases[side]["native_sha256"] for side in workers
            },
        }
        persist(
            root / "partial.json", {**result, "contexts": contexts, "complete": True}
        )
        return result
    except BaseException as error:
        primary = error
        raise
    finally:
        await _close_workers(workers, primary)


async def _close_workers(workers: dict, primary: BaseException | None) -> None:
    failure = primary
    for worker in workers.values():
        try:
            await worker.close()
        except BaseException as error:
            if failure is None:
                failure = error
            else:
                failure.add_note(f"worker cleanup: {type(error).__name__}: {error}")
    if primary is None and failure is not None:
        raise failure


async def measure_case(
    case: dict, kind: str, workers_by_side: dict, releases: dict, root: Path
) -> dict:
    selected = (
        workers_by_side
        if kind == "interleaved"
        else {"candidate": workers_by_side["candidate"]}
    )
    evidence = []
    try:
        for index in range(ROUNDS):
            evidence.append(
                await _round(
                    case, selected, releases, root / f"round-{index}", round_index=index
                )
            )
        if evidence[0]["environment"] != evidence[1]["environment"]:
            raise ValueError("confirmation-round environment changed")
        row = _measured_row(case, evidence, kind)
        return {**row, "result": comparison(row)}
    except Exception as error:
        return {
            **case,
            "status": "error",
            "error": f"{type(error).__name__}: {error}",
            "error_notes": list(getattr(error, "__notes__", ())),
            "evidence": evidence,
            "partial_evidence": observe(lambda: _partial_evidence(root)),
        }


def _partial_evidence(root: Path) -> list:
    return [
        observe(lambda: json.loads(path.read_text(encoding="utf-8")))
        for index in range(ROUNDS)
        if (path := root / f"round-{index}" / "partial.json").exists()
    ]


def _sample_seconds(evidence: list[dict], side: str) -> list[list[float]]:
    return [
        [sample["seconds"] for sample in round_["samples"][side]] for round_ in evidence
    ]


def _measured_row(case: dict, evidence: list[dict], kind: str) -> dict:
    return {
        **case,
        "status": "ok",
        "correctness": True,
        "comparison": kind,
        "baseline": (
            _sample_seconds(evidence, "baseline") if kind == "interleaved" else []
        ),
        "candidate": _sample_seconds(evidence, "candidate"),
        "evidence": evidence,
    }


def _case_order(count: int) -> list[int]:
    import numpy as np

    return np.random.default_rng(20260905).permutation(count).tolist()


async def measure_shard(
    shard: dict, releases: dict, root: Path, baseline_source: Path | None
) -> dict:
    from scripts.benchmark_suite.legacy import validate_sources

    if baseline_source is None:
        raise ValueError("paired comparison requires a baseline source checkout")
    sources = {"baseline": baseline_source.resolve(), "candidate": ROOT}
    await validate_sources(sources, releases)

    root.mkdir(parents=True, exist_ok=True)
    sites = {
        side: await install(release, root / side) for side, release in releases.items()
    }
    workers_by_side = {
        side: (site, ROOT if shard["family"] == "engines" else sources[side])
        for side, site in sites.items()
    }
    baseline_ids = baseline_case_ids(baseline_source, shard)
    cases = shard_cases(shard)
    report = {
        "contract": CONTRACT,
        "harness_sha256": harness_sha256(),
        "shard": shard,
        "releases": releases,
        "baseline_case_ids": None if baseline_ids is None else sorted(baseline_ids),
        "cases": [],
        "errors": [],
    }
    order = _case_order(len(cases))
    for index in order:
        case = cases[int(index)]
        print(f"Measuring {case['id']}", flush=True)
        kind = comparison_kind(case, baseline_ids)
        row = await measure_case(
            case, kind, workers_by_side, releases, root / f"case-{index}"
        )
        report["cases"].append(row)
        (root / "results.json").write_text(
            json.dumps(report, indent=2, allow_nan=False) + "\n", encoding="utf-8"
        )
    return report
