"""Discover and retain every Rust bench target, including specialized reports."""

from __future__ import annotations

import hashlib
import json
import shutil
import tomllib
from pathlib import Path

from scripts.benchmark_suite.asof import asof_rows
from scripts.benchmark_suite.asof_e2e import asof_e2e_rows
from scripts.benchmark_suite.asof_eviction import asof_eviction_rows
from scripts.benchmark_suite.catalog import CONTRACT
from scripts.benchmark_suite.dependency_migrations import (
    applied_dependency_migrations,
    load_dependency_migrations,
    stamp_dependency_migrations,
)
from scripts.benchmark_suite.join_materialization import materialization_rows
from scripts.benchmark_suite.legacy import combine_blocks
from scripts.benchmark_suite.migrations import declared_migrations, load_migrations
from scripts.benchmark_suite.normalize import criterion_rows, read_json
from scripts.benchmark_suite.process import ROOT, child_environment, command
from scripts.benchmark_suite.provenance import harness_sha256
from scripts.benchmark_suite.rust_harness import (
    TARGET as JOIN_HARNESS_TARGET,
)
from scripts.benchmark_suite.rust_harness import (
    common_join_harness,
    with_harness_migrations,
    with_measured_harness,
)
from scripts.benchmark_suite.rust_provenance import (
    target_dependency_fingerprint,
    with_compiled_dependencies,
)
from scripts.benchmark_suite.sql_stream import sql_stream_rows
from scripts.benchmark_suite.window_groups import window_groups_rows
from scripts.verify_sql_datafusion_performance import verify_report
from scripts.write_criterion_provenance import build_provenance


def clear_stale_bench_binary(shared: Path, target: str) -> None:
    """Remove restored bench executables so each side links its own source.

    The shared target directory is cached across runs and hosts builds from
    both source trees. A restored executable whose unit hash collides with
    this side's can otherwise be re-selected as fresh, silently measuring the
    other revision's benchmark.
    """

    for stale in shared.glob(f"release/deps/{target}-*"):
        stale.unlink()


def bench_targets(source: Path) -> list[str]:
    manifest = tomllib.loads(
        (source / "crates/calc-flow/Cargo.toml").read_text(encoding="utf-8")
    )
    targets = [entry["name"] for entry in manifest["bench"]]
    if not targets or len(targets) != len(set(targets)):
        raise ValueError("invalid Rust benchmark inventory")
    return targets


def clear_stale_product_library(shared: Path) -> None:
    # Cargo unit hashes can collide across worktrees with different product code.
    for suffix in ("rlib", "rmeta"):
        for stale in shared.glob(f"release/deps/libcalc_flow-*.{suffix}"):
            stale.unlink()


async def build_binaries(
    source: Path, output: Path, shared: Path, *, targets: tuple[str, ...] | None = None
) -> dict:
    targets = targets if targets is not None else bench_targets(source)
    manifest_path = source / "crates/calc-flow/Cargo.toml"
    manifest = (
        tomllib.loads(manifest_path.read_text(encoding="utf-8"))
        if manifest_path.is_file()
        else {}
    )
    target_features = {
        entry["name"]: entry.get("required-features", [])
        for entry in manifest.get("bench", [])
    }
    clear_stale_product_library(shared)
    environment = {
        **child_environment(),
        "CARGO_TARGET_DIR": str(shared),
        "CARGO_BUILD_JOBS": "2",
        "CARGO_INCREMENTAL": "0",
    }
    binaries = {}
    for target in targets:
        features = target_features.get(target, [])
        feature_args = ["--features", ",".join(features)] if features else []
        log = output / f"build-{target}.jsonl"
        clear_stale_bench_binary(shared, target)
        # Loop alignment was added to stabilize a since-retired sub-nanosecond
        # core getter benchmark. Removing it would shift every core timing, so
        # it stays until a measured change retires it. Align only the bench
        # target's loops; cargo rustc passes the extra codegen flag to that
        # target, not its deps.
        argv = (
            [
                "cargo",
                "rustc",
                "--locked",
                "--profile",
                "bench",
                "-p",
                "calc-flow",
                *feature_args,
                "--bench",
                target,
                "--message-format=json",
                "--",
                "-C",
                "llvm-args=--align-loops=64",
            ]
            if target == "core"
            else [
                "cargo",
                "bench",
                "--locked",
                "-p",
                "calc-flow",
                *feature_args,
                "--bench",
                target,
                "--no-run",
                "--message-format=json",
            ]
        )
        with common_join_harness(source, output, target) as build_source:
            await command(
                argv,
                cwd=build_source,
                log=log,
                env=environment,
            )
        destination = output / target
        shutil.copy2(_compiled_executable(log, target), destination)
        binaries[target] = destination
    return binaries


def _compiled_executable(log: Path, target: str) -> str:
    artifacts = []
    for line in log.read_text(encoding="utf-8").splitlines():
        if not line.startswith("{"):
            continue
        item = json.loads(line)
        if (
            item.get("reason") == "compiler-artifact"
            and item["target"]["name"] == target
            and item.get("executable")
        ):
            artifacts.append(item["executable"])
    if len(artifacts) != 1:
        raise ValueError(f"expected one compiled executable for {target}")
    return artifacts[0]


SQL_MINIMUM_SAMPLES = 20


def _require_baseline_samples(
    case_name: object, engine_name: str, samples: object
) -> list[float]:
    if not isinstance(samples, list):
        raise ValueError(f"baseline {case_name}/{engine_name} samples are incomplete")
    if len(samples) < SQL_MINIMUM_SAMPLES or any(
        isinstance(value, bool) or not isinstance(value, int | float) or value <= 0
        for value in samples
    ):
        raise ValueError(f"baseline {case_name}/{engine_name} samples are incomplete")
    return samples


def _baseline_report_rows(report: dict) -> dict:
    """Read one frozen baseline report under its own legacy field contract.

    The baseline evidence was verified under its contemporary contract when
    that revision was the candidate; this comparison consumes only per-case
    samples, so an older field set (for example before ``output_rows``)
    stays readable without weakening the candidate verifier.
    """

    if not isinstance(report.get("cases"), list) or not report["cases"]:
        raise ValueError("baseline sql report has no cases")
    rows = {}
    for case in report["cases"]:
        for engine in ("calc_flow", "raw_datafusion"):
            samples = _require_baseline_samples(
                case.get("name"), engine, case.get(engine, {}).get("samples_ms")
            )
            rows[f"sql_datafusion_performance/{case['name']}/{engine}"] = {
                "samples": [value / 1000 for value in samples],
                "rows": case["rows"],
                "scope": "native-sql-paired-boundary",
                "metadata": {
                    "environment": report["environment"],
                    "correctness": case["correctness"],
                    "engine": case[engine],
                },
            }
    return rows


def sql_rows(path: Path, *, side: str) -> dict:
    report = read_json(path)
    if side == "baseline":
        return _baseline_report_rows(report)
    verify_report(report, minimum_samples=SQL_MINIMUM_SAMPLES, require_stable=False)
    return {
        f"sql_datafusion_performance/{case['name']}/{engine}": {
            "samples": [value / 1000 for value in case[engine]["samples_ms"]],
            "rows": case["rows"],
            "scope": "native-sql-paired-boundary",
            "metadata": {
                "environment": report["environment"],
                "correctness": case["correctness"],
                "engine": case[engine],
            },
        }
        for case in report["cases"]
        for engine in ("calc_flow", "raw_datafusion")
    }


async def run_binary(
    target: str, binary: Path, source: Path, output: Path, side: str
) -> dict:
    environment = {**child_environment(), "CRITERION_HOME": str(output / "criterion")}
    if target == "stream_asof_eviction":
        path = output / "asof-eviction.json"
        await command(
            [str(binary), "--samples", "20", "--output", str(path)],
            cwd=source,
            log=output / "run.log",
            env=environment,
        )
        return asof_eviction_rows(path)
    if target == "stream_asof_perf":
        path = output / "asof.json"
        await command(
            [str(binary), "--output", str(path)],
            cwd=source,
            log=output / "run.log",
            env=environment,
        )
        return asof_rows(path)
    if target == "stream_window_groups":
        path = output / "window-groups.json"
        await command(
            [str(binary), "--samples", "20", "--output", str(path)],
            cwd=source,
            log=output / "run.log",
            env=environment,
        )
        return window_groups_rows(path)
    if target == "stream_sql_aggregate":
        path = output / "sql-stream.json"
        await command(
            [str(binary), "--samples", "20", "--output", str(path)],
            cwd=source,
            log=output / "run.log",
            env=environment,
        )
        return sql_stream_rows(path)
    if target == "stream_asof_e2e":
        path = output / "asof-e2e.json"
        await command(
            [str(binary), "--output", str(path)],
            cwd=source,
            log=output / "run.log",
            env=environment,
        )
        return asof_e2e_rows(path)
    if target == "stream_join_materialization":
        path = output / "materialization.json"
        await command(
            [str(binary), "--output", str(path)],
            cwd=source,
            log=output / "run.log",
            env=environment,
        )
        return materialization_rows(path)
    if target == "sql_datafusion_performance":
        path = output / "sql.json"
        await command(
            [
                str(binary),
                "--profile",
                "matched-adaptive",
                "--samples",
                "20",
                "--warmups",
                "1",
                "--output",
                str(path),
            ],
            cwd=source,
            log=output / "run.log",
            env=environment,
        )
        return sql_rows(path, side=side)
    await command(
        [str(binary), "--bench"], cwd=source, log=output / "run.log", env=environment
    )
    return {
        f"{target}/{name}": row
        for name, row in criterion_rows(output / "criterion").items()
    }


async def allocation(binary: Path, source: Path, output: Path, side: str) -> dict:
    path = output / "allocation.json"
    role = "baseline" if side == "baseline" else "candidate"
    await command(
        [
            str(binary),
            "--warmup-dispatches",
            "1000",
            "--measured-dispatches",
            "10000",
            "--repetitions",
            "10",
            "--cases",
            "all-existing-data",
            "--role",
            role,
            "--output",
            str(path),
        ],
        cwd=source,
        log=output / "allocation.log",
        env=child_environment(),
    )
    report = read_json(path)
    if report["valid"] is not True or not report["cases"]:
        raise ValueError("allocation evidence is invalid or empty")
    return report


def _validate_allocation_report(side: str, report: dict) -> None:
    names = [case["name"] for case in report["cases"]]
    if report["role"] != side or report["valid"] is not True:
        raise ValueError("invalid allocation report or version role")
    if not names or len(names) != len(set(names)):
        raise ValueError("empty or duplicate allocation case inventory")


def _allocation_metric(name: str, metric: str, sides: dict) -> dict:
    values = {
        side: [rep["normalized"][metric] for rep in cases[name]["repetitions"]]
        for side, cases in sides.items()
    }
    return {
        "id": f"rust/allocation/{name}/{metric}",
        "family": "rust",
        "backend": "calc-flow",
        "scenario": name,
        "scope": "allocation-counter",
        "status": "ok",
        "kind": "metric",
        "metric": metric,
        "baseline_value": min(values["baseline"]),
        "candidate_value": min(values["candidate"]),
        "correctness": True,
    }


def _allocation_case_index(reports: dict) -> dict:
    for side, report in reports.items():
        _validate_allocation_report(side, report)
    sides = {
        side: {case["name"]: case for case in report["cases"]}
        for side, report in reports.items()
    }
    if set(sides["baseline"]) != set(sides["candidate"]):
        raise ValueError("allocation case sets differ")
    return sides


def allocation_rows(reports: dict) -> list[dict]:
    sides = _allocation_case_index(reports)
    rows = []
    for name, case in sides["candidate"].items():
        if not case["valid"] or not sides["baseline"][name]["valid"]:
            raise ValueError(f"invalid allocation case {name}")
        for metric in ("calls_per_dispatch", "bytes_per_dispatch"):
            rows.append(_allocation_metric(name, metric, sides))
    return rows


def _rust_provenance(roots: dict, output: Path) -> dict:
    identities = {}
    for side, source in roots.items():
        identity = with_measured_harness(
            build_provenance(
                source,
                [
                    Path(f"crates/calc-flow/benches/{name}.rs")
                    for name in bench_targets(source)
                ],
            ),
            output / side,
        )
        identities[side] = with_compiled_dependencies(
            identity,
            source,
            {
                name: output / side / f"build-{name}.jsonl"
                for name in bench_targets(source)
            },
            build_roots={
                target: Path(record["build_source"])
                for target, record in identity.get("measured_harnesses", {}).items()
            },
        )
    return identities


async def measure_rust(shard: dict, releases: dict, roots: dict, output: Path) -> dict:
    shared = ROOT / "target/benchmark-rust-build"
    binaries = {
        side: await build_binaries(source, output / side, shared)
        for side, source in roots.items()
    }
    provenance = _rust_provenance(roots, output)
    if set(binaries["baseline"]) - set(binaries["candidate"]):
        raise ValueError(
            "Rust benchmark targets removed; an explicit migration is required"
        )
    blocks = {side: [] for side in roots}
    errors = []
    migrations = load_migrations(ROOT)
    applied = with_harness_migrations(
        declared_migrations(provenance, migrations), provenance, migrations
    )
    stamps = stamp_dependency_migrations(
        provenance,
        _stamp_fingerprints(provenance, applied),
        load_dependency_migrations(),
    )
    for index, side in enumerate(("baseline", "candidate", "candidate", "baseline")):
        block, failures = await _rust_block(
            binaries[side],
            roots[side],
            output / f"block-{index}-{side}",
            stamps[side],
            side,
        )
        errors.extend(f"{side}/{error}" for error in failures)
        blocks[side].append(block)
        (output / "blocks.json").write_text(
            json.dumps(blocks, indent=2) + "\n", encoding="utf-8"
        )
    cases = combine_blocks(shard, _without_retired_cases(blocks, applied))
    try:
        reports = await _allocation_reports(binaries, roots, output)
        cases.extend(allocation_rows(reports))
    except Exception as error:
        errors.append(f"allocation_regression: {error}")
    return {
        "contract": CONTRACT,
        "harness_sha256": harness_sha256(),
        "provenance": provenance,
        "binary_sha256": _binary_hashes(binaries),
        "shard": shard,
        "releases": releases,
        "cases": cases,
        "errors": errors,
        "expected_case_ids": [case["id"] for case in cases],
        "workload_migrations": sorted(
            applied.values(), key=lambda entry: entry["target"]
        ),
        "dependency_migrations": applied_dependency_migrations(stamps),
    }


def _target(name: str) -> str:
    return name.split("/", 1)[0]


def _names(side_blocks: list[dict]) -> set[str]:
    return {name for block in side_blocks for name in block}


def _measured_targets(side_blocks: list[dict]) -> set[str]:
    """Targets that report at least one case in every block of one side."""
    targets = [{_target(name) for name in block} for block in side_blocks]
    return set.intersection(*targets) if targets else set()


def _retired_cases(blocks: dict, applied: dict) -> set[str]:
    removed = _names(blocks["baseline"]) - _names(blocks["candidate"])
    eligible = _measured_targets(blocks["candidate"]) & applied.keys()
    return {name for name in removed if _target(name) in eligible}


def _without_retired_cases(blocks: dict, applied: dict) -> dict:
    """Drop cases a declared migration removed from the candidate bench source.

    A migrated target's candidate inventory is authoritative once the candidate
    measured that target: a case only its baseline blocks still report was
    removed deliberately. Without a declaration it stays a missing-block error.
    """
    retired = _retired_cases(blocks, applied)
    return {
        side: [
            {name: row for name, row in block.items() if name not in retired}
            for block in values
        ]
        for side, values in blocks.items()
    }


async def _allocation_reports(binaries: dict, roots: dict, output: Path) -> dict:
    return {
        side: await allocation(
            values["allocation_regression"], roots[side], output / side, side
        )
        for side, values in binaries.items()
    }


def _binary_hashes(binaries: dict) -> dict:
    return {
        side: {
            name: hashlib.sha256(path.read_bytes()).hexdigest()
            for name, path in values.items()
        }
        for side, values in binaries.items()
    }


def _with_fingerprints(measured: dict, fingerprints: dict) -> dict:
    return {
        name: {**row, "metadata": {**row["metadata"], **fingerprints}}
        for name, row in measured.items()
    }


def _migration_marker(declared: dict | None) -> dict:
    """Mark rows accepted through one declared migration with its reference."""
    return {} if declared is None else {"workload_migration": declared["reference"]}


def _stamp_fingerprints(provenance: dict, applied: dict) -> dict:
    """Per-side, per-target fingerprint metadata for row stamping.

    Each target's rows carry its own scoped workload fingerprint, so a changed
    bench source invalidates only that target; a declared migration re-baselines
    the stamp to the candidate identity and records its reference instead.
    """
    _require_common_harness(provenance)
    candidate_scoped = provenance["candidate"]["scoped_workload_fingerprints"]
    return {
        side: {
            target: {
                "machine_fingerprint": identity["machine_fingerprint"],
                "dependency_fingerprint": target_dependency_fingerprint(
                    identity, target
                ),
                "workload_fingerprint": identity.get(
                    "measured_workload_fingerprints", {}
                ).get(
                    target, candidate_scoped[target] if target in applied else scoped
                ),
                **_migration_marker(applied.get(target)),
            }
            for target, scoped in identity["scoped_workload_fingerprints"].items()
        }
        for side, identity in provenance.items()
    }


def _require_common_harness(provenance: dict) -> None:
    baseline_identity = provenance.get("baseline", {})
    candidate_identity = provenance["candidate"]
    baseline = baseline_identity.get("measured_harnesses", {})
    candidate = candidate_identity.get("measured_harnesses", {})
    baseline_targets = baseline_identity.get("scoped_workload_fingerprints", {})
    candidate_targets = candidate_identity["scoped_workload_fingerprints"]
    shared = baseline_targets.keys() & candidate_targets.keys() & {JOIN_HARNESS_TARGET}
    for target in baseline.keys() | candidate.keys() | shared:
        if _candidate_only_harness(target, baseline_identity, candidate_identity):
            continue
        if (
            target not in baseline
            or target not in candidate
            or any(
                baseline[target][key] != candidate[target][key]
                for key in ("measured_sha256", "harness_git_sha")
            )
        ):
            raise ValueError(
                f"Rust comparison requires a common measured harness: {target}"
            )


def _candidate_only_harness(target: str, baseline: dict, candidate: dict) -> bool:
    return (
        target not in baseline.get("scoped_workload_fingerprints", {})
        and target in candidate["scoped_workload_fingerprints"]
        and target not in baseline.get("measured_harnesses", {})
    )


async def _rust_block(
    binaries: dict, source: Path, output: Path, stamps: dict, side: str
) -> tuple[dict, list[str]]:
    block, errors = {}, []
    for target, binary in binaries.items():
        if target == "allocation_regression":
            continue
        try:
            measured = await run_binary(target, binary, source, output / target, side)
            block.update(_with_fingerprints(measured, stamps[target]))
        except Exception as error:
            errors.append(f"{target}: {error}")
    return block, errors
