"""Validate release identities and original per-sample evidence before reporting."""

from __future__ import annotations

import re

from scripts.benchmark_suite.catalog import (
    CONTRACT,
    POLARS_ENGINE,
    comparison_kind,
    get_shard,
    polars_thread_count,
    shard_cases,
    worker_thread_count,
)
from scripts.benchmark_suite.dependency_migrations import validate_dependency_migrations
from scripts.benchmark_suite.measure import validate_stream_sample
from scripts.benchmark_suite.provenance import harness_sha256
from scripts.benchmark_suite.report import SAMPLES, comparison, validate_shards
from scripts.toolkit import FULL_SHA


def validate_shape(report: dict) -> dict:
    if not isinstance(report, dict):
        raise ValueError("benchmark artifact must be an object")
    shard = get_shard(report["shard"]["id"])
    if not isinstance(report["cases"], list) or not isinstance(report["errors"], list):
        raise ValueError("cases and errors must be lists")
    if any(not isinstance(error, str) for error in report["errors"]):
        raise ValueError("errors must be strings")
    for case in report["cases"]:
        _validate_case_shape(case, shard)
    return shard


def _validate_case_shape(case: dict, shard: dict) -> None:
    if not isinstance(case, dict) or not isinstance(case.get("id"), str):
        raise ValueError("each result must have a string case id")
    if not isinstance(case.get("scope"), str) or case.get("status") not in (
        "ok",
        "error",
    ):
        raise ValueError("each result must declare its status and timing scope")
    if case.get("family") != shard["family"]:
        raise ValueError("case family differs from its shard")


def validate_releases(releases: dict, base: str, head: str) -> None:
    for side, expected in (("baseline", base), ("candidate", head)):
        release = releases[side]
        if (
            not FULL_SHA.fullmatch(expected)
            or release["git_sha"] != expected
            or release["git_clean"] is not True
            or release["build_profile"] != "release"
            or not re.fullmatch("[0-9a-f]{64}", release["native_sha256"])
        ):
            raise ValueError(f"{side}: not a clean release build at the expected SHA")


def _validate_round(case: dict, evidence: dict, releases: dict) -> None:
    sides = (
        {"candidate"}
        if case["comparison"] in ("external", "new")
        else {"baseline", "candidate"}
    )
    if set(evidence["samples"]) != sides:
        raise ValueError("measured worker roles differ from the comparison contract")
    _validate_completion(evidence["completion"], sides)
    if evidence["native_sha256"] != {
        side: releases[side]["native_sha256"] for side in sides
    }:
        raise ValueError("raw worker native hashes differ from release manifests")
    for samples in evidence["samples"].values():
        _validate_measurements(samples)
        for sample in samples:
            validate_stream_sample(case, sample)
    if case["family"] == "warm":
        _validate_cursors(case, evidence)


def _validate_completion(completion: dict, sides: set[str]) -> None:
    if set(completion) != sides or any(
        completion[side]["state"] != "completed" for side in sides
    ):
        raise ValueError("worker completion was not established")


def _validate_measurements(samples: list[dict]) -> None:
    if len(samples) != SAMPLES:
        raise ValueError("confirmation round has an incomplete sample inventory")
    if any(sample["correctness"]["passed"] is not True for sample in samples):
        raise ValueError("a measured output failed correctness")


def _validate_cursors(case: dict, evidence: dict) -> None:
    expected = [
        case["history_rows"] + case["rows"] * (index + 1) for index in range(SAMPLES)
    ]
    for samples in evidence["samples"].values():
        if [sample["start_row"] for sample in samples] != expected:
            raise ValueError("warm base/head sample cursors differ")


def _validate_evidence(case: dict, releases: dict) -> None:
    rounds = case["evidence"]
    if len(rounds) != 2 or rounds[0]["environment"] != rounds[1]["environment"]:
        raise ValueError("missing confirmation or changed environment")
    environment = rounds[0]["environment"]
    if (
        case.get("backend") in ("polars", "polars-1t")
        and environment.get("polars_engine") != POLARS_ENGINE
    ):
        raise ValueError("unexpected Polars collection engine")
    if environment["polars_threads"] != polars_thread_count(case) or environment[
        "tokio_worker_threads"
    ] != str(worker_thread_count(case)):
        raise ValueError("unexpected worker thread configuration")
    for side in ("baseline", "candidate"):
        actual = _evidence_seconds(case, side)
        if actual != case[side]:
            raise ValueError("summary samples differ from raw worker evidence")
    for evidence in rounds:
        _validate_round(case, evidence, releases)
    comparison(case)


def _evidence_seconds(case: dict, side: str) -> list[list[float]]:
    if side == "baseline" and case["comparison"] in ("external", "new"):
        return []
    return [
        [sample["seconds"] for sample in evidence["samples"].get(side, [])]
        for evidence in case["evidence"]
    ]


def _validate_catalog_cases(report: dict, shard: dict) -> None:
    expected = {case["id"]: case for case in shard_cases(shard)}
    for case in report["cases"]:
        if any(case.get(key) != value for key, value in expected[case["id"]].items()):
            raise ValueError(f"{case['id']}: workload dimensions changed")
        if case["status"] != "ok":
            continue
        baseline_ids = report.get("baseline_case_ids")
        kind = comparison_kind(
            case, None if baseline_ids is None else frozenset(baseline_ids)
        )
        if case["comparison"] != kind:
            raise ValueError("comparison kind differs from the baseline catalog")
        _validate_evidence(case, report["releases"])


def validate_fragment(
    report: dict, base: str, head: str, rust_base: str | None = None
) -> None:
    shard = validate_shape(report)
    if report["contract"] != CONTRACT or shard != report["shard"]:
        raise ValueError("report contract or shard differs from the current catalog")
    # The Rust shard keeps the first-parent baseline while every other family
    # anchors at the resolved release baseline.
    expected = (
        rust_base if rust_base is not None and shard["family"] == "rust" else base
    )
    validate_releases(report["releases"], expected, head)
    if report["harness_sha256"] != harness_sha256():
        raise ValueError(
            "measurement harness or dependency lock differs from the candidate"
        )
    _validate_inventory(report, shard)
    if shard["family"] in ("engines", "warm"):
        _validate_catalog_cases(report, shard)
    if shard["family"] == "rust":
        validate_dependency_migrations(report)


def _validate_inventory(report: dict, shard: dict) -> None:
    expected = (
        [case["id"] for case in shard_cases(shard)]
        if shard["family"] in ("engines", "warm")
        else report["expected_case_ids"]
    )
    if not expected:
        raise ValueError("benchmark inventory is empty")
    validate_shards(expected, [case["id"] for case in report["cases"]])
