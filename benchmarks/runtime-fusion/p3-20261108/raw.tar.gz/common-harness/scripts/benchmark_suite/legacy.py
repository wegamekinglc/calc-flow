"""Preserve existing fixture boundaries; compare whole-suite blocks honestly."""

from __future__ import annotations

import hashlib
import json
import os
import re
import sys
from pathlib import Path

from scripts.benchmark_suite.catalog import CONTRACT
from scripts.benchmark_suite.dependency_migrations import dependency_migration_problem
from scripts.benchmark_suite.identity import IDENTITIES, validate_component
from scripts.benchmark_suite.normalize import pytest_rows, read_json
from scripts.benchmark_suite.process import ROOT, child_environment, command, install
from scripts.benchmark_suite.provenance import harness_sha256
from scripts.benchmark_suite.report import comparison, validate_shards
from scripts.toolkit import sha256_file


def pytest_arguments(family: str) -> list[str]:
    if family == "lifecycle":
        return [
            "benchmarks/test_symbolic_baseline.py::test_stream_window_checkpoint_and_recovery"
        ]
    return ["benchmarks", "-m", "not stream_lifecycle"]


async def _pytest_run(shard: dict, source: Path, site: Path, output: Path) -> dict:
    environment = {
        **child_environment(site),
        "PYTHONPATH": os.pathsep.join(str(path) for path in (site, source, ROOT)),
        "CALC_FLOW_BENCHMARK_SCALE": shard.get("scale", "standard"),
        "CALC_FLOW_SUITE_INVENTORY": str(output / "inventory.json"),
    }
    await command(
        [
            sys.executable,
            str(ROOT / "scripts/benchmark_suite/pytest_driver.py"),
            *pytest_arguments(shard["family"]),
            "-q",
            "--benchmark-only",
            "--benchmark-save-data",
            f"--benchmark-json={output / 'pytest.json'}",
        ],
        cwd=source,
        log=output / "run.log",
        env=environment,
    )
    rows = pytest_rows(output / "pytest.json")
    validate_shards(read_json(output / "inventory.json"), list(rows))
    rows = {
        name: {
            **row,
            "metadata": {
                **row["metadata"],
                "benchmark_support_sha256": sha256_file(ROOT / "benchmarks/support.py"),
                "benchmark_source_sha256": hashlib.sha256(
                    (source / name.split("::", 1)[0]).read_bytes()
                ).hexdigest(),
            },
        }
        for name, row in rows.items()
    }
    if shard["family"] == "lifecycle":
        await command(
            [
                sys.executable,
                str(ROOT / "scripts/verify_stream_lifecycle_evidence.py"),
                str(output / "pytest.json"),
                "--minimum-rounds",
                "20",
            ],
            cwd=source,
            log=output / "verify.log",
            env=environment,
        )
    return rows


async def _setup(releases: dict, output: Path) -> dict:
    sites = {}
    for side in ("baseline", "candidate"):
        sites[side] = await install(releases[side], output / side)
    return sites


def combine_blocks(shard: dict, blocks: dict) -> list[dict]:
    available = [block for values in blocks.values() for block in values]
    names = sorted({name for block in available for name in block})
    result = []
    for name in names:
        descriptor = _latest_descriptor(name, available)
        result.append(_block_row(shard, name, descriptor, blocks))
    if not result:
        raise ValueError("legacy suite produced no cases")
    return result


def _latest_descriptor(name: str, available: list[dict]) -> dict:
    return next(block[name] for block in reversed(available) if name in block)


def _is_new_coverage(name: str, blocks: dict) -> bool:
    """A benchmark the candidate added has no baseline to pair against."""

    candidate_blocks = blocks["candidate"]
    baseline_blocks = blocks["baseline"]
    return all(name in block for block in candidate_blocks) and not any(
        name in block for block in baseline_blocks
    )


def _block_row(shard: dict, name: str, descriptor: dict, blocks: dict) -> dict:
    row = {
        "id": f"{shard['id']}/{name}",
        "family": shard["family"],
        "backend": "calc-flow",
        "scenario": name,
        "rows": descriptor["rows"],
        "scope": descriptor["scope"],
        "metadata": descriptor["metadata"],
    }
    if _is_new_coverage(name, blocks):
        candidate = [block[name]["samples"] for block in blocks["candidate"]]
        return {
            **row,
            "status": "ok",
            "correctness": True,
            "comparison": "new",
            "baseline": [],
            "candidate": candidate,
            "result": comparison(
                {
                    **row,
                    "status": "ok",
                    "correctness": True,
                    "comparison": "new",
                    "baseline": [],
                    "candidate": candidate,
                }
            ),
        }
    problem = block_problem(name, blocks, rust=shard["family"] == "rust")
    if problem:
        return {**row, "status": "error", "error": problem}
    row = {
        **row,
        "status": "ok",
        "correctness": True,
        "comparison": "suite-blocks",
        **{
            side: [block[name]["samples"] for block in values]
            for side, values in blocks.items()
        },
    }
    return {**row, "result": comparison(row)}


def _missing_block(name: str, blocks: dict) -> bool:
    return any(
        len(values) != 2 or any(name not in block for block in values)
        for values in blocks.values()
    )


def block_problem(name: str, blocks: dict, *, rust: bool = False) -> str | None:
    if _missing_block(name, blocks):
        return "benchmark missing from a base/head confirmation block"
    rows = [block[name] for values in blocks.values() for block in values]
    problem = _descriptor_problem(rows)
    if problem:
        return problem
    return _fingerprint_problem(
        [row["metadata"] for row in rows],
        rust_blocks=(name, blocks) if rust else None,
    )


def _descriptor_problem(rows: list[dict]) -> str | None:
    for key in ("rows", "scope"):
        if any(row[key] != rows[0][key] for row in rows):
            return f"benchmark {key} changed; no timing classification"
    return None


def _fingerprint_problem(
    metadata: list[dict], *, rust_blocks: tuple[str, dict] | None = None
) -> str | None:
    problem = _raw_identity_problem(metadata) or _required_fingerprints_problem(
        metadata
    )
    if problem:
        return problem
    if rust_blocks is not None:
        problem = dependency_migration_problem(*rust_blocks)
        if problem:
            return problem
    return _matching_fingerprints_problem(
        metadata, check_dependency=rust_blocks is None
    )


def _matching_fingerprints_problem(
    metadata: list[dict], *, check_dependency: bool
) -> str | None:
    for key in (
        "machine_fingerprint",
        "dependency_fingerprint",
        "workload_fingerprint",
        "benchmark_source_sha256",
        "benchmark_support_sha256",
    ):
        if key == "dependency_fingerprint" and not check_dependency:
            continue
        if any(row.get(key) != metadata[0].get(key) for row in metadata):
            return f"benchmark {key} changed; no timing classification"
    return None


def _required_fingerprints_problem(metadata: list[dict]) -> str | None:
    for name in IDENTITIES:
        key = f"{name}_fingerprint"
        if any(
            not isinstance(row.get(key), str)
            or re.fullmatch(r"[0-9a-f]{64}", row[key]) is None
            for row in metadata
        ):
            return f"benchmark {key} missing or malformed; no timing classification"
    return None


def _raw_identity_problem(metadata: list[dict]) -> str | None:
    keys = [f"{name}_identity" for name in IDENTITIES] + ["benchmark_support_sha256"]
    if not any(key in row for row in metadata for key in keys):
        return None
    try:
        for row in metadata:
            for name in IDENTITIES:
                validate_component(row, name)
    except ValueError as error:
        return str(error)
    return None


async def validate_sources(roots: dict, releases: dict) -> None:
    from scripts.profile_warm_stream import source_identity

    for side, root in roots.items():
        identity = await source_identity(root)
        if identity["git_clean"] is not True or any(
            identity[key] != releases[side][key]
            for key in ("git_sha", "source_sha256", "cargo_lock_sha256")
        ):
            raise ValueError(f"{side} source checkout differs from the sealed release")


async def observe_workers(
    sites: dict, releases: dict, roots: dict, output: Path
) -> dict:
    from scripts.benchmark_suite.measure import validate_environment
    from scripts.benchmark_suite.process import Worker

    observed = {}
    for side, site in sites.items():
        worker = await Worker.start(
            site, output / side / "identity", source=roots[side]
        )
        try:
            observed[side] = validate_environment(
                await worker.request(operation="hello"), releases[side]
            )
        finally:
            await worker.close()
    if observed["baseline"] != observed["candidate"]:
        raise ValueError("legacy worker environments differ")
    return observed["candidate"]


async def measure_legacy(
    shard: dict, releases: dict, output: Path, baseline: Path | None
) -> dict:
    if baseline is None:
        raise ValueError("legacy comparison requires a baseline source checkout")
    roots = {"baseline": baseline.resolve(), "candidate": ROOT}
    await validate_sources(roots, releases)
    if shard["family"] == "rust":
        from scripts.benchmark_suite.rust import measure_rust

        return await measure_rust(shard, releases, roots, output)
    sites = await _setup(releases, output)
    environment = await observe_workers(sites, releases, roots, output)
    blocks = {"baseline": [], "candidate": []}
    report = {
        "contract": CONTRACT,
        "harness_sha256": harness_sha256(),
        "environment": environment,
        "shard": shard,
        "releases": releases,
        "errors": [],
        "cases": [],
    }
    for index, side in enumerate(("baseline", "candidate", "candidate", "baseline")):
        destination = output / f"block-{index}-{side}"
        destination.mkdir(parents=True, exist_ok=True)
        try:
            block = await _pytest_run(shard, roots[side], sites[side], destination)
            blocks[side].append(block)
        except Exception as error:
            report["errors"].append(f"{side} block {index}: {error}")
            blocks[side].append({})
        (output / "blocks.json").write_text(
            json.dumps(blocks, indent=2) + "\n", encoding="utf-8"
        )
    try:
        report["cases"] = combine_blocks(shard, blocks)
    except ValueError as error:
        report["errors"].append(str(error))
    report["expected_case_ids"] = [case["id"] for case in report["cases"]]
    return report
