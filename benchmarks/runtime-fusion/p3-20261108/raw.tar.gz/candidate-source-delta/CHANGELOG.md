# Changelog

This is the single history of Calc Flow's public surfaces, engine and Studio
capabilities, and documentation organization. Current usage and design are in
the [documentation index](docs/README.md).

Entries describe the state at their date, including superseded decisions and
measurements. Use the current guides for supported behavior.

## 2026-11

- 2026-11-08: Prepare the `calc-flow` Rust crate for crates.io with package
  metadata, a native quickstart, distribution and external consumer checks,
  and a separate release workflow. Audit the packaged registry lockfile before
  upload; the standard Arrow 59 dependency chain uses compatible zstd security
  backports without changing Python source builds or checkpoint contracts.
- 2026-11-08: Share input history across eligible different-width Float64
  Rows means and mean differences, including sorted SQL AVG windows. Keep
  independent accumulators and checkpoint bytes, credit each optional cache
  owner separately, and retain owned queues when the cache quota refuses an
  allocation. Cover held aliases, restore and serial output rejection or
  cancellation. End-to-end performance acceptance remains pending.

- 2026-11-07: Withdraw the delegated delta-aggregation prototype after
  measurement. Large compact-SUM batches ran their delta aggregation as a
  partitioned, template-reused DataFusion GROUP BY on a dedicated session
  and fed the grouped result through the ordinary kernel; the mechanism
  worked (800k-row batches aggregated in 6.7-8.9 ms at four partitions,
  content-equal to the serial path), but paired AB/BA runs measured -2.03%
  at 1M-row batches, 0.00% at 100k-row batches and -0.08% below the
  admission floor, all short of improvement: the inline kernel is already
  as fast as the delegated aggregate, so the large-batch gap lives in other
  serial stages. Preserve the prototype on `feature/sum-delta-delegation`
  and the [complete study](benchmarks/sum-state/sum-delta-delegation-20261107.md);
  this closes the third and final measured parallel-aggregate route.
- 2026-11-07: Record an explicitly requested both-engine core-count sweep
  (1/4/8/16/32 pinned CPUs, 10M-row stock positions, disclosed concurrent
  load). The SQL engine's large-batch aggregation scales 3.5x to sixteen
  cores while the streaming engine stays flat beyond four, and the SQL
  curve bounds the withdrawn delta-delegation route: large at four or more
  cores, free of the rejected sharding prototypes' routing and state
  round-trips, at the cost of the SQL engine's higher CPU budget. See the
  [sweep table](benchmarks/stock-positions/engine-core-sweep-20261107.md).

- 2026-11-07: Withdraw the key-sharded compact grouped SUM prototype after
  measurement. Sharding by the complete group key removed the rejected lane
  design's cross-group merges and produced byte-identical snapshots in unit
  tests, but paired AB/BA runs of the streaming stock-positions example
  (10M rows, checkpoints disabled, four pinned CPUs) measured +10.15% at
  100,000-row batches and +8.43% at 1,000,000-row batches: the routing pass
  and per-fragment state round-trips outweigh what four-thread parallelism
  saves on the already-optimized serial update. Preserve the prototype on
  `feature/sum-key-sharding` and the
  [complete study](benchmarks/sum-state/sum-key-sharding-20261107.md); the
  serial path remains delivered.

- 2026-11-07: Repair native SQL join admission for nested CTEs and column
  aliases, isolate rolling rewrite metrics per query, and bypass cached
  single-partition templates in experimental multi-partition runs. Charge ASOF output
  using its actual source buffers. Preserve zero-column rows, explicit empty
  records and captured materialized sequence inputs in Python streams; retain
  validation exception details when copied or serialized. Settle every
  benchmark worker when cleanup raises. Remove duplicate SQL predicate
  matching without changing admitted canonical queries.

- 2026-11-07: Extend input-free DataFusion query templates from single-table
  row-local plans to multi-table immutable plans built only from
  data-independent operators (projections, filters, aggregates, unions,
  sorts, repartitions) over in-memory scans; joins keep planning every run
  because their build side follows statistics, and limited queries keep
  planning because top-k operators carry execution-updated pruning filters.
  Template reuse is
  keyed by query text, aliases, exact schemas, and each run's effective
  partition count, and the fixed policy now shares the plan-level cache at
  any partition count. In a two-input state-feedback stock-positions probe
  (`UNION ALL` plus grouped `SUM`, one million rows, 100x100 keys, pinned
  four CPUs, two rounds of five alternating pairs), repeated batch SQL
  execution improved -41.03% (1,000-row batches, fixed p1), -33.37%
  (10,000-row batches, fixed p1), -27.76% (1,000-row batches, fixed p4), and
  -12.84% (100,000-row batches, fixed p1), with physical planning counts
  falling from one plan per batch to one plan total; all four paired
  verdicts were `improved` and outputs matched an independent accumulator.

- 2026-11-07: Share snapshot key columns across repeated compact-SQL
  snapshots. Group slots are append-only and group keys never change, so the
  key columns of a sealed output chunk are rebuilt in every full snapshot for
  nothing: staging new columns per transaction and installing them at commit
  lets every later snapshot reuse the committed Arrow arrays while a chunk's
  row count and first group are unchanged. A refused or failed output leaves
  nothing staged, and installed bytes are reserved from the incremental
  memory pool. In the streaming stock-positions example (2,000,000 business
  rows, 100x100 keys, checkpoints disabled) paired AB/BA runs improved
  -34.35% at 1,000-row batches on four pinned CPUs (wall 1541.5 to 1012.0 ms,
  child CPU 1.876 to 1.315 s) and -43.83% at 1,000-row batches on one pinned
  CPU (1755.5 to 986.0 ms); 10,000-row batches measured -9.19% and
  100,000-row batches stayed inconclusive (+3.02%, both round intervals
  spanning zero) with unchanged CPU time.

- 2026-11-06: Repeat the compiled integer sign CASE experiment in a quiet
  environment against main `5a66b6d5`. Complete five fixed cases, 200 formal
  observations, both CPU profiles and full snapshot checks. All maintained
  verdicts are inconclusive; neither dense case establishes the required
  improvement. Withdraw the runtime prototype and preserve the
  [complete retest evidence](benchmarks/sum-state/sum-case-retest-20261106.md)
  separately from the earlier stopped acquisition.

- 2026-11-06: Record a narrow compiled integer sign CASE experiment and its
  [source/allocation evidence](benchmarks/sum-state/sum-case-projection-20261106.md).
  Verify lower mixed-mask allocations and higher uniform-mask allocations.
  Stop the runtime comparison at its environment guard before any workload;
  withdraw the unmeasured runtime prototype and retain tools and evidence.

- 2026-11-06: Record a bounded grouped integer SUM candidate/rank experiment.
  Remove merge-time candidate lookups in the prototype, but obtain no accepted
  dense-stream improvement across five fixed cases. Withdraw runtime changes
  and preserve current main. Publish the
  [complete study](benchmarks/sum-state/sum-candidate-ranks-20261106.md),
  paired intervals, CPU profiles, correctness evidence and reproducible tools.

- 2026-11-05: Pin `arrow-data` and its required buffer/schema dependencies to
  59.3.2 to address `RUSTSEC-2026-0442`. Reject RunEndEncoded arrays whose run
  ends do not cover their logical offset plus length. Preserve the audit gates
  and add safe-construction regression controls.

- 2026-11-05: Record a bounded composite UTF-8 grouped `SUM` key experiment.
  Lower canonical encoding and allocated bytes in a focused probe, but obtain
  no confirmed dense-stream improvement in five fixed end-to-end cases.
  Withdraw the runtime prototype and preserve the existing key path. Publish
  the [complete study](benchmarks/sum-state/sum-columnar-keys-20261105.md),
  paired intervals, profiles, correctness checks and reproducible tools.
- 2026-11-05: Accept a non-empty list or tuple of materialized Arrow tables,
  record batches or table batches as one stream input. The sequence is
  schema-checked and concatenated without copying buffers, then replayed by the
  native Arrow source with its record boundaries intact, avoiding one Python
  source call per batch. Empty sequences, mismatched schemas and non-Arrow items
  are rejected; snapshot SQL and source-provided watermark rules are unchanged.


- 2026-11-05: Store a single grouped integer SQL `SUM` in one compact nullable
  state and cache its bound type metadata. Reduce selected dense-stream median
  elapsed time by 28.24% with one CPU and 31.18% with four CPUs, and sparse-stream
  elapsed time by 13.93%, in a frozen three-case comparison. Preserve generic group
  layout, transactional updates, and checkpoint encoding. See the
  [inline-state study](benchmarks/sum-state/sum-inline-state-20261105.md) for
  paired intervals, profiles, resource scope, and unmeasured paths.

- 2026-11-05: Expose the trusted active-entity count through
  `Batch.from_pyarrow(..., active_entities=n)` and `Batch.from_array(...)`, and
  add `BatchMetadata::with_datafusion_active_entities` for Rust callers. The
  value enables entity-aware `auto` partition selection for single-input batch
  graphs; zero or a conflicting existing value is rejected. Project and
  checkpoint formats are unchanged.
- 2026-11-05: Add an opt-in `parallelism_mode="auto_rows"` DataFusion policy.
  It derives the target-partition request from input rows and host capacity
  without requiring trusted active-entity statistics; valid entity metadata can
  only lower the request, and missing metadata is ignored instead of forcing one
  partition. Multi-input batch SQL uses the existing whole-run external-row
  policy, the default remains `fixed`, and project/checkpoint formats are
  unchanged.

- 2026-11-05: Record a bounded batch-parallel integer SQL `SUM` experiment and
  its reproducible profiling tools. Reject the runtime prototype after confirmed
  dense-stream regressions of 15.75% with four CPUs and 18.60% with eight CPUs.
  Preserve the serial runtime and publish the
  [complete experiment and follow-up direction](benchmarks/sum-state/sum-batch-parallel-20261104.md).

- 2026-11-04: Construct cumulative SQL UTF-8 grouping-key output from borrowed
  strings and share group lookups within each output chunk. Remove intermediate
  scalar-string clones while preserving complete snapshots, schemas,
  transactional updates and checkpoint layout. See the focused
  [output-construction report](benchmarks/sum-state/sum-followup-columnar-20261104/README.md).

- 2026-11-04: Merge grouped integer SQL `SUM` states in columns, reducing
  per-group accumulator construction and state conversion during cumulative
  streaming updates. Preserve wrapping integer arithmetic, null handling,
  transactional state updates, and checkpoint compatibility. See the focused
  [performance report](benchmarks/sum-state/README.md) for measured scope and
  before/after results.

- 2026-11-03: Allow explicitly configured stream row budgets and source batches
  above one million rows while retaining the default and strict edge admission.
  Preserve historical project-v3 omitted-field defaults. Derive stock demo
  budgets from batch and snapshot sizes, build Arrow columns directly, and
  report declared or actual batch costs in payload-free budget errors.

- 2026-11-02: Prepare the `calc-flow-python` 2026.11.2 release, aligning
  workspace crates, exact native dependencies, Python metadata, and current
  documentation. This release removes Pydantic and its transitive dependencies
  from the default Python installation. `ProjectDocument` retains native
  project-v3 validation, canonical JSON, and lightweight serialization with
  improved validation and dump performance. It now raises
  `ProjectValidationError`; Pydantic-specific `include`/`exclude` dump filters
  are not supported. Dependency metadata, benchmark support locks, and Rust
  example numbering are aligned accordingly. Project and managed checkpoint
  manifest format versions remain 3; engine and operator state compatibility
  checks still apply when restoring checkpoints.

- 2026-11-01: Prepare the `calc-flow-python` 2026.11.1 release, aligning
  workspace crates, exact native dependencies, Python metadata, and current
  documentation. This release optimizes native SQL ASOF top-1 and interval band
  execution, reduces streaming Join output and state overhead, and keeps
  single-match Join selections compact. It also reuses Python declaration
  preparation and finite SQL query preparation, reduces Arrow binding and result
  wrapping overhead, and adds Rust counterparts for the Python examples. Project
  and managed checkpoint manifest format versions remain 3; engine and operator
  state compatibility checks still apply when restoring checkpoints.

## 2026-10

- 2026-10-31: Compute fixed non-null Join output widths from schema, charge compact
  ASOF fixed output positions once, skip checkpoint-disabled log projection,
  store contiguous interval matches as ranges, and plan evictions with per-chunk
  bitmaps. Preserve cancellation, checkpoint identity, state recovery, pair
  ordering and output budgets.

- 2026-10-31: Add restricted native batch ASOF top-1 and interval band execution
  for recognized SQL shapes. Preserve the DataFusion fallback, null and unmatched
  rows, duplicate matches, timestamp handling, output schemas and query metrics,
  while avoiding window sorting and offset cross-join expansion.

- 2026-10-29: Reuse Python declaration preparation before repeated batch or
  stream compilation, with registration-scoped invalidation and independently
  owned stream plans. Convenience collection still creates a fresh native plan.
  Share join recovery input ownership and checked workspace helpers, and remove
  duplicate batch-input validation along trusted internal paths. Clarify append
  SQL compact state and complete-replacement snapshot SQL in the references.

- 2026-10-27: Prepare the `calc-flow-python` 2026.10.27 release, aligning
  workspace crates, exact native dependencies, Python metadata, and current
  documentation. This release adds cumulative extrema, sum, and variance;
  compact grouped ordered `LAST_VALUE` with explicit compact SQL state budgets;
  and complete-replacement `snapshot_sql` over latest initialized relations.
  The stock account valuation example now uses native snapshot SQL. It also
  includes checkpoint recovery and null-handling fixes, shared owned-state
  quotas, and SQL checkpoint work dispatch. Project and managed checkpoint
  manifest format versions remain 3; engine and operator state compatibility
  checks still apply when restoring checkpoints.

- 2026-10-21: Prepare the `calc-flow-python` 2026.10.21 release, aligning
  workspace crates, exact native dependencies, Python metadata, and current
  documentation. This release includes the DataFusion 55 / Arrow 59 upgrade,
  streaming Join, ASOF, and Window state and execution improvements, and native
  streaming ingress for materialized Arrow inputs. SQL checkpoints from
  DataFusion 54 and ASOF checkpoints marked with Arrow 58 require replay into
  a new job when upgrading; project and manifest format versions remain 3.

- 2026-10-20: Reuse source-column width checks and borrowed retained chunks
  during streaming Join output preparation. Hash bounded short-string blocks
  with shared cooperation accounting, and append interval match runs directly
  during worker fill and ordered result assembly. Store single-source ASOF
  output positions as compact nullable indices and preserve one-pass output
  gathering when multiple sources appear. Reuse partial-eviction summaries and
  move captured key owners directly into checkpoint tombstones. Preserve input
  transactions, explicit budgets, output order, and checkpoint identities.

- 2026-10-19: Prepare large streaming ASOF matches and output references in
  contiguous CPU-sized fragments, including a single hot key. Preserve local
  fragment references and shared Arrow spans, and allow narrow outputs to use
  row parallelism independently of their column count. Prepare interval Join
  retained-row charges and chunks on the owned native CPU pool, preserving
  source-order state admission. Optional acceleration yields to explicit memory
  limits; checkpoint formats and default memory policy remain unchanged.

- 2026-10-19: Reuse prepaid interval Join window bounds between parallel count
  and fill/gather, with cursor fallback under explicit memory pressure. Avoid
  repeated incoming-row output-width checks within each match run and check
  retained sparse replacement candidates per chunk owner instead of per row.
  Preserve inclusive bounds, stable pair ordering, resource limits, cancellation
  cleanup, and checkpoint formats.

- 2026-10-19: Extend CPU-aware streaming work beyond Join. Decouple ASOF compute
  routing from persistent shards and let explicit budgets size finalization
  prefixes. Scale warm ordered rolling mean/dual-SMA across whole-entity lanes,
  reuse entity counts, and build compact row schedules without private batch or
  scratch-byte ceilings. Reuse compiled
  immutable expression steps for repeated row-local SQL while preserving state,
  arithmetic order, explicit limits and checkpoint formats.
- 2026-10-19: Retain the existing serial cross-section mean after a complete-group
  parallel experiment regressed the selected million-row workload. Keep the
  rejected candidate and its measurements as evidence rather than enabling the
  slower path by default.
- 2026-10-19: Preserve project-v3 stream JSON's historical omitted budget values
  and connector-project fingerprints. New runtime constructors use the larger
  defaults, which remain explicit when exported from `StreamRunOptions`.
- 2026-10-19: Reduce repeated Join preparation scans by aggregating admitted-key
  frequencies, sharing dense row ranges, and mapping parallel fragments directly
  to final identities. Treat unresolved probe-only keys as misses during cost
  estimation. Pack admission masks into bounded internal messages and group
  native output records by the configured edge row/byte budgets while sharing
  Arrow buffers. Preserve deterministic identities, output order, sequence
  preflight, cancellation ownership, and explicit memory limits.
- 2026-10-19: Prepare large Join key groups on the bounded native CPU pool,
  preserving deterministic retained-row identity semantics and serial fallback.
  Extend funded row-wise probe/gather eligibility to large primitive narrow
  projections, retaining match, state and output budgets, and reuse incoming
  payload segments during output gathering. Prepay the full backing pinned by
  projected probe-only views so sealed-dimension joins can use that path.
  Batch graphs with
  multi-input SQL can opt into a run-scoped Auto partition budget based on
  external table row counts, so an earlier small node does not fix the run to
  one partition. Fixed defaults and checkpoint layouts are unchanged.
- 2026-10-18: Share Window group values across batches and checkpoint marks.
  Bind Join incoming metadata by segment, append admission blocks, and hash
  typed key columns in bounded scratch. Prepare native retained chunks without
  a whole-batch row-descriptor vector, share distinct chunk keys, and route
  native index append per distinct key. Restore native Join histories directly
  into chunks while preserving legacy migration and existing checkpoint formats.
- 2026-10-18: Apply post-merge review follow-ups to the Join performance
  work. Drop the batch-local key interning table when preparation ends
  instead of holding it and its credit until commit, and budget its hash
  table's power-of-two bucket growth. Retire keys aggregated by bulk
  eviction in deterministic first-appearance plan order rather than HashMap
  iteration order, keeping slot recycling reproducible. Right-size Join
  checkpoint tombstone lists and their expiration credit at each capture
  drain so a whole-side flush no longer stays resident for the operator's
  lifetime. Compute each row's small-key identity once and share it across
  hashing, dictionary walks and candidate comparisons on the per-row path.
  Also remove a changelog rebase artifact and a duplicated cfg(test)
  attribute. Checkpoint formats and observable behavior are unchanged.
- 2026-10-18: Admit Join rows through retain bitmaps, zero-copy views and
  batch-local key interning. Groups whose rows are all expired are skipped
  wholesale in retained-row assembly, charging and payload projection (the
  projection becomes a buffer-sharing view); mixed groups visit only the
  retained bits. Key identities are deduplicated per batch by typed column
  hashing and each DISTINCT key is resolved against the persistent
  dictionary once, with ids broadcast back and references aggregated, so
  births, ordering and checkpoint identities are bit-identical to the
  per-row path (dual-path equivalence tests included). Interleaved A/B on
  engines/1000000/calc-flow-stream: join medians fell from 314-348 ms to
  115-128 ms (about 2.5-3x; independent reviewer spot-check 290 -> 102 ms)
  and interval_join fell 11-16%; the 64-key workload now pays 64
  dictionary probes per 65,536-row batch instead of one per row.
- 2026-10-18: Compute constant-width Join output chunks by row count.
  When every selected output column on both sides is fixed-width and the
  source arrays report no nulls, per-row output bytes are constant, so the
  output preflight emits equal-length ranges by division instead of walking
  every matched pair; variable-width or nullable inputs keep the per-pair
  scan. Preflight-attributable self-time in the interval-join profile fell
  from about 6.4% to 3.8% (flat_row and bytes_with leave the hot path), and
  interleaved A/B against the branch's own base showed the fast path faster
  in 5 of 7 rounds (median about -6%).
- 2026-10-17: Route timestamp ± interval-month-day-nano arithmetic through a
  calendar fast path. A new optimizer rule rewrites the expression in filters
  and projections into crate-internal scalar UDFs; when every interval in a
  batch is pure nanoseconds divisible by the timestamp unit and both operands
  and the shifted result sit inside chrono's representable range, the UDF
  replaces the per-row timezone-aware calendar kernel with checked integer
  addition, and any other batch falls back whole to arrow's own kernels so
  results, null handling and errors match by construction. In interleaved A/B
  runs of `engines/1000000/calc-flow-sql/interval_join`, medians fell about
  1.6-2.6x (calmest rounds roughly 480 -> 300 ms on a loaded machine, versus
  a 338 ms unloaded baseline); the 1:1 `join` control is unchanged.
- 2026-10-18: Derive Join checkpoint deltas lazily and evict expired rows
  in bulk. Checkpointing no longer records one upsert per admitted row and
  one tombstone per evicted row: each side keeps a captured row_id
  watermark, upserts are derived from live state above the watermark at
  capture, and only below-watermark evictions enter a compact columnar
  tombstone list. Eviction cuts each sorted expiration run once, clears
  state chunks and native key runs per prefix, and retires dictionary
  references in aggregated counts. Checkpoint bytes for identical
  schedules are unchanged (oracle-tested against the old pending-log
  encoding), restores of old checkpoints are accepted unchanged, and the
  fresh-preparation watermark freeze that guards against row loss is
  pinned by its counterexample test. Interleaved A/B on
  engines/1000000/calc-flow-stream/interval_join: 1595 -> 1365 ms median
  (about -14.5%); stream join and projection are unchanged.
- 2026-10-17: Drive the Join time-window probe through per-key window
  cursors instead of two binary searches per counted row and two more per
  filled row. Serial and gather probes now advance monotone cursors by
  galloping and fall back to a full search for out-of-order windows, and the
  count pass's bounds are reused by the fill pass. Full-run searches per
  16,400-row gather batch drop from 32,800 to 6 in the pinned regression
  test, and `NativeIndex::window_by_id` leaves the interval-join profile
  top-20 (3.6% self to 1.0% for the remaining gallop advance); wall-clock on
  `engines/1000000/calc-flow-stream/interval_join` moves only about 2-3%,
  consistent with the search share. Cursor scratch (distinct keys x units x
  `Option<WindowCursor>`) is charged up front and a refusal declines to the
  sanctioned serial fallback unchanged.
- 2026-10-17: Add a synchronous small-key fast path for Join key identities,
  repairing part of the roughly 5× stream-join regression from PR #427. Keys
  whose framed bytes fit one copy quantum (at most 4096 bytes and fewer
  than 64 columns) hash, probe and compare synchronously after a single
  cooperative charge per row; larger keys keep the chunked async path, and
  cancellation is still observed per row and per collision-chain candidate.
  Hash and equality bytes are bit-identical to the chunked path, so
  dictionary, restore and checkpoint identities are unchanged. In
  interleaved A/B runs of `engines/1000000/calc-flow-stream/join`, timings
  fell from 492/496 ms to 370/372 ms (about 25%); key-identity preparation
  fell from 44% to 31% of Join CPU. The remaining gap to the pre-#427
  level of about 95 ms needs dictionary bookkeeping redesign and is
  tracked separately.
- 2026-10-17: Amortize Join projected-copy stop checks. Row scans in the
  selected-copy path (`checkpoint_v2/projected_copy` with its views and
  dictionary remap) check cancellation, deadline and abandonment once per
  4,096-row stride instead of once per row; per-column, per-run and
  per-allocation checks are unchanged and every stop point stays observable.
  The per-row path had been about 21% of Join CPU, with 16% in
  `CancellationToken::is_cancelled` (a mutex per call). In interleaved A/B
  runs of `engines/1000000/calc-flow-stream/join`, timings fell from
  797/761 ms to 662/615 ms (about 18%), and `GatherStop::check` dropped out
  of the profile top-25.
- 2026-10-17: Fix the 2.1–2.2× streaming interval-join regression introduced
  by PR #452 (chunked Join state and batch selections). Whole-selection match
  iteration now walks a sequential cursor over runs in O(pairs + runs)
  instead of binary-searching per pair, and output preflight caches row costs
  by dense bounded indexing instead of per-pair `BTreeMap` nodes, restoring
  the DAL-303 dense-cache bound with a gap-safe fallback. In interleaved A/B
  runs of `engines/1000000/calc-flow-stream/interval_join`, timings fell
  from 5086/5007 ms to 2042/2236 ms (2.3×), better than the pre-#452
  parent's 2261–2518 ms; the 1:1 streaming join case is unchanged.
- 2026-10-17: Anchor scheduled complete-benchmark baselines at the newest
  reachable `calc-flow-python-v*` release tag, falling back to the first
  parent only when no tag is reachable or the release commit is the head. The
  previous first-parent default let a merged regression become the baseline of
  every later run, so #427's stream-join regression was flagged exactly once
  and #452's interval regression was never paired. Manual dispatch and
  pull-request baselines are unchanged. The Rust shard keeps the first parent,
  or the explicit SHA when one is given, through a third `rust-baseline`
  wheel side, because its sealed harness compiles the candidate bench file
  against the baseline source. The complete report header records the resolved
  baseline provenance, invalid provenance renders `unresolved` and fails the
  gate closed, and cases added since the release report `new-coverage` until
  the next release.
- 2026-10-16: Upgrade the Rust and Python benchmark engines to DataFusion
  55.0.0 and the hash-locked Polars reference to 2.0.0. Move the Rust toolchain
  to its required 1.94.0 minimum, synchronize Arrow/Parquet 59.2 and the Python
  Arrow bridge, and adapt grouped state merges without allocating all-true
  filters. SQL checkpoints bind the compiled engine version and reject earlier
  engine state. Benchmark SQL provenance uses compiled crate versions, while
  Polars retains explicit streaming collection and reports that selection.
  Apply equivalent library lint updates required by the new toolchain without
  changing validation or CI gates. Preserve sparse-group nulls and canonical
  checkpoint fingerprints under DataFusion 55, account for Arrow terminal offsets
  per emitted array, and retain zero-width binary payload rows during ASOF
  admission. Symbolic square roots keep IEEE NaN behavior for negative inputs,
  while guarded rolling input schemas follow native nullability proofs. This
  upgrade makes no performance claim.
- 2026-10-16: Replace opt-in native benchmark process CPU ticks with the safe
  Linux process CPU clock and its reported resolution. Reject unavailable or
  invalid v2 clock metadata, retaining historical evidence and CPU thresholds.
  Seal the benchmark-only optional dependency in the common overlay and lock.
  This repairs measurement precision; it adds no performance acceptance result.

- 2026-10-16: Add an explicit milestone source policy for separately sealed
  original build and execution tools, with unchanged compiled inputs/recipes,
  complete Python/fixture seals and a verified Git diff. Retain exact B/C and
  receipt identities, all artifact gates and historical policies. Guard source
  checks before preparation-anchor creation. This tool change adds no performance
  result and does not close the outstanding acceptance targets.

- 2026-10-16: Add a current-milestone Join/ASOF acceptance controller with both
  sealed revisions in OFF, LOW and ON modes, absolute mode thresholds, ASOF10M
  and interval1M planning cases, and a full interval output oracle. Charge actual
  preparation time inside the fixed acquisition budget and retain historical
  policies separately. This tooling preparation makes no performance claim;
  genuine during-compaction handler overlap remains unmeasured.

- 2026-10-16: Retain Join/ASOF ingress receivers through supervised failure
  publication and cancellation. Preserve the underlying operator reason and
  detail when preparation workers stop; upstream edge-close errors remain
  secondary to that failure.

- 2026-10-16: Add bounded Join probe/gather morsels on the existing native pool.
  Large eligible batches use up to four stable input ranges, with global match
  limits and state admission before output work. Keep funded serial fallbacks,
  cancellation cleanup, V1 charges and checkpoint formats unchanged. Price
  result leases from physical selected buffers, including restored nullable
  fixed-width values; exceeding the result cap keeps the existing fallback.
  Shapes requiring array-copy range preflight keep the split path before fused
  workspace admission.

- 2026-10-16: Merge general ASOF integer-sequence batches into reserved columns
  by key, preserving unordered input positions and duplicate identity history.
  Finalization caches each key's latest Arrow payload route and advances
  identity-history cursors across ordered and normalized unordered input.
  Public schemas, frozen state charges, and checkpoint layouts remain unchanged.

- 2026-10-16: Store streaming Join state in chunks with stable row references
  and sorted expiration run heads. Native match selection uses incoming identity
  ranges or fan-out runs; output columns use Arrow take/interleave with bulk
  compaction for encoded payloads. Preserve V1 logical charges, deterministic
  output order, output-before-state-commit semantics and checkpoint layouts 1–3.

- 2026-10-15: Reject duplicate live row IDs when restoring layout-1 Join
  checkpoints. Validate event times and complete V1 logical charges for every
  historical row in full layout-1 checkpoints, including overwritten and
  tombstoned rows. Reject invalid history before replacing installed state while
  preserving existing error priority. Checkpoint layouts, versions and recovery
  compatibility for valid checkpoints remain unchanged.

- 2026-10-15: Fix streaming Join retention and checkpoint recovery for negative
  `Int8` keys and `Date32`/`Date64` keys. Valid keys no longer fail signed-byte
  conversion or date-array type checks. V1 key tags and logical charges,
  checkpoint layouts, schemas and versions remain unchanged.

- 2026-10-14: Retain required streaming Join payload dependencies plus identity
  and event-time fields when all consumers qualify for compiler projection.
  Preserve complete input-schema validation, V1 logical state charges and graph
  fingerprints. Actually narrowed state uses strict inner layout 3/codec 2,
  exact logical/physical schema descriptors and carried V1 admission charges.
  Legacy layout 1/2 migration establishes a fresh narrow base before incremental
  deltas and rebase; semantic state version 1, project format 3 and manifest v3
  remain unchanged. The Python inventory reports layouts `(1, 2, 3)`.
  Rebuild checkpoint history after checkpoint-disabled updates, and reject
  emitted-row counter overflow before sending output from the input batch.
  See [Join recovery](docs/streaming-guide.md#join-output-materialization-and-recovery).

- 2026-10-14: Cut per-row and per-batch cost in `WindowAggregateOperator`
  input processing. Rows in the same slide interval share one resolved set of
  window assignments and late classification; scratch slots are cached per
  interned group, so high-cardinality batches no longer evict each other's
  windows; numeric min/max compare native values and null-free columns skip
  per-row validity checks; batch entries sort by window start and group-key
  rank; and live state merges a large batch in one pass. Accumulator state,
  checkpoint segments, output rows, and late metrics are unchanged. Two
  regressions from the unreleased columnar kernel and net-delta checkpoint
  work are fixed: a rejected batch reports the same first error as the
  row-wise reference path, and a persisted window re-opened by a lagging
  context watermark within one epoch keeps its upsert instead of a tombstone.
  In three interleaved local runs of `stream_window_groups` (100,000 rows per
  case, 20 samples), median case time fell to 0.54-0.69 of the previous main
  across all 24 cases, for example `integer_8192_hopping_five` from 22.78 to
  12.89 ms and `string_4_tumbling_sum` from 3.46 to 2.39 ms.

- 2026-10-13: Release a closed event-time window from
  `WindowAggregateOperator` state when its close is emitted, in every
  checkpoint mode. With checkpointing enabled, the default, an emitted window
  previously stayed in live state until the next checkpoint: it held memory,
  kept counting against the window `StateBudget`, and was rescanned by every
  watermark and delta compaction. A job that closed more windows between two
  checkpoints than the budget allows, one million windows and 256 MiB by
  default, failed with `window state budget exceeded` although those windows
  were already emitted, and per-watermark cost grew with the windows closed
  since the last checkpoint. The budget now bounds open windows only. Jobs
  with checkpointing disabled already released at emission and are
  unaffected. Runtime-driven jobs emit the same rows in the same order with
  the same sequence numbers; late-row classification, the checkpoint segment
  format, restore compatibility, and the public API are unchanged. In paired,
  correctness-checked local runs of the engine-suite `window_sum` case
  (ten-second tumbling windows, 64,000-row batches, checkpointing enabled with
  no checkpoint inside the timed region), the ready-enqueue-to-Arrow median
  fell from 9,161 to 1,616 ms at 10 million rows and from 269 to 176 ms at
  1 million; a 10,000,640-row run that exceeded the default budget before now
  completes in 1,559 ms. The change first ships in the release after
  `2026.10.13`.

- 2026-10-13: Move the workspace crates and Python core to calendar version
  `2026.10.13` for the `calc-flow-python` release. It is the first release
  with the public `Runtime` registration methods and the first tagged after
  the Studio subtree left this repository.

- 2026-10-13: Move Calc Flow Studio out of this repository. The `web-ui/`
  subtree, Studio guide, Studio CI jobs, and Studio release tooling are
  removed; the application now lives in the separate
  [calc-flow-studio](https://github.com/wegamekinglc/calc-flow-studio)
  repository and depends on `calc-flow-python` only as a published package.
  The core engine, Python API, and release workflow are unchanged.

- 2026-10-13: Make Studio's parent-side registration reads tolerant of the full
  record contract. `RunManager` capabilities and preview submission skip
  records of kinds Studio cannot replay in a worker, such as `kafka_decoder`,
  instead of raising `KeyError`, and strip unlisted keys such as the NumPy and
  JAX helpers' process-local `stream_lifecycle` proof before transport, so
  helper-installed providers replay into preview workers instead of failing
  the strict worker preflight. The worker preflight is unchanged and still
  rejects malformed or unknown records.

- 2026-10-12: Make three `calc_flow.Runtime` methods public:
  `register_mapping_provider`, `registration_snapshot`, and
  `capability_registration_snapshot`. The underscore spellings
  `_register_mapping_provider`, `_registration_snapshot`, and
  `_capability_registration_snapshot` are removed with no aliases, including
  the previously documented `_register_mapping_provider`. To migrate, rename
  the call; arguments and behavior are unchanged. The public names first ship
  in the release after `2026.10.12`. Registration records are trusted
  process-local values, while `capabilities()` remains the data-only view. The
  native binding, Rust exports, REST, and OpenAPI are unchanged.

- 2026-10-12: Move the workspace crates, Python core, Studio, and frontend to
  calendar version `2026.10.12` for the `calc-flow-python` release. Studio
  requires `calc-flow-python>=2026.10.12,<2027`.

- 2026-10-11: Build single-source Join output indices directly and batch capture
  bookkeeping in bounded groups. Promote to multiple sources only when needed,
  preserving row order, cancellation checks, and reserved-memory ownership.

- 2026-10-11: Remove the implicit 1 GiB DataFusion runtime memory-pool limit.
  Keep per-runtime reservation accounting and release tracking. Explicit
  operator state budgets, edge budgets, and SQL result collection limits remain
  independent. Checkpoint performance diagnostics use the unbounded runtime
  default and record their pool policy separately from historical bounded runs.

- 2026-10-11: Add `StateLineageBackend::stage_segments` for borrowed snapshot
  segments, with a sequential default for existing backends. Local staging
  syncs each owner directory once per batch while retaining every file,
  ancestor, publication, and manifest durability boundary. Retries reconfirm
  visible staged files; managed cancellation settles the admitted batch before
  releasing lineage ownership, without acknowledging the checkpoint.

- 2026-10-11: Reuse source identifiers while streaming Join gathers consecutive
  output rows from the same input batch. Avoid repeated source-map lookups while
  preserving row order, independent output buffers, and bounded gather storage.

- 2026-10-11: Batch local checkpoint segment publication so each affected
  committed directory is synced once per snapshot. Preserve file, staging,
  creation, and manifest durability boundaries; reconfirm visible files after
  failed publication and settle admitted batches before cancellation completes.
  Add a provided `StateLineageBackend::publish_segments` method that preserves
  existing backends' committed-read and staged-publication contracts.

- 2026-10-10: Avoid repeated binary searches when streaming Join expires the
  first row of a key's ordered index. Refresh index capacity funding only when
  an emptied key releases storage, preserving dense-row mappings, key ownership,
  and exact memory accounting.

- 2026-10-10: Add explicit checkpoint-disabled streaming with
  `StreamRuntimeConfig(checkpointing=False)` in Python and
  `StreamingRunner::without_checkpoints` in Rust. Preserve live state and
  budgets while skipping checkpoint storage, snapshots, and recovery journals;
  require ordinary sinks and expose best-effort delivery. Keep checkpointing
  enabled by default and preserve natural EOF and cancellation cleanup. Successful
  checkpoint-enabled EOF no longer reports an internal checkpoint failure.

- 2026-10-10: Reuse funded streaming Join probe keys when parallel work
  declines, avoiding a second key-construction pass during serial fallback.
  Gather flat output columns across multiple input and retained batches with
  column-wise interleave while preserving match order and independent output
  buffers; nested and dictionary payloads retain their compacting path.

- 2026-10-10: Fund flat numeric, string and binary Join checkpoint payload
  concatenation from the typed Arrow builder allocation bounds. Large captures
  and captures after recovery no longer exhaust resident credit through
  per-slice generic-constructor over-reservation; runtime limits and funding
  ownership remain enforced.

- 2026-10-10: Split ASOF benchmark setup diagnostics into right fixture,
  right admission, left fixture, and left admission durations. Preserve the
  watermark timing boundary and accept historical reports without the new
  fields; validate complete phase timings against the original setup total.
- 2026-10-10: Gate the owned parallel Join probe on estimated key-run
  visits so thin one-to-one shapes stay on the actor thread and avoid
  two-submission dispatch overhead.

- 2026-10-10: Size the Join probe key arena algebraically from column
  extents instead of a per-cell walk; charges stay byte-identical and
  fixed-width key columns size in constant time.

- 2026-10-10: Split large native streaming Join probes into at most eight
  contiguous count and fill work units. Check the global match limit before
  filling, fund fragments alongside the combined pair buffer, and preserve
  input and opposite-row order when workers complete in a different order.

- 2026-10-10: Run large native streaming Join probes as funded count and fill
  work units, with the actor checking the match limit between them. Share
  immutable input and index owners through cancellation cleanup, and await
  their release before later state changes. Keep small inputs synchronous
  and preserve serial matching after worker admission refusal.

- 2026-10-10: Recover authentic prior-release V1 Join checkpoints, publish V2
  state, and resume it in a fresh process with unchanged rows, logical charges,
  and source cursors. Preserve original checksums when bounded manifest loading
  reads legacy sources without a history field; current manifests still write
  that field explicitly. Advertise Join physical layouts 1 and 2 with semantic
  state version 1.

- 2026-10-10: Resolve each distinct streaming Join probe key once for both
  matching passes and keep one canonical key owner per distinct probe key.
  Typed key columns reuse one funded row buffer and immediately intern each
  frame, preserving checkpoint bytes without a full-batch key arena. Vectorized
  admission removes redundant scalar scans and charges the remaining work within bounded cancellation
  grants, preserving error order and resource limits. Tokio cooperative budget
  replaces a forced scheduler yield at every work boundary; cancellation and
  deadline checks retain their existing granularity.

- 2026-10-09: Intern repeated streaming Join keys and probe per-key ordered
  time lists through a native hash dictionary. Batch admission masks and
  binary window boundaries reduce row-level probe work while preserving
  funded state, output ordering, and V1 checkpoint bytes. Generic admission
  shares parent batches and gathers flat output columns without per-row
  record wrappers, retaining concatenation for mixed and nested payloads.

- 2026-10-09: Write columnar V2 streaming Join checkpoints with immutable
  payload batches and incremental row indexes. Preserve prepared-cut anchors
  and restored V2 history across captures; migrate V1 state through funded
  asynchronous preparation before writing V2. Keep logical row charges and
  public operator identity unchanged.

- 2026-10-09: Read columnar V2 streaming Join checkpoints with strict
  inventory, schema and historical-row validation before atomic restoration.
  Managed recovery uses funded native work; checkpoint capture continues to
  write V1 and rebuilds its base after restoring V2 state.

- 2026-10-09: Cancel successfully started native stream jobs when Python
  startup is abandoned before ownership handoff. Await source shutdown and
  managed state release even while the startup result remains referenced.

- 2026-10-09: Restore streaming Join state before terminal managed sink
  recovery. Reuse funded V1 loading and decoding, validate native ended and
  empty state before publishing ingress status, and leave sources unopened.

- 2026-10-09: Fund nullable Float64 non-key payloads during streaming Join
  managed V1 recovery. Retain raw value bytes and validity padding with the
  existing row lease through the last surviving values or validity buffer.
  Preserve checkpoint bytes, logical charges and original reader fallback.

- 2026-10-09: Include non-null Boolean non-key payloads in funded streaming
  Join managed V1 recovery. Preserve packed value bytes and valid padding,
  original key support, null fallback, checkpoint bytes and logical charges.

- 2026-10-08: Prepay certified non-null Utf8 payload and key recovery for
  streaming Join managed V1 checkpoints. Native verification and decoding
  retain independent workspace, while fresh offsets and values keep their
  resident credit through the last Arrow buffer owner. Preserve checkpoint
  bytes, logical charges and original reader fallback behavior.

- 2026-10-08: Include Float32 and Float64 non-key payloads in certified,
  funded streaming Join managed V1 recovery. Preserve IEEE value bits,
  existing key support, null fallback, checkpoint bytes and logical fees.

- 2026-10-08: Prepay certified streaming Join managed V1 delta-only recovery,
  including the first dirty checkpoint. Derive carried-delta workspace from
  the actual segment inventory while preserving existing decoding, ownership,
  checkpoint bytes and optional refusal routes.

- 2026-10-08: Prepay streaming Join managed V1 base-plus-delta decoding and
  the checked installation tail. Certified scalar payloads keep independent
  funding after fold and through surviving Arrow buffers; original segment
  order, checkpoint bytes, diagnostics and optional refusal routes remain.

- 2026-10-08: Prepay streaming Join managed V1 full-base decoding on the existing
  owned native worker and the checked installation tail. Certified scalar rows
  retain independent funding through surviving Arrow buffers; unsupported
  histories and optional budget refusals preserve the original recovery routes.

- 2026-10-08: Prepay finite expected-schema copies for streaming Join managed
  V1 recovery. Native workers construct independent schema controls for the
  original IPC comparison; unsupported profiles and optional budget refusals
  preserve the metadata-only recovery route and its existing fees.

- 2026-10-08: Prepay bounded streaming Join checkpoint metadata validation
  during normal managed restart and parse it once on the existing owned native
  worker. Unsupported profiles and optional funding refusals use the original
  V1 reader; cancellation checks guard the final restored-state assignment.

- 2026-10-08: Prepay selected streaming Join checkpoint wire loads from
  certified managed Local storage using the configured runtime budget. Owned
  loading drains real I/O and keeps funding with surviving segment references;
  layout-1 checkpoint encoding and legacy loader behavior remain unchanged.

- 2026-10-07: Reject non-ASCII Studio session tokens with the existing
  `403 {"detail": "Invalid launch token"}` response instead of HTTP 500
  (DAL-321).

- 2026-10-07: Prepare ordered streaming ASOF left chunks directly from
  validated admission ranges for scalar integer or UTF-8 keys and native-width
  integer sequences. Legacy dictionary capacities, checkpoint bytes, owned
  buffers, budgets and cancellation boundaries retain their contracts.

- 2026-10-07: Coalesce streaming ASOF left output planning over canonical
  sources and physical row ranges, removing unused left row-position storage.
  Existing span gathering, backing charges, output budgets, prefix commits
  and checkpoint encoding retain their contracts.

- 2026-10-07: Prepare streaming Join checkpoint bases on bounded native workers.
  Data and progress handlers share retained vectors without cloning or encoding
  the base. Cancelled preparation retains paid ownership until cleanup and
  actual workspace refunds; layout-1 checkpoints and logical limits are preserved.

- 2026-10-06: Aggregate streaming ASOF left batch, key and sequence-owner
  bookkeeping over ordered runs. Prefix matching, canonical encoding, capacity
  charges and cancellation/resource decisions retain their contracts.

- 2026-10-06: Maintain streaming Join retained-state gauges, expiration indexes
  and pending checkpoint operations incrementally. Decode timestamp units once
  per record and canonicalize incoming keys once. Preserve physical row IDs,
  ordered matches, logical resource limits and the frozen layout-1 captures.

- 2026-10-06: Add 64-key inclusive five-second interval Join benchmark
  references through 1M input rows, explicit 1,024-row native variants, and
  separate 100 ms checkpoint/recovery lifecycle cases at 100k and 1M rows.
  Replay sources seek stable cursors and replay legal watermarks; original
  sample evidence requires actual nonterminal publication and recovery with
  unchanged output multiplicity. Lifecycle durations remain separate from
  throughput references.

- 2026-10-06: Traverse streaming ASOF left chunks in ordered runs, advancing
  the merge heap once per run. Adjacent-row checks and exponential search bound
  interleaved-run lookup work. Canonical row order, typed sequence ownership,
  checkpoint encoding and workspace accounting retain their contracts.

- 2026-10-06: Expose inner Join ingress watermark, idle, and end observations
  through Rust, Python and Studio, including non-terminal managed restart at
  startup.
  Studio preserves watermark precision with decimal strings; existing Join
  counters and checkpoint layout remain unchanged. Static Join benchmark
  readiness now seals the dimension before quotes, requires zero retained and
  evicted quote rows, and excludes this setup from stream scope v6 timing.

- 2026-10-06: Await streaming ASOF payload retirement before reusing chunk
  workspace, preventing temporary budget failures while old owners are still
  being released. Managed job cleanup waits for those owners and reservations;
  cancellation, reset, checkpoint encoding and configured budgets retain their
  contracts.

- 2026-10-06: Use sink delivery events for ready-stream ASOF benchmark
  lockstep, replacing timed status polling. Stream scope v5 treats declared
  older scopes as new coverage. Cross-library reports include independently
  measured Polars 1-thread and 32-thread references with verified pool sizes.
  The benchmark guide now reflects all reopened Join, ASOF and window tiers.

- 2026-10-01: Use batch-table indices for temporary streaming ASOF admission
  rows, retaining each payload once per batch and resolving right payload
  references directly at install. Detached left preparation keeps its owner
  table and workspace lease together. Identity preflight also counts accepted
  rows, allowing one complete identity-vector reservation under watermarks,
  with one extra row slot charged for converter startup overlap.
  Retained state, version 3 checkpoint layout, and aggregate resource limits
  keep their existing contracts.

- 2026-10-01: Push exact downstream column projections into streaming ASOF
  output materialization. All direct projection consumers contribute their
  column requirements; output workspace and Arrow gathering use only those
  fields. Complete left arrays can share buffers when their backing memory
  fits the visible slice charge. Full input validation, retained payloads,
  logical graph fingerprints, and v3 checkpoint schemas remain in force.
  Window aggregation borrows single UTF-8 group keys from Arrow and creates
  canonical keys once per distinct batch group. Owned group values are read
  only when creating a new window accumulator.
  Composite string keys encode borrowed values before interning. Aggregate
  update order and checkpoint encoding retain their existing contracts.

- 2026-10-01: Preserve input focus during Studio schema-field and Source/Sink
  binding renames (DAL-313). Unfinished Options JSON stays with its binding
  across renames and adjacent additions/removals; project switches and
  external binding replacements reset local drafts.

- 2026-10-01: Move stream ASOF state, layout, and accounting to version 3.
  Checkpoints use a canonical columnar index with key dictionaries, typed
  integer sequence columns, shared generic identity buffers, batch references,
  and capacity hints. Resource charges cover retained capacities and unique
  buffer owners. Shared right columns and sparse payload pool replacements are
  prepared on blocking workers with reservations retained through cancellation.
  Rust and Python capabilities advertise state/layout 3; the operator identity
  remains `stream_asof_join@1`. Versions 1 and 2 are rejected.
  Admission uses typed string-key dictionaries with integer sequences, copies
  ordered integer sequence ranges, and aggregates shared owner counts. Output
  workspace uses Arrow offset ranges; finalization and eviction avoid encoding
  integer sequences that need no owned buffer. Eviction previews reserve their
  encoding-owner removal scratch before changing state.

## 2026-09

- 2026-09-30: Verify coverage comparison baselines from successful Linux CI
  reruns. The resolver checks the latest attempt's three coverage jobs and
  required steps, and binds each checksum-bearing artifact to its successful
  job's execution interval, including jobs carried forward from earlier
  attempts. Source-tree, repository, and coverage threshold checks still apply.

- 2026-09-30: Continue stream ASOF Join acceleration. Admission retains flat
  Arrow payload batches without eagerly writing their checkpoint IPC segments;
  checkpoint preparation encodes each retained batch once and later captures
  share its immutable bytes. The existing v2 checkpoint format, accounting
  version, state charge, and v1/v2 restore behavior remain compatible. See the
  second-round performance comparison in the associated PR for measured effects.

- 2026-09-30: Speed up ordered stream ASOF Join admission. It checks adjacent
  identities in already ordered batches, skips resident identity probes when
  the new range follows retained state, and avoids interning short inline keys.
  Watermark-local disorder still uses full duplicate detection; duplicate
  counters and checkpoint identity bytes remain unchanged.

- 2026-09-30: Encode single non-null `Int64` and `UInt64` ASOF identity columns
  directly into Arrow's canonical row bytes. Other types and nullable columns
  keep the generic Arrow converter. This reduces admission allocation and
  preserves checkpoint identity compatibility.

- 2026-09-30: Reuse a per-key candidate cursor while finalizing large ordered
  ASOF output prefixes. Small prefixes and cases without cursor workspace use
  the existing binary search. Matching, identity-only rows, tolerance bounds,
  output order, and checkpoint state are unchanged.

- 2026-09-30: Store globally ordered pending ASOF left rows contiguously and
  append later non-overlapping batches without per-row tree insertion.
  Overlapping batches retain the tree fallback. Finalized prefixes release
  their batch references and compact vector capacity when it exceeds the
  remaining identities' charged headroom. Admission moves validated identities
  into payload references without cloning each row and projects checkpoint index
  length and state charges in one scan;
  checkpoint index bytes and v1/v2 recovery remain unchanged.

- 2026-09-30: Locate stream ASOF right buckets with a hash table while
  retaining sorted keys for canonical checkpoint writes. Eviction releases
  oversized bucket and hash-table capacity as right history contracts. The
  existing v2 index bytes, state charge, and v1/v2 restore rules remain
  compatible.

- 2026-09-30: Keep ASOF right payload and identity-only histories in separate
  ordered time and sequence columns. Eviction previews inspect their expired
  prefixes, and committed sweeps advance head cursors and release dead payload
  references before periodically compacting capacity. Stalled identity history
  no longer makes each payload sweep revisit all retained rows. Canonical key
  ordering uses a tree, including reverse arrivals of many distinct keys; sparse
  identity-only buckets allocate no payload column. Existing v2 checkpoint bytes
  and v1/v2 recovery remain compatible. Older payloads enter a separate identity
  tree when their order overlaps retained history, without moving retained
  identity columns. Empty key and batch-reference indexes release their owned
  allocations when the committed state charge reaches zero. Eviction workspace
  reserves the batch-reference tree's minimum leaf allocation as well as its
  per-batch slots, retaining the configured workspace cap.

- 2026-09-30: Accumulate ASOF right row counts while admitting identities,
  reserve each right column for the accepted batch, and skip the identity-only
  history probes already covered by duplicate validation. Output workers own
  one Arrow reference per distinct source and primitive row positions instead
  of cloning a payload handle for each output row. Prefix matching accumulates
  checkpoint-length, row-charge, and batch-reference changes in the same walk;
  ordered prefix selection uses binary search, and sink acceptance commits
  aggregated batch-reference changes without constructing an owned key vector.
  Checkpoint bytes, counters, cancellation, and configured resource caps retain
  their existing contracts.

- 2026-09-30: Intern retained ASOF right keys in a `u32` handle dictionary
  using DataFusion's canonical-byte batch hashing and a per-instance seed.
  Repeated admissions share resident key buffers. Checkpoints sort keys by
  bytes with reserved scratch, using a blocking worker in the managed async
  path; v1/v2 index bytes and state accounting remain compatible. Repeated small
  admissions amortize right-column growth. Identity workspace covers the batch
  encoding, sequence copies, and converter headers; new owned key copies grow
  a separate reservation once per unique key before allocation. Dropped late
  rows do not allocate identity buffers, and contiguous accepted runs reuse
  their batch converter. Tight hash workspace
  uses scalar probing with the same equality semantics.

- 2026-09-30: Retain ASOF payload rows as eight-byte batch and row handles.
  One private pool owns each Arrow payload batch, releases it after its final
  row reference, and trims its indexes as history contracts. Output and
  checkpoint preparation borrow pool entries. Canonical v2 checkpoint bytes,
  state charges, and strict v1/v2 recovery checks remain compatible.

- 2026-09-30: Retain pending ASOF left rows in sorted Arrow chunks with one
  canonical key owner per chunk and compact row positions. Borrowed cursors
  merge overlapping chunks in canonical time, key, and sequence order.
  Preparation and prefix compaction run on blocking workers with owned
  workspace, including retained input buffers after cancellation and reset;
  accepted output commits prebuilt buffers without allocation.
  Recovery migrates only validated live index rows. Checkpoint bytes and
  accounting remain v2 compatible.

- 2026-09-29: Require immutable `Program(engine="sql")` or
  `Program(engine="streaming")` selection at construction and add
  `Program.execute(inputs)` dispatch. SQL returns named Arrow tables;
  streaming returns owned async output events. Streaming SQL ordinary
  aggregates and `GROUP BY` now retain input and emit full cumulative
  snapshots after each batch. SQL aggregate state has no fixed default row or
  byte cap; applications may configure a stream state budget. Direct
  collection and stream calls reject the opposite engine. Four separately
  identified benchmarks cover the
  new entry point across both engines, with projection and cumulative
  aggregation; existing timing identities stay intact.

- 2026-09-28: Repair the scheduled benchmark suite. The `engines-100` shard's
  shared-lock verification now compiles for the project's Python 3.13
  explicitly, since the Finance-Python step installs Python 3.9 first and the
  unpinned compile had resolved for it and failed since 2026-09-26. The shared
  benchmark lock drops `hypothesis` and `sortedcontainers`, which left the
  project dependencies on 2026-09-27. A declared `m4_state_window` workload
  migration covers the dense window cases and the collector-drain fix, so
  those Rust cases are compared instead of failing their fingerprint check.

- 2026-09-28: Cut ordered rolling stream overhead for SMA-style plans (#342).
  For a non-null microsecond event time, one non-null Utf8 entity, and one
  non-null `UInt64` sequence, the ordering proof compares Arrow values in
  place and row-encodes only each batch's first and last identities. Whenever
  the only entity column is non-null Utf8, entity routing assigns batch-local
  IDs from the string values, reuses the previously observed entity order
  when it repeats, and row-encodes each distinct entity once. Plans whose one
  or two row-window numeric groups feed only one or two Float64 mean or
  mean-difference outputs run a fixed-arity loop over the unchanged numeric
  state, and retained-history tails reuse the routed per-entity row counts. Other key shapes and outputs keep the
  row-encoded and generic typed paths. Output bits, checkpoint bytes, restore,
  and emit-before-commit rollback are unchanged. In paired, interleaved,
  correctness-checked local runs over 64 symbols (64,000-row batches), the
  ready-to-sink median for `SMA20` fell from 944 to 435 ms at 10 million rows
  (2.2×), 88 to 40 ms at 1 million, and 9.2 to 3.9 ms at 100,000; `dual_sma`
  fell from 1,017 to 538 ms, 100 to 51 ms, and 10.5 to 5.4 ms. At 10 million
  rows, ordering proof fell from 210 to 41 ms, entity resolution from 339 to
  71 ms, and history maintenance from 77 to 20 ms; the numeric update, now
  the largest stage, fell from 225 to 193 ms. 64-row batches stayed at about
  0.45 ms per batch.

- 2026-09-28: Reuse plans and cut stateful-operator costs from the #339
  roadmap. Repeated `compute` and `collect` calls reuse the program's lowered
  project document within one runtime registration revision; each call still
  compiles a fresh native plan. A DataFusion runtime rebinds a recorded
  single-table projection/filter plan with only immutable functions to new
  rows when the same query, alias, and exact schema repeat, which removes
  per-batch planning from stream SQL and expression nodes; such reuses report
  `physical_planning_count == 0`. Window aggregation assigns windows lazily,
  shares encoded group keys, and downcasts each column once per batch; dense
  local benchmarks ran about 2.1× faster tumbling and 2.6× faster hopping.
  ASOF finalization drains finished prefixes over the shared committed
  checkpoint bytes instead of copying the remaining segment for every chunk,
  so settling 8,192 pending rows fell from about 0.7–1.9 s to 0.14–0.2 s.
  Stream Join checkpoint capture reuses Arrow IPC schema framing per schema;
  checkpoint bytes are unchanged.

- 2026-09-28: Stop cloning resident typed rolling state on every stream
  batch. The typed stream transition now copies only the entities a batch
  touches into a private update and commits it after output emission
  succeeds, as the ordered stream path already did. Failed batches still leave
  the resident state untouched. With 50,000 resident entities, a 64-row batch
  touching eight of them fell from about 5–13 ms to 9–11 µs in a local probe.

- 2026-09-28: Share batch metadata across stream fanout. `BatchMetadata`
  clones share their source and attributes, so each fanout branch copies
  reference counts instead of the source string and attribute map; its JSON
  form, equality, and accessors are unchanged. Source, progress-driver, and
  operator fanout move each message into its last output edge instead of
  cloning it. Cloning a 16-row table batch with eight attributes fell from
  about 238 ns to 37 ns in a local probe.

- 2026-09-27: Reduce fixed per-call overhead from the #339 performance review.
  Expression lowering, primitive search, and common-subexpression extraction
  visit each shared subexpression once, so deeply shared row-local diamonds
  lower in linear rather than exponential time. Built-in SQL, expression, and
  stream Join operators parse their read-only query once at construction, and
  their per-call `sql_parse_ns` metric is now zero. Plans with only built-in
  operators skip the null-state rollback snapshot on each execute. Table
  batches measure their Arrow byte cost once and share it with clones. Native
  batch and stream compilation releases the GIL, and multi-output `collect`
  reads native outputs once.

- 2026-09-25: Remove benchmark scenarios, performance controller checks,
  benchmark support script tests, and benchmark target compilation from regular
  Linux and Windows CI. The complete benchmark suite runs independently at
  06:00 and 18:00 Asia/Shanghai, including its warm-stream correctness checks.
  Supplemental SQL/DataFusion experiments remain available by manual dispatch
  only.

- 2026-09-25: Publish explicit Python 3.9–3.14 abi3 wheel files on Linux,
  macOS, and Windows. The release builds two native ABI tiers per platform,
  adds interpreter-specific wheel tags, and installs each tagged wheel in its
  corresponding Python unit-test job before publishing. Artifact verification
  now requires all thirty wheels and the source distribution. The Python
  release workflow remains focused on package build, verification, tests, and
  PyPI upload.

- 2026-09-24: Prepare `calc-flow-python` for CPython 3.9–3.14 with two
  abi3 wheel tiers on the existing five platform targets. The 3.13+ tier
  retains its direct Unicode extraction and eager asyncio task paths;
  older interpreters use compatible fallbacks. Python 3.9 resolves PyArrow
  21 and JAX 0.4.30 when the JAX extra is requested. Stream result ownership,
  cancellation cleanup, and JAX device selection work across the supported
  interpreter range. Release CI installs matching wheels on each version and
  retains the paired performance acceptance gates. Source installs select the
  build interpreter's CPython ABI, and pull request CI checks the 3.9 source
  path and the 3.14 modern wheel path. User examples use the 3.9-compatible
  UTC and timeout APIs.

- 2026-09-23: Restore stream Join handler throughput after DAL-300. The
  bounded-chunk preflight scanned every matched pair through hashed per-row
  caches (a measured 26% release-gate regression on
  `handler/right_10k_one_to_one` and `handler/right_10k_fanout10`); admission
  now caches conservative logical row charges columnarly, single-chunk
  outputs are decided from the charge sum alone, and the flat fallback
  indexes per-row costs by dense position. Chunk boundaries, atomic
  admission, oversized-row rejection, and checkpoint recovery are unchanged.
  The allocation comparability lock now covers the measurement identity
  (frozen harness source, pinned allocation-counter build, toolchain);
  lockfile, manifest, and harness-commit values stay recorded attribution
  because every release bumps the product's own entries in them, which made
  the previous byte-equality lock reject ordinary release-to-release
  comparisons.

- 2026-09-23: Release paired timing collects two rounds of six adjacent
  AB/BA invocations per case (24 observations) instead of two rounds of ten,
  and the two mandatory 20-minute soaks moved from the acceptance job into a
  parallel `soak-gates` job. The first 2026.9.23 release attempt measured the
  complete collection at roughly five minutes per case across 74 cases and
  exceeded the six-hour GitHub job cap while rust cases were still running,
  so the previous sampling could never complete on hosted runners; six pairs
  per round is the smallest count that still yields a finite 95% median
  interval. The AB/BA alternation, fresh isolated workers, sealed binaries,
  and +5% paired-median verdict are unchanged; restoring ten pairs per round
  requires splitting the collection into parallel per-suite jobs. PR-suite
  sampling is unaffected.

- 2026-09-22: Scope Rust suite dependency comparisons to each benchmark
  target's compiled dependencies and compiler identity, retaining aggregate
  provenance. Adding a target no longer invalidates shared cases; real
  dependency changes still fail closed. Join preflight caches costs only for
  distinct matched row indices while preserving complete preflight, output
  order, oversized-row rejection before emission, and checkpoint recovery.
  Join report parsing requires positive integer input dimensions and integer
  oracle/sample row counts, rejecting booleans and floats. These corrections
  add no performance measurements or speedup claims.

- 2026-09-22: Package versions switch from aligned SemVer to calendar
  versioning `YYYY.M.D` (release dates, starting at `2026.9.22`). Workspace
  crate, Python core, Studio, and frontend still move together; native
  internal crate dependencies pin the date version exactly, and Studio
  requires `calc-flow-python` within the release's calendar year
  (`>=2026.9.22,<2027`) instead of the removed `>=5.0.0,<6` major bound.
  Release tags become annotated `calc-flow-python-v<version>` at the current
  `main` head; the workflow trigger is `calc-flow-python-v*`. Historical
  `v4.0.0`/`v5.0.0` tags remain valid performance baselines. PyPI
  immutability now means retrying under the next calendar date.

- 2026-09-21: Materialize bounded event-time Join output one chunk at a time
  after complete range/row-budget and sequence preflight (DAL-300). An
  oversized row rejects the input's output before emission; cancellation after
  partial delivery recovers by checkpoint replay, without rolling back
  sink-accepted output. Matching, ordering and checkpoint formats remain
  unchanged. Add the maintained `stream_join_materialization` command and
  four-case reports retaining allocation, RSS and backpressure diagnostics;
  state, match descriptors, nested/dictionary preflight and edge/sink ownership
  remain costs outside a total-RSS guarantee.
  [PR #321](https://github.com/wegamekinglc/calc-flow/pull/321) records 160
  paired samples at `d43a8f6` against benchmark-only overlay `00322fc9` on
  product `a594ad6`: `wide_f100_slow` improved, `narrow_f100_fast` and
  `wide_f100_fast` had no confirmed regression, and `wide_f10_fast` remained
  inconclusive. The 80 separate candidate samples are informational;
  `ddc0ff6` CLI checks yielded 12 oracles and no performance samples.
  Later validation and documentation heads were not performance remeasured.
  The comparison used unmerged PR #319's `8ec52c88` harness (tree-equivalent
  to `48fed573`), separately from product source. No release-wide performance
  pass follows; historical release inconclusive, SQL sameHEAD RSS failures
  and whole-suite ABBA informational boundaries remain unchanged.

- 2026-09-21: Keep distinct symbolic sources separate when generated source
  IDs collide (DAL-298). Relational DAGs and ordinary batch fan-out reserve
  output and planned physical node IDs, including intermediate rolling,
  cross-section, materialization, and shared prefilter stages. Both paths also
  check reachable logical input names and allocated source IDs when assigning
  fallback IDs, adding deterministic numeric suffixes through consecutive
  collisions. These source-ID collisions no longer silently merge same-schema
  inputs or cause an internal conflict with calculation nodes or differing
  schemas. Logical collection and streaming bindings remain unchanged.
  Noncolliding graphs and previously valid unsuffixed fallback graphs retain
  their node IDs and plan fingerprints; project and checkpoint formats are
  unchanged. This does not migrate or
  guarantee recovery of checkpoints from graphs that previously merged sources
  incorrectly.

- 2026-09-21: Enforce the complete declared schema for Python Kafka custom
  decoder output (DAL-296 / DAL-297). Field count, order, names, and types
  remain strict; valid columns adopt the source's nullability and metadata,
  while actual NULLs in non-nullable columns fail at the decoder boundary.
  Undeclared schemas retain callback metadata, and caller-owned Arrow
  objects remain unchanged. Zero-batch Tables retain their schema and decode
  as valid zero-row output under the same validation and bounds as
  RecordBatches. Empty output consumes the message and advances its cursor
  for continued consumption; zero-column results preserve their row counts.

- 2026-09-21: Reject MySQL sink values that fail the connector's conversion
  checks before epoch state changes and durable checkpoint publication
  (DAL-295). Non-finite floats and out-of-range Arrow dates/timestamps leave the
  previous valid recovery point intact; corrected replayable input can resume
  without duplicating committed epochs. Prepared recovery uses the same value
  checks. Incremental IPC encoding, checkpoint format, and database commit after
  manifest publication are unchanged; existing invalid manifests are not repaired.

- 2026-09-21: Require comparable paired release performance evidence (DAL-299).
  `python -m scripts.release_performance` binds ordinary Python and Rust
  `core`/`stream_join_perf` observations to sealed native/binary hashes and
  complete identities, collecting two rounds of ten adjacent AB/BA invocation
  pairs under the existing +5% paired-median rules. Independent summaries are
  rejected as release timing evidence; dependency-drift acknowledgement no
  longer permits incompatible lifecycle comparisons. Unified Python collectors
  support older checkouts, frontend reports record actual Node identities,
  and ABBA suite blocks remain informational. Failed release runs retain raw
  evidence and downstream skip reasons for 30 days; the acceptance job budget
  is 360 minutes. Specialized gates and thresholds remain in force. This
  evidence-chain correction establishes no product speedup and does not clear
  historical inconclusive release measurements or SQL sameHEAD RSS failures.

- 2026-09-21: Add the maintained `stream_asof_perf` command and eight-case
  settlement reports with a strict Rust-suite loader (DAL-301). Stable right
  history avoids repeated retained-state cloning and row re-encoding while
  preserving canonical v1 bytes, strict watermarks, per-chunk commit, and
  cancellation/restore behavior. Remaining checkpoint copying and hashing
  still cost `O(retained state)` per chunk.
  [PR #322](https://github.com/wegamekinglc/calc-flow/pull/322) records five
  scenarios with 200 paired samples: four `improved`, one
  `no-confirmed-regression`, measured at `8020cf89` against the benchmark-only
  baseline overlay `e2d768f8` on product `a594ad6`. The separate eight-case
  loader run retained 160 candidate-only samples; the later `b7e92cc5` CLI
  checks yielded 24 oracles and no performance samples. Later validation and
  documentation commits were not performance remeasured. The comparison
  harness came from unmerged PR #319 at `8ec52c88` (tree-equivalent to
  `48fed573`), independently of the product source. RSS did not improve
  consistently. Earlier ASOF noise results, historical release inconclusive,
  SQL sameHEAD RSS failures and ABBA informational boundaries remain unchanged;
  these measurements establish no release-wide performance result.

- 2026-09-20: Native streaming covers the `join` engine scenario through the
  100k tier. The bounded temporal join runs with the dimension side complete
  at the stream origin and an inclusive `before` bound spanning the
  workload, so every quote row matches exactly its symbol's factor row and
  the shared oracle applies. The engine matrix reaches 26 supported
  engine/scenario combinations and 180 engine cases; the 1M and 10M tiers
  of the native-stream join stay unsupported in the catalog by a
  user-directed pacing constraint (2026-09-20) — the join retains one state
  row per matched input row for the whole run, so samples need roughly 5
  seconds at 1M and 200 seconds at 10M on the dev machine, which would slow
  the whole suite's cadence.

- 2026-09-20: Fail the stream join's single-message output fast path before
  emission. The batched-emission fast path that emits one output record per
  input batch skipped the pre-emission output-sequence validation the chunked
  path performs, so an exhausted output sequence could build a batch before
  failing. The fast path now runs the same fail-closed sequence check first.
  The internal concatenation helper is renamed `concat_column` (from
  `concat_key_column`) to reflect that it concatenates payload columns as
  well as keys.

- 2026-09-20: Surface operator failure reasons and right-size ASOF workspace
  admission. Streaming error projection no longer collapses every operator
  reason into one opaque "operator ... execution failed" text: the
  engine-authored reason message and reason code are appended to the
  node-prefixed failure on the entry, task, and preflight surfaces. ASOF
  admission replaces its per-row schema tax (roughly 41 KB per admitted row,
  so a 10,000-row batch charged about 410 MB against a 64 MiB state limit)
  with an allocation-free arithmetic upper bound on each admitted row's
  bounded IPC encoding and an aligned-slice-plus-headroom identity charge.
  Charging stays arithmetic so an unfittable schema is rejected before any
  flatbuffer is built, `max_state_bytes` still bounds the workspace before
  any encode, and 10,000-row batches now pass under
  `AsofStateLimits(100_000, 64 MiB)`.

- 2026-09-20: Add protobuf and custom Kafka payload decoders. The Kafka
  source gains a third payload format, `protobuf/1`: one protobuf message per
  record value, decoded through a `FileDescriptorSet` loaded once when the
  source opens. The `descriptor_set` and `message` options name the serialized
  pool and the fully-qualified message, and the required explicit schema
  projects scalar message fields by name onto the Arrow vocabulary; enums
  decode to their value names. Proto3 implicit-presence fields decode their
  declared defaults, explicit-presence fields decode null when the column is
  nullable and fail closed otherwise, and repeated, map, bytes, and nested
  message fields fail closed with the field name preserved. The format is
  source-only; sinks reject it at option validation. Custom sources select a
  trusted decoder through the data-only `decoder` option and the `custom/1`
  binding format: Rust transports implement `FormatDecoder` and register
  through `KafkaDecoderRegistry` (shared into the source factory or global
  registration), while Python runtimes register callables through
  `Runtime.register_kafka_decoder`, which enforces the explicit schema and
  decode bounds. Registrations stay visible through the frozen connector
  snapshot, so decoders may register until the job opens; an unregistered
  identity fails the source at open time, and built-in format names are
  reserved.

- 2026-09-19: Emit the bounded stream join's matches as batched multi-row
  output records instead of one message per matched row. Each input batch's
  matches materialize in matched-pair order into one record, chunked into
  messages sized to the edge row/byte budget with one sequence per message;
  row order, pair semantics, the `emitted_match_rows` status counter, and
  checkpoint and watermark-eviction semantics are unchanged. Every chunk is
  validated before the first message leaves the operator, so a single
  over-budget row fails with the same `message.bytes` error before any
  emission instead of mid-stream, and a record that fits one message skips
  the per-row charge scan. Measured on the real runner (1:1 inner join,
  64,000-row batches): the 20,000-row workload drops from 5.4 s to 1.0 s
  (3,728 to 19,519 rows/s) and the 1M-row workload completes at 38,244
  rows/s; the `stream_join_perf` operator bench measures 40% lower latency
  on `one_to_one` and 43% on `fanout10`, with `no_match` unchanged.

- 2026-09-19: Extend benchmark native-stream and SQL operator coverage. The
  engine matrix adds `projection`, `filter`, and `group_by` to the native
  streaming column, for 25 supported engine/scenario combinations and 175
  engine cases; `join` stays unsupported because the bounded inner stream
  join emits one output stream message per matched row and cannot carry the
  10M-row scale. Every `sql_datafusion_performance` profile now measures
  `projection`, `filter`, `group_by`, and `join` workloads alongside the two
  rolling workloads, so serial-control, matched-adaptive, p32-saturation,
  and attribution evidence covers them. Non-windowed cases record
  `window: 0` and their true output cardinality in the evidence contract's
  new `output_rows` field; partition rows, skew, and verification follow
  that cardinality. `--require-stable` skips the CV check for per-sample
  medians under a 20 ms floor with an explicit note, mirroring the P1
  calibration-spec skip. Cases absent from the baseline catalog are measured
  as new coverage without the paired gate, the baseline catalog is parsed
  declaratively instead of executed, and the Rust comparison clears stale
  rust-cache bench executables per side so a colliding unit hash can no
  longer measure the baseline's bench as candidate evidence.

- 2026-09-19: Collect the engine-comparison Polars column through Polars'
  streaming engine. The engine-matrix adapter now uses
  `collect(engine="streaming")`, so the Polars column measures the streaming
  execution path by default and `docs/benchmark-suite.md` names the
  streaming collection in its timing-boundary table. Historical in-memory
  Polars timings are not directly comparable with the new streaming numbers;
  treat cross-engine engine-matrix comparisons as restarted from this
  change. Oracle equivalence holds on all six scenarios at 100k and 1M rows
  (`rtol=atol=1e-10`, `equal_nan`); at 1M rows streaming measures 1.4–2.1x
  faster than in-memory on join, group_by, filter, and projection and 1.4x
  slower on sma20. The hash-pinned Polars wheels move from 1.44.1 to 1.44.2
  within the existing `polars>=1.32,<2` range; the DataFusion pins stay at
  54.0.0, the latest `datafusion-python` release, matching the core's
  DataFusion major.

- 2026-09-19: Remove harness-owned costs from the paired SQL/DataFusion
  benchmark's timed windows. Peak memory now reads the kernel-maintained
  `VmHWM` high-water mark, re-anchored per sample through `clear_refs`,
  instead of a helper thread polling `/proc/self/status` every millisecond
  inside every timed sample, and timed samples no longer retain their output
  batch: the warm-up pair keeps proving completion equivalence. Outputs,
  phase boundaries, and the evidence schema are unchanged; on the nightly
  matched-adaptive profile the change removes 7–18% of measured median
  latency and 30–69% of peak RSS while tightening sample CV. The bench's
  self-tests now run through `scripts/run_rust_tests.py`, with the
  RSS-window test compiled only on Linux, so the new memory-window and
  retention contracts bind in CI; the harness change is declared in
  `benchmarks/rust-workload-migrations.json` as a measurement-only
  migration.

- 2026-09-18: Keep SQL/DataFusion stability evidence observable and confirm
  the P1 machine tiering with hosted-runner measurements. The weekly
  adaptive-tuning matrix job now uploads its screening and candidate reports
  with `if: always()`, matching the nightly job, so stability-gate failures
  still leave the measured JSON behind for tolerance recalibration; the
  within-run CV, independent-median, and independent peak-RSS verifier
  failures now name the measured value against the threshold, for example
  `cases[0].raw_datafusion CV 12.4% exceeds 10%` and `independent median
  ratio 1.18x (30.1 ms vs 35.5 ms) exceeds 1.10x for (...) raw_datafusion`.
  Runner-measured evidence from the same date (4-vCPU hosted runner:
  matched-adaptive p16 medians 218.2 ms `sma_20` and 307.5 ms
  `dual_sma_spread` against the 90/110 ms calibration budgets; paired
  ratios 0.99–1.03x; p16 peak RSS within 1.02–1.11x of the p1 control;
  measured p16/p1 latency factors 0.45–0.49 versus 0.22 on the 32-core
  calibration host)
  confirms the absolute budgets stay calibration-spec-only and the
  paired-ratio and RSS budgets remain the hosted-runner gates. The matrix
  stability tolerances (CV 10%, independent median 1.10x, RSS 1.15x) are
  unchanged pending measured 100k-row noise from the now-uploaded weekly
  evidence.

- 2026-09-18: Make the SQL/DataFusion P1 evidence gate machine-aware. The
  absolute latency budgets (90 ms `sma_20`, 110 ms `dual_sma_spread`) now bind
  only at or above the 16-logical-core calibration specification
  (`environment.available_parallelism >= 16`); smaller hosts, including GitHub
  hosted runners, pass with an explicit skip note instead of a failure, while
  the paired-ratio and p16-vs-p1 peak-RSS budgets keep binding on every host
  and latency and ratio read the better of the two independent repeats. P1
  failures now name the measured value against the threshold, and the nightly
  benchmark workflow uploads the measured reports with `if: always()` and
  runs each profile with `--warmups 2`.

- 2026-09-17: Scope Rust benchmark workload fingerprints per bench target and
  add an explicit declared-migration path for harness-pipeline bench source
  changes. Editing one `crates/calc-flow/benches/*.rs` file now removes timing
  classification from only that target's cases instead of the whole Rust
  shard. Bench source changes that do not alter measured workload semantics
  can be declared in `benchmarks/rust-workload-migrations.json`, which pins
  the exact baseline and candidate source SHA-256 values, a reason, and a
  reference, and is applied only on an exact byte match; undeclared or
  mismatched changes still fail closed with accepted rows marked
  `workload_migration` in the retained artifacts.

- 2026-09-13: Add executable late-output examples.
  `examples/26_late_side_output.py` drains paired normal and late outputs
  through one owned Program iterator with explicit result checks, including
  under `python -O`. `crates/calc-flow-connectors/examples/late_output_recovery.rs`
  replays a persisted source trace into two independent transactional Parquet
  sinks across separate cut, resume, and verify processes, proving per-output
  recovery without a cross-Sink transaction.

- 2026-09-13: Expose Studio late-output support in the capability contract.
  `GET /api/v3/capabilities` gains `runtime.lateOutput` with const-1
  `schemaVersion`/`metricsVersion` and the validated operator list, carried
  through the regenerated `openapi.json` and `schema.d.ts`; the browser
  `decoders.ts` rejects a late-output capability whose versions are not 1.

- 2026-09-13: Connect Python `with_late_output`/`LateOutputs` and Studio
  to native rolling/cross-section side output. One Program iterator drains
  paired TableExpr outputs sharing one state owner; local lateness/policy,
  full stage-input diagnostics, explicit consumption, and single-stage
  validation are preserved by lowering. Studio edits and preserves both
  ports, schemas, routes, and Sink bindings, probes actual runtime support,
  and rejects invalid projects before workers start. Normal computation
  matches Drop; late rows retain occurrence order without Watermark/Idle,
  while both routes join checkpoint epochs. Delivery is proved independently
  for each output, with no cross-Sink transaction or temporary-iterator
  restart guarantee.
  **Rust 5.0.0 migration:** downstream exhaustive matches on `LatePolicySpec`
  must handle `SideOutput { metrics_version, schema_version }`.
  `OperatorMetadata` now requires `Any`, so implementations must use
  `'static` types rather than borrowing non-static data. This is a breaking
  source change from Rust 4.x. All workspace crates, Python core, Studio,
  and frontend are 5.0.0; native internal crate dependencies are pinned
  to `=5.0.0`, Studio requires `calc-flow-python>=5.0.0,<6`, and
  `Cargo.lock`/`web-ui/package-lock.json` carry the aligned versions.
  Project format 3, manifest v3, REST `/api/v3`, and old Error/Drop
  serialization/checkpoint contracts remain unchanged. Enabling side output
  requires a new lineage and an explicit source activation/replay boundary;
  old checkpoints cannot restore historically discarded rows.

- 2026-09-13: Enable native rolling/cross-section late-output execution and
  durable recovery. Diagnostic branches and their supported expression/SQL
  derivatives carry data, barriers, and end-of-input without watermark or idle
  progress. Checkpoints persist a strict `late_output` version-1 object and
  restore the independent late sequence. Normal and late outputs participate
  in aligned epochs and terminal recovery, with delivery proved per output.
  Transactional Parquet recovery validates epoch/output identity, manifests,
  and the complete prepared file inventory before finishing a staged commit.
  Project/manifest formats and operator state layouts remain unchanged;
  Python expression compilation still accepts only error/drop.

- 2026-09-13: Extend the public rolling/cross-section `LatePolicySpec` and
  project schema with `SideOutput { metrics_version: 1, schema_version: 1 }`,
  a required `late` port, reserved diagnostic fields, and stream-only routing
  validation. Align package versions at 5.0.0 and Studio's core dependency with
  the v5 major. Native operators prepare whole-envelope state, metrics, and
  bounded diagnostic output before sending; accepted state and independent
  output sequences commit only after successful emission, and failed or
  cancelled sends forbid live callback retry. Managed runner admission and
  ordinary operator callbacks still reject side-output execution; this does
  not enable durable late-output recovery. Project and manifest versions
  remain 3, and Python expression compilation still accepts only error/drop.

- 2026-09-12: Optimize proven UInt64 modulo filters and compatible COUNT/AVG
  full-window SQL rolling plans, retaining fallback for unproved expressions.
  Reduce Native entity/history preparation and output charging; add bounded
  rolling stage metrics, eligible rolling/projection task pairing and job-owned
  entity lanes. Specialized Float64 mean readouts and output merging preserve
  numerical profiles, ordering, exact resource budgets and checkpoint
  compatibility. Cancellation and failure retain ownership through actual
  worker joins and cleanup. Operator failures publish their original error and
  signal cancellation before releasing input and output endpoints, preventing
  cascading edge closures from masking ASOF and checkpoint callback failures.
  CI verifies a complete report from an identical source tree before replacing
  a coverage comparison base with missing flags, preserving measurement identity
  and coverage thresholds. The entity-parallel gain target remains unmet;
  final full-matrix, tail-latency and memory/recovery measurements remain
  follow-up work, not claimed performance acceptance.

- 2026-09-09: Fix silent row loss when Python metadata normalization receives
  zero-column Arrow inputs with schema metadata (DAL-192). `compute` and
  collection (including async forms) and async iterable streams preserve input
  row counts while retaining caller metadata and `Batch.metadata`.

- 2026-09-09: Add the independent `stream_asof_join@1` native operator for
  bounded backward stream matching. Typed sequence identities make equal-time
  selection deterministic; strict dual-watermark finality preserves each
  accepted left row with nullable unmatched right fields. Immutable Python
  expression/builder declarations, project-v3 contracts, checkpoint recovery,
  bounded state/workspace, late policies, and payload-free status share the
  native implementation. Studio carries new ASOF metrics as exact decimal
  strings and preserves the new project kind on import/save. Existing inner
  Join configuration and checkpoint contracts remain independent.

- 2026-09-09: Make Python expressions, SQL, and composable functions the
  application API, with Rust as the internal runtime. Root imports, overloaded
  operators, named table methods, inferred Arrow schemas, and automatic Program
  inputs simplify authoring. `compute`/`compute_async` and collection return
  Arrow tables with independent batch state. `cf.sql` and `TableExpr.sql`
  compose native SQL with expressions; `Expr.pipe` applies reusable synchronous
  functions at declaration time. SQL schemas are planned natively without row
  execution. `TableExpr.stream` and `Program.stream` own one native job through
  async contexts and iteration, retaining state across batches and returning
  tables or named output events with bounded backpressure and awaited cleanup.
  Event-time iterables default to nondecreasing timestamps across the source
  and native watermarks at `max_seen - 1 microsecond`, producing finalized
  temporal results before EOF. The `watermarks` keyword selects existing
  policies for disorder, iterable-provided progress, or named input policies;
  source-bound policies remain explicit. Timestamp-free stateless inputs need
  no progress configuration.
  Iterable inputs use best-effort delivery and temporary managed checkpoints;
  durable recovery keeps explicit bindings and managed state. Stream SQL uses
  one alias and per-batch semantics, with no inherited temporal ordering.
  `Program.to_project` exports data-only native graphs. Project-v3, managed
  checkpoint, provider, and Studio REST contracts retain their formats.
  Documentation and executable SQL/streaming examples use this Python path.

- 2026-09-08: Compile symbolic fixed UTC tumbling/hopping event-window
  aggregation into the existing native window operator. Immutable
  `WindowAggregate` declarations and `window.count/sum/min/max/avg` helpers
  define ordered output columns; aggregate-bearing declarations use `@2`,
  while aggregate-free `@1` declarations retain their canonical identities.
  Each unique complete declaration shares one native state owner across
  branches. Exact schema and distinct row-origin analysis constrain window
  paths to stateless table transformations before and after aggregation.
  Native schema planning confirms the nullability of those transformations
  without opening sources or executing user rows; a bounded runtime cache
  retains successful schema results separately from compiled plans.
  Native final output, late-assignment dropping, metrics, and checkpoint
  layout remain authoritative. Symbolic stream compilation caches immutable
  project JSON and creates a fresh owning plan for each job or restart.

- 2026-09-08: Consolidate connector documentation under `docs/connectors/`
  with an overview and one guide per transport, each linking its Python
  example, service setup, configuration, and delivery contract. Move shared
  stream graph and static-input fragments into the project guide.

- 2026-09-08: Add standalone Python examples for all seven native source
  connectors, including CSV, JSON Lines, and Parquet file inputs. Document
  optional wheel features and reproducible service setup, check calculated
  Parquet outputs, and make service examples opt-in in the example runner.

- 2026-09-06: Organize documentation from overview and first run through
  function guides, API references, design, and development operations. Add
  batch, array, project-persistence, and Studio guides tied to executable
  examples; separate the symbolic API and compiler design. Add a JSON/YAML and
  async file-store round-trip example and result assertions in introductory
  programs. Consolidate historical narrative here. Dated plans, research,
  audits, migration guides, and per-commit performance reports are retained in
  [the documentation tree before this reorganization](https://github.com/wegamekinglc/calc-flow/tree/1ba2521abcb9fd3dcdb0747ccfe026bcea31f7b3/docs)
  and Git history rather than the current documentation tree.

- 2026-09-06: Publish the Python distribution as `calc-flow-python`, retaining
  `import calc_flow` and the `calc-flow` Rust crate. Restrict PyPI uploads to
  the core package, preserve Studio build/smoke validation, and require an
  explicit ancestor performance baseline for the first release.

- 2026-09-06: Add the opt-in MySQL connector with InnoDB consistent snapshots,
  monotonic integer cursor polling, parameterized append/upsert writes, and
  recoverable epoch-ledger transactions. Include verified TLS by default,
  Python feature registration, and MySQL 8.4 container and coverage gates.

- 2026-09-05: Unify the complete Linux CI benchmark inventory and full-result
  tables across all Python scales, Rust, Studio, frontend and stream lifecycle.
  Add SQL/native-stream and DataFusion/Polars/TA-Lib comparisons from 10 to
  10,000,000 rows, warm-state append cases, sealed release provenance and
  repeat-confirmed base/head regression gates. Retain informational labels for
  legacy block comparisons and external references, including raw failure
  evidence and explicit missing-case reports.

- 2026-09-05: Consolidate Python connector callback preparation into one
  interpreter attachment and skip row-count maps for resident rolling entities.
  Add opt-in bounded callback wall-clock diagnostics and legal sparse-entity
  append workloads down to one row. Paired measurements now isolate each
  scenario in fresh workers with seeded randomized scenario order.

- 2026-09-05: Reduce warm-state streaming overhead with column-only Arrow
  projections, validated columnar rolling finalization, exact column-wise
  output byte charging, touched-entity state staging, and retained-history
  append deltas. Preserve general-path fallback and checkpoint layouts. The
  Python bridge coalesces ready dispatches and avoids extra loop turns for
  immediately completed work while respecting custom task factories and
  connector lifecycle ownership. Operator elapsed-time metrics now include
  successful watermark handlers and expose their duration separately. Add
  provenance-bound release builds and a paired persistent-runner benchmark
  with strict numerical/identity checks and separate forced/normal-GC results.

- 2026-09-04: Add reproducible SQL-versus-DataFusion performance controls and
  evidence gates. Project-v3 and the immutable Python builder now expose
  compatible fixed parallelism plus opt-in conservative auto partitioning,
  trusted active-entity metadata, explicit decision telemetry, phase and
  physical-operator metrics, and rollback switches for bounded AVG rewrites
  and diagnostic collection. A same-binary AB/BA benchmark, strict JSON
  contract, P1 verifier, P3 Pareto matrix, P4 attribution gate, nightly and
  weekly workflows, and DataFusion boundary semantics tests cover the release
  path. Auto remains opt-in; cross-run caches and partition-preserving DAG
  envelopes remain evidence-gated No-Go directions.

- 2026-09-03: Extend Python and Studio capability contracts to schema version
  3 with the validated operator `state_layouts` inventory. Carry the inventory
  through the REST response, OpenAPI, and browser decoder; reject capability
  responses with an unsupported schema version.

- 2026-09-02: Add symbolic relational stream-join DAGs and explicit post-join
  ordering (SCE-18). Independent and nested bounded joins, unrelated outputs,
  and ordered post-join rolling/cross-section stages now lower to one existing
  native `stream_join@1` state owner per unique declaration. Calls without
  output ordering retain byte-identical symbolic `stream_join@1` identity;
  complete canonical entity, event-time, and sequence metadata uses symbolic
  `stream_join@2` and lowers away before project-v3 compilation. Three-source
  reference vectors cover segmentation invariance and checkpoint recovery
  with both nested join states retained. No Python execution path, native join
  checkpoint layout, or project format changes.

- 2026-09-01: Add durable unadjusted EWMA and composed MACD to the symbolic
  temporal catalog (SCE-16). `ts.ewma` and its exact-node alias `ts.ema` share
  native state by entity, input, and span while retaining independent
  `min_periods` gates; `ts.macd` remains a pure fast-minus-slow composition.
  Rolling checkpoints use layout v2 only when exponential accumulators are
  present and restore those accumulators without requiring retained row
  history. Finance-Python-derived reference vectors, segmentation and
  recovery coverage, public examples, and a same-process paired benchmark
  freeze missing-value and restart behavior.

- 2026-09-01: Extend symbolic stateful composition without adding a second
  execution engine. The lowerer now schedules nested rolling expressions as
  deterministic innermost-first project-v3 stages, materializes row-local
  inputs before rolling and cross-section state, and shares identical
  multi-stage rolling pipelines across output branches. Existing one-stage
  node identifiers and serialized shapes remain stable. Finance-inspired
  acceptance vectors now include composed RSI, and the public streaming
  example checkpoints a two-stage rolling program mid-stream, restores both
  native states from the replay cursor, and verifies terminal restart without
  duplicate output. EMA/EWMA and MACD were deferred here and subsequently
  delivered by SCE-16 after their algorithm and durable-state contract froze.

## 2026-08

- 2026-08-31: Integrate symbolic computation across Studio, public examples,
  documentation, and release gates (SCE-15 / DAL-147). Studio's node inspector
  now derives serialized source expressions, lowered node/provider identity,
  state and watermark bounds, static-input declarations, and copy boundaries
  exclusively from strict project-v3 documents; it remains an inspector, not
  a second symbolic compiler. Executable examples cover composed financial
  features, symbolic stream checkpoint recovery, and static NumPy matrices in
  batch and stream modes, alongside the existing NumPy/JAX provider example.
  The public symbolic workflow guide documents capability failures and the
  distinction between compile-time cost facts and measured runtime metrics.
  Artifact inspection now rejects repository-only symbolic plans/specs from
  wheels, sdists, and crates while retaining current public documentation.

- 2026-08-31: Optimize complete symbolic programs (SCE-14 / DAL-146).
  Identical pure expression materializations now share one program-wide stage;
  compatible rolling outputs share one history/partition index, and compatible
  cross-section outputs share one grouping/sort stage across output branches.
  Prefilter identity and exact group finality remain part of compatibility, so
  filters are never moved across temporal or cross-section finality boundaries.
  Consecutive array work remains one fused provider stage at the explicit
  table/array boundary. Each `Runtime` caches immutable batch and stream plans
  by program fingerprint, mode and lateness, exact input declarations,
  capability schema/session/revision, and selected operator/provider/UDF
  versions; every successful runtime registration invalidates the cache.
  `Program.explain()` now appends deterministic physical sharing plus bounded
  state, copy-boundary, static-weight, and provider-call cost facts without
  exposing row values, static contents, or object identities.

- 2026-08-30: Compile symbolic table/array matrix segments (SCE-13 / DAL-145)
  through built-in NumPy and JAX `symbolic_matrix@1` providers. Explicit
  selected-column order, row lineage, safe float32/float64 promotion, static
  weight matmul, and named table attachment now lower for batch and stream.
  Streaming latches and places weights once per job, reuses the same immutable
  weights object across micro-batches, invokes one fused callback per segment,
  and exposes table/array and one-time weight-placement copy bytes in output
  metadata. Placement bytes count logical provider transfer rather than peak
  memory, process RSS, or the transient internal snapshot clone. Shape, width,
  backend, JAX x64, and provider output row-count checks fail closed. Rust now
  exposes the manually approved, non-exhaustive owned
  `StaticArraySnapshot`/`StaticArrayValues` seam as the complete SCE-13
  crate-root export delta, plus
  `Batch::static_array_snapshot()` with five read-only accessors, without
  `Clone`, value-bearing `Debug`, serde, construction, or mutation support.
  Project compilation cross-checks both static declaration kinds against their
  unconnected port kinds. Matrix lowering requires every `from_columns` source
  to be the attached table and exactly one matmul; the only occurrence of the
  static `weights` identity is that matmul's direct RHS. Analyzer/provider dtype
  promotion and primitive domains agree. First placement, including the
  transient snapshot clone and provider conversion, runs on a blocking worker
  and commits its cache atomically only after success and a post-worker
  cancellation check.

- 2026-08-29: Complete grouped cross-section features (SCE-10). The shared
  native `CrossSectionOperator` now evaluates winsorize, top/bottom selection,
  and mean-fill alongside rank/percentile/demean/z-score without duplicating
  grouping, sample classification, or measured-value sorting for compatible
  outputs. Winsorize uses Hyndman-Fan type-7 quantiles and preserves float32 or
  float64; top/bottom return nullable boolean masks with positive `count`,
  explicit `include_ties`, exact scalar ordering, and canonical-identity
  boundary tie breaking; mean-fill replaces only null floating values when
  `min_samples` is met and preserves valid values, NaN, and input type. The
  strict project-v3 variants, Python `cs.winsorize`/`cs.top`/`cs.bottom`/
  `cs.mean_fill` lowering, generated JSON Schema/OpenAPI/TypeScript contracts,
  and Rust/Python docs move together. Batch, final-only stream, segmentation,
  exact/fixed-bucket partitioning, late-event policy, state release, and
  checkpoint/recovery continue to use the existing group-final lifecycle and
  state layout version 1.

- 2026-08-29: Keep incremental window checkpoints self-contained across
  epochs by carrying every retained immutable state segment named by the
  snapshot inventory. Restart recovery no longer depends on an earlier
  process retaining those segment bytes in memory.

- 2026-08-29: Add stateless external stream providers (SCE-12 / DAL-144).
  Rust gains the public `StreamOperatorLifecycle` proof: external
  `StreamOperator` implementations default to `Unproven`, while trusted
  factories may declare a stateless lifecycle with separate micro-batch
  invariance, determinism, and replay-safety claims. Stream compilation
  revalidates that proof for operators classified as stateless, and any plan
  requesting exactly-once output also rejects such a provider when it is
  nondeterministic or replay-unsafe. Checkpointed-stateful operators remain
  eligible through their versioned checkpoint capability. An unproven
  operator may still produce an ordinary stream plan, preserving the existing
  two-stage contract, but a runner configured with checkpoints rejects that
  plan during admission before opening connectors; exactly-once requires a
  checkpoint runtime and therefore cannot admit the unproven operator. The
  Python stateless bridge invokes its trusted callback once for each accepted
  data micro-batch on a blocking worker, converts callback failures to provider
  errors, and emits only after a post-callback cancellation check and output
  validation. An already running `spawn_blocking` callback is not
  preempted; cancellation observed after a successful callback discards its
  result without emitting it. NumPy and JAX `expression@1` opt into this
  lifecycle only for the conservative row-axis-independent subset: the
  expression must depend on `x` and contain neither a function call nor matrix
  multiplication. Their `table_matmul@1` registrations remain batch-only;
  static-input matrix multiplication is deferred to SCE-13.
- 2026-08-28: Add the native cross-section operator for complete-group
  rank, percentile, z-score, and demean across Rust, Python, and the
  regenerated contracts. `CrossSectionOperator` evaluates exact-time or
  fixed-bucket groups — one group per exact event time and partition key,
  or per UTC `[start, start + width)` bucket — under the rule that one
  micro-batch is never evidence of completeness: groups accumulate across
  envelopes and close only when the input watermark reaches the group's
  finality coordinate (the exact event time or bucket end plus the allowed
  lateness, with equality closing) or at end of input, then emit once in
  canonical order — groups by finality coordinate then key, rows by event
  time, entity, and sequence — and release their state and identity index.
  The data-only `CrossSectionSpec` joins project format v3 with the frozen
  fields: configuration and state-layout versions 1, a non-null UTC
  `timestamp[us]` event-time column, ordered `entity_by` and `sequence_by`
  keys, an optional `partition_by` key whose empty value selects one global
  group per grouping coordinate, the `exact_time`/`fixed_bucket` grouping,
  `outputs` (kind `rank`, `percentile`, `demean`, or `zscore` with
  `primitive_version` 1, input/output names, and `min_samples`; the order
  statistics add `direction`, `tie_method`, and `null_placement`; `zscore`
  adds `ddof` 0 or 1), `allowed_lateness_micros`, `late_policy`, and the
  frozen `nan_exclude_preserve_v1` value policy. The JSON Schema, Studio
  OpenAPI document, and TypeScript contract regenerate in the same commits.
  Late rows follow the policy — `error` rejects the whole envelope
  transactionally before any state changes, and `drop` discards the row and
  records metrics — duplicate row identities are rejected across partition
  groups within one envelope and across open envelopes, and open groups
  checkpoint at the aligned epoch cut as versioned Arrow IPC state that
  restores the watermark frontier, output sequence, and metrics, so batch
  and stream produce the same rows across segmentation and recovery.
  `Program.compile_batch` and `Program.compile_stream` lower
  `cs.rank`/`cs.percentile`/`cs.demean`/`cs.zscore` declarations into
  cross-section nodes: the input must declare its ordering keys, every
  occurrence in one output must share one grouping declaration — the same
  partition columns and the same exact-time-or-bucket-width shape — and
  `cs.winsorize` remains rejected in this release. The capability snapshot
  reports `cross_section@1` as a batch/stream,
  group-final-append-only, watermark-requiring, micro-batch-invariant,
  checkpointed-stateful operator with state version 1 — the first operator
  reporting `group_final_append_only`.

- 2026-08-28: Add event-time duration frames and the rolling aggregates
  `min`, `max`, `covariance`, and `correlation` to `RollingOperator` across
  Rust, Python, and the regenerated contracts. Aggregate outputs now declare
  either a `rows` frame or a `duration` frame — the exact-width event-time
  interval `(t − micros, t]`, open at the lower bound — with `min_periods`
  capped at the frame size for `rows` frames only; per-entity retention
  keeps the largest row demand and the widest duration bound together, so
  mixed row/duration outputs retain by both bounds. `min`/`max` read a
  monotonic extrema queue over the total-order column types (booleans,
  integers, floats, strings, dates, `timestamp[us]` with no timezone or
  UTC), preserve the input type, and order floating samples by the IEEE
  total order, so −0.0 and +0.0 are distinguishable — a self-consistent
  deterministic choice, not SQL `MIN`/`MAX` semantics.
  `covariance`/`correlation` declare left/right
  input columns and read a reversible West co-moment accumulator over
  pairwise-valid positions; their classification order is frozen — the
  `min_periods` and divisor null gates first, any ±inf on either side reads
  NaN, and only a finite zero-variance window reads null for correlation —
  so an infinity window never reads null. Checkpoint segments still store
  only retained history and buffered rows, with the extrema queues and pair
  state rebuilt by the same ordered fold on restore. The Python constructors
  `ts.min`, `ts.max`, `ts.covariance`, and `ts.correlation` and
  duration-frame windows lower into rolling nodes; the JSON Schema, Studio
  OpenAPI document, and TypeScript contract are regenerated in the same
  commit.

- 2026-08-28: Add immutable static stream inputs (SCE-11). Stream plans can
  now declare per-job immutable side values — model weights, reference
  matrices, lookup tables — that are validated, latched, and digested exactly
  once per job during runner start, before any source opens. Python gains the
  keyword-only `StreamingRunner(..., static_inputs=...)` mapping of `Batch`
  values and the `StreamExecutionPlan.static_input_ids` property; Rust gains
  the additive `StreamingRunner::with_static_inputs` builder, plan-level
  `static_input_ids()`/`static_inputs()` accessors, and the crate-root
  `StaticInputSpec`, `StaticInputDigest`, `StaticMutability`, and
  `STATIC_INPUT_DIGEST_VERSION` exports. Project-v3 documents declare the
  inputs as a data-only root `static_inputs` array naming graph external
  input ports; live values never enter the document. Each value is reduced to
  a `calc_flow.static_input.digest.v1` SHA-256 digest over canonical tagged
  bytes; declarations join the plan fingerprint while payload digests stay
  out of the lineage key, so a restart with a different value reaches the
  existing lineage and is rejected before sources open with a frozen message.
  Checkpoint manifests record one digest per name under `static_inputs`,
  omitted when empty. Studio `POST /jobs` fails closed with `422` before
  spawning a worker for projects declaring static inputs, since REST cannot
  carry live values. Compatibility is fully additive: existing Python and
  Rust call sites are unchanged, previously valid project-v3 documents and
  checkpoint manifests serialize byte-for-byte identically, and the project
  format version stays `3`.

- 2026-08-28: Reject wall-clock built-in functions in stream query
  compilation (DAL-166). `compile_stream` now rejects read-only expression
  and SQL queries that call `now`, `current_date`, or `current_time`:
  DataFusion declares these built-ins `Volatility::Stable`, so the
  volatile-function guard let them compile while checkpoint replays of the
  same input produced different output, breaking the replay-safety the
  guard exists to protect. The check resolves each call against the
  built-in default function registry and matches the canonical name, so
  the `current_timestamp` and `today` aliases and the no-parenthesis
  keyword spellings are rejected too, with the same error shape as the
  volatile rejection. This is a user-visible tightening: existing stream
  queries that call these functions now fail at compile time. Batch query
  compilation is unchanged.

- 2026-08-26: Make epoch checkpoint capture cost proportional to the dirty
  set, not the retained state (DAL-160). `OperatorStateSnapshot.segments`
  now maps segment IDs to the new public `StateSegment` type — an
  allocation-shared (`Arc`) byte buffer with a SHA-256 computed once at
  construction — replacing `BTreeMap<String, Vec<u8>>` in a breaking Rust
  API change; custom `StreamOperator` checkpoint implementations and
  snapshot consumers must wrap segment bytes in `StateSegment::new`. The
  stream Join encodes dirty upserts from the records its dirty log carries
  at admission instead of scanning live state per dirty row, eliminating a
  quadratic capture path that reached 45–78.5 s per epoch at ~1.04M
  retained rows, and carries prepared base/delta segments across epochs by
  sharing allocations rather than copying bytes. The manifest transaction
  reuses the already-committed handle for a segment whose content is
  unchanged since the current session committed it, skipping the per-epoch
  re-hash, re-write, and re-validation of carried state; recovery-time
  manifest selection still revalidates every referenced segment byte on
  every fresh session (AC-08), while same-session publish and retention
  skip that redundant re-read. Manifests may now reference handles
  committed at earlier epochs, and recovery loads validate handle ownership
  without requiring one shared epoch. A resident `stream_join_perf`
  Criterion suite preserves the frozen AC19 join baseline (nine scenarios
  plus a capture-independence canary pair) for future 0.80×/1.20× gate
  comparisons; the scheduled nightly workflow stays contract-frozen to the
  `core` harness.
- 2026-08-27: Add the native row-window rolling operator for lag and delta
  across Rust, Python, and the generated contracts. `RollingOperator`
  evaluates ordered `lag`/`delta` outputs over entity-partitioned, event-time
  rows in both batch and final-only stream graphs: stream evaluation buffers
  rows until the input watermark passes each row's closing coordinate, then
  emits final rows in canonical order, classifying late rows with an
  envelope-scoped `error` policy or a metrics-recorded `drop` policy; its
  per-entity histories checkpoint at the aligned epoch cut with state version
  1, and batch and stream produce the same ordered rows across segmentation
  and recovery. The data-only `RollingSpec` joins project format v3 with nine
  required fields — `configuration_version`/`state_layout_version` 1, ordered
  `partition_by`/`sequence_by` keys, a non-null UTC `timestamp[us]`
  `event_time` column, `outputs` (kind `lag` or `delta`,
  `primitive_version` 1, input/output names, positive `periods`),
  `allowed_lateness_micros`, `late_policy`, and the frozen
  `stateful_numeric_v1` value policy — with the JSON Schema, Studio OpenAPI
  document, and TypeScript contract regenerated in the same commit.
  `Program.compile_batch` and `Program.compile_stream` now lower
  `ts.lag`/`ts.delta` declarations into rolling nodes, requiring declared
  `entity_by`/`event_time`/`sequence_by` ordering keys and, in this release,
  plain input-column arguments; `compile_stream`'s validated
  `allowed_lateness_micros` and `late_policy` are written into every lowered
  node. The capability snapshot reports `rolling@1` as a batch/stream,
  per-row-final, micro-batch-invariant, checkpointed-stateful operator with
  state version 1. Rolling aggregates, duration frames, correlation, and
  cross-section declarations remain loudly rejected.
- 2026-08-28: Add the native rolling aggregates `count`, `sum`, `mean`,
  `variance`, and `stddev` to `RollingOperator` across Rust, Python, and the
  regenerated contracts. Each aggregate output declares a `rows` frame and
  `min_periods`, with `ddof` 0 or 1 on the two statistical kinds; valid
  samples are non-null, non-NaN values, infinities count as numeric samples,
  and the minimum-period gate reads null so a computed NaN stays distinct.
  Output types follow the frozen table: `uint64` count, checked `int64` /
  `uint64` integer sums, and `float64` for floating sums and every
  statistical output. Floating sums follow IEEE arithmetic; integer sums
  slide through a wide transient accumulator with a checked narrowing at
  readout, so a window whose true sum is representable never reports a false
  overflow while genuine integer overflow fails the run loudly. Mean,
  variance, and standard deviation read a reversible West accumulator that
  also counts the window's infinities: a mean over one infinity sign is
  that infinity, over both signs it is NaN, and variance and standard
  deviation over any infinity window are NaN behind the minimum-period and
  divisor null gates — the ±inf readout semantics were adjudicated in
  `.codex/artifacts/critiques/sce-07-rolling-inf-mean.md`. Outputs over the
  same input column and frame share one accumulator group, and the
  checkpoint segment still stores only history and buffered rows, with
  every accumulator rebuilt by the same ordered fold on restore. The Python
  constructors `ts.count`, `ts.sum`, `ts.mean`, `ts.variance`, and
  `ts.stddev` lower into rolling nodes; `ts.min`, `ts.max`, correlation,
  and duration frames remain rejected.

- 2026-08-26: Compile symbolic row-local programs into execution plans.
  `Program.compile_batch(runtime)` and `Program.compile_stream(runtime, *,
  allowed_lateness_micros=0, late_policy="error")` lower literal, field,
  arithmetic, comparison, boolean, `where`, `coalesce`,
  `log`/`exp`/`sqrt`/`abs`/`clip`/`cast`, and
  `select`/`filter`/`with_columns` declarations into strict project-v3
  `expression` nodes. Row-local chains fuse into one node per program
  output, and structurally shared non-trivial subexpressions materialize
  exactly once through deterministically named CSE tiers. Node IDs and plan
  fingerprints are deterministic, the lowered project carries strict JSON
  only, the Rust graph compiler keeps final validation, and no symbolic
  Python runs while a compiled plan executes. Declarations outside the
  row-local lowerer fail loudly at compile time. Stream compilation now
  also rejects read-only `expression`/`sql` queries that call volatile
  built-in functions such as `random()`, resolved against the built-in
  default function registry, so the deterministic and replay-safe
  capability claims of those operators stay truthful.

- 2026-08-26: Add the complete Python publication boundary: a cross-platform
  local package builder, five-platform abi3 matrix and metadata verification,
  SHA-256 release manifests, annotated-tag and PyPI immutability checks, and
  separate OIDC Trusted Publisher jobs for `calc-flow` and
  `calc-flow-studio`. Studio now publishes a nonempty package README, and its
  frontend helper modules use case-distinct filenames so release builds also
  work on Windows.

- 2026-08-25: Extend the runtime capability snapshot to lifecycle-aware
  schema version 2 across Python and Studio. `OperatorCapability` and
  `ProviderCapability` report execution modes, output finality, statefulness,
  micro-batch invariance, watermark requirement, checkpoint support with a
  positive state version exactly when checkpointed state is declared,
  determinism, and replay safety; providers additionally report static-input
  support, a partition contract, and closed `CapabilityRule` /
  `ProviderArrayRules` identities. The vocabularies and rule identities are
  closed and validated fail-closed at construction, in the Studio `/api/v3`
  response models, and in the browser decoder: unknown identities, forged
  lifecycle keys on registration records, and inconsistent state claims are
  rejected. Existing provider registrations stay source compatible and
  report batch-only conservative values until an approved stream proof
  exists. `GET /api/v3/capabilities` serves `schemaVersion` 2 with the
  nested runtime version removed; clients consuming the version 1 shape must
  regenerate their contract.

- 2026-08-24: Add the public symbolic declaration surface
  `calc_flow.symbolic`. Typed immutable column, table, array, and parameter
  expressions carry canonical v1 digests; an ordered `FeatureSet` of uniquely
  named features feeds `TableExpr.with_columns` as derived columns; and an
  immutable `Program` over declared inputs and outputs carries a
  runtime-independent v1 fingerprint that conforming implementations reproduce
  byte-for-byte. A complete program verifies, fingerprints, and explains with
  no data or runner: `Program.analyze(runtime, mode=...)` and
  `Program.explain(runtime, mode=...)` take one explicit runtime capability
  snapshot and statically infer value types, domains and lineages, symbolic
  dimensions, attachment compatibility, state requirements, and stream safety,
  reporting immutable `AnalysisIssue` findings on stable output- or
  input-rooted paths. Type inference proves only what the capability snapshot
  proves, so cross-type arithmetic requires an explicit `row.cast`. The
  package has no data execution path; execution remains owned by the existing
  execution plans and runners.

- 2026-08-22: Release the 4.0 bounded event-time stream Join across Rust,
  Python, project v3, and Studio. The inner equi-Join has explicit asymmetric
  time bounds, required state and match limits, deterministic recovery, typed
  failure reasons, and independently checkpointed output-watermark progress.

- 2026-08-21: Add a maintained cross-language example runner, Python terminal
  checkpoint recovery and Rust event-time window examples, a complete
  executable-example inventory, a continuous streaming usage guide, and a
  component-level design and architecture guide. Reconcile current docs with
  the public project-v3, connector, recovery, and Studio `/api/v3/jobs`
  surfaces.

- 2026-08-21: Close every P0 finding from the 2026-08-19 audit. The canonical
  Rust/PyO3/Python project contract is v3, registered connectors own their
  deferred source/sink lifecycles, PostgreSQL CDC and delivery preflight are
  complete, Studio jobs own the native continuous runtime, and the 3.0 release
  and verification gates are restored. This supersedes the temporary M6/M7
  withdrawal below.

- 2026-08-19: Withdraw M6/M7 acceptance pending the
  [current-main audit](https://github.com/wegamekinglc/calc-flow/blob/1ba2521abcb9fd3dcdb0747ccfe026bcea31f7b3/docs/superpowers/audits/2026-08-19-continuous-streaming-v3-current-main.md).
  The 2026-08-18 entries record merged, release-labelled slices, not completed
  milestone gates: the canonical project/PyO3/Python surface is still v2,
  registered connector lifecycles and database protocols are incomplete, and
  Studio jobs do not yet own the native continuous runtime. Repair the 3.0
  release trigger and release-helper unit-test coverage, but do not publish
  3.0 until every P0 audit finding and the exact-head M7 evidence are closed.

- 2026-08-18: Complete the M6 connector milestone. The
  `calc-flow-connectors` workspace crate ships six transports behind
  feature gates — file/Parquet (default), Kafka, PostgreSQL,
  ClickHouse, and HTTP/WebSocket — each registering through the
  trusted `ConnectorRegistry` with the eight-axis capability
  vocabulary. Project format v3 introduces `runtime.mode`,
  connector-bound source/sink/database bindings, `SecretRef`
  credentials, and `StateConfig`; `schemas/project-v3.schema.json` is
  the canonical contract and the v2 schema artifact is removed. The
  Python surface exposes `registered_connectors()` and the
  `ConnectorCapability` types; Studio serves the `/api/v3` continuous
  job API with checkpoint, shutdown, cancel, SSE events, and the
  `ResourceLimits` endpoint replacing the v2 worker timeout.
- 2026-08-18: Add the M7 release gates.
  `scripts/verify_perf_gates.py` evaluates paired Python statistics and Rust
  Criterion confidence intervals at the 5% regression threshold and documents
  the opt-in 1,200-second soak
  procedures; `scripts/verify_security_gates.py` publishes the
  18-entry threat-model coverage checklist linking each security
  boundary to its named enforcement evidence.

- 2026-08-15: Harden the public continuous-runtime delivery. Python blocking
  start now reclaims its dedicated event-loop thread after blocking or async
  terminal operations, observer cancellation during cleanup, and abandoned-job
  GC; a native terminal outcome that has already linearized retains precedence.
  Studio POSIX checkpoint replace and unlink paths fsync the parent directory.
  Public diagnostics fail closed and redact non-portable source IDs. The
  48-case fault matrix and three-process soak now run through the crate-root
  public facade and read real fault, cancellation, checkpoint-failure, and
  registry probes, while a real POSIX directory-sync failure test strengthens
  indeterminate manifest-publication evidence.

- 2026-08-14: Complete the A6 continuous-runtime cutover. Rust now exports the
  source-driven connector, binding, managed-checkpoint, one-shot
  `StreamingRunner`, and owning `StreamingJob` surface at the crate root.
  Python exposes that lifecycle as the sole `StreamingRunner`. The v2
  `Source`/`Sink`, `MicroBatchRunner`, push runner, public checkpoint store,
  and their PyO3 compatibility classes are removed with no aliases. Studio's
  unchanged v2 checkpoint inspection routes use a private async document
  store; project format v2, checkpoint manifests v3, REST, and OpenAPI remain
  unchanged.

- 2026-08-13: Add crate-private stable operator checkpoint identities and
  explicit stateless, versioned stateful, or unproven capabilities. Stream
  fingerprints now freeze the capability contract, checkpoint admission
  rejects unproven operators before task registration, restore fails closed on
  state-layout version mismatch, and per-output delivery proof records both
  requested and effective guarantees without silently upgrading at-least-once.

- 2026-08-12: Preserve full-range late-window accounting when the watermark
  and window end span more than `i64::MAX` microseconds. Valid `EventTime`
  inputs now record the exact `u64` lateness metric instead of aborting the
  input batch with a signed-subtraction overflow.

- 2026-08-10: Add the crate-private M5 epoch-checkpoint runtime: whole-job and
  per-output capability preflight, globally aligned source/operator cuts,
  manifest-last state publication and strict recovery selection,
  transactional and epoch-idempotent sink completion, mixed ended/live and
  terminal recovery, retention/orphan cleanup, owner-settled cancellation, and
  payload-safe checkpoint status and metrics. Add the 48-case fault matrix,
  scoped M5-D12-E1 benchmark orchestrator, and three-process 20-minute
  checkpoint/restart soak harness. Existing public v2 runner and checkpoint
  APIs, project formats, Python binding, and Studio routes remain unchanged.

- 2026-08-08: Add the public v3 state and window surface: strict bounded
  checkpoint manifests, lineage-exclusive `StateBackend` sessions,
  immutable checksum-verified `LocalStateBackend` segments, deterministic
  compaction, and the stream-only `WindowAggregateOperator` with fixed UTC
  tumbling/hopping windows, ordered aggregates, late-assignment accounting,
  deterministic close output, and incremental Arrow IPC snapshots. The
  source-driven runtime remains crate-private, and barrier coordination,
  durable restart, Python bindings, and Studio contracts remain unchanged.

- 2026-08-08: Add crate-private job-scoped stream progress coordination with
  deterministic source policies, watermark aggregation, idle/reactivation,
  timer ordering, completion receipts, progress snapshots, and replayable
  traces. This capability prepares continuous execution without changing the
  public v2 runners or adding a Python or Studio surface.

- 2026-08-06: Complete the crate-private M2 continuous-runtime skeleton with
  whole-job preflight, bounded source/operator/sink tasks, stable supervision,
  private runner/job/reaper lifecycle, deterministic metrics, stress coverage,
  and the universal 1,200-second soak gate (10-second cadence, 120 samples,
  30-sample/300-second warm-up). Failed or cancelled launch now closes every
  begun resource in stable order with an independent five-second timeout per
  resource; typed cleanup diagnostics preserve the primary outcome. Add the
  non-exhaustive `CalcFlowError::TaskPanicked` variant as this slice's sole
  public API item. Without changing `EdgeBudget` or `edge_channel` signatures,
  `(R, B)` now independently caps queued envelopes and charged rows at `R`, and
  charged bytes at `B`; direct callers must choose
  `R >= max(required_row_limit, required_simultaneous_messages)`. Existing
  public v2 runners remain unchanged until the separately reviewed post-M5 A6
  integration.

- Unify batch memory metering ahead of bounded stream channels. `Batch` and
  `TableBatch` gain `estimated_bytes()`: table batches are charged the Arrow
  memory size of their visible slices (sliced arrays sharing a larger backing
  allocation are charged only their visible window), and `ExternalPayload`
  now requires an exact or conservative `estimated_bytes()` with no opt-out —
  a breaking change for payload implementors. Row and byte sums use checked
  arithmetic and report overflow as a typed `InvalidArgument` error. Python
  NumPy and JAX payloads report their exact visible bytes (views are charged
  their visible window, empty arrays zero); host objects without an `nbytes`
  report receive a logical per-element charge. All charges are logical queue
  occupancy, not process RSS. `BatchingSource` over-limit behavior converges
  on the v3 fail-before-enqueue rule: a single source item exceeding the row
  or byte limit now fails with a latched typed error and the source must be
  reopened, instead of the item being emitted alone as before.

- Split the operator and plan surface by lifecycle — `BatchOperator` /
  `BatchExecutionPlan` for finite one-shot graphs, `StreamOperator` /
  `StreamExecutionPlan` for continuously running graphs — and replace the
  crate-internal opaque runtime markers with the typed v3 stream contract:
  `StreamMessage` (public data plus crate-private watermark, barrier, idle,
  and end-of-input control), strongly typed `EventTime` (signed UTC
  microseconds with checked, uniformly floor-rounded Arrow conversions), and
  `Epoch` (starts at 1, strictly increasing). Stream-rule violations fail at
  compile time before any source opens. This is a breaking Rust API change
  with no v2 compatibility layer; the PyO3 `ExecutionPlan` keeps its name
  over the batch plan, so Python and Studio surfaces are unchanged in this
  step. `docs/runtime-envelope.md` is rewritten as the normative v3
  contract.

## 2026-07

- Rust-native 2.0 replaces the Python v1 engine with the `calc-flow` crate
  and PyO3 bindings. Core and Studio are separately packaged; table work uses
  DataFusion and array providers are explicitly registered. Project and
  checkpoint formats cross a breaking boundary with no automatic converter.
  Earlier application code and saved documents must be recreated against the
  native API; stateful processing restarts from a chosen source boundary.

- Add a large, responsive Studio Data Source editor dialog with temporary
  per-source drafts. Inline JSON is validated and applied only on **Confirm**;
  Cancel, close, Escape, and backdrop dismissal discard edits. Keyboard focus
  starts in the editor, remains contained, and returns to the opener. The top
  action toolbar now uses consistently sized controls and intentional
  narrow-screen wrapping. Project, REST, OpenAPI, and engine contracts remain
  unchanged.
- Add frozen native Python `ExecutionOptions(settings, deadline)` for blocking
  and async plan execution. Its constructor remains positional-or-keyword,
  while plans receive it through the keyword-only `options=` parameter.
  Strict settings accept `settings=None` as empty and copy nested mappings in
  one pass with closed, redacted JSON validation. Any valid timezone-aware
  deadline is normalized to UTC with microseconds preserved. An absolute
  deadline continues while a same-plan run waits; queued cancellation remains
  isolated from the active run, and an observed deadline or accepted
  cancellation wins over a later provider error. Deadline expiry raises
  `calc_flow.CancelledError`; asyncio task cancellation remains
  `asyncio.CancelledError`, waits for native cleanup, and linearizes against a
  native result at handler entry. Existing two-argument providers remain
  compatible, while `accepts_context=True` opts into a frozen native
  `ProviderContext`; the public Python API does not expose the native
  cancellation token. These execution-options changes leave project and
  checkpoint formats unchanged.
- Add versioned Studio runtime and preview-worker discovery at
  `GET /api/v2/capabilities`, and model validation, run-state, and table/array
  result responses as closed unions. This is an intentional generated
  TypeScript client source break that requires consumers to regenerate and
  migrate; `/api/v2/catalog` remains a UDF-only compatibility route.
