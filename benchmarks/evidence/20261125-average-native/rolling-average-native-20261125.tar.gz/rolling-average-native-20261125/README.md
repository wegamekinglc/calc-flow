# Rust streaming cumulative average

The 2026.11.14 release, the November 25 main branch and the reviewed candidate use the same `stage_avg.rs`. The adapter calls the public `StreamingRunner`, with one standard `RollingOperator` and a collecting Arrow sink. It validates all one million ordered output sequences and means after timing. The Python test has its own graph projection, scheduler, API conversion, output collection and sample distribution.

## Build and validate

Use a disposable Git worktree with the required revisions available. The adapter adds an untracked example and changes modification times to force a fresh product library and example. Keep Cargo outputs under `target/`.

```bash
export CARGO_BUILD_JOBS=2
export CARGO_TARGET_DIR="$CASE_ROOT/cargo"
for rev in 7012b5b409553df04e29e6d7f9a11abf919cbf93 72072c1dc6c0874b79ccd8ce78103c97caec623d 51f8b0cd5c2ac1e0577481f6fd4f7e4d290acfbe
do
  git -C "$BUILD_CHECKOUT" switch --detach "$rev"
  python3 "$CASE_ROOT/build.py" "$BUILD_CHECKOUT" "$rev" avg
done
```

The build receipts record the Cargo artifacts, repository and source trees, adapter and binary digests, rustc version, feature flags and compile profile.

## Paired acquisition

Use a Python interpreter with the repository's benchmark dependencies and psutil, and a checkout at the registered main/candidate for the maintained resource gate and statistics. Run on an idle machine, after the builds. The scripts create new observation directories and retain stopped runs.

```bash
export PYTHONPATH="$SCRIPT_CHECKOUT"
candidate=51f8b0cd5c2ac1e0577481f6fd4f7e4d290acfbe
python "$CASE_ROOT/measure.py" avg "$candidate" 7012b5b409553df04e29e6d7f9a11abf919cbf93
python "$CASE_ROOT/measure.py" avg "$candidate" 72072c1dc6c0874b79ccd8ce78103c97caec623d
```

Each case uses a source-provided watermark and EOF in an uncheckpointed, single-thread job. Source readiness to last Arrow write excludes plan setup, startup, job teardown and oracle validation. The acquisition budget includes each worker's fixture, all process overhead and every validation. Each group has a fixed 60-second budget, four excluded warmups and 20 formal adjacent pairs over two rounds. See `protocol.md` and the resource and sample JSONL files. The release build exceeded its initial compile-time estimate after Cargo recompiled vendored Arrow IPC and its DataFusion dependents; the build receipt records its actual duration.
