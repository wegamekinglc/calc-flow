set -eu
root="$(dirname "$PWD")"
while test ! -f "$root/asof-layout-direct-trace-nov25/run-after-clean.exit"; do sleep 7; done
sha256sum --quiet -c registered.sha256
for sha in 7012b5b409553df04e29e6d7f9a11abf919cbf93 a3c9331539c260f3ef2b835f3349ae69feffbd06; do
 git -C source switch -q --detach "$sha"
 CARGO_BUILD_JOBS=2 CARGO_TARGET_DIR="$root/staged-perf-ec402c59/asof-charge-release-nov24/target/cargo" python3 build.py "$PWD/source" "$sha" admit
done
