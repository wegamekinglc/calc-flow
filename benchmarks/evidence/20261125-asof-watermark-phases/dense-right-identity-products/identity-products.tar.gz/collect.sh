set -eu
head=$1
py=$2
target_dir=$3
wheel_cache=$4
parent_dir=$5
release_dir=$6
harness=$7
core_src=$8
shim="$harness/target/post-timer-worker"
while test ! -f build-bases.exit; do sleep 5; done
test "$(cat build-bases.exit)" = 0
sha256sum --quiet -c registered.sha256
for f in engine_comparison.py engine_stream.py; do cmp "$PWD/worker/benchmarks/$f" "$shim/benchmarks/$f"; done
test "$(git -C "$core_src" rev-parse HEAD)" = "$head"
git -C source switch --detach "$head"
CARGO_TARGET_DIR="$target_dir" CARGO_BUILD_JOBS=2 python3 build.py "$PWD/source" "$head" admit
mkdir wheel
ln -s "$wheel_cache" wheel/cargo
touch "$core_src/crates/calc-flow/src/lib.rs" "$core_src/crates/calc-flow-python/src/lib.rs"
PYTHONPATH="$core_src" "$py" -m scripts.benchmark_suite build --source "$core_src" --output "$PWD/wheel" >wheel/build-driver.log 2>&1
while ps -e -o stat=,comm= | awk '$2 ~ /^(rustc|rust-lld|cargo-clippy|clippy-driver)$/ && $1 !~ /^[TZ]/ {found=1} END {exit !found}'; do sleep 2; done
export PYTHONPATH="$harness" ASOF_BENCH_HARNESS="$harness" ASOF_VERIFIED_WORKER="$shim"
for arm in parent release; do
 if test "$arm" = parent; then
   base=a3c9331539c260f3ef2b835f3349ae69feffbd06
   manifest="$parent_dir/wheel/release.json"
   base_src="$core_src/../../asof-borrow-expired-prefix-nov25"
 else
   base=7012b5b409553df04e29e6d7f9a11abf919cbf93
   manifest="$release_dir/release.json"
   base_src="$harness/../release-proof"
 fi
 rc=0
 "$py" observe.py "$base" "$head" >"native-$arm.log" 2>&1 || rc=$?
 echo "$rc" >"native-$arm.exit"
 rc=0
 "$py" public_compare.py asof_join --baseline "$manifest" --candidate "$PWD/wheel/release.json" --baseline-sha "$base" --baseline-source "$base_src" --candidate-source "$core_src" --sha "$head" --output "$PWD/wheel-$arm" >"wheel-$arm.log" 2>&1 || rc=$?
 echo "$rc" >"wheel-$arm.exit"
done
