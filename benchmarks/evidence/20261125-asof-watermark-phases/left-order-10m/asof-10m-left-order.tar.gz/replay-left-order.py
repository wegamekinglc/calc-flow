"""Verify each independent VM archive and replay its raw paired evidence."""
from __future__ import annotations

import json
from pathlib import Path
import sys

import paired

ROOT = Path(__file__).resolve().parent
CONF = paired.read(ROOT/"registration.json")
RUN, REGISTERED = CONF["run"], CONF["registration"]
HEAD = "f67422bac9c0e23a8d22e717422c7b5bb329f723"
BASES = {"release":"7012b5b409553df04e29e6d7f9a11abf919cbf93","parent":"5540d317884b59c53a8a9f80ac7129b78314c694"}

def main():
    offline="--offline" in sys.argv
    run=paired.read(ROOT/"run.json") if offline else paired.api(f"/runs/{RUN}")
    assert run["status"]=="completed" and run["head_sha"]==REGISTERED and run["event"]=="workflow_dispatch"
    artifacts=paired.read(ROOT/"artifacts.json") if offline else paired.api(f"/runs/{RUN}/artifacts?per_page=100")["artifacts"]
    (ROOT/"run.json").write_text(json.dumps(run,indent=2)+"\n")
    (ROOT/"artifacts.json").write_text(json.dumps(artifacts,indent=2)+"\n")
    results={}
    paired.HEAD=HEAD
    for surface in ("rust","python"):
        for tag,base in BASES.items():
            key=f"{surface}-{tag}"
            items=[a for a in artifacts if a["name"]==f"asof-left-order-10m-{key}-{RUN}-1"]
            if not items:
                results[key]={"state":"no archived measurements"}
                continue
            item,=items
            dest=ROOT/key
            dest.mkdir(exist_ok=True)
            scope=paired.download(item,dest)
            assert (scope/"registration.txt").read_text().strip()==REGISTERED
            topology={x["field"]:x["data"] for x in paired.read(scope/"topology.json")["lscpu"]}
            metadata={"artifact":item["id"],"digest":item["digest"],"model":topology["Model name:"],"cpu_count":topology["CPU(s):"],"cores_per_socket":topology["Core(s) per socket:"],"threads_per_core":topology["Thread(s) per core:"]}
            d=scope/tag
            if not (d/"bound.json").exists():
                results[key]={**metadata,"state":"not started"}
                continue
            for line in (d/"registered.sha256").read_text().splitlines():
                digest,name=line.split(None,1)
                assert paired.rawhash(d/name)==digest
            bound=paired.read(d/"bound.json")
            assert bound["baseline"]==base and bound["candidate"]==HEAD
            if not list(d.glob("obs-job-*/outcome.json")) and not (d/"python/outcome.json").exists():
                results[key]={**metadata,"state":"setup stopped"}
                continue
            verified=(paired.replay_rust if surface=="rust" else paired.replay_python)(d,base)
            results[key]={**metadata,**verified}
            print(key,verified["state"],verified.get("verdict"),verified.get("ms"),verified.get("rounds"))
    (ROOT/"replay.json").write_text(json.dumps(results,indent=2)+"\n")
if __name__=="__main__":
    main()
