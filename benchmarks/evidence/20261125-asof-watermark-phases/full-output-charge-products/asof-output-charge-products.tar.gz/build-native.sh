set -eu
while test ! -f "$1/diagnostic-build.exit"; do sleep 2; done
test "$(cat "$1/diagnostic-build.exit")" = 0
git -C "$2" diff --quiet
git -C "$2" switch --detach "$3"
python3 build.py "$2" "$3" admit
for group in release previous; do
    for file in "admit-${3:0:10}" "admit-${3:0:10}.receipt.json"; do ln "$file" "$group/$file"; done
done
