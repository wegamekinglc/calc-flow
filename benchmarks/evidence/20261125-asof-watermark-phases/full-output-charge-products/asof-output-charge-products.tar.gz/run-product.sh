set -eu
exec 9>product.lock
flock -n 9
for f in native-build.exit wheel-build.exit; do
    while test ! -f "$f"; do sleep 2; done
    test "$(cat "$f")" = 0
done
while ps -e -o stat=,comm= | awk '$2 ~ /^(rustc|rust-lld|cargo-clippy|clippy-driver)$/ && $1 !~ /^[TZ]/ {found=1} END {exit !found}'; do sleep 2; done
repo=$1
common=$2
ordinary=$3
benchpy=$4
release_manifest=$5
parent_manifest=$6
release_sha=$7
parent_sha=$8
head=$9
export PYTHONPATH="$repo"
run_group() {
    label=$1
    shift
    rc=0
    "$@" >"$label.log" 2>&1 || rc=$?
    echo "$rc" >"$label.exit"
}
run_group native-release "$ordinary" release/measure.py admit "$head" "$release_sha"
run_group native-previous "$ordinary" previous/measure.py admit "$head" "$parent_sha"
export PYTHONPATH="$common"
for scope in release-1m parent-1m release-10m; do
    baseline=$release_manifest
    if test "$scope" = parent-1m; then baseline=$parent_manifest; fi
    run_group "py-$scope" "$benchpy" "wheel-$scope.py" asof_join --baseline "$baseline" --candidate "$PWD/wheel/release.json" --candidate-source "$PWD/source" --output "$PWD/py-$scope" --sha "$head"
done
