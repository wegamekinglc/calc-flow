"""Install and qualify one environment; no workload is prepared or executed."""
from __future__ import annotations

import asyncio
import json
import sys
import time
from pathlib import Path

from benchmarks.native_release_identity import verify_package_files
from scripts.benchmark_suite.measure import validate_environment
from scripts.benchmark_suite.process import child_environment, command, install
from scripts.benchmark_suite.release import load_release
from scripts.toolkit import write_json

ROOT=Path(__file__).resolve().parents[1]
RELEASE="7012b5b409553df04e29e6d7f9a11abf919cbf93"
MAIN="89cc36a88d7905c955ecdf7584b185c262b31e2b"
SCRIPT="""from scripts.benchmark_suite.worker import environment
import json,sys
from pathlib import Path
from calc_flow import _native
import calc_flow
print(json.dumps(dict(environment(), executable=sys.executable, native_path=str(Path(_native.__file__).resolve()), package_path=str(Path(calc_flow.__file__).resolve()))))"""

async def setup(k, sha):
    sources={"main":"round3-asof-proof","release":"release-proof","asof":"round4-asof-proof"}
    products={"main":"round3-asof","release":"release-1114","asof":"round4-asof"}
    root=ROOT/"target"/("setup-"+k)
    root.mkdir(exist_ok=False)
    start=time.monotonic()
    try:
        manifest=ROOT.parent/"main-src/target/products"/products[k]/"release.json"
        release=load_release(manifest)
        from public_compare import locked_versions, verify_build
        identity=verify_build(release,ROOT.parent/sources[k],sha)
        if k=="release":
            site=ROOT.parent/"round2-harness/target/observed-asof-release/baseline/site"
        elif k=="main":
            site=ROOT.parent/"round3-harness/target/setup-asof/site"
        else:
            site=await install(release,root)
        verify_package_files(Path(release["wheel_path"]),site)
        await command([sys.executable,"-c",SCRIPT],cwd=ROOT,log=root/"environment.json",env=child_environment(site,source=ROOT),timeout=8)
        env=json.loads((root/"environment.json").read_text())
        validate_environment(env,release,backend="calc-flow-stream",polars_threads=4,tokio_threads=4)
        if Path(env["native_path"]).parent != site/"calc_flow" or Path(env["package_path"]).parent!=site/"calc_flow" or env["executable"]!=sys.executable:
            raise ValueError("interpreter/package differs from registered site")
        write_json(root/"site-proof.json",{"build":identity,"site":str(site),"environment":env,"python_locks":locked_versions(),"source":str(ROOT.parent/sources[k]),"elapsed":time.monotonic()-start})
    finally:
        write_json(root/"elapsed.json",{"elapsed":time.monotonic()-start})
if __name__=="__main__":
    name,sha=sys.argv[1:]
    if name not in ("main","release","asof") or (name=="main" and sha!=MAIN) or (name=="release" and sha!=RELEASE):
        raise ValueError("unexpected endpoint")
    asyncio.run(asyncio.wait_for(setup(name,sha),timeout=14))
