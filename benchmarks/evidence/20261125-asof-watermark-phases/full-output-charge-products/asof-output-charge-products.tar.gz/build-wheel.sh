set -eu
while test ! -f "$1/study-driver.exit"; do sleep 3; done
mkdir -p "$PWD/wheel"
ln -s "$2" "$PWD/wheel/cargo"
touch "$PWD/source/crates/calc-flow/src/lib.rs" "$PWD/source/crates/calc-flow-python/src/lib.rs"
PYTHONPATH="$PWD/source" "$3" -m scripts.benchmark_suite build --source "$PWD/source" --output "$PWD/wheel"
