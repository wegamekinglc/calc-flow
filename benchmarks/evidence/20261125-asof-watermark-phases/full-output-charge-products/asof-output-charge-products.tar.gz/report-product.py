"""Replay fixed-pair ASOF output-budget evidence and produce a small public archive."""
import hashlib
import json
import statistics
import tarfile
from pathlib import Path

from scripts.benchmark_suite.report import _paired_verdict
from scripts.benchmark_suite.statistics import paired_round
from scripts.toolkit import linear_percentile
from verify import verify

root = Path(__file__).resolve().parent
read = lambda p: json.loads(p.read_text())
files = {root/'terminal-proofs.json',*root.glob('*.py'), *root.glob('*.sh'), root/'stage_admit.rs',
         root/'protocol.md', root/'preregistered.sha256'}
files.update(p for p in (root/'state-check-worker').rglob('*') if p.is_file())
for arm in ('release','previous'):
    files.update(root/arm/name for name in ('protocol.md','stage_admit.rs','measure.py','verify.py'))
rows = []
details = {}
for group in ('release', 'previous'):
    d, = (root/group).glob('obs-admit-*')
    proof = verify(d)
    out = read(d/'outcome.json')
    files.update(d.glob('*.json*'))
    base = '11.14' if group == 'release' else '父提交'
    details['native-'+group] = dict(replay=proof,outcome=out)
    if proof['state'] == 'complete':
        v = out['pooled_ms']
        rows.append(['Rust 单次水位',base,'10 万',v['base']['p50'],v['head']['p50'],
                     v['base']['p95'],v['head']['p95'],out['verdict']])
    else:
        rows.append(['Rust 单次水位',base,'10 万',None,None,None,None,'stopped'])
for scope, count, base in [('release-1m',1_000_000,'11.14'),('parent-1m',1_000_000,'父提交'),('release-10m',10_000_000,'11.14')]:
    d = root/('py-'+scope)
    for f in d.rglob('*'):
        if 'site' not in f.relative_to(d).parts and f.is_file() and f.suffix in ('.json','.jsonl','.log'):
            files.add(f)
    out = read(d/'outcome.json')
    detail = details['python-'+scope] = dict(outcome=out)
    row = ['Python 至表交付',base,'100 万' if count==1_000_000 else '1,000 万']
    if out['state'] != 'completed':
        rows.append([*row,None,None,None,None,'stopped'])
        continue
    result, samples = read(d/'result.json'), read(d/'samples.json')
    observed = []
    expected = {'passed':True,'rows':count,'finite_rows':count,'max_abs_error':0.0}
    def verify_response(response):
        assert response['correctness']==expected and response['seconds']>0
    for f in (d/'measurement').rglob('*.completed.json'):
        request=read(f)
        response=request.get('response',{})
        value=response.get('warmup',response)
        if isinstance(value,dict) and 'seconds' in value and 'correctness' in value:
            verify_response(value)
            observed.append(request['operation'])
    assert observed.count('prepare')==4 and observed.count('sample')==40
    assert samples['status']=='ok' and result['oracle_checked_executions']==44
    assert len(result['cpus'])==4 and all(all(c['suitable'] for c in json.loads(x)['cores']) for x in (d/'resources.jsonl').read_text().splitlines())
    rounds = []
    values = {'baseline':[],'candidate':[]}
    for evidence in samples['evidence']:
        assert evidence['environment']['cpu_affinity']==result['cpus']
        times={}
        for side in values:
            assert len(evidence['samples'][side])==10
            for item in evidence['samples'][side]:
                verify_response(item)
            times[side]=[item['seconds'] for item in evidence['samples'][side]]
            values[side]+=times[side]
        rounds.append(paired_round(times['baseline'],times['candidate']))
    assert rounds==result['round_intervals'] and _paired_verdict(rounds)==result['verdict']
    quantiles=[statistics.median(v) for v in values.values()]+[linear_percentile(v,.95) for v in values.values()]
    assert quantiles==[result[k] for k in ('base_p50','head_p50','base_p95','head_p95')]
    terminal=read(root/'terminal-proofs.json')
    for side in ('baseline','candidate'):
        proof=terminal[d.name+'/'+side];q=read(d/'qualification.json')['builds'][side]
        assert proof['sha']==q['sha'] and proof['native_sha256']==q['release']['native_sha256'] and proof['rows']==count
        assert proof['state']['terminal_asof_status']['state_rows']==0 and proof['state']['post_eof_output_rows']==count
    detail.update(result=result, verified_requests=44, separate_terminal_state_checks=2)
    rows.append([*row,*[x*1000 for x in quantiles],result['verdict']])
export=root/'product-export'
export.mkdir(exist_ok=True)
result_file=root/'product-replay.json'
result_file.write_text(json.dumps(details,indent=2,allow_nan=False)+'\n')
files.add(result_file)
files.update(root.glob('*.receipt.json'))
files.update(f for f in (root/'wheel').glob('*.json') if f.is_file())
files.update(root.glob('*.exit'))
archive=export/'asof-output-charge-products.tar.gz'
digest=lambda f: hashlib.file_digest(f,'sha256').hexdigest()
inventory=root/'product-sha256.txt'
inventory.write_text(''.join(digest(p.open('rb'))+'  '+str(p.relative_to(root))+'\n' for p in sorted(files)))
files.add(inventory)
with tarfile.open(archive,'w:gz') as t:
    for f in sorted(files):
        t.add(f,arcname=str(f.relative_to(root)),recursive=False)
with tarfile.open(archive) as t:
    assert all(digest(t.extractfile(str(p.relative_to(root))))==digest(p.open('rb')) for p in files)
table=[['入口','对照','每侧行数','对照 p50','候选 p50','对照 p95','候选 p95','两轮判定'],
       *[[f'{s:,.3f}' if isinstance(s,float) else str(s) if s is not None else '—' for s in row] for row in rows]]
widths=[max(map(len,c)) for c in zip(*table)]
line=lambda cells: '| '+' | '.join(s.ljust(n) for s,n in zip(cells,widths))+' |'
lines=['# 完整 ASOF 输出段的预算计算','','候选提交 `f09846cc`。父提交为 `ea7a21ce`，11.14 为 `7012b5b4`。时长单位为毫秒。每组两轮，每轮十对正式观测。另有四次预热。安装包从数据就绪计至 Arrow 结果交付，EOF 在计时后发送。Rust 单次水位在已接纳的两侧状态上启动。','',line(table[0]),'|'+'|'.join('-'*(n+2) for n in widths)+'|',*[line(r) for r in table[1:]],'','原生每次执行都校验完整结果和终态。公开正式组的四十次计时和四次预热均校验全量行与值。维护中的普通 worker 未保存终态计数，另以同一批已安装的 wheel 对每组各臂独立验证一次完整结果、物理顺序及 EOF 后状态，耗时不计入统计。本次五组都取得完整配对数据。父提交比较衡量本次改动，发布版比较衡量当前剩余差距。','',f'[复算脚本、构建记录及原始数据]({archive.name})，SHA-256 `{digest(archive.open("rb"))}`。','']
(export/'README.md').write_text('\n'.join(lines))
(export/result_file.name).write_bytes(result_file.read_bytes())
