"""Supplement ordinary result-only public requests with untimed terminal-state proofs."""
from pathlib import Path
import hashlib,json,os,subprocess,sys,time,tempfile
from scripts.benchmark_suite.process import child_environment
root=Path(__file__).resolve().parent
worker=Path(sys.argv[1]).resolve()
groups=sys.argv[2:]
code="""
import hashlib,json,sys
from pathlib import Path
from benchmarks.engine_comparison import EngineCase
from calc_flow import _native
case=json.loads(Path(sys.argv[1]).read_text())['scenario']
site=Path(sys.argv[2]); native=Path(_native.__file__).resolve()
assert native.parent==site/'calc_flow'
x=EngineCase(case,Path(sys.argv[3]))
try:
    out=x.sample()
    proof=dict(correctness=out['correctness'],state=out['stream_evidence'],completion=x.finish(),native_sha256=hashlib.file_digest(native.open('rb'),'sha256').hexdigest())
finally:x.close()
print(json.dumps(proof))
"""
start=time.monotonic(); result={}
for group in groups:
 d=root/group
 if json.loads((d/'outcome.json').read_text())['state']!='completed':continue
 q=json.loads((d/'qualification.json').read_text());n=q['scenario']['rows']
 cpus=json.loads((d/'result.json').read_text())['cpus']
 for side in ('baseline','candidate'):
    site=d/side/'site'
    with tempfile.TemporaryDirectory(dir=root) as temp:
        p=subprocess.run(['taskset','-c',','.join(map(str,cpus)),sys.executable,'-c',code,str(d/'qualification.json'),str(site),temp],cwd=worker,env=child_environment(site,source=worker),capture_output=True,text=True,timeout=max(1,50-(time.monotonic()-start)))
    if p.returncode:raise RuntimeError(p.stderr[-4000:])
    j=json.loads(p.stdout)
    assert j['native_sha256']==q['builds'][side]['release']['native_sha256']
    assert j['correctness']=={'passed':True,'rows':n,'finite_rows':n,'max_abs_error':0.0} and j['completion']=={'state':'completed'}
    assert j['state']['post_eof_output_rows']==n
    t=j['state']['terminal_asof_status']
    assert all(t[k]==n for k in ('emitted_left_rows','matched_rows','evicted_right_rows'))
    assert all(t[k]==0 for k in ('state_rows','state_bytes','pending_left_rows','retained_right_rows','unmatched_rows','identity_only_rows','workspace_limit_failures','state_limit_failures','output_limit_failures'))
    assert all(t[s]['accepted_rows']==n and t[s]['ended'] and t[s]['late_rows']==t[s]['duplicate_rows']==0 for s in ('left','right'))
    result[group+'/'+side]={'sha':q['builds'][side]['sha'],'rows':n,'cpus':cpus,**j}
    (root/'terminal-proofs.json').write_text(json.dumps(result,indent=2)+'\n')
print('validated',len(result),'separate installed-product state checks in',round(time.monotonic()-start,3),'seconds')
