"""Build a self-contained, additive cross-stage comparison from the original worker records."""
from pathlib import Path
import json, statistics
import sys
from observe import ROOT, FIELDS, PRODUCT, checked, require, summarize, write

def read(path): return json.loads(path.read_text())
def rows(p): return [json.loads(s) for s in p.read_text().splitlines()]
def main(root):
    metrics={}
    for mode in ['calibration','diagnostic']:
        path=root/('obs-'+mode)
        outcome=read(path/'outcome.json')
        require(outcome['state']=='complete' and outcome['wall_seconds']<40,'outcome')
        required=rows(path/'resources.jsonl')
        require(0<len(required) and all(r['suitable'] for r in required),'resource interval')
        metrics[mode]=summarize(path)
        require(metrics[mode]==outcome['metrics'],'outcome replay')
    require(read(root/'obs-calibration/outcome.json')['cpu']==read(root/'obs-diagnostic/outcome.json')['cpu'],'calibration CPU parity')
    traced=root/'obs-diagnostic'
    formal=[r for r in rows(traced/'observations.jsonl') if r['pair']]
    inner={}
    for side in PRODUCT:
        obs=[r for r in formal if r['side']==side]
        tickets=[rows(traced/r['trace'])[0]['admitted_gather_tickets_match_arrow_left_right_emit_residual'] for r in obs]
        inner[side]={'tickets_by_stage_min':[min(vals) for vals in zip(*tickets)],
                     'tickets_by_stage_max':[max(vals) for vals in zip(*tickets)],
                     'max_abs_closure_error_ns':max(abs(r['ns']['wall_ns']-sum(r['ns'][k] for k in FIELDS)) for r in obs)}
    def delta_means(k):
        return (statistics.mean(r['ns'][k] for r in formal if r['side']=='main')-
                statistics.mean(r['ns'][k] for r in formal if r['side']=='release'))/1e6
    delta={k:delta_means(k) for k in ['watermark_ns','wall_ns','outside_finalize_ns',*FIELDS,'state_removal_ns']}
    require(abs(delta['watermark_ns']-sum(delta[k] for k in [*FIELDS,'outside_finalize_ns']))<1e-8,'mean attribution additive')
    rank=sorted(['matching_ns','arrow_output_ns','state_removal_ns'],key=lambda k:metrics['diagnostic'][k]['paired_median_difference_ms'],reverse=True)
    def p50(mode, k, side):
        return metrics[mode][k]['p50_ms'][side]
    external={}
    for side in PRODUCT:
        base=p50('calibration','watermark_ns',side)
        external[side]={'instrumented_p50_ms':p50('diagnostic','watermark_ns',side),'sealed_p50_ms':base,
                        'instrumented_minus_sealed_percent':100*(p50('diagnostic','watermark_ns',side)/base-1)}
    return dict(metrics=metrics,mean_delta_ms=delta,rank_by_positive_paired_median_gap=rank,
                external_calibration=external,trace_checks=inner)
if __name__=='__main__':
    root=Path(sys.argv[1]) if len(sys.argv)>1 else ROOT
    out=main(root)
    write(root/'comparison.json',out)
    print(json.dumps({k:v for k,v in out.items() if k!='metrics'},indent=2))
