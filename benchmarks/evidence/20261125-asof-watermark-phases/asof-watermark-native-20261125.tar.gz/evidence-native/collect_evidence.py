"""Copy only replayable evidence, excluding native binaries and source worktrees."""
from pathlib import Path
import hashlib, json, shutil
from comparison import main as verify
ROOT=Path(__file__).resolve().parent
out=ROOT/'evidence-native'
out.mkdir(exist_ok=False)
required=['README.md','protocol.md','preregistered.sha256','main.patch','release.patch','main-diagnostic.bundle','release-diagnostic.bundle','observe.py','test_observe.py','comparison.py','stage_admit.rs','build.py','build-native.sh','prepare.py','comparison.json']
for f in required: shutil.copy2(ROOT/f,out/f)
for d in ['obs-calibration','obs-diagnostic']: shutil.copytree(ROOT/d,out/d)
shutil.copy2(ROOT/'build-native.log',out/'build-native.log')
for f in ROOT.glob('admit-*.receipt.json'): shutil.copy2(f,out/f.name)
result=verify(out)
if result!=json.loads((out/'comparison.json').read_text()): raise ValueError('raw evidence replay mismatch')
hashes=[hashlib.sha256(f.read_bytes()).hexdigest()+'  '+str(f.relative_to(out)) for f in sorted(out.rglob('*')) if f.is_file()]
(out/'manifest.sha256').write_text('\n'.join(hashes)+'\n')
print(len(hashes), 'evidence files under',out)
