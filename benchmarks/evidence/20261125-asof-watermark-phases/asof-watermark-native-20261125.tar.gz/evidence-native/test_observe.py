import unittest
from observe import checked
class Evidence(unittest.TestCase):
    def setUp(self):
        self.gauges = dict(pending_left_rows=100000,retained_right_rows=100000,emitted_left_rows=0,matched_rows=0,evicted_right_rows=0,state_rows=200000,identity_only_rows=0)
        end={**self.gauges,'pending_left_rows':0,'retained_right_rows':0,'emitted_left_rows':100000,'matched_rows':100000,'evicted_right_rows':100000,'state_rows':0}
        self.result=dict(seconds=.1,watermark_seconds=.01,output_rows=100000,validated_all_rows=True,evicted_right_rows=100000,retained_right_rows=0,pending_before_watermark=100000,retained_before_watermark=100000)
        self.row=dict(schema='calc-flow.asof-watermark-exclusive.v1',pid=123,operator='asof',success=True,ended=False,frontier=1563,before=self.gauges,after=end,emitted_delta=100000,matched_delta=100000,evicted_delta=100000,wall_ns=9000000,matching_ns=2000000,arrow_output_ns=2000000,left_commit_ns=1000000,right_eviction_ns=3000000,emit_ns=0,residual_ns=1000000,admitted_gather_tickets_match_arrow_left_right_emit_residual=[0]*6)
    def test_guard(self):
        checked(self.result,[self.row],123)
        for row in [{**self.row,'wall_ns':8999999},{**self.row,'emitted_delta':99999},{**self.row,'pid':7},{**self.row,'frontier':1}]:
            with self.assertRaises(ValueError): checked(self.result,[row],123)
        with self.assertRaises(ValueError): checked(self.result,[self.row,self.row],123)
if __name__=='__main__': unittest.main()
