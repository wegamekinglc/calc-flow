#!/bin/bash
set -euo pipefail
here=$(cd "$(dirname "$0")" && pwd -P)
checkout="$here/../native-runtime-bench-nov24"
export CARGO_BUILD_JOBS=2
export CARGO_TARGET_DIR=$(cd "$here/../staged-perf-ec402c59/asof-charge-release-nov24/target/cargo" && pwd -P)
for rev in 234af6cd213946aafafcc9d62563dbd641f2dc8b 34b5ddb6ffe5d0066ee364763b9fcded99f5c49a; do
    git -C "$checkout" diff --quiet
    git -C "$checkout" switch --detach "$rev"
    python3 "$here/build.py" "$checkout" "$rev" admit
done
