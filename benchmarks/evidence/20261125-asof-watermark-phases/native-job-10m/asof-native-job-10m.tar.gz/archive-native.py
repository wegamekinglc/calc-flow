import hashlib, json, shutil, tarfile
from pathlib import Path

root=Path(__file__).resolve().parent
obs,=root.glob('obs-job-*')
outcome=json.loads((obs/'outcome.json').read_text())
out=root/'export';out.mkdir(exist_ok=True)
files=[root/name for name in ('protocol.md','stage_job.rs','project.json','bound.sha256','prepare.py','build.py','build-both.sh','measure.py','qualify.py','verify.py','run-bound.sh','replay.json','build-both.log','measured.log','archive-native.py')]
files+=sorted(root.glob('qual-*.json'))+sorted(root.glob('qual-*.stderr'))+sorted(root.glob('*.receipt.json'))+sorted(root.glob('*-build.stderr'))+sorted(root.glob('*-build.jsonl'))+sorted(obs.iterdir())
def digest(p):return hashlib.sha256(p.read_bytes()).hexdigest()
manifest=root/'artifact-sha256.txt'
manifest.write_text(''.join(f'{digest(f)}  {f.relative_to(root)}\n' for f in files))
name='asof-native-job-10m.tar.gz'
with tarfile.open(out/name,'w:gz') as t:
 for f in [*files,manifest]:t.add(f,arcname=str(f.relative_to(root)),recursive=False)
with tarfile.open(out/name) as t:
 for f in [*files,manifest]:assert hashlib.sha256(t.extractfile(str(f.relative_to(root))).read()).hexdigest()==digest(f)
rows=[json.loads(s) for s in (obs/'observations.jsonl').read_text().splitlines()] if (obs/'observations.jsonl').exists() else []
summary=['# Rust StreamingRunner backward ASOF at 10M rows per side','',
'Release 7012b5b4 and #733 dce77f04 ran the same compiled project in the public Rust StreamingRunner on one logical CPU. Each of the ten chunks per input contains one million rows and 64 UTF-8 keys. The managed job has two ready bounded inputs, source watermarks and a collecting Arrow sink. The clock spans ready publication through the last assembled two-column table. The full output oracle and terminal state checks follow that boundary.','']
if outcome['state']=='complete':
 summary += ['Both rounds completed. Four warmups were excluded. Every one of the 44 fresh worker processes checked all ten million rows in order, exact prices and sequences, both source completions, ten million matches and right evictions, and zero remaining rows or budget failures.','']
 for k,v in outcome['pooled_ms'].items():summary.append(f"- {k} p50 {v['p50']:.3f} ms and p95 {v['p95']:.3f} ms.")
 summary+=['',f"Maintained paired verdict: {outcome['verdict']}. Paired round evidence: `{json.dumps(outcome['rounds'])}`."] 
else: summary += [f"Acquisition stopped after {len(rows)} worker observations. The group has no qualified two-round estimate. The reason was `{outcome['error']}`."]
summary+=['',f"Each executable also passed one full qualification before the formal clock. Group acquisition wall time {outcome['wall_seconds']:.2f} seconds. The separate public Python four-thread result and the native 100K callback use different boundaries and workloads.",'',f"[Replayable sources, checksum manifest, build receipts, observations, oracle and host logs]({name}) (SHA256 `{digest(out/name)}`). Extract in a fresh directory. With the repository on PYTHONPATH and the locked benchmark environment active, run `python verify.py obs-job-*` to recompute the result.",'']
(out/'README.md').write_text('\n'.join(summary))
