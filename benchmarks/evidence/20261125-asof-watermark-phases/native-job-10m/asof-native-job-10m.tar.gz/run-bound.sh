set -eu
export PYTHONPATH="$1"
export TMPDIR="$PWD/managed-tmp"
python_bin="$2"
release="$3"
candidate="$4"
sha256sum -c bound.sha256
timeout 20 "$python_bin" qualify.py "$release" "$candidate"
"$python_bin" measure.py job "$candidate" "$release"
