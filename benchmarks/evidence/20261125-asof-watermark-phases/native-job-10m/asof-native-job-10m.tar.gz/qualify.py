"""Run one untimed full-result qualification per sealed executable within 20 seconds."""

import json
import os
import subprocess
import sys
import time
from pathlib import Path

from scripts.benchmark_suite.process import child_environment

root = Path(__file__).resolve().parent
started = time.monotonic()
cpu = min(os.sched_getaffinity(0))
os.sched_setaffinity(0, {cpu})
for commit in sys.argv[1:]:
    result = subprocess.run(
        [root / f"job-{commit[:10]}"],
        capture_output=True,
        env=child_environment(tokio_threads=1, polars_threads=1),
        timeout=max(0.0, 20 - (time.monotonic() - started)),
    )
    (root / f"qual-{commit[:10]}.stderr").write_bytes(result.stderr)
    result.check_returncode()
    payload = json.loads(result.stdout)
    assert payload["validated_all_rows"] and payload["closed"]
    assert payload["output_rows"] == 10_000_000
    (root / f"qual-{commit[:10]}.json").write_text(json.dumps({
        "commit": commit, "cpu": cpu, "elapsed_group_seconds": time.monotonic() - started,
        "result": payload,
    }, indent=2) + "\n")
