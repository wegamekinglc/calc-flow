set -eu
w=$1
d=$2
candidate=$3
release=$4
git -C "$w" diff --exit-code HEAD -- crates/calc-flow/src
test "$(git -C "$w" rev-parse HEAD)" = "$candidate"
python3 "$d/build.py" "$w" "$candidate" job
git -C "$w" switch --detach "$release"
python3 "$d/build.py" "$w" "$release" job
