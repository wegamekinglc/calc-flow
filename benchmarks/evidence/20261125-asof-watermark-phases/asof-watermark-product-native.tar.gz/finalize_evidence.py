from pathlib import Path
import json,sys,tarfile,hashlib,statistics
from verify import verify
d=Path(__file__).parent.resolve()
head=sys.argv[1]
arms={'main':'89cc36a88d7905c955ecdf7584b185c262b31e2b','release':'7012b5b409553df04e29e6d7f9a11abf919cbf93'}
info={}
files=[d/n for n in ['stage_admit.rs','protocol.md','prepare.py','build.py','verify.py','measure.py','finalize_evidence.py']]
for label,base in arms.items():
    obs=d/f'obs-admit-{base[:10]}-{head[:10]}'
    verification=verify(obs)
    data=json.loads((obs/'outcome.json').read_text())
    results=[json.loads(line) for line in (obs/'observations.jsonl').read_text().splitlines() if line]
    info[label]={'verified':verification,'outcome':data,
                 'secondary_admission_p50_ms':{s:statistics.median(r['result']['seconds']*1000 for r in results if r['pair'] and r['side']==s) for s in ('base','head')}}
    files.extend(sorted(obs.iterdir()))
out=d/'native-product-summary.json'
out.write_text(json.dumps(info,ensure_ascii=False,indent=2)+'\n')
files += [out, d/(head[:10]+'-build.jsonl'),d/(head[:10]+'-build.stderr')]
tarpath=d/'asof-watermark-product-native.tar.gz'
with tarfile.open(tarpath,'w:gz',compresslevel=9) as tar:
    for f in files: tar.add(f,arcname=f.relative_to(d))
print(hashlib.sha256(tarpath.read_bytes()).hexdigest())
print(json.dumps(info))
