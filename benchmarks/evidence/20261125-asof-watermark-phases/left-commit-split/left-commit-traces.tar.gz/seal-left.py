"""Verify paired left-commit clocks, inventory every raw file and write the readable result."""
import datetime,hashlib,json,statistics,sys,tarfile
from pathlib import Path
from observe import PRODUCT, TRACED, checked, summarize

root=Path(__file__).resolve().parent
src=root/'obs-diagnostic'
out=root/'export'
out.mkdir(exist_ok=True)
read=lambda p:json.loads(p.read_bytes())
digest=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
identity=read(src/'identity.json')
assert identity['executables']==TRACED and identity['product']==PRODUCT
for side in PRODUCT:
    receipt=read(src/f'{side}.receipt.json')
    assert receipt['commit']==TRACED[side]
    executable=root/('admit-'+TRACED[side][:10])
    if executable.exists():assert receipt['binary_sha256']==digest(executable)
outcome=read(src/'outcome.json')
logs=src/'observations.jsonl'
rows=[json.loads(x) for x in logs.read_bytes().splitlines()] if logs.exists() else []
parts=['left_check_ns','left_prepare_ns','left_apply_ns','left_other_ns']
for pos,row in enumerate(rows):
    rnd,within=divmod(pos,22)
    pair,arm=divmod(within,2)
    assert (row['round'],row['pair'],row['side'])==(rnd+1,pair,(('release','main') if pair==0 or pair%2 else ('main','release'))[arm])
    trace=[json.loads(x) for x in (src/row['trace']).read_bytes().splitlines()]
    assert checked(row['result'],trace,row['pid'])==row['ns']
    assert trace[0]['after']['state_bytes']==0
    assert trace[0]['left_check_ns' if row['side']=='release' else 'left_prepare_ns']==0
report={'state':outcome['state'],'checked_observations':len(rows),'products':PRODUCT,'traced':TRACED}
lines=['# 原生 ASOF 左侧提交分解','','每侧 10 万行、64 个键。直接产出水位，单核单工作线程，发布版 7012b5b4 对候选 9aed8b4b。左侧时钟由互斥子阶段构成。前缀核验计候选提交时的 starts_with；预备工作计发布版的 prepare_prefix_checkpoint；状态变动计候选在核验成功后执行的状态清理，发布版计 commit_prepared_left_prefix。发布版的准备步骤包含可能的异步让出。发布版的剩余项包含提交尾部的 retirement.wait 和输出状态更新，候选在发送前完成相应状态计算，计入处理器剩余项。两版的子阶段均按各自实现边界计时。','']
if outcome['state']=='complete':
    assert summarize(src)==outcome['metrics'] and len(rows)==44
    resources=[json.loads(x) for x in (src/'resources.jsonl').read_bytes().splitlines()]
    assert all(x['suitable'] and x['cpu']==outcome['cpu'] for x in resources)
    report['mean_paired_delta_ms']={}
    table=[['原生时钟','发布版 p50','候选 p50','同对平均差']]
    names=['外层水位回调','左侧提交合计','待输出前缀核验','发布版提交准备','提交中的状态变动','其余左侧工作']
    for name,k in zip(names,['watermark_ns','left_commit_ns',*parts],strict=True):
        a,b=([x['ns'][k]/1e6 for x in rows if x['side']==side and x['pair']] for side in PRODUCT)
        mean=statistics.mean(y-x for x,y in zip(a,b,strict=True))
        report['mean_paired_delta_ms'][k]=mean
        table.append([name,f'{statistics.median(a):.4f}',f'{statistics.median(b):.4f}',f'{mean:+.4f}'])
    m=report['mean_paired_delta_ms']
    assert abs(sum(m[k] for k in parts)-m['left_commit_ns'])<1e-8
    from unicodedata import east_asian_width
    width=lambda x:sum(2 if east_asian_width(c) in 'WF' else 1 for c in x)
    lengths=[max(map(width,col)) for col in zip(*table)]
    line=lambda cells:'| '+' | '.join(c+' '*(w-width(c)) for c,w in zip(cells,lengths))+' |'
    lines+=['单位为毫秒。差值是候选减发布版，每个正式观察对先相减，再对 20 对求平均。0 表示该版本没有对应步骤。','',line(table[0]),'|'+'|'.join('-'*(w+2) for w in lengths)+'|',*[line(r) for r in table[1:]],'']
    ordinary=read(root/'plain/obs-admit-7012b5b409-9aed8b4b20/outcome.json')
    report['ordinary_p50_ms']={arm:ordinary['pooled_ms'][key]['p50'] for arm,key in [('release','base'),('main','head')]}
    plain_resource=root/'plain/obs-admit-7012b5b409-9aed8b4b20/resources.jsonl'
    original=json.loads(plain_resource.read_bytes().splitlines()[0])
    fmt=lambda x:datetime.datetime.fromtimestamp(x,datetime.UTC).strftime('%Y-%m-%d %H:%M:%S UTC')
    stamps=[fmt(original['utc_seconds']),fmt(resources[0]['utc_seconds'])]
    report['group_preflight_utc']={'ordinary':stamps[0],'traced':stamps[1]}
    traced=outcome['metrics']['watermark_ns']['p50_ms']
    diffs={arm:100*(traced[arm]/old-1) for arm,old in report['ordinary_p50_ms'].items()}
    report['traced_vs_prior_ordinary_p50_percent']=diffs
    lines+=['普通组与插桩组预检时间分别为 '+stamps[0]+' 和 '+stamps[1]+'。相对于较早普通组，插桩组外层水位 p50 变化为发布版 '+f"{diffs['release']:+.2f}%"+'、候选 '+f"{diffs['main']:+.2f}%"+'。分别运行的两组同时反映测量扰动和环境变化。','']
else:
    report['reason']=outcome['exception']
    lines+=['触及测量限制。记录已完成观察及原因，停止组不估算分位数。','']
lines+=['输出 oracle 检查行数、非递减顺序、每行左右序列号一致及右值关系。普通构建使用先前同一对提交、同一 CPU 的完整组。两个插桩版本均从各自生产提交应用归档内的补丁。左侧各步骤的差值用于定位，保留所有正确性检查。[无插桩对照与 Arrow 分解](https://github.com/wegamekinglc/calc-flow/tree/c98c074656a46436d90d6a16837c8df074f52351/benchmarks/evidence/20261125-asof-watermark-phases/direct-output-layout)','']
(out/'replay.json').write_text(json.dumps(report,indent=2)+'\n')
files=[*(src.glob('*.json*')),*[root/name for name in ('protocol.md','registered.sha256','main.patch','release.patch','stage_admit.rs','observe.py','prepare.py','build.py','build-run.sh','seal-left.py')],out/'replay.json']
control=root/'plain/obs-admit-7012b5b409-9aed8b4b20'
files+=list(control.glob('*.json*'))
for side in PRODUCT:
    files.append(root/'plain'/('admit-'+PRODUCT[side][:10]+'.receipt.json'))
def name(p):return str(p.relative_to(root))
inventory=out/'raw.sha256'
inventory.write_text(''.join(digest(p)+'  '+name(p)+'\n' for p in sorted(files)))
archive=out/'left-commit-traces.tar.gz'
with tarfile.open(archive,'w:gz') as tar:
    for p in sorted([*files,inventory]):tar.add(p,arcname=name(p),recursive=False)
with tarfile.open(archive) as tar:
    for p in files:assert hashlib.sha256(tar.extractfile(name(p)).read()).hexdigest()==digest(p)
lines+=['[逐次记录与补丁]('+archive.name+')，SHA-256 `'+digest(archive)+'`。','']
(out/'README.md').write_text('\n'.join(lines))
