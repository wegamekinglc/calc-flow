set -eu
sha256sum --quiet -c registered.sha256
export CARGO_TARGET_DIR="$(dirname "$PWD")/staged-perf-ec402c59/asof-charge-release-nov24/target/cargo"
export CARGO_BUILD_JOBS=2
for side in release main; do
  sha=$(git -C "source-$side" rev-parse HEAD)
  python3 build.py "$PWD/source-$side" "$sha" admit
done
while ps -eo stat=,comm= | awk '$2 ~ /^(rustc|rust-lld|cargo-clippy|clippy-driver)$/ && $1 !~ /^[TZ]/ {found=1} END {exit !found}'; do sleep 2; done
sha256sum --quiet -c registered.sha256
../worktrees/benchmark-large-engines-20261114/target/benchmark-venv/bin/python observe.py diagnostic
