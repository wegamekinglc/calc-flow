import shutil,sys
from pathlib import Path
root=Path(__file__).resolve().parent
shutil.copyfile(root/'stage_admit.rs',Path(sys.argv[1])/'crates/calc-flow/examples/stage_admit.rs')
