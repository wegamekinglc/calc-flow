set -eu
study=$(pwd)
t=$(dirname "$study")
py="$t/worktrees/benchmark-large-engines-20261114/target/benchmark-venv/bin/python"
harness="$t/managed-runtime-20261124/round5-harness"
head=$(git -C source-main rev-parse HEAD)
base=$(git -C source-release rev-parse HEAD)
sha256sum --quiet -c registered.sha256
for src in engine_comparison.py engine_stream.py; do cmp "worker/benchmarks/$src" "$harness/target/post-timer-worker/benchmarks/$src"; done
mkdir wheel
ln -s "$t/managed-runtime-20261124/main-src/target/cargo" wheel/cargo
touch source-main/crates/calc-flow/src/lib.rs source-main/crates/calc-flow-python/src/lib.rs
( PYTHONPATH="$study/source-main" "$py" -m scripts.benchmark_suite build --source "$study/source-main" --output "$study/wheel" ) >wheel/build-driver.log 2>&1 & wheel_pid=$!
export CARGO_TARGET_DIR="$t/staged-perf-ec402c59/asof-charge-release-nov24/target/cargo" CARGO_BUILD_JOBS=2
r=0
for sha in "$base" "$head"; do
 git -C native-build-source diff --quiet
 git -C native-build-source switch --detach "$sha"
 python3 build.py "$study/native-build-source" "$sha" job || { r=$?; break; }
done
wait "$wheel_pid" || r=$?
test "$r" = 0
while ps -eo stat=,comm= | awk '$2 ~ /^(rustc|rust-lld|cargo-clippy|clippy-driver)$/ && $1 !~ /^[TZ]/ {found=1} END {exit !found}'; do sleep 2; done
export TMPDIR="$study/managed-tmp" PYTHONPATH="$harness"
rc=0
timeout 15 "$py" qualify.py "$base" "$head" >qualification.log 2>&1 || rc=$?
if test "$rc" = 0; then "$py" measure.py job "$head" "$base" >native.log 2>&1 || rc=$?; fi
echo "$rc" > native.exit
rc=0
/usr/bin/time -f %e -o public-elapsed.txt taskset -c 2,4,16,20 "$py" public_compare.py asof_join --baseline "$t/asof-arrow-output-followup-nov25/wheels/source-release/release.json" --candidate "$study/wheel/release.json" --candidate-source "$study/source-main" --output "$study/python-10m" --sha "$head" >public.log 2>&1 || rc=$?
echo "$rc" > public.exit
"$py" report-product.py
"$py" phase-results.py
