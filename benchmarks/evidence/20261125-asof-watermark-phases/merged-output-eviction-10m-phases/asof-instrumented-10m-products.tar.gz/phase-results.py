"""Replay matching, Arrow and retirement for each registered 10M product and surface."""
import hashlib,json,statistics
from pathlib import Path
from diagnostic_validate import counts,FIELDS
from scripts.benchmark_suite.statistics import paired_round
from scripts.benchmark_suite.report import _paired_verdict
from scripts.toolkit import linear_percentile

r=Path(__file__).resolve().parent
plain=r.parent/'asof-output-and-eviction-10m-nov26'
read=lambda p:json.loads(p.read_text())
lines=lambda p:[json.loads(s) for s in p.read_text().splitlines()]
parts=['arrow_charge_ns','arrow_columns_ns','arrow_assembly_ns','arrow_bookkeeping_ns']
signed=lambda v:f'{v:+.3f}'
def paired(a,b):
    assert len(a)==len(b)==20
    change=[y-x for x,y in zip(a,b)]
    ci=[paired_round(a[i:i+10],b[i:i+10]) for i in (0,10)] if min(a)>0 and min(b)>0 else []
    return dict(release_p50=statistics.median(a),candidate_p50=statistics.median(b),release_p95=linear_percentile(a,.95),candidate_p95=linear_percentile(b,.95),mean_delta_ms=statistics.mean(change),rounds=ci,verdict=_paired_verdict(ci) if ci else None)
def phase(summary):
    return {population:{ph:paired(*[[x[population][ph]/1e6 for x in arm] for arm in summary]) for ph in ['wall_ns',*FIELDS,*parts]} for population in ('all','emitting','other')}
proof=read(r/'product-replay.json')
refs=read(plain/'bound.json');bound=read(r/'bound.json')
assert refs['candidate']==bound['direct_parent'] and bound['release_parent'].startswith('7012b5b4')
report={}
for surf,flag in [('native','native-release'),('python','python-release')]:
    obj=proof[flag]; gate=obj.get('outcome',obj); report[surf]=dict(outcome=gate)
    if gate['state'] not in ('completed','complete'):continue
    if surf=='native':
        d,=r.glob('obs-job-*'); orig,=plain.glob('obs-job-*')
        raw=lines(d/'observations.jsonl')
        for row in raw:
            rr=row['result'];cb=lines(d/rr['trace'])
            assert counts(cb,rr['pid'])==rr['phases']
        arms=[[row['result'] for row in raw if row['side']==s and row['pair']] for s in ('base','head')]
        summary=[[x['phases'] for x in arm] for arm in arms]
        ctrl=read(orig/'outcome.json')
        controls=[ctrl['pooled_ms'][s]['p50'] for s in ('base','head')] if ctrl['state']=='complete' else []
        cpu=gate['cpus'];control_cpu=ctrl.get('cpus')
    else:
        d=r/'python-10m';orig=plain/'python-10m';case=read(d/'samples.json');idx={}
        for f in (d/'measurement').rglob('asof-finalize.jsonl'):
            for item in lines(f.parent/'trace-request-ranges.jsonl'):
                key=(item['pid'],item['request_id']);assert key not in idx;idx[key]=f,item
        def replay(x):
            a=x['trace_range'];f,b=idx[(a['pid'],a['request_id'])]
            with f.open('rb') as h:
                h.seek(b['byte_start']);raw=h.read(b['byte_end']-b['byte_start'])
            cs=[json.loads(z) for z in raw.splitlines()]
            assert len(cs)==a['records'] and counts(cs,a['pid'])==a['stages'];return a['stages']
        arms=[[x for round in case['evidence'] for x in round['samples'][s]] for s in ('baseline','candidate')]
        summary=[[replay(x) for x in arm] for arm in arms]
        for rr in case['evidence']:
            for s in ('baseline','candidate'):
                for v in rr['samples'][s]:assert v['stream_evidence']['terminal_asof_status']['state_rows']==0
        ctrl=read(orig/'result.json') if (orig/'result.json').exists() else {}
        controls=[ctrl[s]*1000 for s in ('base_p50','head_p50')] if ctrl else []
        cpu=read(d/'result.json')['cpus'];control_cpu=ctrl.get('cpus')
    metric=paired(*[[x['seconds']*1000 for x in arm] for arm in arms])
    report[surf].update(outer=metric,phases=phase(summary),cpus=cpu)
    inventory={}
    for side, executions in zip(('release','candidate'),summary,strict=True):
        populations={}
        for pop in ('all','emitting','other'):
            rec=[x[pop] for x in executions]
            def span(xs):return {'min':min(xs),'median':statistics.median(xs),'max':max(xs)}
            populations[pop]={'callbacks_per_job':span([v['callbacks'] for v in rec]),
                              'admitted_tickets_per_job':{phase:span([v['tickets'][i] for v in rec]) for i,phase in enumerate(FIELDS)}}
        inventory[side]=populations
    report[surf]['callback_inventory']=inventory

    if controls:
        assert cpu==control_cpu==[2,4,16,20]
        report[surf]['instrumentation_overhead_percent']={s:100*(metric[s+'_p50']/ref-1) for s,ref in zip(('release','candidate'),controls)}
dest=r/'product-export';(dest/'paired-phases.json').write_text(json.dumps(report,indent=2,allow_nan=False)+'\n')
labels={'wall_ns':'累计处理器','matching_ns':'匹配与就绪','arrow_output_ns':'Arrow 输出','arrow_charge_ns':'其中，预算','arrow_columns_ns':'其中，取列','arrow_assembly_ns':'其中，装配与边预算','arrow_bookkeeping_ns':'其中，其余','left_commit_ns':'左侧提交','right_eviction_ns':'右侧淘汰','emit_ns':'发送','residual_ns':'其他处理器工作'}
markdown=['','## 回调耗时分解','','按每次独立作业汇总水位及 EOF 回调，再计算候选减发布版的配对平均差。发送和某些阶段可能包含异步等待。外层交付时钟在发送 EOF 前结束，累计回调包括其后的工作，不能从交付时钟中直接扣除此表各项。下表单位为毫秒。','']
table=[['阶段','Rust 平均差','Python 平均差']]
for key,title in labels.items():table.append([title,*[signed(report[s]['phases']['all'][key]['mean_delta_ms']) if 'phases' in report[s] else '—' for s in ('native','python')]])
from unicodedata import east_asian_width
width=lambda s:sum(2 if east_asian_width(c) in 'WF' else 1 for c in s)
widths=[max(map(width,col)) for col in zip(*table)]
line=lambda row:'| '+' | '.join(v+' '*(w-width(v)) for v,w in zip(row,widths))+' |'
markdown += [line(table[0]),'|'+'|'.join('-'*(w+2) for w in widths)+'|',*[line(row) for row in table[1:]],'']
markdown+=['资源中止的分段组仅记录已通过校验的样本。完整组的普通产品和插桩产品在相同固定核心上前后独立运行。各阶段墙钟、每作业产生输出的回调数和获准的 gather 请求数按入口分别列出。[逐阶段统计及插桩前后对照](paired-phases.json)']
with (dest/'README.md').open('a') as f:f.write('\n'.join(markdown)+'\n')
