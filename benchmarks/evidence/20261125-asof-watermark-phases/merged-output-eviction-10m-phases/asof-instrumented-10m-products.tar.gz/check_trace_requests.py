"""Bind measured requests and accepted timings to the two frozen products."""
import hashlib
import json
import sys
from pathlib import Path

root = Path(sys.argv[1]).resolve()
bound = json.loads((root / 'bound.json').read_bytes())
cpus = [2, 4, 16, 20]
builds = {'baseline': bound['release'], 'candidate': bound['candidate']}
result = {'native_qualifications': [], 'native_observations': {}, 'python_requests': {}}

def read(path):
    return json.loads(path.read_bytes())

def digest(path):
    with path.open('rb') as data:
        return hashlib.file_digest(data, 'sha256').hexdigest()

def native(data):
    assert data['keys'] == 64 and data['validated_all_rows'] and data['closed']
    assert data['cpus'] == data['workers'] == 4 and data['affinity'] == '2,4,16,20'
    assert data['output_rows'] == 10_000_000
    assert data['state']['state_bytes'] == data['state']['state_rows'] == 0

for arm, sha in builds.items():
    path = root / f'job-{sha[:10]}'
    receipt = read(path.with_name(path.name + '.receipt.json'))
    assert receipt['commit'] == sha and receipt['binary_sha256'] == digest(path)
    assert receipt['harness_sha256'] == digest(root / 'stage_job.rs')
    qual = root / f'qual-{sha[:10]}.json'
    if qual.exists():
        record = read(qual)
        assert record['cpus'] == cpus and record['commit'] == sha
        native(record['result'])
        result['native_qualifications'].append(arm)
for scope in root.glob('obs-job-*'):
    identity = read(scope / 'identity.json')
    assert (identity['base'], identity['head']) == tuple(builds.values())
    for arm, sha in zip(('base','head'), builds.values()):
        assert read(scope / f'{arm}.receipt.json') == read(root/f'job-{sha[:10]}.receipt.json')
    observations = scope / 'observations.jsonl'
    for line in observations.read_bytes().splitlines() if observations.exists() else ():
        row = json.loads(line)
        native(row['result'])
        key = f"{row['side']}-" + ('timed' if row['pair'] else 'warmup')
        counts = result['native_observations']
        counts[key] = counts.get(key, 0) + 1

public = root / 'python-10m'
if (root/'native.exit').read_text().strip() != '0':
    result['native_diagnostic'] = {p.name: p.read_text()[-2500:] for p in
        [root/'qualification.log', root/'native.log', *(root.glob('qual-*.stderr'))] if p.is_file()}
qualification = public / 'qualification.json'
if qualification.is_file():
    for arm, build in read(qualification)['builds'].items():
        assert build['sha'] == build['release']['git_sha'] == builds[arm]
        installed = public / arm / 'installed-interpreter.json'
        if installed.is_file():
            environment = read(installed)
            assert environment['native_sha256'] == build['release']['native_sha256']
            assert environment['cpu_affinity'] == cpus
            assert Path(environment['native_path']).parent == Path(environment['package_path']).parent
            assert (public/arm).resolve() in Path(environment['native_path']).resolve().parents
samples = read(public/'samples.json') if (public/'samples.json').exists() else None
for scope in sorted((public/'measurement').glob('round-*')):
    rnd = int(scope.name.split('-')[1])
    partial = read(scope/'partial.json') if (scope/'partial.json').exists() else {}
    for arm, sha in builds.items():
        observed = []
        for path in sorted((scope / arm).glob('request-*.completed.json')):
            request = read(path)
            rid = request['request_id']
            prefix = f'request-{rid:04}'
            assert path.name == prefix+'.completed.json'
            assert {k:v for k,v in request.items() if k != 'response'} == read(path.with_name(prefix+'.started.json'))
            worker = read(path.with_name(f'worker-{prefix}.json'))
            ctx = request['context']
            assert ctx == worker['context']
            response = request['response']
            # The parent adds trace ranges only after the child has sent its response.
            def without_ranges(payload):
                if 'warmup' in payload:return {**payload, 'warmup':without_ranges(payload['warmup'])}
                return {k:v for k,v in payload.items() if k!='trace_range'}
            assert without_ranges(response) == worker['response']
            assert (ctx['round'],ctx['side'],ctx['release']['git_sha']) == (rnd,arm,sha)
            assert ctx['case_id'] == 'engines/10000000/calc-flow-stream/asof_join'
            op, value = request['operation'], request['response']
            if op == 'hello':
                assert value['native_sha256'] == ctx['release']['native_sha256'] and value['cpu_affinity'] == cpus
                assert int(value['tokio_worker_threads']) == int(value['polars_threads']) == 4
            if op in ('sample','prepare'):
                assert any(p['phase']=='terminal-awaited' for p in worker['phases'])
                if op == 'sample':
                    assert ctx['sample'] == len(observed) == rid-3
                    observed.append(value)
                else:
                    assert rid == 2 and ctx['phase'] == 'warmup'
            key = f'{rnd}-{arm}-{op}'
            result['python_requests'][key] = result['python_requests'].get(key,0)+1
        persisted = partial.get('samples',{}).get(arm,[])
        assert observed[:len(persisted)] == persisted
        if partial.get('complete'):
            assert observed == persisted
        if samples and len(samples.get('evidence',[])) > rnd:
            assert observed == samples['evidence'][rnd]['samples'][arm]
print(json.dumps(result, indent=2))
