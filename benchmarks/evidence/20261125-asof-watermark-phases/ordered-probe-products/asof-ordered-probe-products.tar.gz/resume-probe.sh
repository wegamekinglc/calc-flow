set -eu
src=$1
benchenv=$2
ordinary=$3
suite=$4
native_scripts=$5
native_cache=$6
wheel_cache=$7
while test ! -f bound.json || test ! -f ../asof-4t-native-job-release-nov25/resume.exit; do sleep 3; done
sha256sum -c registered.sha256
head=$(python3 -c 'import json;print(json.load(open("bound.json"))["candidate"])')
prev=f09846cc65d25fbaa36f1702749cc15d43ccb1e5
release=7012b5b409553df04e29e6d7f9a11abf919cbf93
test "$(git -C source rev-parse HEAD)" = "$head"
test "$(git -C source rev-parse HEAD^)" = "$prev"
git -C "$src" diff --quiet
git -C "$src" switch --detach "$head"
CARGO_TARGET_DIR="$native_cache" CARGO_BUILD_JOBS=2 python3 build.py "$src" "$head" admit >native-build.log 2>&1
for group in previous release; do
 for suffix in "" ".receipt.json"; do ln "admit-${head:0:10}$suffix" "$group/admit-${head:0:10}$suffix"; done
done
while test ! -f ../rolling-page-borrows-native-nov25/resume-products.exit; do sleep 3; done
mkdir -p wheel
ln -s "$wheel_cache" wheel/cargo
touch source/crates/calc-flow/src/lib.rs source/crates/calc-flow-python/src/lib.rs
PYTHONPATH="$PWD/source" "$benchenv" -m scripts.benchmark_suite build --source "$PWD/source" --output "$PWD/wheel" >wheel/build-driver.log 2>&1
while ps -e -o stat=,comm= | awk '$2 ~ /^(rustc|rust-lld|cargo-clippy|clippy-driver)$/ && $1 !~ /^[TZ]/ {found=1} END {exit !found}'; do sleep 2; done
group() { label=$1; shift; rc=0; "$@" >"$label.log" 2>&1 || rc=$?; echo "$rc" >"$label.exit"; }
export PYTHONPATH="$native_scripts"
group native-release "$ordinary" release/measure.py admit "$head" "$release"
group native-parent "$ordinary" previous/measure.py admit "$head" "$prev"
export PYTHONPATH="$suite"
group py-parent-1m "$benchenv" wheel-parent-1m.py asof_join --baseline "$PWD/../asof-full-charge-product-nov25/wheel/release.json" --candidate "$PWD/wheel/release.json" --candidate-source "$PWD/source" --output "$PWD/py-parent-1m" --sha "$head"
group py-release-10m "$benchenv" wheel-release-10m.py asof_join --baseline "$suite/../main-src/target/products/release-1114/release.json" --candidate "$PWD/wheel/release.json" --candidate-source "$PWD/source" --output "$PWD/py-release-10m" --sha "$head"
