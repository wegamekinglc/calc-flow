"""Replay fixed-pair ASOF output-budget evidence and produce a small public archive."""
import hashlib
import json
import statistics
import tarfile
from pathlib import Path

from scripts.benchmark_suite.report import _paired_verdict
from scripts.benchmark_suite.statistics import paired_round
from scripts.toolkit import linear_percentile
from verify import verify

root = Path(__file__).resolve().parent
read = lambda p: json.loads(p.read_text())
files = {*root.glob('*.py'), *root.glob('*.sh'), root/'stage_admit.rs',
         root/'protocol.md', root/'registered.sha256',root/'bound.json'}
files.update(p for p in (root/'state-check-worker').rglob('*') if p.is_file())
files.add(root/'registered-before-state-output.sha256')
for entry in (root/'registered.sha256').read_text().splitlines():
    sha, path = entry.split(None, 1)
    f = root/path.strip()
    assert hashlib.file_digest(f.open('rb'),'sha256').hexdigest()==sha
    files.add(f)
rows = []
details = {}
for group in ('release', 'previous'):
    d, = (root/group).glob('obs-admit-*')
    proof = verify(d)
    out = read(d/'outcome.json')
    files.update(d.glob('*.json*'))
    base = '11.14' if group == 'release' else '父提交'
    details['native-'+group] = dict(replay=proof,outcome=out)
    if proof['state'] == 'complete':
        v = out['pooled_ms']
        rows.append(['Rust 单次水位',base,'10 万',v['base']['p50'],v['head']['p50'],
                     v['base']['p95'],v['head']['p95'],out['verdict']])
    else:
        rows.append(['Rust 单次水位',base,'10 万',None,None,None,None,'stopped'])
for scope, count, base in [('parent-1m',1_000_000,'父提交'),('release-10m',10_000_000,'11.14')]:
    d = root/('py-'+scope)
    for f in d.rglob('*'):
        if 'site' not in f.relative_to(d).parts and f.is_file() and f.suffix in ('.json','.jsonl','.log'):
            files.add(f)
    out = read(d/'outcome.json')
    detail = details['python-'+scope] = dict(outcome=out)
    row = ['Python 至表交付',base,'100 万' if count==1_000_000 else '1,000 万']
    observed = []
    expected = {'passed':True,'rows':count,'finite_rows':count,'max_abs_error':0.0}
    def verify_response(response):
        assert response['correctness']==expected and response['seconds']>0
        status=response['stream_evidence']['terminal_asof_status']
        assert all(status[k]==count for k in ('emitted_left_rows','matched_rows','evicted_right_rows'))
        assert response['stream_evidence']['post_eof_output_rows']==count
        assert all(status[k]==0 for k in ('state_rows','state_bytes','retained_right_rows','pending_left_rows','identity_only_rows','unmatched_rows','state_limit_failures','workspace_limit_failures','output_limit_failures'))
        for endpoint in ('left','right'):
            side=status[endpoint]
            assert side['ended'] and side['accepted_rows']==count and side['duplicate_rows']==side['late_rows']==0
    for f in (d/'measurement').rglob('*.completed.json'):
        request=read(f)
        response=request.get('response',{})
        value=response.get('warmup',response)
        if isinstance(value,dict) and 'seconds' in value and 'correctness' in value:
            verify_response(value)
            observed.append(request['operation'])
    detail['completed_requests']={op:observed.count(op) for op in ('prepare','sample')}
    if out['state'] != 'completed':
        resources=[json.loads(x) for x in (d/'resources.jsonl').read_text().splitlines()] if (d/'resources.jsonl').exists() else []
        detail['rejected_intervals']=[item for item in resources if any(not c['suitable'] for c in item['cores'])]
        rows.append([*row,None,None,None,None,'stopped'])
        continue
    result, samples = read(d/'result.json'), read(d/'samples.json')
    assert observed.count('prepare')==4 and observed.count('sample')==40
    assert samples['status']=='ok' and result['oracle_checked_executions']==44
    assert len(result['cpus'])==4 and all(all(c['suitable'] for c in json.loads(x)['cores']) for x in (d/'resources.jsonl').read_text().splitlines())
    rounds = []
    values = {'baseline':[],'candidate':[]}
    for evidence in samples['evidence']:
        assert evidence['environment']['cpu_affinity']==result['cpus']
        times={}
        for side in values:
            assert len(evidence['samples'][side])==10
            for item in evidence['samples'][side]:
                verify_response(item)
            times[side]=[item['seconds'] for item in evidence['samples'][side]]
            values[side]+=times[side]
        rounds.append(paired_round(times['baseline'],times['candidate']))
    assert rounds==result['round_intervals'] and _paired_verdict(rounds)==result['verdict']
    quantiles=[statistics.median(v) for v in values.values()]+[linear_percentile(v,.95) for v in values.values()]
    assert quantiles==[result[k] for k in ('base_p50','head_p50','base_p95','head_p95')]
    detail.update(result=result, verified_requests=44)
    rows.append([*row,*[x*1000 for x in quantiles],result['verdict']])
export=root/'product-export'
export.mkdir(exist_ok=True)
result_file=root/'product-replay.json'
result_file.write_text(json.dumps(details,indent=2,allow_nan=False)+'\n')
files.add(result_file)
files.update(root.glob('*.receipt.json'))
files.update(f for f in (root/'wheel').glob('*.json') if f.is_file())
files.update(root.glob('*.exit'))
archive=export/'asof-ordered-probe-products.tar.gz'
digest=lambda f: hashlib.file_digest(f,'sha256').hexdigest()
inventory=root/'product-sha256.txt'
inventory.write_text(''.join(digest(p.open('rb'))+'  '+str(p.relative_to(root))+'\n' for p in sorted(files)))
files.add(inventory)
with tarfile.open(archive,'w:gz') as t:
    for f in sorted(files):
        t.add(f,arcname=str(f.relative_to(root)),recursive=False)
with tarfile.open(archive) as t:
    assert all(digest(t.extractfile(str(p.relative_to(root))))==digest(p.open('rb')) for p in files)
table=[['入口','对照','每侧行数','对照 p50','候选 p50','对照 p95','候选 p95','两轮判定'],
       *[[f'{s:,.3f}' if isinstance(s,float) else str(s) if s is not None else '—' for s in row] for row in rows]]
widths=[max(map(len,c)) for c in zip(*table)]
line=lambda cells: '| '+' | '.join(s.ljust(n) for s,n in zip(cells,widths))+' |'
lines=['# ASOF 有序探测的右侧时间边界','','候选提交 `'+read(root/'bound.json')['candidate'][:8]+'`。父提交为 `f09846cc`，11.14 为 `7012b5b4`。时长单位为毫秒。每组两轮，每轮十对正式观测。另有四次预热。安装包从数据就绪计至 Arrow 结果交付，EOF 在计时后发送。Rust 单次水位在已接纳的两侧状态上启动。','',line(table[0]),'|'+'|'.join('-'*(n+2) for n in widths)+'|',*[line(r) for r in table[1:]] ,'','本次安装包千万行组在 2 次预热及 1 次正式单臂观测后，资源监测记录到在同一周期内换入 5 页、换出 10,599 页。正式单臂为发布版。候选进程的本地回执对应控制器失败请求，该组完整正式配对为零。两个父提交比较均未确认端到端提速。','','两种入口分别校验完整结果、终态及资源采样。停止的组在原始记录中保留，均不参与性能判断。父提交比较衡量本次改动，发布版比较衡量当前剩余差距。','',f'[复算脚本、构建记录及原始数据]({archive.name})，SHA-256 `{digest(archive.open("rb"))}`。','']
(export/'README.md').write_text('\n'.join(lines))
(export/result_file.name).write_bytes(result_file.read_bytes())
