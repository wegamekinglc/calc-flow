"""Fetch the four hosted raw archives by exact run ID and independently replay them."""
from __future__ import annotations

import hashlib
import io
import json
import os
from pathlib import Path
import statistics
import subprocess
import sys
import tarfile
import zipfile

OFFLINE = "--offline" in sys.argv

from scripts.benchmark_suite.report import _paired_verdict
from scripts.benchmark_suite.statistics import paired_round
from scripts.toolkit import linear_percentile

OUT = Path(__file__).resolve().parent
RUN = 45691470579
OID = 'a6273968fb085141f8f703f538c1b27d622c6d24'
HEAD = 'e3104f444688ab3890c4b45f6098c28e052de7a8'
CONTROLS = {'release':'7012b5b409553df04e29e6d7f9a11abf919cbf93','parent':'f069199b25cd7893879df799a2d44e95d6a9cbad'}
API = "repos/wegamekinglc/calc-flow/actions"
COUNT = 10_000_000
def api(route):
    return json.loads(subprocess.check_output(['gh','api',API+route]))
def read(p): return json.loads(p.read_text())
def records(p): return [json.loads(line) for line in p.read_text().splitlines()] if p.exists() else []
def rawhash(p):
    with p.open('rb') as f: return hashlib.file_digest(f,'sha256').hexdigest()
def download(artifact, group):
    z = group / "original.zip"
    if not OFFLINE:
      with z.open("wb") as f:
        subprocess.run(["gh","api",API+"/artifacts/"+str(artifact["id"])+"/zip"],check=True,stdout=f)
    assert 'sha256:'+rawhash(z)==artifact["digest"] and z.stat().st_size==artifact["size_in_bytes"]
    with zipfile.ZipFile(z) as archive:
        assert archive.namelist()==['asof-raw.tar.gz']
        compressed=archive.read('asof-raw.tar.gz')
    with tarfile.open(fileobj=io.BytesIO(compressed), mode='r:gz') as cf:
        for entry in cf.getmembers():
            assert Path(entry.name).parts[0]=='evidence' and '..' not in Path(entry.name).parts
            assert entry.isreg() or entry.isdir()
        cf.extractall(group, filter='data')
    return group/'evidence'
def qualifying_state(status):
    assert all(status[key]==COUNT for key in ('emitted_left_rows','matched_rows','evicted_right_rows'))
    assert all(status[key]==0 for key in ('state_rows','state_bytes','retained_right_rows','pending_left_rows','identity_only_rows','unmatched_rows','state_limit_failures','workspace_limit_failures','output_limit_failures'))
    for name in ('left','right'):
        side=status[name]
        assert side['ended'] and side['accepted_rows']==COUNT and side['duplicate_rows']==side['late_rows']==0
def resources(d, require):
    intervals=records(d/'resources.jsonl')
    failures=[]
    for idx,item in enumerate(intervals):
        cpus={c['cpu'] for c in item['cores']}
        assert 2<=len(cpus)<=4
        assert item['preflight']==(idx==0)
        for c in item['cores']:
            assert not cpus.intersection(c['siblings'])
            assert abs(c['external_host_percent'] - max(0, c['host_busy']-c['owned_host_percent']))<1e-9
            expected=(max(c['cpu_busy'],c['sibling_busy'])<=20 and c['host_busy']<50) if item['preflight'] else (c['sibling_busy']<50 and c['external_host_percent']<50)
            expected=expected and c['available_bytes']>=10*1024**3 and c['major_faults']<256 and c['swap_pages']<1024
            assert expected==c['suitable']
            if not expected:failures.append(c)
    if require:
        assert intervals and not failures
    return dict(accepted_intervals=len(intervals)-sum(any(not c['suitable'] for c in i['cores']) for i in intervals), rejected=failures, selected_cpus=[c['cpu'] for c in intervals[0]['cores']] if intervals else [])
def replay_rust(root, base):
    d,=root.glob('obs-job-*')
    identity=read(d/'identity.json')
    assert identity['base']==base and identity['head']==HEAD
    out=read(d/'outcome.json')
    obs=records(d/'observations.jsonl')
    for arm,sha in [('base',base),('head',HEAD)]:
        r=read(d/(arm+'.receipt.json'))
        assert r['commit']==sha and r==read(root/f'job-{sha[:10]}.receipt.json')
        assert r['harness_sha256']==rawhash(root/'stage_job.rs')
    evidence=resources(d,out['state']=='complete')
    for ordinal,record in enumerate(obs):
        rnd,pos=divmod(ordinal,22)
        pair,arm=divmod(pos,2)
        order=('base','head') if pair==0 or pair%2 else ('head','base')
        assert (record['round'],record['pair'],record['side'])==(rnd+1,pair,order[arm])
        x=record['result']
        assert x['seconds']>0 and x['workers']==4 and x['cpus']==len(evidence['selected_cpus'])
        assert x['keys']==64 and x['closed'] and x['validated_all_rows'] and x['output_rows']==COUNT
        qualifying_state(x['state'])
    evidence['completed_observations']=len(obs)
    if out['state']!='complete': return dict(state='stopped',error=out['error'],**evidence)
    assert len(obs)==44
    samples=[{side:[x['result']['seconds']*1000 for x in obs if x['round']==r and x['pair'] and x['side']==side] for side in ('base','head')} for r in (1,2)]
    stats=statistics_for(samples)
    assert stats['ms']==out['pooled_ms'] and stats['verdict']==out['verdict'] and stats['rounds']==out['rounds']
    return dict(state='complete',**stats,**evidence)
def statistics_for(samples, to_ms=1):
    assert len(samples)==2 and all(len(r[s])==10 for r in samples for s in r)
    rounds=[paired_round(r['base'],r['head']) for r in samples]
    ms={}
    for s in ('base','head'):
        vals=[v for r in samples for v in r[s]]
        ms[s]={'p50':statistics.median(vals)*to_ms,'p95':linear_percentile(vals,.95)*to_ms}
    return dict(rounds=rounds,verdict=_paired_verdict(rounds),ms=ms,delta_percent=100*(ms['head']['p50']/ms['base']['p50']-1))
def replay_python(root, base):
    d=root/'python'
    out=read(d/'outcome.json')
    qual=read(d/'qualification.json') if (d/'qualification.json').exists() else {}
    evidence=resources(d,out['state']=='completed')
    samples=[]
    finished={'prepare':0,'sample':0}
    for rnd in range(2):
        q=d/'measurement'/f'round-{rnd}'
        if not q.exists():continue
        values={}
        for arm,sha,label in [('baseline',base,'base'),('candidate',HEAD,'head')]:
            assert qual['builds'][arm]['release']['git_sha']==sha
            observed=[]
            for f in sorted((q/arm).glob('request-*.completed.json')):
                msg=read(f)
                worker=read(f.with_name('worker-'+f.name.replace('.completed','')))
                started=read(f.with_name(f.name.replace('.completed','.started')))
                assert started=={k:v for k,v in msg.items() if k!='response'}
                assert worker['response']==msg['response'] and worker['context']==msg['context']
                ctx=msg['context']
                assert (ctx['case_id'],ctx['round'],ctx['side'],ctx['release']['git_sha'])==('engines/10000000/calc-flow-stream/asof_join',rnd,arm,sha)
                val=msg['response']
                if msg['operation']=='hello':
                    assert val['native_sha256']==ctx['release']['native_sha256'] and val['cpu_affinity']==evidence['selected_cpus']
                    assert int(val['tokio_worker_threads'])==int(val['polars_threads'])==4
                if msg['operation'] not in finished:continue
                finished[msg['operation']]+=1
                assert any(p['phase']=='terminal-awaited' for p in worker['phases'])
                result=val.get('warmup',val)
                assert result['seconds']>0 and result['correctness']=={'rows':COUNT,'finite_rows':COUNT,'max_abs_error':0.0,'passed':True}
                assert result['stream_evidence']['post_eof_output_rows']==COUNT
                qualifying_state(result['stream_evidence']['terminal_asof_status'])
                if msg['operation']=='sample':
                    assert ctx['sample']==len(observed)
                    observed.append(result)
            if (q/'partial.json').exists():
                partial=read(q/'partial.json')
                recorded=partial.get('samples',{}).get(arm,[])
                assert observed[:len(recorded)]==recorded
            values[label]=[x['seconds'] for x in observed]
        samples.append(values)
    evidence['completed_observations']=finished
    if out['state']!='completed': return dict(state='stopped',error=out['error'],**evidence)
    assert finished=={'prepare':4,'sample':40}
    result=read(d/'result.json')
    stats=statistics_for(samples,1000)
    assert result['verdict']==stats['verdict'] and result['round_intervals']==stats['rounds']
    for s in ('base','head'):
        for pct in ('p50','p95'):assert abs(result[s+'_'+pct]*1000-stats['ms'][s][pct])<1e-9
    return dict(state='complete',**stats,**evidence)

def main():
    run=read(OUT/'run.json') if OFFLINE else api(f'/runs/{RUN}')
    assert run['head_sha']==OID and run['event']=='workflow_dispatch' and run['status']=='completed'
    artifacts=read(OUT/'artifacts.json') if OFFLINE else api(f'/runs/{RUN}/artifacts?per_page=100')['artifacts']
    (OUT/'run.json').write_text(json.dumps(run,indent=2)+'\n')
    (OUT/'artifacts.json').write_text(json.dumps(artifacts,indent=2)+'\n')
    details={}
    for surface in ('rust','python'):
        for name,base in CONTROLS.items():
            ident=surface+'-'+name
            group=OUT/ident
            exact=f'asof-10m-{surface}-{name}-{RUN}-1'
            found=[a for a in artifacts if a['name']==exact]
            if not found:
                details[ident]=dict(state='unmeasured',reason='no raw archive uploaded')
                continue
            item,=found
            if not group.exists():group.mkdir()
            root=download(item,group)
            assert (root/'registration.txt').read_text().strip()==OID
            (root/'topology.json').read_bytes()
            for line in (root/'registered.sha256').read_text().splitlines():
                checksum,path=line.split(None,1)
                assert rawhash(root/path)==checksum
            details[ident]={'artifact_id':item['id'],'artifact_sha256':item['digest'],**(replay_rust(root,base) if surface=='rust' else replay_python(root,base))}
    (OUT/'replay.json').write_text(json.dumps(details,indent=2)+'\n')
    print(json.dumps(details,indent=2))
if __name__=='__main__':
    main()
