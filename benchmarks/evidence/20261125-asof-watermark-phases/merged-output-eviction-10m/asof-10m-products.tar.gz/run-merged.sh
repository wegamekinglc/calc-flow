set -eu
study=$(pwd)
parent=$(dirname "$study")
while test ! -f "$parent/asof-left-commit-split-nov26/run.exit"; do sleep 4; done
harness="$parent/managed-runtime-20261124/round5-harness"
py="$parent/worktrees/benchmark-large-engines-20261114/target/benchmark-venv/bin/python"
sha256sum --quiet -c registered.sha256
for f in engine_comparison.py engine_stream.py; do cmp "worker/benchmarks/$f" "$harness/target/post-timer-worker/benchmarks/$f"; done
release=7012b5b409553df04e29e6d7f9a11abf919cbf93
head=$(python3 -c 'import json;print(json.load(open("bound.json"))["candidate"])')
test "$(git -C source rev-parse HEAD)" = "$head"
mkdir wheel
ln -s "$parent/managed-runtime-20261124/main-src/target/cargo" wheel/cargo
touch source/crates/calc-flow/src/lib.rs source/crates/calc-flow-python/src/lib.rs
( PYTHONPATH="$study/source" "$py" -m scripts.benchmark_suite build --source "$study/source" --output "$study/wheel" ) >wheel/build-driver.log 2>&1 & wheel_pid=$!
r=0
CARGO_TARGET_DIR="$parent/staged-perf-ec402c59/asof-charge-release-nov24/target/cargo" CARGO_BUILD_JOBS=2 python3 build.py "$study/native-source" "$head" job >native-build.log 2>&1 || r=$?
wait "$wheel_pid" || r=$?
test "$r" = 0
while ps -eo stat=,comm= | awk '$2 ~ /^(rustc|rust-lld|cargo-clippy|clippy-driver)$/ && $1 !~ /^[TZ]/ {found=1} END {exit !found}'; do sleep 2; done
export TMPDIR="$study/managed-tmp" PYTHONPATH="$harness"
r=0
timeout 15 "$py" qualify.py "$release" "$head" >qualification.log 2>&1 || r=$?
if test "$r" = 0; then "$py" measure.py job "$head" "$release" >native.log 2>&1 || r=$?; fi
echo "$r" >native.exit
r=0
/usr/bin/time -f %e -o public-elapsed.txt taskset -c 2,4,16,20 "$py" public_compare.py asof_join --baseline "$parent/managed-runtime-20261124/main-src/target/products/release-1114/release.json" --candidate "$study/wheel/release.json" --candidate-source "$study/source" --output "$study/python-10m" --sha "$head" >public.log 2>&1 || r=$?
echo "$r" >public.exit
"$py" check_raw.py "$study" > checked-requests.json
"$py" report-product.py
