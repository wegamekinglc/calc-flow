"""Bind a fetched main only after all four reviewed product heads are ancestors."""
from pathlib import Path
import subprocess,json,datetime,os
d=Path(__file__).resolve().parent
def git(*args):return subprocess.check_output(['git',*args],text=True).strip()
subprocess.run(['git','fetch','-q','origin','main'],check=True)
candidate=git('rev-parse','origin/main')
proof={}
for n,want in [(748,'cb8adc7b638b0876c1d9ff248ec54e57c3568056'),(749,'a3c9331539c260f3ef2b835f3349ae69feffbd06'),(750,'9aed8b4b20156a460369d0765c4bc9e42e0925e5'),(751,'b6feec7df990e9200887982498c2db3479d93c61')]:
    rec=json.loads(subprocess.check_output(['gh','pr','view',str(n),'--json','state,headRefOid,mergeCommit,mergedAt,baseRefName'],text=True))
    assert rec['state']=='MERGED' and rec['headRefOid']==want and rec['baseRefName']=='main'
    for sha in [want,rec['mergeCommit']['oid']]:subprocess.run(['git','merge-base','--is-ancestor',sha,candidate],check=True)
    proof[n]=rec
assert not (d/'bound.json').exists()
subprocess.run(['git','worktree','add','--quiet','--detach',str(d/'source'),candidate],check=True)
assert not git('-C',str(d/'source'),'status','--porcelain')
subprocess.run(['git','worktree','add','--quiet','--detach',str(d/'native-source'),candidate],check=True)
rec=dict(candidate=candidate,tree=git('rev-parse',candidate+'^{tree}'),parents=git('show','-s','--format=%P',candidate).split(),release='7012b5b409553df04e29e6d7f9a11abf919cbf93',ancestor_checks=proof,bound_at=datetime.datetime.now(datetime.UTC).isoformat())
tmp=d/'pending-binding.json';tmp.write_text(json.dumps(rec,indent=2)+'\n');os.replace(tmp,d/'bound.json')
print(candidate)
