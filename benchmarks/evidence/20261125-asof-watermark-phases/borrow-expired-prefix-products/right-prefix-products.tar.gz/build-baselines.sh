set -eu
registered=$1
target_dir=$2
while test ! -f "$registered/run.exit"; do sleep 12; done
sha256sum --quiet -c registered.sha256
export CARGO_BUILD_JOBS=2 CARGO_TARGET_DIR="$target_dir"
for ref in 7012b5b409553df04e29e6d7f9a11abf919cbf93 de20f8216c8dcb1bfce3e3811c3884a3080157df; do
 git -C source diff --quiet
 git -C source switch -q --detach "$ref"
 python3 build.py "$PWD/source" "$ref" admit
done
