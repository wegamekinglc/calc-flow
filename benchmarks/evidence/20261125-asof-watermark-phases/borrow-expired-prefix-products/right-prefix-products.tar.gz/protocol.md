# Right-only ASOF progress and installed managed output

The 1M public historical trace showed work on a callback without a joint
frontier or emitted payload. Test the specific right-first ordering separately,
without inferring the original scheduling order. Retiring eligible identity or
payload locators on a partial sweep touches the columnar fallback; the proposed
change eliminates its temporary copies of locator prefixes.

Use the same registered sources for two independent product pairs, 2026.11.14
7012b5b4 vs candidate and pre-change de20f821 vs candidate. Bind the reviewed
candidate SHA and its direct parent before measurements. Four groups, always
retain a stopped group without replacement. Each uses two rounds of ten
alternating formal pairs, one excluded warmup per arm per round. Preserve
resource preflight, process affinity, swap/fault checks, exact wheel/native
hashes and correctness gates. Run groups sequentially.

Rust uses one worker, 100,000 rows per input, 64 keys, and two fixed-width
batches per side. Start the stopwatch after both inputs are admitted, advance
only the right watermark, and stop on callback return. Assert no output, all
pending left and all retained right rows, verify both watermarks and zero
payload retirements, then advance left and validate all matched projected
values and output order. Include release any pre-callback retirement wait in
this outer clock. Allow 45 seconds per group including preparation and replay.

Installed Python uses the maintained native managed ASOF job and ready-result
clock at 1M rows per input, 64 string keys, one worker, with the validated
post-timer physical-order and EOF worker. Both arms independently process
the same default schedule with no forced watermark arrival order. Verify all
projected values and terminal inventories. Allow 120 seconds per group including
package installation and qualification. Allow an additional 60 seconds total
for coordination and final replay, 390 seconds in total. Native release builds
and the candidate wheel have separate build time (estimated 60 minutes total).
