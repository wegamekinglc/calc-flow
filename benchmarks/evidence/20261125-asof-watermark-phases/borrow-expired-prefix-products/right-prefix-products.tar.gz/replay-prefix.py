"""Replay fixed-pair ASOF output-budget evidence and produce a small public archive."""
import hashlib
import json
import statistics
import tarfile
from pathlib import Path

from scripts.benchmark_suite.report import _paired_verdict
from scripts.benchmark_suite.statistics import paired_round
from scripts.toolkit import linear_percentile
from observe import checked, summarize

root = Path(__file__).resolve().parent
read = lambda p: json.loads(p.read_text())
files=set()
for pattern in ('*.py','*.sh','*.rs','*.md','*.json','*.sha256','*.exit','*.txt'):
    files.update(f for f in root.glob(pattern) if f.is_file() and f.name not in ('product-sha256.txt', 'product-replay.json'))
for directory in ['wheel','worker']:
    scope=root/directory
    if scope.is_dir():
        for f in scope.rglob('*') if directory in ('worker','public-settings') else scope.glob('*'):
            if f.is_file() and f.suffix in ('.json','.py','.log','.sha256'): files.add(f)
for manifest in [*root.glob('registered.sha256'),*root.glob('bound-cpus.sha256'),*root.glob('*/bound.sha256')]:
    files.add(manifest)
    for entry in manifest.read_text().splitlines():
        expected, path=entry.split(None,1)
        f=manifest.parent/path.strip()
        assert hashlib.file_digest(f.open('rb'),'sha256').hexdigest()==expected
        files.add(f)
rows=[]
details={}
for group, base, sha in [('parent','前一主线', 'de20f8216c'), ('release','11.14','7012b5b409')]:
    d,=root.glob('obs-'+sha+'-*')
    outcome=read(d/'outcome.json')
    files.update(d.glob('*.json*'))
    rowslog=[json.loads(x) for x in (d/'observations.jsonl').read_text().splitlines()] if (d/'observations.jsonl').exists() else []
    identity=read(d/'identity.json')
    for arm in ('base','head'):
        receipt=read(d/(arm+'.receipt.json'))
        assert receipt['commit']==identity['executables'][arm]
        assert receipt['harness_sha256']==identity['adapter_sha256']
    for k,row in enumerate(rowslog):
        rnd,within=divmod(k,22)
        pair,arm=divmod(within,2)
        sides=('base','head') if pair==0 or pair%2 else ('head','base')
        assert (row['round'],row['pair'],row['side'])==(rnd+1,pair,sides[arm])
        assert checked(row['result'])==row['ns']
    details['native-'+group]=dict(outcome=outcome,checked_observations=len(rowslog))
    if outcome['state']=='complete':
        resources=[json.loads(line) for line in (d/'resources.jsonl').read_text().splitlines()]
        assert resources[0]['preflight'] and len(resources)>1
        assert all(x['cpu']==outcome['cpu'] and x['suitable'] for x in resources)
        score=summarize(d)
        assert score==outcome['metrics']
        v=score['watermark_ns']
        rows.append(['Rust 右侧水位回调',base,'10 万',v['p50_ms']['base'],v['p50_ms']['head'],v['p95_ms']['base'],v['p95_ms']['head'],v['verdict']])
    else:
        rows.append(['Rust 右侧水位回调',base,'10 万',None,None,None,None,'stopped'])
for scope, base in [('parent','前一主线'),('release','11.14')]:
    count=1_000_000
    d=root/('wheel-'+scope)
    assert (d/'outcome.json').is_file(), d
    for f in d.rglob('*'):
        if 'site' not in f.relative_to(d).parts and f.is_file() and f.suffix in ('.json','.jsonl','.log'):
            files.add(f)
    out = read(d/'outcome.json')
    detail = details['python-'+scope] = dict(outcome=out)
    row = ['Python 至表交付',base,'100 万' if count==1_000_000 else '1,000 万']
    observed = []
    expected = {'passed':True,'rows':count,'finite_rows':count,'max_abs_error':0.0}
    def verify_response(response):
        assert response['correctness']==expected and response['seconds']>0
        status=response['stream_evidence']['terminal_asof_status']
        assert all(status[k]==count for k in ('emitted_left_rows','matched_rows','evicted_right_rows'))
        assert response['stream_evidence']['post_eof_output_rows']==count
        assert all(status[k]==0 for k in ('state_rows','state_bytes','retained_right_rows','pending_left_rows','identity_only_rows','unmatched_rows','state_limit_failures','workspace_limit_failures','output_limit_failures'))
        for endpoint in ('left','right'):
            side=status[endpoint]
            assert side['ended'] and side['accepted_rows']==count and side['duplicate_rows']==side['late_rows']==0
    for f in (d/'measurement').rglob('*.completed.json'):
        request=read(f)
        response=request.get('response',{})
        value=response.get('warmup',response)
        if isinstance(value,dict) and 'seconds' in value and 'correctness' in value:
            verify_response(value)
            observed.append(request['operation'])
    detail['completed_requests']={op:observed.count(op) for op in ('prepare','sample')}
    if out['state'] != 'completed':
        resources=[json.loads(x) for x in (d/'resources.jsonl').read_text().splitlines()] if (d/'resources.jsonl').exists() else []
        detail['rejected_intervals']=[item for item in resources if any(not c['suitable'] for c in item['cores'])]
        rows.append([*row,None,None,None,None,'stopped'])
        continue
    result, samples = read(d/'result.json'), read(d/'samples.json')
    assert observed.count('prepare')==4 and observed.count('sample')==40
    assert samples['status']=='ok' and result['oracle_checked_executions']==44
    assert len(result['cpus'])==1 and all(all(c['suitable'] for c in json.loads(x)['cores']) for x in (d/'resources.jsonl').read_text().splitlines())
    rounds = []
    values = {'baseline':[],'candidate':[]}
    for evidence in samples['evidence']:
        assert evidence['environment']['cpu_affinity']==result['cpus']
        times={}
        for side in values:
            assert len(evidence['samples'][side])==10
            for item in evidence['samples'][side]:
                verify_response(item)
            times[side]=[item['seconds'] for item in evidence['samples'][side]]
            values[side]+=times[side]
        rounds.append(paired_round(times['baseline'],times['candidate']))
    assert rounds==result['round_intervals'] and _paired_verdict(rounds)==result['verdict']
    quantiles=[statistics.median(v) for v in values.values()]+[linear_percentile(v,.95) for v in values.values()]
    assert quantiles==[result[k] for k in ('base_p50','head_p50','base_p95','head_p95')]
    detail.update(result=result, verified_requests=44)
    rows.append([*row,*[x*1000 for x in quantiles],result['verdict']])
export=root/'product-export'
export.mkdir(exist_ok=True)
result_file=root/'product-replay.json'
result_file.write_text(json.dumps(details,indent=2,allow_nan=False)+'\n')
files.add(result_file)
files={f for f in files if not f.name.startswith(('ci-','recover-pr-ci','report-product','replay-prefix.log','replay-prefix.exit'))}
archive=export/'right-prefix-products.tar.gz'
digest=lambda f: hashlib.file_digest(f,'sha256').hexdigest()
inventory=root/'product-sha256.txt'
inventory.write_text(''.join(digest(p.open('rb'))+'  '+str(p.relative_to(root))+'\n' for p in sorted(files)))
files.add(inventory)
with tarfile.open(archive,'w:gz') as t:
    for f in sorted(files):
        t.add(f,arcname=str(f.relative_to(root)),recursive=False)
with tarfile.open(archive) as t:
    assert all(digest(t.extractfile(str(p.relative_to(root))))==digest(p.open('rb')) for p in files)
table=[['入口','对照','每侧行数','对照 p50','候选 p50','对照 p95','候选 p95','两轮判定'],
       *[[f'{s:,.3f}' if isinstance(s,float) else str(s) if s is not None else '—' for s in row] for row in rows]]
from unicodedata import east_asian_width
width=lambda value:sum(2 if east_asian_width(c) in 'WF' else 1 for c in value)
widths=[max(map(width,c)) for c in zip(*table)]
line=lambda cells: '| '+' | '.join(s+' '*(n-width(s)) for s,n in zip(cells,widths))+' |'
bound=read(root/'bound.json')
lines=['# ASOF 右侧水位和已安装 Python 对照','',
       f"候选 {bound['sha']}。前一主线 {bound['pre_pr']}。发布版 {bound['release']}。每组使用一个工作线程。时间单位为毫秒。",
       '',line(table[0]),'|'+'|'.join('-'*(n+2) for n in widths)+'|',*[line(r) for r in table[1:]],'',
       'Rust 原生表预先接纳左右各 10 万行，仅对右侧推进水位，计时到处理器返回。随后推进左侧，校验总行数、非递减顺序，并逐行核对左右序列相等及右值等于左序列的三倍。这个 Rust 校验不能识别所有重复替代或遗漏。Python 使用独立安装的 wheel，从各侧 100 万行的输入就绪计时到完整 Arrow 表交付，独立核对整表投影值、物理行序、EOF 和终态。Python 的默认调度不保证右侧先到。','',
       '每个完整组包含两轮、每轮十对正式计时以及每轮每侧一次预热。stopped 表示触发资源或时间等限制，已收取的样本仅供校验，不推算分位数或速度。具体状态、原因和样本数见 JSON。','',
       f'[协议、日志与逐次结果]({archive.name})，SHA-256 `{digest(archive.open("rb"))}`。','']
(export/'README.md').write_text('\n'.join(lines))
(export/result_file.name).write_bytes(result_file.read_bytes())
