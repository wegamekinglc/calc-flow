"""Run only the registered native watermark fixture; persist paired and per-progress evidence."""
from __future__ import annotations
import asyncio, hashlib, json, math, os, shutil, statistics, sys, time
from pathlib import Path

ROOT = Path(__file__).resolve().parent
import subprocess
from scripts.sparse_changelog_ci import _resource
from scripts.benchmark_suite.process import child_environment
from scripts.benchmark_suite.report import _paired_verdict
from scripts.benchmark_suite.statistics import paired_round
from scripts.toolkit import linear_percentile

PRODUCT=("base","head")
N=100_000

def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

def write(path, data):
    path.write_text(json.dumps(data, indent=2, allow_nan=False)+'\n')

def append(path, item):
    with path.open('a') as f: f.write(json.dumps(item,allow_nan=False)+'\n')

def require(condition, reason):
    if not condition: raise ValueError(reason)

def checked(data):
    r=data['right_only']
    require(data.get('validated_all_rows') is True and data['output_rows']==N,'complete output')
    require(data['pending_before_watermark']==N==data['retained_before_watermark'],'admission inventory')
    require(r['left']['watermark_micros'] is None and r['right']['watermark_micros']==(N-1)//64+1,'right-only progress')
    require(r['pending_left_rows']==r['retained_right_rows']==N and r['state_rows']==2*N,'right-only inventory')
    require(r['emitted_left_rows']==r['matched_rows']==r['evicted_right_rows']==0,'right-only output')
    require(data['evicted_right_rows']==N and data['retained_right_rows']==0,'settled state')
    seconds=data['watermark_seconds']
    require(math.isfinite(seconds) and seconds>0,'watermark time')
    return {'watermark_ns':round(seconds*1e9)}

async def sample(path,cpu,exe,rnd,i,side):
    require(os.sched_getaffinity(0)=={cpu},'changed affinity')
    proc=await asyncio.create_subprocess_exec(str(exe),stdout=asyncio.subprocess.PIPE,stderr=asyncio.subprocess.PIPE,env=child_environment(tokio_threads=1,polars_threads=1))
    try:stdout,stderr=await proc.communicate()
    finally:
        if proc.returncode is None:proc.kill();await proc.wait()
    require(proc.returncode==0,stderr.decode()[-1000:])
    result=json.loads(stdout)
    append(path/'observations.jsonl',dict(round=rnd,pair=i,side=side,pid=proc.pid,result=result,ns=checked(result)))

def summarize(path):
    obs=[json.loads(line) for line in (path/'observations.jsonl').read_text().splitlines()]
    require(len(obs)==44,'44 observations')
    for index,row in enumerate(obs):
        rnd,pos=divmod(index,22); i,arm=divmod(pos,2)
        order=['base','head'] if i==0 or i%2 else ['head','base']
        require((row['round'],row['pair'],row['side'])==(rnd+1,i,order[arm]),'pair order')
        require(checked(row['result'])==row['ns'],'replay equality')
    fields=obs[0]['ns'].keys()
    def values(k, s, rnd=None):
        return [r['ns'][k]/1e6 for r in obs if r['pair'] and r['side']==s and (rnd is None or r['round']==rnd)]
    out={}
    for k in fields:
        rounds=[]
        absolutes=[]
        for rnd in [1,2]:
            a,b=values(k,'base',rnd),values(k,'head',rnd)
            require(len(a)==len(b)==10,'formal pair count')
            absolutes.append(statistics.median([y-x for x,y in zip(a,b)]))
            if min(a)>0: rounds.append(paired_round(a,b))
        out[k]={'p50_ms':{s:statistics.median(values(k,s)) for s in PRODUCT},
                'p95_ms':{s:linear_percentile(values(k,s),.95) for s in PRODUCT},
                'paired_median_difference_ms_by_round':absolutes,
                'paired_median_difference_ms':statistics.median([y-x for x,y in zip(values(k,'base'),values(k,'head'))]),
                'rounds':rounds,'verdict':_paired_verdict(rounds) if len(rounds)==2 else None}
    return out

async def run(baseline,head,path):
    shas=dict(base=baseline,head=head);builds={};receipts={}
    for side,sha in shas.items():
        exe=ROOT/f'admit-{sha[:10]}';receipt=exe.with_suffix('.receipt.json')
        meta=json.loads(receipt.read_text());shutil.copyfile(receipt,path/f'{side}.receipt.json')
        require(meta['commit']==sha and digest(exe)==meta['binary_sha256'],'executable identity')
        git=lambda spec:subprocess.check_output(['git','-C',str(ROOT/'source'),'show',spec])
        require(meta['harness_sha256']==digest(ROOT/'stage_admit.rs') and meta['lock_sha256']==hashlib.sha256(git(sha+':Cargo.lock')).hexdigest(),'adapter and lock identity')
        require(meta['tree']==subprocess.check_output(['git','-C',str(ROOT/'source'),'rev-parse',sha+'^{tree}'],text=True).strip(),'product tree')
        builds[side]=exe;receipts[side]=meta
    for field in ('harness_sha256','rustc','cargo','settings'):
        require(receipts['base'][field]==receipts['head'][field],field)
    write(path/'identity.json',dict(executables=shas,adapter_sha256=digest(ROOT/'stage_admit.rs'),protocol_sha256=digest(ROOT/'protocol.md'),run_sha256=digest(Path(__file__)),machine=list(os.uname())))
    cpu=await _resource(path/'resources.jsonl',None)
    os.sched_setaffinity(0,{cpu})
    async def collect():
        for rnd in [1,2]:
            for i in range(11):
                for side in (['base','head'] if i==0 or i%2 else ['head','base']):
                    await sample(path,cpu,builds[side],rnd,i,side)
    async with asyncio.TaskGroup() as tg:
        task=tg.create_task(collect())
        while not task.done(): await _resource(path/'resources.jsonl',cpu)
    return dict(cpu=cpu,metrics=summarize(path))

if __name__=='__main__':
    baseline,head=sys.argv[1:];path=ROOT/f'obs-{baseline[:10]}-{head[:10]}';path.mkdir()
    start=time.monotonic()
    try:
        outcome=asyncio.run(asyncio.wait_for(run(baseline,head,path),44))
        require(time.monotonic()-start<45,'cohort time limit')
        outcome['state']='complete'
    except BaseException as e:
        outcome={'state':'stopped','exception':repr(e)}
        raise
    finally:
        outcome['wall_seconds']=time.monotonic()-start;write(path/'outcome.json',outcome)
