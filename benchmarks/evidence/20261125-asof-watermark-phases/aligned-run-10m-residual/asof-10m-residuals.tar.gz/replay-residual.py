"""Authenticate the diagnostic run and replay four paired cohorts and both clocks."""
from __future__ import annotations

import hashlib
import json
from collections import Counter, defaultdict
from pathlib import Path
import statistics
import sys

import paired
from scripts.benchmark_suite.statistics import _median_ranks
from scripts.toolkit import linear_percentile

OUT = Path(__file__).resolve().parent
RUN = 45697865677
REF = "e15c751ab20bd1b5d1987fec774e8c08a171a5bb"
ORIGINAL = {"release":"7012b5b409553df04e29e6d7f9a11abf919cbf93","candidate":"e3104f444688ab3890c4b45f6098c28e052de7a8"}
OFFLINE="--offline" in sys.argv

def artifact(surface, run, artifacts):
    group=OUT/surface
    group.mkdir(exist_ok=True)
    product,=[a for a in artifacts if a["name"]==f"asof-residual-10m-{surface}-{RUN}-1"]
    root=paired.download(product,group)
    assert (root/"registration.txt").read_text().strip()==REF
    return root, product

def extract(surface,d):
    if surface=="rust":
        probe,=d.glob("obs-job-*")
        return [(r['side'],r['round']-1,r['pair']-1,r['result']['seconds']) for r in paired.records(probe/'observations.jsonl')]
    return [(k,rnd,idx,item['seconds']) for rnd,ev in enumerate(paired.read(d/'python/samples.json')['evidence']) for s,k in [('baseline','base'),('candidate','head')] for idx,item in enumerate(ev['samples'][s])]

def shifts(data):
    out={}
    for side in ("base","head"):
        control=[v*1000 for s,r,i,v in data["plain"] if s==side and i>=0]
        trace=[v*1000 for s,r,i,v in data["trace"] if s==side and i>=0]
        assert len(control)==len(trace)==20
        out[side]={"plain_mean_ms":statistics.mean(control),"trace_mean_ms":statistics.mean(trace),"p50_shift_percent":100*(statistics.median(trace)/statistics.median(control)-1)}
    return out

def deltas(samples):
    by_pair=defaultdict(dict)
    for arm,rnd,i,obs in samples:
        if i>=0:by_pair[rnd,i][arm]=obs
    result={}
    for key in sorted({k for arms in by_pair.values() for obs in arms.values() for k in obs['ns']}):
        selection=[]
        for rnd in range(2):
            changes=[(by_pair[rnd,i]['head']['ns'].get(key,0)-by_pair[rnd,i]['base']['ns'].get(key,0))/1e6 for i in range(10)]
            rank,coverage=_median_ranks(len(changes));sort=sorted(changes)
            selection.append(dict(median_ms=statistics.median(changes),low_ms=sort[rank-1],high_ms=sort[-rank],coverage=coverage))
        result[key]=selection
    return result

def inventories(samples):
    return {arm:{key:sorted(set(obs['inventory'].get(key,0) for side,_,i,obs in samples if side==arm and i>=0)) for key in sorted({k for side,_,i,obs in samples if side==arm and i>=0 for k in obs['inventory']})} for arm in ('base','head')}

def main():
    run=paired.read(OUT/"run.json") if OFFLINE else paired.api(f"/runs/{RUN}")
    assert run['head_sha']==REF and run['event']=='workflow_dispatch' and run['status']=='completed'
    artifacts=paired.read(OUT/"artifacts.json") if OFFLINE else paired.api(f"/runs/{RUN}/artifacts?per_page=100")['artifacts']
    (OUT/"run.json").write_text(json.dumps(run,indent=2)+"\n")
    (OUT/"artifacts.json").write_text(json.dumps(artifacts,indent=2)+"\n")
    result={}
    for surface in ('rust','python'):
        entries={}
        root,raw=artifact(surface,run,artifacts)
        state={"artifact":raw["id"],"digest":raw["digest"],"cohorts":{}}
        result[surface]=state
        topo={r["field"]:r["data"] for r in paired.read(root/"topology.json")["lscpu"]}
        state["cpu_model"]=topo["Model name:"]
        for mode in ("plain","trace"):
            d=root/mode
            if not (d/"bound.json").exists():
                state["cohorts"][mode]={"state":"not started"}
                continue
            for line in (d/'registered.sha256').read_text().splitlines():
                checksum,path=line.split(None,1)
                assert paired.rawhash(d/path)==checksum
            bound=paired.read(d/'bound.json')
            assert bound['mode']==mode and bound['products']==ORIGINAL
            if mode=='plain':assert bound['revisions']==ORIGINAL
            else:assert all(bound['revisions'][k]!=ORIGINAL[k] for k in ORIGINAL)
            paired.HEAD=bound['revisions']['candidate']
            try:
                result_mode=(paired.replay_rust if surface=='rust' else paired.replay_python)(d,bound['revisions']['release'])
            except (FileNotFoundError,ValueError) as error:
                # Preserve initialization failures separately from incomplete comparisons.
                if (d/'python/outcome.json').exists() or list(d.glob('obs-job-*/outcome.json')):raise
                result_mode={'state':'setup stopped','error':str(error)}
            state['cohorts'][mode]=result_mode
            if result_mode['state']!='complete':continue
            entries[mode]=extract(surface,d)
            if mode=='trace':
                sys.path.insert(0,str(d))
                import phase_replay
                original_means=paired.read(d/'phase-means-ms.json')
                original_samples=paired.read(d/'phase-observations.json')
                result_raw=phase_replay.report(d,surface)
                assert result_raw==original_means and paired.read(d/'phase-observations.json')==original_samples
                samples=paired.read(d/'phase-observations.json')
                state['inside_ms']=result_raw
                state['paired_differences_ms']=deltas(samples)
                state['inventory']=inventories(samples)
        if len(entries)==2:
            state['instrumentation']=shifts(entries)
    (OUT/'replay.json').write_text(json.dumps(result,indent=2,allow_nan=False)+'\n')
    for surface,data in result.items():
        print(surface,data['cpu_model'],{m:(r['state'],r.get('delta_percent')) for m,r in data['cohorts'].items()})
        print('instrumentation',data.get('instrumentation'))
        for name,x in data.get('inside_ms',{}).items():
            if name.startswith('admit_') or name in ('outer_ns','other_inside_window_ns','crossing_callback_ns') or name.startswith('python.') or name in ('watermark.matching_ns','watermark.arrow_output_ns','watermark.left_commit_ns','watermark.right_eviction_ns'):
                print(name,*(round(x[k],2) for k in ('base','head','delta_ms')))
if __name__=='__main__': main()
