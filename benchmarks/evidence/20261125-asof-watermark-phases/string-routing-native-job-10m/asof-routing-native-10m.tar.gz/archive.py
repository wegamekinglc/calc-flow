"""Seal the two registered comparisons and independently replay their verdicts."""
import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys
import tarfile

root = Path(__file__).resolve().parent
head = sys.argv[1]
py = sys.executable
rows = []
files = [root / f for f in (
    "protocol.md", "run-once.sh", "stage_job.rs", "project.json", "prepare.py", "build.py",
    "verify.py", "qualify.py", "measure.py", "archive.py", "build.log",
    f"{head[:10]}-build.jsonl", f"{head[:10]}-build.stderr", f"job-{head[:10]}.receipt.json",
)]
for label in ("release", "ordered"):
    group = root / label
    obs, = group.glob("obs-job-*")
    replay = subprocess.check_output([py, root / "verify.py", obs], cwd=root, text=True)
    (group / "replay.json").write_text(replay)
    files.extend(group / n for n in ("bound.sha256", "measured.log", "replay.json", "qualify.py", "protocol.md", "stage_job.rs", "project.json", "measure.py", "verify.py"))
    files.extend(group.glob("qual-*"))
    files.extend(group.glob("*.receipt.json"))
    files.extend(obs.iterdir())
    outcome = json.loads((obs / "outcome.json").read_text())
    identity = json.loads((obs / "identity.json").read_text())
    assert identity["head"] == head and obs.is_dir()
    receipt = json.loads((obs / "head.receipt.json").read_text())
    assert receipt["commit"] == head and receipt["harness_sha256"] == identity["adapter_sha256"]
    for c in [identity["base"], identity["head"]]:
        q = json.loads((group / f"qual-{c[:10]}.json").read_text())
        assert q["commit"] == c and q["result"]["validated_all_rows"] and q["result"]["closed"] and q["result"]["output_rows"] == 10_000_000
    rows += [f'## {label} {identity["base"][:10]} compared with {head[:10]}', '']
    if outcome["state"] == "complete":
        for key,title in (("base","Baseline"),("head","Candidate")):
            stats = outcome["pooled_ms"][key]
            rows.append(f'- {title} p50 {stats["p50"]:.3f} ms and p95 {stats["p95"]:.3f} ms.')
        rows += ["", f'Maintained verdict `{outcome["verdict"]}`. Both rounds and intervals are recorded below.', "", "```json", json.dumps(outcome["rounds"], indent=2), "```"]
    else:
        observations = json.loads(replay)[0]["observations"]
        rows.append(f"The resource or timing gate stopped acquisition after {observations} observations. The comparison has no paired verdict. The recorded reason was `{outcome['error']}`.")
    rows += ["", f'Formal acquisition took {outcome["wall_seconds"]:.2f} seconds. Both independent full-size qualifications passed.', ""]
def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()
manifest = root / "artifact-sha256.txt"
manifest.write_text("".join(f"{digest(p)}  {p.relative_to(root)}\n" for p in files))
out = root / "export"
out.mkdir(exist_ok=True)
archive = out / "asof-routing-native-10m.tar.gz"
with tarfile.open(archive, "w:gz") as t:
    for p in [*files, manifest]:
        t.add(p, arcname=str(p.relative_to(root)), recursive=False)
with tarfile.open(archive) as t:
    for p in [*files, manifest]:
        assert hashlib.sha256(t.extractfile(str(p.relative_to(root))).read()).hexdigest() == digest(p)
(out / "README.md").write_text("\n".join([
    "# ASOF string key routing in the public Rust streaming job",
    "",
    "Two separately paired comparisons use 10M UTF-8-keyed rows per input, ten 1M chunks and one pinned CPU. Each worker checks every output sequence and price, both inputs at EOF, matched and emitted counts, zero retained state and zero budget failures. The production clock runs from ready sources through Arrow output assembly. The separate installed Python job uses four workers.",
    "", *rows,
    f"[Sources, manifests, sealed build receipts, per-worker oracles and resource logs]({archive.name}) (SHA256 `{digest(archive)}`). Extract the archive into a fresh directory, set PYTHONPATH to the benchmark repository, and run `python verify.py release/obs-job-* ordered/obs-job-*`.",
    "",
]))
