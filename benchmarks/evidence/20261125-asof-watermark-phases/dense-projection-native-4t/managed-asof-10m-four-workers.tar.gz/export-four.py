"""Recompute and archive the registered 10M native four-worker ASOF comparison."""
import hashlib
import json
import tarfile
from pathlib import Path
from verify import verify

r=Path(__file__).resolve().parent
files=set()
for pat in ('*.py','*.sh','*.rs','*.md','*.json','*.sha256','*.exit','*.stderr','qual-*.json'):
    files.update(r.glob(pat))
cohorts=list(r.glob('obs-job-*'))
if cohorts:
    d,=cohorts
    proof=verify(d)
    out=json.loads((d/'outcome.json').read_text())
    files.update(d.glob('*.json*'))
else:
    assert (r/'resume.exit').read_text().strip()!='0'
    proof={'state':'stopped','observations':0,'error':(r/'measured.log').read_text()[-4000:]}
    out=proof
if (r/'measured.log').exists():files.add(r/'measured.log')
report=r/'four-replay.json'
report.write_text(json.dumps(dict(replay=proof,outcome=out),indent=2)+'\n')
files.add(report)
dest=r/'export';dest.mkdir(exist_ok=True)
archive=dest/'managed-asof-10m-four-workers.tar.gz'
digest=lambda f:hashlib.file_digest(f,'sha256').hexdigest()
manifest=r/'artifact-digests.txt'
manifest.write_text(''.join(digest(p.open('rb'))+'  '+str(p.relative_to(r))+'\n' for p in sorted(files)))
with tarfile.open(archive,'w:gz') as z:
    for p in sorted(files|{manifest}):z.add(p,arcname=str(p.relative_to(r)),recursive=False)
with tarfile.open(archive) as z:
    assert all(digest(z.extractfile(str(p.relative_to(r))))==digest(p.open('rb')) for p in files|{manifest})
lines=['# ASOF 的 Rust 四线程整作业对照','','11.14 发布版 `7012b5b4` 对照 #744 最终提交 `df01447e`。每侧 1,000 万行，分十批，有 64 个字符串键。两端使用四个 Tokio worker 和相同的四个物理核 2、4、16、20。原生 Rust 测量从投递首批已就绪数据前计至收齐输出并封装为 Batch。随后关闭源并验证作业终态。完整校验覆盖两侧接纳、输出各行与终态。','']
if out['state']=='complete':
    v=out['pooled_ms']
    lines+= [f"p50 为 {v['base']['p50']:.3f} → {v['head']['p50']:.3f} ms，p95 为 {v['base']['p95']:.3f} → {v['head']['p95']:.3f} ms。两轮配对判定为 `{out['verdict']}`。", '']
else:lines+=['本组停止，正式比较未完成。原因见原始结果。','']
lines+=['此前 Python 安装包对照基于计费重构前的 `ade0e864`。其发布版到候选的 10M p50 为 632.36 → 969.47 ms。两个入口独立报告。[安装包对照](https://github.com/wegamekinglc/calc-flow/tree/f7915aee6d159f8a9f0d122a14a4fb757ca670d4/benchmarks/join-asof/20261125-asof-dense-charge-public-10m)','',f'[复算记录](four-replay.json) · [原始数据与校验]({archive.name})，SHA-256 `{digest(archive.open("rb"))}`。','']
(dest/'README.md').write_text('\n'.join(lines));(dest/report.name).write_bytes(report.read_bytes())
