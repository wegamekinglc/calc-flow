set -eu
out=$1
export PYTHONPATH=$2
py=$3
base=$4
candidate=$5
cd "$out"
test ! -d "obs-job-${base:0:10}-${candidate:0:10}"
export TMPDIR="$PWD/managed-tmp"
sha256sum -c bound.sha256
timeout 15 "$py" qualify.py "$base" "$candidate"
"$py" measure.py job "$candidate" "$base"
