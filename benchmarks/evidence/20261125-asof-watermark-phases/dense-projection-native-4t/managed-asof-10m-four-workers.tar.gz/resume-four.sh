set -eu
while test ! -f "../asof-arrow-output-followup-nov25/study-driver.exit"; do sleep 3; done
bash build-both.sh "$2" df01447e06f8dce7c56a4f807dcf7802d52360b4 7012b5b409553df04e29e6d7f9a11abf919cbf93 >build.log 2>&1
date -u >completed-build.txt
while test ! -f "$1/product-driver.exit"; do sleep 5; done
test "$(cat "$1/product-driver.exit")" = 0
export PYTHONPATH=$3
bash run-four.sh "$4" 7012b5b409553df04e29e6d7f9a11abf919cbf93 df01447e06f8dce7c56a4f807dcf7802d52360b4 >measured.log 2>&1
"$4" verify.py obs-job-* >replay.json
