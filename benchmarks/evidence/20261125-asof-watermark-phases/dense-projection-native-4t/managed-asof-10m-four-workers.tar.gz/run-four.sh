set -eu
py=$1
base=$2
head=$3
test ! -d "obs-job-${base:0:10}-${head:0:10}"
sha256sum -c frozen.sha256
sha256sum -c bound-cpus.sha256
export TMPDIR="$PWD/managed-tmp"
timeout 15 "$py" qualify.py "$base" "$head"
"$py" measure.py job "$head" "$base"
