set -eu
checkout=$1
candidate=$2
release=$3
for commit in "$candidate" "$release"; do
    git -C "$checkout" diff --exit-code HEAD --
    git -C "$checkout" switch --detach "$commit"
    test "$(git -C "$checkout" rev-parse HEAD)" = "$commit"
    python3 build.py "$checkout" "$commit" job
done
