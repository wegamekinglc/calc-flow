"""Run one untimed full-result qualification per sealed executable within 15 seconds."""

import json
import os
import subprocess
import sys
import time
from pathlib import Path

from scripts.benchmark_suite.process import child_environment

root = Path(__file__).resolve().parent
started = time.monotonic()
cpus = json.loads((root / "cpus.json").read_text())
os.sched_setaffinity(0, set(cpus))
for commit in sys.argv[1:]:
    result = subprocess.run(
        [root / f"job-{commit[:10]}"],
        capture_output=True,
        env=child_environment(tokio_threads=4, polars_threads=4),
        timeout=max(0.0, 15 - (time.monotonic() - started)),
    )
    (root / f"qual-{commit[:10]}.stderr").write_bytes(result.stderr)
    result.check_returncode()
    payload = json.loads(result.stdout)
    assert payload["validated_all_rows"] and payload["closed"]
    assert payload["output_rows"] == 10_000_000
    (root / f"qual-{commit[:10]}.json").write_text(json.dumps({
        "commit": commit, "cpus": cpus, "elapsed_group_seconds": time.monotonic() - started,
        "result": payload,
    }, indent=2) + "\n")
