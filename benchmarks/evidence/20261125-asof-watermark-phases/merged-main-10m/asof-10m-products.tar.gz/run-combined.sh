set -eu
while test ! -e bound.json; do sleep 3; done
sha256sum -c registered.sha256
sha256sum -c bound-cpus.sha256
head=$(python3 -c 'import json;print(json.load(open("bound.json"))["candidate"])')
release=7012b5b409553df04e29e6d7f9a11abf919cbf93
test "$(git -C source rev-parse HEAD)" = "$head"
# Duration has its own products and formal clock. Keep the two bands exclusive.
while test ! -e ../rolling-duration20-native-nov25/resume.exit; do sleep 3; done
s=$1
py=$2
ordinary=$3
harness=$4
native_scripts=$5
nc=$6
wc=$7
git -C "$s" diff --quiet
git -C "$s" switch --detach "$head"
mkdir -p wheel
ln -s "$wc" wheel/cargo
touch source/crates/calc-flow/src/lib.rs source/crates/calc-flow-python/src/lib.rs
( PYTHONPATH="$PWD/source" "$py" -m scripts.benchmark_suite build --source "$PWD/source" --output "$PWD/wheel" ) >wheel/build-driver.log 2>&1 & wheel_pid=$!
r=0
CARGO_TARGET_DIR="$nc" CARGO_BUILD_JOBS=2 python3 build.py "$s" "$head" job >native-build.log 2>&1 || r=$?
wait "$wheel_pid" || r=$?
test "$r" = 0
while ps -e -o stat=,comm= | awk '$2 ~ /^(rustc|rust-lld|cargo-clippy|clippy-driver)$/ && $1 !~ /^[TZ]/ {found=1} END {exit !found}'; do sleep 2; done
export TMPDIR="$PWD/managed-tmp"
export PYTHONPATH="$native_scripts"
r=0
timeout 15 "$ordinary" qualify.py "$release" "$head" >qualification.log 2>&1 || r=$?
if test "$r" = 0; then "$ordinary" measure.py job "$head" "$release" >native.log 2>&1 || r=$?; fi
echo "$r" >native.exit
export PYTHONPATH="$harness"
r=0
/usr/bin/time -f %e -o public-elapsed.txt taskset -c 2,4,16,20 "$py" public_compare.py asof_join --baseline "$harness/../main-src/target/products/release-1114/release.json" --candidate "$PWD/wheel/release.json" --candidate-source "$PWD/source" --output "$PWD/python-10m" --sha "$head" >public.log 2>&1 || r=$?
echo "$r" >public.exit
