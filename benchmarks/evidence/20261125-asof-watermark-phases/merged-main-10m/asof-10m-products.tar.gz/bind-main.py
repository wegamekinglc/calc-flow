"""Bind a fetched main only after all four reviewed product heads are ancestors."""
from pathlib import Path
import subprocess,json,datetime,os
d=Path(__file__).resolve().parent
def git(*args):return subprocess.check_output(['git',*args],text=True).strip()
subprocess.run(['git','fetch','-q','origin','main'],check=True)
candidate=git('rev-parse','origin/main')
proof={}
for n,want in [(744,'df01447e06f8dce7c56a4f807dcf7802d52360b4'),(745,'f09846cc65d25fbaa36f1702749cc15d43ccb1e5'),(746,'6a34d3040af6f4f5beff9939302fa40ad2f7968c'),(747,'b5201971b337ce6387f7e8febf1ae28dfb4798d8')]:
    rec=json.loads(subprocess.check_output(['gh','pr','view',str(n),'--json','state,headRefOid,mergeCommit,mergedAt,baseRefName'],text=True))
    assert rec['state']=='MERGED' and rec['headRefOid']==want and rec['baseRefName']=='main'
    for sha in [want,rec['mergeCommit']['oid']]:subprocess.run(['git','merge-base','--is-ancestor',sha,candidate],check=True)
    proof[n]=rec
assert not (d/'bound.json').exists()
subprocess.run(['git','worktree','add','--quiet','--detach',str(d/'source'),candidate],check=True)
assert not git('-C',str(d/'source'),'status','--porcelain')
rec=dict(candidate=candidate,tree=git('rev-parse',candidate+'^{tree}'),parents=git('show','-s','--format=%P',candidate).split(),release='7012b5b409553df04e29e6d7f9a11abf919cbf93',ancestor_checks=proof,bound_at=datetime.datetime.now(datetime.UTC).isoformat())
tmp=d/'pending-binding.json';tmp.write_text(json.dumps(rec,indent=2)+'\n');os.replace(tmp,d/'bound.json')
print(candidate)
