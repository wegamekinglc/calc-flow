set -eu
while test ! -f run.exit; do sleep 4; done
test -e native.exit
test -e public.exit
export PYTHONPATH=$2
"$1" report-product.py
tmp=$(mktemp -d -p .)
tar -xzf product-export/asof-10m-products.tar.gz -C "$tmp"
(cd "$tmp" && sha256sum --quiet -c registered.sha256 && sha256sum --quiet -c product-sha256.txt)
