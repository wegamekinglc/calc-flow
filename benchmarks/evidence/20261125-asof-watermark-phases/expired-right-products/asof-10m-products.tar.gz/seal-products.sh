set -eu
test -e resume-right.exit
test -e previous/measured.exit
test -e release/measured.exit
python_bin=$1
export PYTHONPATH=$2
"$python_bin" report-product.py
tmp=$(mktemp -d -p .)
tar -xzf product-export/asof-10m-products.tar.gz -C "$tmp"
(cd "$tmp" && sha256sum --quiet -c product-sha256.txt && (cd previous && sha256sum --quiet -c bound.sha256) && (cd release && sha256sum --quiet -c bound.sha256))
