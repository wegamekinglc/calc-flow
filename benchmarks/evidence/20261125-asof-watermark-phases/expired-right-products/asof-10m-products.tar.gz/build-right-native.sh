set -eu
s=$1
head=$2
release=$3
parent=$4
 git -C "$s" diff --quiet
 git -C "$s" switch --detach "$head"
 python3 build.py "$s" "$head" job
 for g in release previous; do
   if test "$g" = release; then b=$release; else b=$parent; fi
   for suffix in "" ".receipt.json"; do
     ln "../asof-4t-native-job-release-nov25/job-${b:0:10}$suffix" "$g/job-${b:0:10}$suffix"
     ln "job-${head:0:10}$suffix" "$g/job-${head:0:10}$suffix"
   done
 done
