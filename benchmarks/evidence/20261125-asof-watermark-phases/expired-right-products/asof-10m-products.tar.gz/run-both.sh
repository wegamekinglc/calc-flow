set -eu
exec 9>native-sequential.lock
flock -n 9
harness=$1
python=$2
candidate=$3
for group in release previous; do
    case $group in
        release) base=7012b5b409553df04e29e6d7f9a11abf919cbf93 ;;
        previous) base=df01447e06f8dce7c56a4f807dcf7802d52360b4 ;;
    esac
    status=0
    bash run-once.sh "$group" "$harness" "$python" "$base" "$candidate" >"$group/measured.log" 2>&1 || status=$?
    echo "$status" >"$group/measured.exit"
done
