set -eu
# The earlier SMA20 and ASOF formal clocks must complete first.
while test ! -f ../asof-probe-boundaries-products-nov25/product.exit; do sleep 5; done
s=$1
py=$2
bench=$3
harness=$4
native_scripts=$5
cache_dir=$6
export CARGO_TARGET_DIR=$7
export CARGO_BUILD_JOBS=2
parent=df01447e06f8dce7c56a4f807dcf7802d52360b4
head=b5201971b337ce6387f7e8febf1ae28dfb4798d8
release=7012b5b409553df04e29e6d7f9a11abf919cbf93
# Independent native and installed products reuse their own compatible build cache.
build_wheels() {
 for side in parent candidate; do
   out="$PWD/$side-wheel"
   mkdir -p "$out"
   ln -s "$cache_dir" "$out/cargo"
   touch "$side-source/crates/calc-flow/src/lib.rs" "$side-source/crates/calc-flow-python/src/lib.rs"
   PYTHONPATH="$PWD/$side-source" "$bench" -m scripts.benchmark_suite build --source "$PWD/$side-source" --output "$out" >"$out/build-driver.log" 2>&1
 done
}
build_wheels & wheel_pid=$!
rc=0
bash build-right-native.sh "$s" "$head" "$release" "$parent" >native-build.log 2>&1 || rc=$?
wait "$wheel_pid" || rc=$?
test "$rc" = 0
while ps -e -o stat=,comm= | awk '$2 ~ /^(rustc|rust-lld|cargo-clippy|clippy-driver)$/ && $1 !~ /^[TZ]/ {found=1} END {exit !found}'; do sleep 2; done
bash run-both.sh "$native_scripts" "$py" "$head"
scope="$harness/target/asof-expired-right-next"
export PYTHONPATH="$harness"
for group in preceding release; do
 baseline="$PWD/parent-wheel/release.json"
 if test "$group" = release; then baseline="$harness/../main-src/target/products/release-1114/release.json"; fi
 r=0
 "$bench" "$scope/${group}_compare.py" asof_join --baseline "$baseline" --candidate "$PWD/candidate-wheel/release.json" --candidate-source "$PWD/candidate-source" --output "$scope/observed-asof-$group" --sha "$head" >"$scope/log-asof-$group.txt" 2>&1 || r=$?
 echo "$r" >"$scope/$group.exit"
done
