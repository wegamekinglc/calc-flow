"""Run only the registered native watermark fixture; persist paired and per-progress evidence."""
from __future__ import annotations
import asyncio, hashlib, json, math, os, shutil, statistics, sys, time
from pathlib import Path

ROOT = Path(__file__).resolve().parent
sys.path.insert(0, str(ROOT/'source-main'))
from scripts.sparse_changelog_ci import _resource
from scripts.benchmark_suite.process import child_environment
from scripts.benchmark_suite.report import _paired_verdict
from scripts.benchmark_suite.statistics import paired_round
from scripts.toolkit import linear_percentile

FIELDS = ['matching_ns','arrow_output_ns','left_commit_ns','right_eviction_ns','emit_ns','residual_ns']
PRODUCT = {'release': '7012b5b409553df04e29e6d7f9a11abf919cbf93', 'main': 'ea7a21cead99c424c1d4a6ce5dcf46abfc449aab'}
CALIBRATION = PRODUCT
TRACED = {'release': '3b4220eea5dec91f3eae43d36b1f59535da42d40', 'main': 'c00091113afc7ec31eeb38444e607bca399e8d7e'}
LOCKS = {'release':'source-release','main':'source-main'}
N = 100_000

def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

def write(path, data):
    path.write_text(json.dumps(data, indent=2, allow_nan=False)+'\n')

def append(path, item):
    with path.open('a') as f: f.write(json.dumps(item,allow_nan=False)+'\n')

def require(condition, reason):
    if not condition: raise ValueError(reason)

def checked(data, callbacks, pid):
    require(data.get('validated_all_rows') is True and data['output_rows']==N,'full output oracle')
    require(data['pending_before_watermark']==N==data['retained_before_watermark'], 'admission state')
    require(data['evicted_right_rows']==N and data['retained_right_rows']==0, 'settled right state')
    for k in ['seconds','watermark_seconds']: require(math.isfinite(data[k]) and data[k]>0, k)
    values={'watermark_ns':round(data['watermark_seconds']*1e9),'admission_ns':round(data['seconds']*1e9)}
    if callbacks is None: return values
    require(len(callbacks)==1,'expected just one direct on_watermark callback')
    row=callbacks[0]
    require(row['schema']=='calc-flow.asof-watermark-exclusive.v1' and row['success'] is True and row['pid']==pid and not row['ended'],'callback provenance')
    for k in ['emitted_delta','matched_delta','evicted_delta']: require(row[k]==N,k)
    require(row['frontier']==(N-1)//64+1 and row['operator']=='asof','native watermark and operator')
    before, after=row['before'],row['after']
    require(before['pending_left_rows']==N==before['retained_right_rows'] and before['state_rows']==2*N,'pre-watermark census')
    for k in ['pending_left_rows','retained_right_rows','state_rows','identity_only_rows']: require(after[k]==0,k)
    for k in ['emitted_left_rows','matched_rows','evicted_right_rows']: require(after[k]==N==after[k]-before[k],k)
    require(all(type(row[k]) is int and row[k]>=0 for k in [*FIELDS,'wall_ns']),'phase nanoseconds')
    require(sum(row[k] for k in FIELDS)==row['wall_ns']<=values['watermark_ns'],'nonoverlap and outer bound')
    parts=['arrow_bookkeeping_ns','arrow_charge_ns','arrow_columns_ns','arrow_assembly_ns']
    require(all(type(row[k]) is int and row[k]>=0 for k in parts) and sum(row[k] for k in parts)==row['arrow_output_ns'],'Arrow subphases close')
    tickets=row['admitted_gather_tickets_match_arrow_left_right_emit_residual']
    require(len(tickets)==6 and all(type(x) is int and x>=0 for x in tickets),'offload tickets')
    return {**values, **{k:row[k] for k in [*FIELDS,*parts,'wall_ns']},
        'state_removal_ns':row['left_commit_ns']+row['right_eviction_ns'],
        'outside_finalize_ns':values['watermark_ns']-row['wall_ns']}

async def sample(path, cpu, exe, mode, rnd, i, side):
    require(os.sched_getaffinity(0)=={cpu},'changed affinity')
    trace=path/f'trace-{rnd}-{i:02}-{side}.jsonl'
    env=child_environment(tokio_threads=1,polars_threads=1)
    env.pop('CALC_FLOW_ASOF_WATERMARK_TRACE',None)
    if mode=='diagnostic': env['CALC_FLOW_ASOF_WATERMARK_TRACE']=str(trace)
    proc=await asyncio.create_subprocess_exec(str(exe), stdout=asyncio.subprocess.PIPE,stderr=asyncio.subprocess.PIPE,env=env)
    try: stdout,stderr=await proc.communicate()
    finally:
        if proc.returncode is None: proc.kill(); await proc.wait()
    require(proc.returncode==0,stderr.decode()[-1000:])
    result=json.loads(stdout)
    callbacks=[json.loads(line) for line in trace.read_text().splitlines()] if mode=='diagnostic' else None
    stats=checked(result,callbacks,proc.pid)
    item=dict(round=rnd,pair=i,side=side,pid=proc.pid,result=result,ns=stats)
    if callbacks is not None: item['trace']=trace.name
    append(path/'observations.jsonl',item)

def summarize(path):
    obs=[json.loads(line) for line in (path/'observations.jsonl').read_text().splitlines()]
    require(len(obs)==44,'44 observations')
    for index,row in enumerate(obs):
        rnd,pos=divmod(index,22); i,arm=divmod(pos,2)
        order=['release','main'] if i==0 or i%2 else ['main','release']
        require((row['round'],row['pair'],row['side'])==(rnd+1,i,order[arm]),'pair order')
        tr=[json.loads(line) for line in (path/row['trace']).read_text().splitlines()] if 'trace' in row else None
        require(checked(row['result'],tr,row['pid'])==row['ns'],'replay equality')
    fields=obs[0]['ns'].keys()
    def values(k, s, rnd=None):
        return [r['ns'][k]/1e6 for r in obs if r['pair'] and r['side']==s and (rnd is None or r['round']==rnd)]
    out={}
    for k in fields:
        rounds=[]
        absolutes=[]
        for rnd in [1,2]:
            a,b=values(k,'release',rnd),values(k,'main',rnd)
            require(len(a)==len(b)==10,'formal pair count')
            absolutes.append(statistics.median([y-x for x,y in zip(a,b)]))
            if min(a)>0: rounds.append(paired_round(a,b))
        out[k]={'p50_ms':{s:statistics.median(values(k,s)) for s in PRODUCT},
                'p95_ms':{s:linear_percentile(values(k,s),.95) for s in PRODUCT},
                'paired_median_difference_ms_by_round':absolutes,
                'paired_median_difference_ms':statistics.median([y-x for x,y in zip(values(k,'release'),values(k,'main'))]),
                'rounds':rounds,'verdict':_paired_verdict(rounds) if len(rounds)==2 else None}
    return out

async def run(mode,path):
    ref=ROOT if mode=='diagnostic' else ROOT/'plain'
    shas=TRACED if mode=='diagnostic' else CALIBRATION
    builds={}
    receipts={}
    for side,sha in shas.items():
        exe=ref/f'admit-{sha[:10]}'; receipt=exe.with_suffix('.receipt.json')
        meta=json.loads(receipt.read_text()); shutil.copyfile(receipt,path/f'{side}.receipt.json')
        require(meta['commit']==sha and digest(exe)==meta['binary_sha256'],'executable identity')
        require(meta['harness_sha256']==digest(ROOT/'stage_admit.rs') and meta['lock_sha256']==digest(ROOT/LOCKS[side]/'Cargo.lock'),'adapter/lock identity')
        if mode=='calibration' and side=='main': require(meta['tree']=='16fab4f6f4b2fab79b4ddedffc04145315f709f7','main tree')
        receipts[side]=meta
        control=json.loads((ROOT/'plain'/f'admit-{CALIBRATION[side][:10]}.receipt.json').read_text())
        for field in ['harness_sha256','rustc','cargo','settings','lock_sha256']:
            require(control[field]==meta[field],f'anchor {side} {field}')
        builds[side]=exe
    for field in ['harness_sha256','rustc','cargo','settings']:
        require(receipts['release'][field]==receipts['main'][field],f'pair {field}')
    write(path/'identity.json',dict(mode=mode,product=PRODUCT,executables=shas,adapter_sha256=digest(ROOT/'stage_admit.rs'),
        protocol_sha256=digest(ROOT/'protocol.md'),run_sha256=digest(Path(__file__)),
        patches={s:digest(ROOT/f'{s}.patch') for s in PRODUCT},machine=list(os.uname())))
    if mode=='diagnostic':
        calibration=json.loads((ROOT/'obs-calibration/outcome.json').read_text())
        require(calibration['state']=='complete' and calibration['cpu'] in os.sched_getaffinity(0),'calibration CPU')
        os.sched_setaffinity(0,{calibration['cpu']})
    cpu=await _resource(path/'resources.jsonl',None)
    os.sched_setaffinity(0,{cpu})
    async def collect():
        for rnd in [1,2]:
            for i in range(11):
                for side in (['release','main'] if i==0 or i%2 else ['main','release']):
                    await sample(path,cpu,builds[side],mode,rnd,i,side)
    async with asyncio.TaskGroup() as tg:
        task=tg.create_task(collect())
        while not task.done(): await _resource(path/'resources.jsonl',cpu)
    return dict(cpu=cpu,metrics=summarize(path))

if __name__=='__main__':
    mode=sys.argv[1]
    if mode=='replay':
        path=Path(sys.argv[2]); print(json.dumps(summarize(path),indent=2)); sys.exit()
    require(mode in ['calibration','diagnostic'] and __debug__,'mode')
    start=time.monotonic(); path=ROOT/('obs-'+mode); path.mkdir(exist_ok=False)
    try:
        outcome=asyncio.run(asyncio.wait_for(run(mode,path),40))
        require(time.monotonic()-start<40,'group including synchronous work exceeded 40 s')
        outcome['state']='complete'
    except BaseException as e:
        outcome={'state':'stopped','exception':repr(e)}
        raise
    finally:
        outcome['wall_seconds']=time.monotonic()-start; write(path/'outcome.json',outcome)
