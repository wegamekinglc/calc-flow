use super::StreamAsofJoinStatus;
use std::{cell::RefCell, future::Future, io::Write, path::Path, time::Instant};
use serde_json::json;

#[derive(Clone, Copy)]
pub(super) enum Stage { Match, Arrow, Left, Right, Emit, Residual }
struct Clock {
    active: Stage, start: Instant, last: Instant, ns: [u64; 6], tickets: [u64; 6],
}
impl Clock {
    fn switch(&mut self, next: Stage) -> Stage {
        let now = Instant::now();
        self.ns[self.active as usize] += u64::try_from((now - self.last).as_nanos()).unwrap();
        self.last = now;
        std::mem::replace(&mut self.active, next)
    }
}
tokio::task_local! { static CLOCK: RefCell<Clock>; }
pub(super) struct Guard(Option<Stage>);
impl Drop for Guard {
    fn drop(&mut self) {
        if let Some(previous) = self.0 {
            let _ = CLOCK.try_with(|c| c.borrow_mut().switch(previous));
        }
    }
}
pub(super) fn enter(stage: Stage) -> Guard {
    Guard(CLOCK.try_with(|c| c.borrow_mut().switch(stage)).ok())
}
// Count a successfully admitted gather-service ticket, outside the worker.
#[allow(dead_code)]
pub(super) fn ticket() {
    let _ = CLOCK.try_with(|c| {
        let mut c = c.borrow_mut();
        let stage = c.active as usize;
        c.tickets[stage] += 1;
    });
}
pub(super) struct Counters { wall: u64, ns: [u64;6], tickets: [u64;6] }
pub(super) async fn measure<F: Future>(future: F) -> (F::Output, Counters) {
    let start = Instant::now();
    let clock = Clock { active: Stage::Residual, start, last: start, ns: [0;6], tickets: [0;6] };
    CLOCK.scope(RefCell::new(clock), async {
        let result = future.await;
        let counts = CLOCK.with(|c| {
            let mut c = c.borrow_mut();
            c.switch(Stage::Residual);
            Counters { wall: u64::try_from((c.last-c.start).as_nanos()).unwrap(), ns:c.ns, tickets:c.tickets }
        });
        (result, counts)
    }).await
}
impl Counters {
    pub(super) fn record(&self, path: &Path, name: &str, frontier: Option<i64>, ended: bool,
           before: &StreamAsofJoinStatus, after: &StreamAsofJoinStatus, success: bool) {
        assert_eq!(self.wall,self.ns.iter().sum::<u64>());
        let state = |s: &StreamAsofJoinStatus| json!({
            "pending_left_rows":s.pending_left_rows, "retained_right_rows":s.retained_right_rows,
            "identity_only_rows":s.identity_only_rows,"state_rows":s.state_rows, "state_bytes":s.state_bytes,
            "emitted_left_rows":s.emitted_left_rows,"evicted_right_rows":s.evicted_right_rows,"matched_rows":s.matched_rows
        });
        let mut line = serde_json::to_vec(&json!({
            "schema":"calc-flow.asof-watermark-exclusive.v1","pid":std::process::id(),
            "operator":name,"frontier":frontier,"ended":ended,"success":success,"before":state(before),"after":state(after),
            "emitted_delta":after.emitted_left_rows-before.emitted_left_rows,
            "matched_delta":after.matched_rows-before.matched_rows,"evicted_delta":after.evicted_right_rows-before.evicted_right_rows,
            "wall_ns": self.wall,
            "matching_ns":self.ns[0],"arrow_output_ns":self.ns[1],"left_commit_ns":self.ns[2],
            "right_eviction_ns":self.ns[3],"emit_ns":self.ns[4],"residual_ns":self.ns[5],
            "admitted_gather_tickets_match_arrow_left_right_emit_residual": self.tickets
        })).unwrap();
        line.push(b'\n');
        std::fs::OpenOptions::new().create(true).append(true).open(path).unwrap().write_all(&line).unwrap();
    }
}
