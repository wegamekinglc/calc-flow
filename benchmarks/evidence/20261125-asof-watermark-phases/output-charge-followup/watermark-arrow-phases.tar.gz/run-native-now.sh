set -eu
sha256sum -c preregistered.sha256
for f in build-plain.exit diagnostic-build.exit; do test "$(cat "$f")" = 0; done
groups=(7873 9818 11128 12199)
for id in "${groups[@]}"; do if kill -0 -- "-$id" 2>/dev/null; then kill -STOP -- "-$id"; fi; done
resume() { for id in "${groups[@]}"; do kill -CONT -- "-$id" 2>/dev/null || true; done; }
trap resume EXIT
sleep 1
if ps -e -o stat=,comm= | awk '$2 ~ /^(rustc|rust-lld|cargo-clippy|clippy-driver)$/ && $1 !~ /^[TZ]/ {found=1} END {exit !found}'; then exit 1; fi
for mode in calibration diagnostic; do
    status=0
    "$1" observe.py "$mode" >"native-$mode.log" 2>&1 || status=$?
    echo "$status" >"native-$mode.exit"
done
