"""Archive the registered run and generate its Chinese reader-facing tables."""
import gzip
import hashlib
import json
import shutil
import tarfile
from pathlib import Path
root=Path(__file__).resolve().parent
dest=root/'export'
dest.mkdir(exist_ok=True)
src=json.loads((root/'paired-phases.json').read_text())
files=set()
for f in ['protocol.md','preregistered.sha256','stage_admit.rs','prepare.py','build.py','instrument.py','detail.py','observe.py','diagnostic_compare.py','public_release_compare.py','diagnostic_validate.py','setup_sites.py','attach_asof_trace.py','run-study.sh','run-native-now.sh','wm_phase.rs','analyze-study.py','export-study.py','main.patch','release.patch','paired-phases.json','build-wheels.sh','build-diagnostics.sh']:
    files.add(root/f)
for g in ('py-control','py-trace','obs-calibration','obs-diagnostic'):
    for f in (root/g).rglob('*'):
        if f.is_file() and not f.is_symlink() and f.suffix in ('.json','.jsonl','.log') and not any(p in {'site','site-packages','dist-info','__pycache__'} or p.endswith('.dist-info') for p in f.relative_to(root/g).parts):
            files.add(f)
for d in (root/'wheels').iterdir():
    files.update(d/f for f in ['release.json','build.json'])
files.update(root.glob('*.receipt.json'))
files.update(root.glob('*-build.stderr'))
def digest(p):
    with p.open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()
files=sorted(files)
manifest=root/'artifact-sha256.txt'
manifest.write_text(''.join(digest(p)+'  '+str(p.relative_to(root))+'\n' for p in files))
archive=dest/'watermark-arrow-phases.tar.gz'
with tarfile.open(archive,'w:gz') as t:
    for p in [manifest,*files]: t.add(p,arcname=str(p.relative_to(root)),recursive=False)
with tarfile.open(archive) as t:
    for p in [manifest,*files]:
        assert hashlib.file_digest(t.extractfile(str(p.relative_to(root))),'sha256').hexdigest()==digest(p)
shutil.copy2(root/'paired-phases.json',dest/'paired-phases.json')
labels={'wall_ns':'回调总计','matching_ns':'匹配和就绪判断','arrow_output_ns':'Arrow 合计','arrow_charge_ns':'输出预算','arrow_columns_ns':'定位与取列，含 worker 等待','arrow_assembly_ns':'组装及边预算检查','arrow_bookkeeping_ns':'其余 Arrow 工作','left_commit_ns':'左侧提交','right_eviction_ns':'右侧淘汰','emit_ns':'发送及等待','residual_ns':'其他回调工作'}
def table(vals):
    table=[['阶段','11.14 p50','main p50','11.14 p95','main p95','平均差值','第一轮配对差','第二轮配对差']]
    for k,v in vals.items():
        table.append([labels[k],*[f"{v[x]:.3f}" for x in ('release_p50','main_p50','release_p95','main_p95')],f"{v['mean_delta_ms']:+.3f}",*[f'{t:+.3f}' for t in v['round_delta_ms']]])
    widths=[max(map(len,c)) for c in zip(*table)];line=lambda r:'| '+' | '.join(x.ljust(n) for x,n in zip(r,widths))+' |'
    return [line(table[0]),'|'+'|'.join('-'*(n+2) for n in widths)+'|',*[line(row) for row in table[1:]]]
lines=['# ASOF 水位处理与 Arrow 输出分段复测','','比较 11 月 14 日发布提交 `7012b5b4` 和合入 #741 的 `main` 提交 `ea7a21ce`。每组两轮，每轮十对正式样本，另有四次预热。单位为毫秒，各行独立取 p50、p95。平均差值来自同对样本，正数表示 main 用时增加。','','原生 Rust 每侧 10 万行、64 键、两批固定宽度数据，计量一次水位回调。公开 Python 安装包每侧 100 万行、64 个字符串键、四线程。Python 分段是同一作业中 Rust 回调的总和，含预水位及 EOF 回调，公开总时钟从输入就绪到最终 Arrow 表交付。两个入口各自对照发布版。']
lines+=['','最初对照的 main 为 `72072c1d`。在每侧十万行的 Rust 单次水位中，Arrow 平均多用 4.772 ms，约占总差距 5.343 ms 的 89.3%。在每侧一百万行的独立安装包中，二十对样本的作业内累计回调平均多用 48.601 ms，其中 Arrow 多用 29.376 ms（60.4%）、匹配多用 10.284 ms、左侧提交多用 8.684 ms、右侧淘汰多用 0.234 ms。每个环境分别以其发布版为基线。下文复测包含后续完整列共享、整段左侧提交和输入处理修复。']
for surface,plain,diag,m in [('Rust 原生','native-calibration','native-diagnostic','phases'),('Python 安装包','python-control','python-trace','all')]:
    c,d=src[plain],src[diag];lines+=['','## '+surface,'']
    for name,g in [('无插桩',c),('插桩',d)]:
        if 'outer' in g:
            v=g['outer'];lines+=['- '+name+f"时钟的 p50 为 {v['release_p50']:.3f} → {v['main_p50']:.3f}，p95 为 {v['release_p95']:.3f} → {v['main_p95']:.3f}。配对判定为 `{v['verdict']}`。"]
        else:
            reason = ('主机在采样前换出 33,085 页，资源检查未通过，正式样本为零。'
                      if (surface == 'Rust 原生' and name == '插桩' and '33085' in str(g.get('error')))
                      else str(g.get('error')))
            lines+=['- '+name+'组已停止。'+reason]
    key=('native' if plain.startswith('native') else 'python')+'-calibration-change-percent'
    if key in src:lines+=['',f"插桩相对于无插桩的 p50 变化为发布版 {src[key]['release']:+.2f}%、main {src[key]['main']:+.2f}%。"]
    if m in d:lines+=['',*table(d[m])]
    if 'emitting' in d:lines+=['','### 仅有输出的回调','',*table(d['emitting'])]
if 'all' in src['python-trace']:
    trace=src['python-trace']['all']
    arrow=['arrow_charge_ns','arrow_columns_ns','arrow_assembly_ns','arrow_bookkeeping_ns']
    total=trace['arrow_output_ns']['mean_delta_ms']
    top=max(arrow,key=lambda k:trace[k]['mean_delta_ms'])
    assert abs(total-sum(trace[k]['mean_delta_ms'] for k in arrow))<1e-5
    lines+=['','## 本轮定位','','按已安装 Python 作业中所有水位回调的配对均值，Arrow 总差值为 '+f"{total:+.3f} ms"+'。其中差值最大的子段为'+labels[top]+f"（{trace[top]['mean_delta_ms']:+.3f} ms）。"]
    if 'outer' in src['python-control']:
        outer=src['python-control']['outer']
        lines+=['',f"相同夹具的无插桩整作业平均差为 {outer['mean_delta_ms']:+.3f} ms。回调分段来自另一组独立配对采样；整作业还包含接纳、调度与最终表交付。"]
if 'all' in src['python-trace']:
    phases=src['python-trace']['all'];match=phases['matching_ns']['mean_delta_ms'];budget=phases['arrow_charge_ns']['mean_delta_ms'];arrow=phases['arrow_output_ns']['mean_delta_ms']
    lines+=['',f"在这个负载上，匹配和就绪判断平均多用 {match:.3f} ms。输出预算占 Arrow 差距的 {100*budget/arrow:.1f}%。右侧淘汰的全作业累计差仅 {phases['right_eviction_ns']['mean_delta_ms']:+.3f} ms；仅统计发出结果的回调会漏掉其他水位和 EOF 处的淘汰。",'','下一小步检查有序探测对同一键的前驱和下一条右记录时间的重复读取。Polars 的 backward 状态跨探测保留已命中位置和扫描位置。calc-flow 还需验证同时间的最大序列、容差边界和间隔很大的时间跳跃。[Polars 源码](https://github.com/pola-rs/polars/blob/22a147de3d2bb2e44b97338a2510816c7105c9f2/crates/polars-ops/src/frame/join/asof/mod.rs#L71)']
lines+=['','Python 对照按序列核对全部行和值，并验证最终状态。这里的数值不能用来推断交付的物理顺序或 Python 绑定自身的开销。']
lines+=['','输出预算代码在计算保留字节数时曾按 run 建立逐行索引，再根据索引计算投影列大小。#745 对确实完整覆盖的有序新 run 复用列长度与有效位图计费，消除了这个索引向量。多 run、空值、重复投影的独立分配测试中，两个预算计算在父提交分配 263,360 字节，候选达到 2,048 字节以内的上限。普通 Rust 和安装包的效果另有产品对照。[实现与测试](https://github.com/wegamekinglc/calc-flow/pull/745)']
lines+=['','发布版输出预算段包含末级预算预留、相关配置检查、一次 Tokio 主动让出及取消检查；构造匹配引用时的部分计费仍计在匹配段。列处理计父任务等待 gather worker 的墙钟。发送单列。每个回调都验证阶段闭合，四个 Arrow 子段之和等于该回调的 Arrow 总时长。','','历次结果见 [初始 Rust 水位分段](https://github.com/wegamekinglc/calc-flow/blob/d0fee918f7277557bd068d3da285dfaa44d2a152/benchmarks/evidence/20261125-asof-watermark-phases/native-phase-summary.md) 和 [初始 Python 水位分段](https://github.com/wegamekinglc/calc-flow/blob/91c75c4d921581f2687f1b5f90fba1bc53c21cfd/benchmarks/join-asof/20261125-asof-public-watermark-phases/README.md)。','','[逐轮统计](paired-phases.json) · [复算脚本、逐回调原始时钟、构建标识与校验记录]('+archive.name+')，SHA-256 `'+digest(archive)+'`。将归档解包，以被测 main 为 PYTHONPATH，用已安装 benchmark 锁定依赖的解释器运行 `python analyze-study.py` 可复算。','']
(dest/'README.md').write_text('\n'.join(lines))
