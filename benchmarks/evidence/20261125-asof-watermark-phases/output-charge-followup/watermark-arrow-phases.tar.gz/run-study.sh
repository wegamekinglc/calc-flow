set -eu
exec 9>study.lock
flock -n 9
for donefile in build-plain.exit diagnostic-build.exit wheel-build.exit; do test "$(cat "$donefile")" = 0; done
sha256sum -c preregistered.sha256
for mode in calibration diagnostic; do test -s "obs-$mode/outcome.json"; done
export PYTHONPATH="$3"
"$2" public_release_compare.py asof_join --baseline "$4" --candidate "$PWD/wheels/plain-main/release.json" --candidate-source "$PWD/plain-main" --output "$PWD/py-control" --sha "$(git -C plain-main rev-parse HEAD)" >py-control.log 2>&1 || echo $? >py-control.exit
if test -f py-control/result.json; then
    cores=$("$2" -c 'import json; print(",".join(map(str,json.load(open("py-control/result.json"))["cpus"])))')
    taskset -pc "$cores" "$$" >/dev/null
fi
"$2" diagnostic_compare.py asof_join --baseline "$PWD/wheels/source-release/release.json" --candidate "$PWD/wheels/source-main/release.json" --candidate-source "$PWD/source-main" --output "$PWD/py-trace" --sha "$(git -C source-main rev-parse HEAD)" >py-trace.log 2>&1 || echo $? >py-trace.exit
