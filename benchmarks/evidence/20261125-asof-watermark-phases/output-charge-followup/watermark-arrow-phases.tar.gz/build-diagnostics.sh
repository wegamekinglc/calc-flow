set -eu
while test ! -f build-plain.exit; do sleep 2; done
test "$(cat build-plain.exit)" = 0
for side in main release; do
    rev=$(git -C "source-$side" rev-parse HEAD)
    git -C "$1" diff --quiet
    git -C "$1" switch --detach "$rev"
    python3 build.py "$1" "$rev" admit
done
