"""Recompute warehouse-independent callback phase and paired wall-clock results."""
from pathlib import Path
import hashlib,json,statistics,sys
from diagnostic_validate import counts
from scripts.benchmark_suite.statistics import paired_round
from scripts.benchmark_suite.report import _paired_verdict
from scripts.toolkit import linear_percentile

root=Path(__file__).resolve().parent
def load(path): return json.loads(path.read_text())
def lines(path): return [json.loads(s) for s in path.read_text().splitlines()]
def sha(path): return hashlib.file_digest(path.open('rb'),'sha256').hexdigest()
phases=['wall_ns','matching_ns','arrow_output_ns','arrow_charge_ns','arrow_columns_ns','arrow_assembly_ns','arrow_bookkeeping_ns','left_commit_ns','right_eviction_ns','emit_ns','residual_ns']
def paired(a,b):
    assert len(a)==len(b)==20
    diff=[y-x for x,y in zip(a,b)]
    conf=[paired_round(a[i:i+10],b[i:i+10]) for i in (0,10)] if min(a)>0 and min(b)>0 else []
    return dict(release_p50=statistics.median(a),main_p50=statistics.median(b),release_p95=linear_percentile(a,.95),main_p95=linear_percentile(b,.95),mean_delta_ms=statistics.mean(diff),round_delta_ms=[statistics.median(diff[i:i+10]) for i in (0,10)],round_intervals=conf,verdict=_paired_verdict(conf) if conf else None)
def phase_metrics(series):
    return {k:paired(*[[row[k]*1e-6 for row in arm] for arm in series]) for k in phases}
out={}
for label in ['calibration','diagnostic']:
    d=root/('obs-'+label);oc=load(d/'outcome.json')
    out['native-'+label]={'outcome':oc['state'],'cpu':oc.get('cpu'),'error':oc.get('exception')}
    if oc['state']!='complete': continue
    records=lines(d/'observations.jsonl')
    assert len(records)==44 and all(r['suitable'] for r in lines(d/'resources.jsonl'))
    series=[[r for r in records if r['side']==side and r['pair']>0] for side in ('release','main')]
    out['native-'+label]['outer']=paired(*[[r['result']['watermark_seconds']*1000 for r in arm] for arm in series])
    if label=='diagnostic':
        for r in records:
            trace,=lines(d/r['trace']);assert trace['pid']==r['pid'] and trace['matched_delta']==100_000 and trace['wall_ns']==sum(trace[k] for k in [phases[1],phases[2],*phases[7:]]) and trace['arrow_output_ns']==sum(trace[k] for k in phases[3:7]);assert trace['wall_ns']==r['ns']['wall_ns']
        out['native-'+label]['phases']=phase_metrics([[r['ns'] for r in arm] for arm in series])
for label in ['control','trace']:
    d=root/('py-'+label);oc=load(d/'outcome.json');out['python-'+label]={'outcome':oc['state'],'error':oc.get('error')}
    if oc['state']!='completed':continue
    case=load(d/'samples.json');stats=load(d/'result.json')
    groups=case['evidence']; assert stats['oracle_checked_executions']==44
    assert all(all(c['suitable'] for c in r['cores']) for r in lines(d/'resources.jsonl'))
    series=[[s for rd in groups for s in rd['samples'][side]] for side in ('baseline','candidate')]
    g=out['python-'+label];g['cpu']=stats['cpus'];g['outer']=paired(*[[r['seconds']*1000 for r in arm] for arm in series])
    if label=='trace':
        idx={}
        for trace in (d/'measurement').rglob('asof-finalize.jsonl'):
            for r in lines(trace.parent/'trace-request-ranges.jsonl'):
                key=(r['pid'],r['request_id']);assert key not in idx;idx[key]=trace,r
        for arm in series:
            for s in arm:
                a=s['trace_range'];path,r=idx[(a['pid'],a['request_id'])]
                with path.open('rb') as f:
                    f.seek(r['byte_start']);raw=f.read(r['byte_end']-r['byte_start'])
                callbacks=[json.loads(x) for x in raw.splitlines()]
                assert len(callbacks)==r['records'] and counts(callbacks,r['pid'])==a['stages']
        for k in ['all','emitting','other']:
            g[k]=phase_metrics([[r['trace_range']['stages'][k] for r in arm] for arm in series])
for name,c,d in [('native','native-calibration','native-diagnostic'),('python','python-control','python-trace')]:
    if 'outer' not in out[c] or 'outer' not in out[d]: continue
    assert out[c]['cpu']==out[d]['cpu'];out[name+'-calibration-change-percent']={arm:100*(out[d]['outer'][arm+'_p50']/out[c]['outer'][arm+'_p50']-1) for arm in ('release','main')}
(root/'paired-phases.json').write_text(json.dumps(out,indent=2,allow_nan=False)+'\n')
