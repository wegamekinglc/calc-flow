from pathlib import Path
def edit(p, old, new):
    s=p.read_text()
    assert s.count(old)==1,(p,old,s.count(old))
    p.write_text(s.replace(old,new))
for side in ('release','main'):
    p=Path('source-'+side)/'crates/calc-flow/src/operator/asof'
    f=p/'wm_phase.rs'
    s=f.read_text().replace('Emit, Residual }','Emit, Residual, Charge, Columns, Assemble }').replace('; 6]', '; 9]').replace(';6]', ';9]')
    s=s.replace('"arrow_output_ns":self.ns[1]', '"arrow_output_ns":self.ns[1]+self.ns[6..].iter().sum::<u64>(),"arrow_bookkeeping_ns":self.ns[1],"arrow_charge_ns":self.ns[6],"arrow_columns_ns":self.ns[7],"arrow_assembly_ns":self.ns[8]')
    s=s.replace('self.tickets\n','[self.tickets[0],self.tickets[1]+self.tickets[6..].iter().sum::<u64>(),self.tickets[2],self.tickets[3],self.tickets[4],self.tickets[5]]\n')
    f.write_text(s)
    guard=lambda stage: 'let _subphase = crate::operator::asof::wm_phase::enter(crate::operator::asof::wm_phase::Stage::'+stage+');\n        '
    f=p/'finalize.rs'
    if side=='main':
        edit(f,'let workspace = self.reserve_workspace(\n',guard('Charge')+'let workspace = self.reserve_workspace(\n')
        edit(f,'let record = self.materialize_selection','drop(_subphase);\n        let record = self.materialize_selection')
        edit(f,'self.state.materialize(',guard('Columns')+'self.state.materialize(')
        edit(f,'let batch = Batch::table(',guard('Assemble')+'let batch = Batch::table(')
        g=p/'columnar/materialize.rs';edit(g,'RecordBatch::try_new(schema.clone(), columns)',guard('Assemble')+'RecordBatch::try_new(schema.clone(), columns)')
    else:
        edit(f,'fn output_batch(&self, result: &Batch, context: &dyn KernelContext) -> Result<Batch> {','fn output_batch(&self, result: &Batch, context: &dyn KernelContext) -> Result<Batch> {\n        '+guard('Assemble'))
        g=p/'output_plan.rs';edit(g,'let _arrow = super::wm_phase::enter(super::wm_phase::Stage::Arrow);','let _arrow = super::wm_phase::enter(super::wm_phase::Stage::Charge);')
        for g in (p/'output.rs', p/'output/segments.rs'):
            edit(g,'self.prepare_output(schema, &mut workspace, name, context)',guard('Columns')+'let charge = crate::operator::asof::wm_phase::enter(crate::operator::asof::wm_phase::Stage::Charge);\n        self.prepare_output(schema, &mut workspace, name, context)')
            edit(g,'let requests = column_requests(schema, self.output_columns.as_deref());','drop(charge);\n        let requests = column_requests(schema, self.output_columns.as_deref());')
        g=p/'output.rs'; key='fn materialize_batch(columns: Vec<ArrayRef>, schema: &SchemaRef, len: usize) -> Result<Batch> {';edit(g,key,key+'\n    '+guard('Assemble'))

    # finalize.rs imports these two names in both instrumented products.
    f=p/'finalize.rs'
    full='crate::operator::asof::wm_phase::'
    f.write_text(f.read_text().replace(full+'enter('+full+'Stage::','enter(Stage::'))
