set -eu
for side in source-main source-release plain-main; do
    out="$PWD/wheels/$side"
    mkdir -p "$out"
    if test -L "$out/cargo"; then test "$(realpath "$out/cargo")" = "$1"; else ln -s "$1" "$out/cargo"; fi
    touch "$PWD/$side/crates/calc-flow/src/lib.rs" "$PWD/$side/crates/calc-flow-python/src/lib.rs"
    PYTHONPATH="$PWD/source-main" "$2" -m scripts.benchmark_suite build --source "$PWD/$side" --output "$out"
done
