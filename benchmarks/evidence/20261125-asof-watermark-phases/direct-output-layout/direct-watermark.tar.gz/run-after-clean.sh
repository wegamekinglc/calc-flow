set -eu
while test ! -f plain/measure-clean.exit; do sleep 7; done
test "$(cat plain/measure-clean.exit)" = 0
if ! test "$(cat plain/native-release.exit)" = 0; then echo 'ordinary release group stopped; diagnostic withheld' >withheld.txt; exit 0; fi
sha256sum --quiet -c registered.sha256
rev="$(git -C source-main rev-parse HEAD)"
test "$(git -C source-main rev-parse HEAD^)" = 9aed8b4b20156a460369d0765c4bc9e42e0925e5
export CARGO_TARGET_DIR="$(dirname "$PWD")/staged-perf-ec402c59/asof-charge-release-nov24/target/cargo" CARGO_BUILD_JOBS=2
python3 build.py "$PWD/source-main" "$rev" admit
while ps -e -o stat=,comm= | awk '$2 ~ /^(rustc|rust-lld|cargo-clippy|clippy-driver)$/ && $1 !~ /^[TZ]/ {found=1} END {exit !found}'; do sleep 2; done
../worktrees/benchmark-large-engines-20261114/target/benchmark-venv/bin/python observe.py diagnostic
