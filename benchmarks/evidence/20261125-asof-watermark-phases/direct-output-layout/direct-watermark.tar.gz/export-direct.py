"""Replay both direct clocks and exclusive inner phases, including partial groups."""
import hashlib
import json
from pathlib import Path
import statistics
import tarfile

from observe import checked, summarize, FIELDS, PRODUCT, TRACED

root=Path(__file__).resolve().parent
read=lambda p:json.loads(p.read_text())
def lines(p):
    return [json.loads(l) for l in p.read_text().splitlines()] if p.exists() else []
def digest(p):
    with p.open("rb") as f: return hashlib.file_digest(f,"sha256").hexdigest()
out=root/"export";out.mkdir(exist_ok=True)
cal=root/"plain/obs-admit-7012b5b409-9aed8b4b20"
files={p:p.name for p in root.iterdir() if p.is_file() and p.suffix in ('.py','.md','.patch','.sha256','.rs','.json','.log','.exit','.sh','.txt') and 'build.jsonl' not in p.name}
files.update({p:'plain/'+cal.name+'/'+p.name for p in cal.glob('*.json*')})
summary={'product':PRODUCT,'traced_sources':TRACED,'ordinary':read(cal/'outcome.json')}
calobs=lines(cal/'observations.jsonl')
for row in calobs: checked(row['result'],None,None)
if (root/'withheld.txt').exists():
    summary['state']='withheld'
else:
    d=root/'obs-diagnostic';outcome=read(d/'outcome.json')
    rows=lines(d/'observations.jsonl')
    files.update({p:'obs-diagnostic/'+p.name for p in d.glob('*.json*')})
    for pos,row in enumerate(rows):
        rnd,inner=divmod(pos,22); pair,arm=divmod(inner,2)
        order=('release','main') if pair==0 or pair%2 else ('main','release')
        assert (row['round'],row['pair'],row['side'])==(rnd+1,pair,order[arm])
        assert checked(row['result'],lines(d/row['trace']),row['pid'])==row['ns']
    summary.update(state=outcome['state'],checked=len(rows),outcome=outcome)
    if outcome['state']=='complete':
        assert len(calobs)==len(rows)==44 and outcome['metrics']==summarize(d)
        assert all(x['suitable'] for x in lines(d/'resources.jsonl'))
        assert outcome['cpu']==summary['ordinary']['cpu']
        arms={s:[r for r in rows if r['pair'] and r['side']==s] for s in PRODUCT}
        parts=FIELDS+['arrow_charge_ns','arrow_columns_ns','arrow_assembly_ns','arrow_bookkeeping_ns','wall_ns','outside_finalize_ns','watermark_ns']
        diffs={k:statistics.mean(r['ns'][k]-b['ns'][k] for b,r in zip(arms['release'],arms['main']))/1e6 for k in parts}
        assert abs(sum(diffs[k] for k in FIELDS)-diffs['wall_ns'])<1e-8
        summary['mean_paired_delta_ms']=diffs
        def outer(q,side):
            v=summary['ordinary']['pooled_ms'][('base' if side=='release' else 'head')][q]
            trace=outcome['metrics']['watermark_ns'][q+'_ms'][side]
            return trace/v-1
        summary['trace_vs_ordinary_p50']={s:outer('p50',s) for s in PRODUCT}
(out/'replay.json').write_text(json.dumps(summary,indent=2)+'\n')
with tarfile.open(out/'direct-watermark.tar.gz','w:gz') as f:
    for path,name in sorted(files.items()):f.add(path,arcname=name,recursive=False)
print(summary['state'],summary.get('mean_paired_delta_ms',{}))
