import json
from pathlib import Path

root=Path(__file__).resolve().parent
dest=root/'export'
d=json.loads((dest/'replay.json').read_text())
base='https://github.com/wegamekinglc/calc-flow'
rows=['# 复测单次 Rust ASOF 产出水位','',
      '左右各 10 万行、64 个键，先接纳两侧数据，再推进一次可产出全部匹配的水位。发布版为 7012b5b4，候选为 PR 750 的 9aed8b4b。原生观测与 Python 安装包使用独立计时。输出检查涵盖总行数、非递减顺序、左右序列号相等以及每行的右值关系。','',
      '历史上 72072c1d 相对发布版的内部处理器平均差距为 +5.343 ms，Arrow 输出为 +4.772 ms。本次使用同一原生负载；每组分两轮各十对正式样本，并分别预热。每个成功的插桩样本验证外层水位时钟包住内部处理器时钟，各内部阶段、Arrow 各子阶段分别求和闭合。[历史阶段测量]('+base+'/blob/d0fee918f7277557bd068d3da285dfaa44d2a152/benchmarks/evidence/20261125-asof-watermark-phases/native-phase-summary.md)','']
o=d['ordinary']
if o['state']=='complete':
    v=o['pooled_ms']
    rows.append(f"普通产品 Rust 回调 p50 为 {v['base']['p50']:.3f} → {v['head']['p50']:.3f} ms，p95 为 {v['base']['p95']:.3f} → {v['head']['p95']:.3f} ms，两轮判定为 {o['verdict']}。")
rows.append('')
if d['state']=='complete':
    ds=d['mean_paired_delta_ms']
    labels={'watermark_ns':'外层水位回调','wall_ns':'内部处理器','matching_ns':'匹配与就绪','arrow_output_ns':'Arrow 输出合计','arrow_charge_ns':'其中预算与整段判定','arrow_columns_ns':'其中列定位与取值','arrow_assembly_ns':'其中 Arrow 组装','arrow_bookkeeping_ns':'其中其余输出管理','left_commit_ns':'左侧提交','right_eviction_ns':'右侧状态淘汰','emit_ns':'交付等待','residual_ns':'未归属处理器时间','outside_finalize_ns':'内部处理器以外'}
    rows+=['同一对中的候选减发布版，然后对 20 个差值求算术平均。单位为毫秒，负数代表候选更快。','']
    rows += [f"- {label} {ds[k]:+.4f} ms" for k,label in labels.items()]
    c=d['trace_vs_ordinary_p50']
    rows+=['',f"按各自普通产品 p50 作参照，插桩外层回调 p50 分别变化 {100*c['release']:+.2f}% 和 {100*c['main']:+.2f}%。普通与插桩组顺序运行，变化同时可能包含时间漂移。这是候选全部已纳入改动相对 11.14 的差值，不能单独归给输出计划复用。"]
else:
    rows.append(f"插桩组状态为 {d['state']}，已接受 {d.get('checked',0)} 次观测。该组没有生成阶段差值或分位数；原因保存在复算 JSON。")
rows+=['','[完整统计与逐组状态](replay.json) · [原始观测、插桩补丁及复算脚本](direct-watermark.tar.gz)']
(dest/'README.md').write_text('\n'.join(rows)+'\n')
