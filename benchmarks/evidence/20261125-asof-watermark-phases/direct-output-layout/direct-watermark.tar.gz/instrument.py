from pathlib import Path
import sys
root=Path(__file__).resolve().parent
revision=sys.argv[1]
p=root/('source-'+revision)/'crates/calc-flow/src/operator/asof'
(p/'wm_phase.rs').write_bytes((root/'wm_phase.rs').read_bytes())
def replace(file, before, after):
    f=p/file; txt=f.read_text()
    assert txt.count(before)==1,(file,before,txt.count(before))
    f.write_text(txt.replace(before,after))
def insert(file, anchor, code):
    replace(file,anchor,code+anchor)
insert('mod.rs','mod finalize;', 'mod wm_phase;\n')
f='replay.rs'
s=(p/f).read_text(); a=s.index('        match self.finalize(',s.index('async fn finalize_with_replay')); b=s.index('\n    }',a)
body=s[a:b]
replace(f,body,'''        let path = std::env::var_os("CALC_FLOW_ASOF_WATERMARK_TRACE");
        let before = path.as_ref().map(|_| self.status.clone());
        let work = async {
'''+body+'''
        };
        if let (Some(path), Some(before)) = (path, before) {
            let (result, timing) = super::wm_phase::measure(work).await;
            timing.record(std::path::Path::new(&path), &self.name, frontier, ended, &before, &self.status, result.is_ok());
            result
        } else {
            work.await
        }''')
f='finalize.rs'
insert(f,'use super::{', 'use super::wm_phase::{enter, Stage};\n') if (p/f).read_text().count('use super::{')==1 else replace(f,'use super::{\n    StreamAsofJoinOperator,', 'use super::wm_phase::{enter, Stage};\nuse super::{\n    StreamAsofJoinOperator,')
if revision=='main':
    insert(f,'        let mut count =\n','        let _matching = enter(Stage::Match);\n')
    insert(f,'        let plan = self\n','        let _arrow = enter(Stage::Arrow);\n        let charge = enter(Stage::Charge);\n')
    insert(f,'            tokio::select! {','            let emit_phase = enter(Stage::Emit);\n')
    insert(f,'            self.state.commit','            drop(emit_phase);\n            let _left = enter(Stage::Left);\n')
    insert(f,'            let evicted = self.state.evict','            let _right = enter(Stage::Right);\n')
else:
    insert(f,'            if !self.has_finalizable','            let matching = enter(Stage::Match);\n')
    insert(f,'            self.commit_prefix_output','            drop(matching);\n            let _left = enter(Stage::Left);\n')
    insert(f,'        let matched = plan.matched;','        let _arrow = enter(Stage::Arrow);\n')
    insert(f,'        let matched = prepared.plans.iter()','        let _arrow = enter(Stage::Arrow);\n')
    insert(f,'        let stamp = SweepStamp::current(&self.status);','        let _right = enter(Stage::Right);\n')
    insert('finalize/prefix.rs','        emit_output(output.batch','        let emit_phase = super::enter(super::Stage::Emit);\n')
    insert('finalize/prefix.rs','        // Nothing after sink acceptance','        drop(emit_phase);\n')
    for file in ['cpu.rs','output.rs','output/segments.rs']:
        f=p/file;s=f.read_text();lines=s.splitlines(keepends=True)
        ids=[i for i,line in enumerate(lines) if 'ticket.finish().await' in line]
        assert ids,(file,ids)
        for i in reversed(ids): 
            indent=lines[i][:len(lines[i])-len(lines[i].lstrip())]
            lines.insert(i,indent+'crate::operator::asof::wm_phase::ticket();\n')
        f.write_text(''.join(lines))
if revision=='release':
    replace('output_plan.rs','''        self.charge_compact_fixed(name)?;
        self.reserve_buffers(right_schema, workspace, name)?;''','''        {
            let _arrow = super::wm_phase::enter(super::wm_phase::Stage::Arrow);
            self.charge_compact_fixed(name)?;
            self.reserve_buffers(right_schema, workspace, name)?;
        }''')
