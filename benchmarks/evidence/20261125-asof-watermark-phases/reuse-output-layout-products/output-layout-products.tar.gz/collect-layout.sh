set -eu
root="$(dirname "$PWD")"
python_bin="$root/worktrees/benchmark-large-engines-20261114/target/benchmark-venv/bin/python"
harness="$root/managed-runtime-20261124/round5-harness"
release_dir="$root/managed-runtime-20261124/main-src/target/products/release-1114"
parent_dir="$root/asof-combined-main-10m-nov25"
base=de20f8216c8dcb1bfce3e3811c3884a3080157df
release=7012b5b409553df04e29e6d7f9a11abf919cbf93
head=932f064175d04e3409503ddc1a4d76b8e962454f
sha256sum --quiet -c registered.sha256
test "$(git -C source rev-parse "$head^")" = "$base"
test "$(git -C source rev-parse "$head^{tree}")" = e1034c33da04358d9c9c29944fd1734247ab94f5
test "$(cat "$root/asof-right-prefix-products-nov25/collect.exit")" = 0
test "$(git -C "$parent_dir/source" rev-parse HEAD)" = "$base"
for ref in "$base" "$head"; do
 git -C source switch -q --detach "$ref"
 CARGO_BUILD_JOBS=2 CARGO_TARGET_DIR="$root/staged-perf-ec402c59/asof-charge-release-nov24/target/cargo" python3 build.py "$PWD/source" "$ref" admit
done
mkdir wheel
ln -s "$root/managed-runtime-20261124/main-src/target/cargo" wheel/cargo
touch source/crates/{calc-flow,calc-flow-python}/src/lib.rs
PYTHONPATH="$PWD/source" "$python_bin" -m scripts.benchmark_suite build --source "$PWD/source" --output "$PWD/wheel" >wheel/build-driver.log 2>&1
for f in engine_comparison.py engine_stream.py; do cmp "$parent_dir/worker/benchmarks/$f" "$harness/target/post-timer-worker/benchmarks/$f"; done
while ps -e -o stat=,comm= | awk '$2 ~ /^(rustc|rust-lld|cargo-clippy|clippy-driver)$/ && $1 !~ /^[TZ]/ {found=1} END {exit !found}'; do sleep 2; done
export PYTHONPATH="$harness" ASOF_BENCH_HARNESS="$harness" ASOF_VERIFIED_WORKER="$harness/target/post-timer-worker"
for arm in parent release; do
 if test "$arm" = parent; then ref=$base; manifest="$parent_dir/wheel/release.json"; checkout="$parent_dir/source"; else ref=$release; manifest="$release_dir/release.json"; checkout="$root/managed-runtime-20261124/release-proof"; fi
 rc=0
 "$python_bin" measure.py admit "$head" "$ref" >"native-$arm.log" 2>&1 || rc=$?
 echo "$rc" >"native-$arm.exit"
 rc=0
 "$python_bin" public_compare.py asof_join --baseline "$manifest" --candidate "$PWD/wheel/release.json" --baseline-sha "$ref" --baseline-source "$checkout" --candidate-source "$PWD/source" --sha "$head" --output "$PWD/wheel-$arm" >"wheel-$arm.log" 2>&1 || rc=$?
 echo "$rc" >"wheel-$arm.exit"
done
