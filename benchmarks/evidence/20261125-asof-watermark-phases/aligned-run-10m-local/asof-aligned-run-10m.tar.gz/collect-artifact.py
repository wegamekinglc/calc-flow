"""Package the two fixed comparisons and build records, including a stopped group."""
import hashlib
import json
import tarfile
from pathlib import Path

root = Path.cwd()
export = root / "product-export"
export.mkdir(exist_ok=True)
read = lambda path: json.loads(path.read_text())
selected = {root / f for f in ("protocol.md", "registered.sha256", "measure-products.sh", "build-products.sh", "replay.sh", "collect-artifact.py", "qualification.log", "build-driver.log", "native-build.log", "measurement.exit", "replay.exit", "measurement-started.txt", "measurement-ended.txt") if (root / f).exists()}
selected.update(root / item.split(None,1)[1] for item in (root / "registered.sha256").read_text().splitlines())
selected.update(root.glob("e310*-build.*"))
selected.update(root.glob("*.receipt.json"))
selected.update(f for f in (root / "wheel").glob("*") if f.suffix in (".json", ".log"))
selected.update(f for f in (root / "superseded-1ba9").glob("*") if f.is_file())
selected.update((root / "superseded-1ba9").glob("*/bound.json"))
rows = []
for name in ("release", "parent"):
    group = root / name
    selected.update(f for f in group.glob("*") if f.is_file() and not f.name.startswith("job-") and f.suffix not in (".pyc",))
    selected.update(group.glob("*.receipt.json"))
    selected.update(group.glob("worker/benchmarks/*.py"))
    selected.update(group.glob("obs-job-*/*.json*"))
    for f in (group / "python-10m").rglob("*"):
        if "site" not in f.relative_to(group / "python-10m").parts and f.is_file() and f.suffix in (".json", ".log", ".jsonl"):
            selected.add(f)
    bound = read(group / "bound.json")
    for surface in ("Rust", "Python"):
        row = {"control": bound["baseline"], "candidate":bound["candidate"], "surface": surface}
        if surface == "Rust" and list(group.glob("obs-job-*/outcome.json")):
            outcome = read(next(group.glob("obs-job-*/outcome.json")))
            if outcome["state"] == "complete":
                row.update(ms=outcome["pooled_ms"], paired_rounds=outcome["rounds"], verdict=outcome["verdict"])
            else:
                row.update(verdict="stopped", evidence=outcome)
        elif surface == "Python" and (group / "python-10m/result.json").exists():
            result = read(group / "python-10m/result.json")
            row.update(ms={side: {q: result[f"{side}_{q}"] * 1000 for q in ("p50", "p95")} for side in ("base", "head")}, paired_rounds=result["round_intervals"], verdict=result["verdict"])
        elif surface == "Python" and (group / "python-10m/outcome.json").exists():
            row.update(verdict="stopped", evidence=read(group / "python-10m/outcome.json"))
        else:
            row.update(verdict="unmeasured")
        if "ms" in row:
            row["p50_change_percent"]=(row["ms"]["head"]["p50"]/row["ms"]["base"]["p50"]-1)*100
        rows.append(row)
summary = export / "result.json"
summary.write_text(json.dumps(dict(rows=rows, machine="WSL2", cores=[2,4,16,20], candidate_scope="10M rows per input, 64 keys, batch size 1M, 4 Tokio workers", verdict_rule="regression only when both rounds' paired-median lower confidence limits exceed +5%"),indent=2,allow_nan=False)+'\n')
selected.add(summary)
inventory = export / "SHA256SUMS"
def digest(p):
    with p.open("rb") as f: return hashlib.file_digest(f, "sha256").hexdigest()
inventory.write_text("".join(digest(p)+"  "+str(p.relative_to(root))+"\n" for p in sorted(selected)))
selected.add(inventory)
dest = export / "asof-aligned-run-10m.tar.gz"
with tarfile.open(dest,"w:gz") as tar:
    for p in sorted(selected): tar.add(p, arcname=str(p.relative_to(root)), recursive=False)
with tarfile.open(dest) as tar:
    for p in selected:
        with tar.extractfile(str(p.relative_to(root))) as entry:
            assert hashlib.file_digest(entry, "sha256").hexdigest()==digest(p)
print(json.dumps({"archive_sha256": digest(dest),"bytes": dest.stat().st_size, "files":len(selected), "rows":rows}, indent=2))
