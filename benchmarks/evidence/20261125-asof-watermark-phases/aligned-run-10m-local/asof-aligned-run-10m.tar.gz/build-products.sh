set -eu
root=$(pwd)
test "$#" = 1
head=$(git rev-parse --verify "$1^{commit}")
test "$head" = "$1"
prior=f069199b25cd7893879df799a2d44e95d6a9cbad
release=7012b5b409553df04e29e6d7f9a11abf919cbf93
git merge-base --is-ancestor "$prior" "$head"
test "$head" != "$prior"
test "$(git rev-parse "$prior:Cargo.lock")" = "$(git rev-parse "$head:Cargo.lock")"
sha256sum --quiet --check registered.sha256
for f in engine_comparison.py engine_stream.py; do cmp "worker/benchmarks/$f" "../managed-runtime-20261124/round5-harness/target/post-timer-worker/benchmarks/$f"; done
git worktree add -q --detach "$root/source" "$head"
git worktree add -q --detach "$root/native-source" "$head"
for g in release parent; do
    if test "$g" = release; then sha=$release; else sha=$prior; fi
    mkdir "$g"
    python3 -c 'import datetime,json,subprocess,sys; a,b=sys.argv[1:]; tree=lambda c:subprocess.check_output(["git","rev-parse",c+"^{tree}"],text=True).strip(); print(json.dumps(dict(baseline=a,release=a,candidate=b,base_tree=tree(a),head_tree=tree(b),bound_at=datetime.datetime.now(datetime.timezone.utc).isoformat()),indent=2))' "$sha" "$head" >"$g/bound.json"
    cp registered.sha256 protocol.md *.py *.sh *.rs project.json cpus.json "$g"
    cp -r worker "$g"
    for binary in job-7012b5b409 job-f069199b25; do
        cp "$binary".receipt.json "$g"
    done
    ln "job-$(echo "$sha"|cut -c1-10)" "$g/"
done
touch source/crates/calc-flow/src/lib.rs source/crates/calc-flow-python/src/lib.rs
parent_dir=$(dirname "$root")
py="$parent_dir/worktrees/benchmark-large-engines-20261114/target/benchmark-venv/bin/python"
( PYTHONPATH="$root/source" "$py" -m scripts.benchmark_suite build --source "$root/source" --output "$root/wheel" ) >wheel/build-driver.log 2>&1 & wheel_pid=$!
r=0
CARGO_TARGET_DIR="$root/native-cargo" CARGO_BUILD_JOBS=2 python3 build.py "$root/native-source" "$head" job >native-build.log 2>&1 || r=$?
wait "$wheel_pid" || r=$?
test "$r" = 0
for g in release parent; do
    ln "job-$(echo "$head" | cut -c1-10)" "$g/"
    cp "job-$(echo "$head" | cut -c1-10)".receipt.json "$g/"
    mkdir "$g/wheel"
    cp wheel/build*.log wheel/*.json "$g/wheel/"
done
