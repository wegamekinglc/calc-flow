"""Replay fixed-pair ASOF output-budget evidence and produce a small public archive."""
import hashlib
import json
import statistics
import tarfile
from pathlib import Path

from scripts.benchmark_suite.report import _paired_verdict
from scripts.benchmark_suite.statistics import paired_round
from scripts.toolkit import linear_percentile
from verify import verify

root = Path.cwd()
label = '11.14' if root.name == 'release' else 'f069199b'
read = lambda p: json.loads(p.read_text())
files=set()
for pattern in ('*.py','*.sh','*.rs','*.md','*.json','*.sha256','*.exit','*.txt'):
    files.update(f for f in root.glob(pattern) if f.is_file() and f.name not in ('product-sha256.txt', 'product-replay.json'))
for directory in ['wheel','parent-wheel','candidate-wheel','worker','public-settings']:
    scope=root/directory
    if scope.is_dir():
        for f in scope.rglob('*') if directory in ('worker','public-settings') else scope.glob('*'):
            if f.is_file() and f.suffix in ('.json','.py','.log','.sha256'): files.add(f)
for manifest in [*root.glob('registered.sha256'),*root.glob('bound-cpus.sha256'),*root.glob('*/bound.sha256')]:
    files.add(manifest)
    for entry in manifest.read_text().splitlines():
        expected, path=entry.split(None,1)
        f=manifest.parent/path.strip()
        assert hashlib.file_digest(f.open('rb'),'sha256').hexdigest()==expected
        files.add(f)
rows=[]
details={'bound_raw_replay':read(root/'checked-requests.json')}
for group, base, path in [(root.name,label,root)]:
    for pat in ('*.json','*.sha256','*.log','*.py','*.rs','*.exit'):
        files.update(p for p in path.glob(pat) if p.is_file() and p.name not in ('product-replay.json',))
    dirs=list(path.glob('obs-job-*'))
    if not dirs:
        status=path/('measured.exit' if path!=root else 'native.exit')
        assert status.is_file() and int(status.read_text())!=0
        details['native-'+group]=dict(state='stopped',exit_code=int(status.read_text()))
        rows.append(['Rust 原生作业',base,'1,000 万',None,None,None,None,'stopped'])
        continue
    d,=dirs
    proof = verify(d)
    out = read(d/'outcome.json')
    files.update(d.glob('*.json*'))
    details['native-'+group] = dict(replay=proof,outcome=out)
    if proof['state'] == 'complete':
        v = out['pooled_ms']
        rows.append(['Rust 原生作业',base,'1,000 万',v['base']['p50'],v['head']['p50'],
                     v['base']['p95'],v['head']['p95'],out['verdict']])
    else:
        rows.append(['Rust 原生作业',base,'1,000 万',None,None,None,None,'stopped'])
for scope, count, base in [(root.name,10_000_000,label)]:
    d = root/'python-10m'
    assert (d/'outcome.json').is_file(), d
    for f in d.rglob('*'):
        if 'site' not in f.relative_to(d).parts and f.is_file() and f.suffix in ('.json','.jsonl','.log'):
            files.add(f)
    out = read(d/'outcome.json')
    detail = details['python-'+scope] = dict(outcome=out)
    row = ['Python 至表交付',base,'100 万' if count==1_000_000 else '1,000 万']
    observed = []
    expected = {'passed':True,'rows':count,'finite_rows':count,'max_abs_error':0.0}
    def verify_response(response):
        assert response['correctness']==expected and response['seconds']>0
        status=response['stream_evidence']['terminal_asof_status']
        assert all(status[k]==count for k in ('emitted_left_rows','matched_rows','evicted_right_rows'))
        assert response['stream_evidence']['post_eof_output_rows']==count
        assert all(status[k]==0 for k in ('state_rows','state_bytes','retained_right_rows','pending_left_rows','identity_only_rows','unmatched_rows','state_limit_failures','workspace_limit_failures','output_limit_failures'))
        for endpoint in ('left','right'):
            side=status[endpoint]
            assert side['ended'] and side['accepted_rows']==count and side['duplicate_rows']==side['late_rows']==0
    for f in (d/'measurement').rglob('*.completed.json'):
        request=read(f)
        response=request.get('response',{})
        value=response.get('warmup',response)
        if isinstance(value,dict) and 'seconds' in value and 'correctness' in value:
            verify_response(value)
            observed.append(request['operation'])
    detail['completed_requests']={op:observed.count(op) for op in ('prepare','sample')}
    if out['state'] != 'completed':
        resources=[json.loads(x) for x in (d/'resources.jsonl').read_text().splitlines()] if (d/'resources.jsonl').exists() else []
        detail['rejected_intervals']=[item for item in resources if any(not c['suitable'] for c in item['cores'])]
        rows.append([*row,None,None,None,None,'stopped'])
        continue
    result, samples = read(d/'result.json'), read(d/'samples.json')
    assert observed.count('prepare')==4 and observed.count('sample')==40
    assert samples['status']=='ok' and result['oracle_checked_executions']==44
    assert len(result['cpus'])==4 and all(all(c['suitable'] for c in json.loads(x)['cores']) for x in (d/'resources.jsonl').read_text().splitlines())
    rounds = []
    values = {'baseline':[],'candidate':[]}
    for evidence in samples['evidence']:
        assert evidence['environment']['cpu_affinity']==result['cpus']
        times={}
        for side in values:
            assert len(evidence['samples'][side])==10
            for item in evidence['samples'][side]:
                verify_response(item)
            times[side]=[item['seconds'] for item in evidence['samples'][side]]
            values[side]+=times[side]
        rounds.append(paired_round(times['baseline'],times['candidate']))
    assert rounds==result['round_intervals'] and _paired_verdict(rounds)==result['verdict']
    quantiles=[statistics.median(v) for v in values.values()]+[linear_percentile(v,.95) for v in values.values()]
    assert quantiles==[result[k] for k in ('base_p50','head_p50','base_p95','head_p95')]
    detail.update(result=result, verified_requests=44)
    rows.append([*row,*[x*1000 for x in quantiles],result['verdict']])
export=root/'product-export'
export.mkdir(exist_ok=True)
result_file=root/'product-replay.json'
result_file.write_text(json.dumps(details,indent=2,allow_nan=False)+'\n')
files.add(result_file)
archive=export/'asof-10m-products.tar.gz'
digest=lambda f: hashlib.file_digest(f,'sha256').hexdigest()
inventory=root/'product-sha256.txt'
inventory.write_text(''.join(digest(p.open('rb'))+'  '+str(p.relative_to(root))+'\n' for p in sorted(files)))
files.add(inventory)
with tarfile.open(archive,'w:gz') as t:
    for f in sorted(files):
        t.add(f,arcname=str(f.relative_to(root)),recursive=False)
with tarfile.open(archive) as t:
    assert all(digest(t.extractfile(str(p.relative_to(root))))==digest(p.open('rb')) for p in files)
table=[['入口','对照','每侧行数','对照 p50','候选 p50','对照 p95','候选 p95','两轮判定'],
       *[[f'{s:,.3f}' if isinstance(s,float) else str(s) if s is not None else '—' for s in row] for row in rows]]
from unicodedata import east_asian_width
width=lambda value:sum(2 if east_asian_width(c) in 'WF' else 1 for c in value)
widths=[max(map(width,c)) for c in zip(*table)]
line=lambda cells: '| '+' | '.join(s+' '*(n-width(s)) for s,n in zip(cells,widths))+' |'
bound=read(root/'bound.json')
lines=[f'# ASOF 候选相对 {label} 的差距','','候选提交 '+bound['candidate']+'。对照版本、源码树及构建身份见原始记录。每侧 1,000 万行，四个工作线程。单位为毫秒。Rust 从首批就绪到输出封装，Python 从就绪到完整 Arrow 表交付，两者均在结束计时后提交 EOF 并验证终态。原计划每组两轮，每轮十对正式观测，另有四次预热。','',line(table[0]),'|'+'|'.join('-'*(n+2) for n in widths)+'|',*[line(r) for r in table[1:]],'','时长为两轮正式计时的合并分位数。stopped 表示资源或时间门槛中断该组。已完成样本及停止原因保留在 JSON 中。','',f'[复算脚本、构建记录及原始数据]({archive.name})，SHA-256 `{digest(archive.open("rb"))}`。','']
(export/'README.md').write_text('\n'.join(lines))
(export/result_file.name).write_bytes(result_file.read_bytes())
