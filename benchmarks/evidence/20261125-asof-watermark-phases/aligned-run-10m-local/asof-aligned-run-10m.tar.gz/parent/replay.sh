set -eu
root=$(pwd)
parent_dir=$(dirname "$root")
export PYTHONPATH="$parent_dir/managed-runtime-20261124/round5-harness"
py="$parent_dir/worktrees/benchmark-large-engines-20261114/target/benchmark-venv/bin/python"
for g in release parent; do
    cd "$root/$g"
    if test -f native.exit; then
        "$py" check_raw.py . > checked-requests.json
        if test -f python-10m/outcome.json; then
            "$py" report-product.py
        else
            "$py" verify.py obs-job-* >native-replay.json
        fi
    fi
done
