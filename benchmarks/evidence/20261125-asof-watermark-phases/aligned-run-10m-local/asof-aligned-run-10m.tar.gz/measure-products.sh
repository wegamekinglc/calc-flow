set -eu
root=$(pwd)
head=$(git -C source rev-parse HEAD)
release=7012b5b409553df04e29e6d7f9a11abf919cbf93
prior=f069199b25cd7893879df799a2d44e95d6a9cbad
parent_dir=$(dirname "$root")
harness="$parent_dir/managed-runtime-20261124/round5-harness"
py="$parent_dir/worktrees/benchmark-large-engines-20261114/target/benchmark-venv/bin/python"
export TMPDIR="$root/managed-tmp" PYTHONPATH="$harness"
sha256sum --quiet --check registered.sha256
test -f wheel/release.json
for f in engine_comparison.py engine_stream.py; do cmp "worker/benchmarks/$f" "$harness/target/post-timer-worker/benchmarks/$f"; done
timeout -k 2 15 "$py" qualify.py "$release" "$prior" "$head" >qualification.log 2>&1
for g in release parent; do
    if test "$g" = release; then
        sha=$release
        base_source="$parent_dir/managed-runtime-20261124/release-proof"
        baseline="$parent_dir/managed-runtime-20261124/main-src/target/products/release-1114/release.json"
    else
        sha=$prior
        base_source="$parent_dir/asof-output-and-eviction-10m-nov26/source"
        baseline="$parent_dir/asof-output-and-eviction-10m-nov26/wheel/release.json"
    fi
    cd "$root/$g"
    for commit in "$sha" "$head"; do
        short=$(echo "$commit"|cut -c1-10)
        cp "$root/qual-$short.json" "$root/qual-$short.stderr" .
    done
    cp "$root/qualification.log" .
    code=0
    "$py" measure.py job "$head" "$sha" >native.log 2>&1 || code=$?
    echo "$code" >native.exit
    test "$code" = 0 || exit "$code"
    /usr/bin/time -f %e -o public-elapsed.txt taskset -c 2,4,16,20 "$py" public_compare.py asof_join --baseline "$baseline" --baseline-source "$base_source" --baseline-sha "$sha" --candidate "$root/wheel/release.json" --candidate-source "$root/source" --output "$root/$g/python-10m" --sha "$head" >public.log 2>&1 || code=$?
    echo "$code" >public.exit
    test "$code" = 0 || exit "$code"
done
