set -eu
w=$1
out=$2
candidate=$3
test "$(git -C "$w" rev-parse HEAD)" = "$candidate"
python3 "$out/build.py" "$w" "$candidate" job
