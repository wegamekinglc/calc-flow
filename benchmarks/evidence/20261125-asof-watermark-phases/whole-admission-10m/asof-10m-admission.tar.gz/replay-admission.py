"""Authenticate the two VMs and replay both baselines on each, including ordered output."""
import json
import sys
from pathlib import Path
import paired

ROOT=Path(__file__).resolve().parent
CONF=json.loads((ROOT/"registration.json").read_text())
RUN=CONF["run"]
REGISTERED=CONF["registration"]
HEAD="5540d317884b59c53a8a9f80ac7129b78314c694"
BASES={"release":"7012b5b409553df04e29e6d7f9a11abf919cbf93","parent":"e3104f444688ab3890c4b45f6098c28e052de7a8"}
def main():
    offline="--offline" in sys.argv
    run=paired.read(ROOT/"run.json") if offline else paired.api(f"/runs/{RUN}")
    assert run["status"]=="completed" and run["head_sha"]==REGISTERED and run["event"]=="workflow_dispatch"
    artifacts=paired.read(ROOT/"artifacts.json") if offline else paired.api(f"/runs/{RUN}/artifacts?per_page=100")["artifacts"]
    (ROOT/"run.json").write_text(json.dumps(run,indent=2)+"\n")
    (ROOT/"artifacts.json").write_text(json.dumps(artifacts,indent=2)+"\n")
    results={}
    paired.HEAD=HEAD
    for surface in ("rust","python"):
        item,=[a for a in artifacts if a["name"]==f"asof-admission-10m-{surface}-{RUN}-1"]
        dest=ROOT/surface
        dest.mkdir(exist_ok=True)
        scope=paired.download(item,dest)
        assert (scope/"registration.txt").read_text().strip()==REGISTERED
        topology={x["field"]:x["data"] for x in paired.read(scope/"topology.json")["lscpu"]}
        groups={}
        results[surface]={"artifact":item["id"],"digest":item["digest"],"model":topology["Model name:"],"cases":groups}
        selected=None
        for tag,base in BASES.items():
            d=scope/tag
            if not (d/"bound.json").exists():
                groups[tag]=dict(state="not started")
                continue
            for line in (d/"registered.sha256").read_text().splitlines():
                digest,name=line.split(None,1)
                assert paired.rawhash(d/name)==digest
            bound=paired.read(d/"bound.json")
            assert bound["baseline"]==base and bound["candidate"]==HEAD
            if not list(d.glob("obs-job-*/outcome.json")) and not (d/"python/outcome.json").exists():
                groups[tag]=dict(state="setup stopped")
                continue
            groups[tag]=(paired.replay_rust if surface=="rust" else paired.replay_python)(d,base)
            if groups[tag]["state"]=="complete":
                cur=groups[tag]["selected_cpus"]
                assert selected is None or cur==selected
                selected=cur
            print(surface,tag,groups[tag])
    (ROOT/"replay.json").write_text(json.dumps(results,indent=2)+"\n")
if __name__=="__main__":main()
