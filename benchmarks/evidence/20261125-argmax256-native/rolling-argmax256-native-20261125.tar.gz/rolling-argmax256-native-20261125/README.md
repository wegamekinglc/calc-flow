# Rust rolling argmax256

The adapter runs the public, single-threaded, uncheckpointed StreamingRunner with one ordinary RollingOperator. It pushes ten one-million-row batches with 64 interleaved key values and an explicit native watermark after each batch. The timer spans first source delivery through the final output row. Every worker finishes normally and checks every row against an independent oldest-maximum oracle. The fixture and periodic oracle follow `benchmarks/engine_comparison.py`. Application graph projection, conversion and public iterator timing are measured independently in the separate Python case.

## Replay

Use a disposable clean Git worktree at each recorded commit. Keep the same path for every revision and direct release outputs to a separate Cargo target directory under target/. The build script adds only the untracked adapter to the crate's examples, rebuilds its library and the example, and records the source tree, release profile, frozen lock, Rust version and digests.

```sh
export CARGO_BUILD_JOBS=2
export CARGO_TARGET_DIR="$CASE_ROOT/cargo"
candidate=$(cat "$CASE_ROOT/candidate.txt")
for rev in 7012b5b409553df04e29e6d7f9a11abf919cbf93 596e28832c9829972a5311ef0a4c3d88f4885564 "$candidate"
do
  git -C "$BUILD_CHECKOUT" switch --detach "$rev"
  python3 "$CASE_ROOT/build.py" "$BUILD_CHECKOUT" "$rev" argmax
done
```

Use a benchmark environment containing psutil and the parent revision's maintained scripts on PYTHONPATH. Run on an idle machine. For a fresh replay, keep the sealed originals and create a separate case directory for the new samples. Each compare creates fresh observation directories and refuses existing ones.

```sh
export PYTHONPATH="$SCRIPT_CHECKOUT"
python "$CASE_ROOT/measure.py" argmax "$candidate" 7012b5b409553df04e29e6d7f9a11abf919cbf93
python "$CASE_ROOT/measure.py" argmax "$candidate" 596e28832c9829972a5311ef0a4c3d88f4885564
python "$CASE_ROOT/summarize.py"
```

The sealed worker binary hashes identify the measured artifacts. Independent local builds should preserve the source trees, flags, compiler, source path policy and adapter, and may produce different binary hashes on a different toolchain or filesystem. Acquisition time includes the startup, fixture, correctness oracle, resource intervals, all warmups and every formal pair. See protocol.md for sample counts and limits.
