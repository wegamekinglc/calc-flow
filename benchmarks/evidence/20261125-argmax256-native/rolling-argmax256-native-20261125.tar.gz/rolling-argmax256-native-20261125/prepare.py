from pathlib import Path
import shutil
import sys
here = Path(__file__).resolve().parent
shutil.copy2(here / "stage_argmax.rs", Path(sys.argv[1]) / "crates/calc-flow/examples/stage_argmax.rs")
