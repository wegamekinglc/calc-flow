# Frozen ASOF admission candidate

Freeze the candidate at #737 f8780771277e4dc78ed0efe8b9c04f31f7485d41, tree 5e197fffc00a17225dcc8fb8b17fea07a4de7208, parent 8b4fb0b5b809b04a5b3241f8b0e48fe57597b3ae. The release and #733 references, timing scopes, row/state oracles and limits remain those registered above.
