# ASOF admission index

Run the shipped Rust StreamAsofJoinOperator through its standard stream callbacks. The four right/left batch admissions are the primary measure. A later watermark settles and materializes the whole ten-column output. Inspect protocol.md and candidate-seal.md for the semantics, case size, registration, and exact revisions.

## Replay

Use the benchmark Python environment with psutil and the recorded candidate checkout on PYTHONPATH for the maintained resource and statistics helpers. Keep the registered build helper, adapter, and scripts together. Keep the acquisition folder separate when rerunning so previous observations remain immutable. The source adapter expects the repository history containing the fixed workload at a35ad02a.

```sh
export CARGO_BUILD_JOBS=2
export CARGO_TARGET_DIR="$CASE_ROOT/cargo"
candidate=$(cat "$CASE_ROOT/candidate.txt")
for rev in 7012b5b409553df04e29e6d7f9a11abf919cbf93 dce77f04b24cd62ae5c725ba33c0e335b2637ec9 "$candidate"
do
  git -C "$BUILD_CHECKOUT" switch --detach "$rev"
  python "$CASE_ROOT/build.py" "$BUILD_CHECKOUT" "$rev" admit
done

export PYTHONPATH="$SCRIPT_CHECKOUT"
python "$CASE_ROOT/measure.py" admit "$candidate" 7012b5b409553df04e29e6d7f9a11abf919cbf93
python "$CASE_ROOT/measure.py" admit "$candidate" dce77f04b24cd62ae5c725ba33c0e335b2637ec9
python "$CASE_ROOT/summarize.py"
```

Every worker confirms the expected pending/retained state before the watermark and all ordered matched rows and final right-state accounting afterward. The raw seconds field and the outcome's paired verdict concern admission. The watermark_seconds field and the summary's watermark quantiles are descriptive. Two previous fully qualified native binaries were reused. The three top-level receipts identify the original frozen sources, adapter, settings, library/executable artifacts and binary checksums.
