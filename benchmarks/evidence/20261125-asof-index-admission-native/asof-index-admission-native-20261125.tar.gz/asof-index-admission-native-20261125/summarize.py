"""Verify each paired acquisition and describe its independent watermark timing."""
from __future__ import annotations

import json
import statistics
from pathlib import Path

from scripts.toolkit import linear_percentile
from verify import verify

ROOT = Path(__file__).resolve().parent
HEAD = (ROOT / "candidate.txt").read_text().strip()
BASELINES = {
    "release": "7012b5b409553df04e29e6d7f9a11abf919cbf93",
    "prior": "dce77f04b24cd62ae5c725ba33c0e335b2637ec9",
}

def read(path):
    return json.loads(path.read_text())

def summarise(base):
    folder = ROOT / f"obs-admit-{base[:10]}-{HEAD[:10]}"
    result = verify(folder)
    if result["state"] != "complete":
        return result
    outcome = read(folder / "outcome.json")
    ident = read(folder / "identity.json")
    assert ident["base"] == base and ident["head"] == HEAD
    for side, commit in [("base", base), ("head", HEAD)]:
        receipt = read(folder / f"{side}.receipt.json")
        assert receipt["commit"] == commit and receipt["harness_sha256"] == ident["adapter_sha256"]
    rows = [json.loads(line) for line in (folder / "observations.jsonl").read_text().splitlines()]
    watermark = {}
    for side in ("base", "head"):
        values = [row["result"]["watermark_seconds"] * 1000 for row in rows if row["pair"] and row["side"] == side]
        watermark[side] = {"p50": statistics.median(values), "p95": linear_percentile(values, 0.95)}
    return {
        **result,
        "base": base,
        "head": HEAD,
        "admission_wall_ms": outcome["pooled_ms"],
        "admission_rounds": outcome["rounds"],
        "watermark_ms": watermark,
        "cpu": outcome["cpu"],
        "wall_seconds": outcome["wall_seconds"],
    }

if __name__ == "__main__":
    summary = {label: summarise(base) for label, base in BASELINES.items()}
    (ROOT / "summary.json").write_text(json.dumps(summary, indent=2, allow_nan=False) + "\n")
