"""Replay the fixed diagnostic against two already-qualified production wheels."""

from __future__ import annotations

import asyncio
import json
import os
import statistics
import subprocess
import sys
from pathlib import Path
from unittest.mock import patch

from scripts.sparse_changelog_ci import _resource, guarded_measure

from benchmarks.native_release_identity import verify_package_files
from benchmarks.native_slow_sink_diagnostics import ROLLING_STAGES
from scripts.benchmark_suite import measure
from scripts.benchmark_suite.catalog import engine_cases
from scripts.benchmark_suite.process import Worker, child_environment
from scripts.benchmark_suite.release import load_release
from scripts.benchmark_suite.report import ROUNDS, SAMPLES
from scripts.toolkit import sha256_file, write_json

HERE = Path(__file__).resolve().parent
REGISTER = json.loads((HERE / "protocol.json").read_text())
BASE = HERE.parent / "managed-runtime-20261124"
HARNESS = BASE / "round4-harness"
SIDES = ("baseline", "candidate")
CALLBACKS = ("data", "watermark", "end")


class DiagnosticWorker(Worker):
    @classmethod
    async def start(cls, site, root, *, source, polars_threads, tokio_threads):
        root.mkdir(parents=True, exist_ok=True)
        log = (root / "stderr.log").open("wb")
        try:
            env = child_environment(
                site,
                source=source,
                polars_threads=polars_threads,
                tokio_threads=tokio_threads,
            )
            process = await asyncio.create_subprocess_exec(
                sys.executable,
                str(HERE / "probe.py"),
                str(root),
                stdin=asyncio.subprocess.PIPE,
                stdout=asyncio.subprocess.PIPE,
                stderr=log,
                cwd=source,
                env={**env, "SMA20_WHEEL_SITE": str(site)},
            )
            return cls(process, log)
        except BaseException:
            log.close()
            raise


def qualify():
    def git(*args):
        return subprocess.check_output(
            ["git", "-C", str(HARNESS), *args], text=True
        ).strip()

    if git("rev-parse", "HEAD") != REGISTER["harness_sha"] or git(
        "status", "--porcelain"
    ):
        raise ValueError("maintained harness must be the clean registered revision")
    if Path(measure.__file__).resolve().parents[2] != HARNESS:
        raise ValueError("controller imported another harness")
    releases, sites, proofs = {}, {}, {}
    for side in SIDES:
        arm = REGISTER["arms"][side]
        manifest = BASE / "main-src/target/products" / arm["product"] / "release.json"
        release = load_release(manifest)
        proof = json.loads(
            (HARNESS / "target" / arm["qualification"] / "site-proof.json").read_text()
        )
        if any(
            release[k] != arm[k]
            for k in (
                "git_sha",
                "wheel_sha256",
                "native_sha256",
                "source_sha256",
                "cargo_lock_sha256",
            )
        ):
            raise ValueError(f"{side} production artifact differs from registration")
        if (
            proof["build"]["release"] != release
            or proof["environment"]["executable"] != sys.executable
        ):
            raise ValueError(f"{side} setup proof or interpreter differs")
        if (
            git("rev-parse", arm["git_sha"] + "^{tree}") != arm["tree"]
            or git("rev-parse", arm["comparison_sha"] + "^{tree}") != arm["tree"]
        ):
            raise ValueError(f"{side} comparison source differs from production tree")
        site = Path(proof["site"])
        verify_package_files(Path(release["wheel_path"]), site)
        releases[side], sites[side], proofs[side] = release, (site, HARNESS), proof
    a, b = (releases[s] for s in SIDES)
    if (
        a["command"][:-1] != b["command"][:-1]
        or any(a[k] != b[k] for k in ("python_executable", "python", "rustc"))
        or proofs["baseline"]["python_locks"] != proofs["candidate"]["python_locks"]
    ):
        raise ValueError("build, interpreter or dependency controls differ")
    return releases, sites, proofs


def summarize(row):
    def node(sample):
        (obs,) = sample["terminal"]["rolling_metrics"].values()
        return obs

    by_callback = {}
    for callback in CALLBACKS:
        result = {}
        for field in ("callback", *ROLLING_STAGES):
            key = field + "_duration_ns"
            per_round = []
            for group in row["evidence"]:
                sides = [
                    [node(item)[callback][key] / 1e6 for item in group["samples"][side]]
                    for side in SIDES
                ]
                left, right = sides
                deltas = [b - a for a, b in zip(left, right, strict=True)]
                per_round.append(
                    {
                        "baseline_median_ms": statistics.median(left),
                        "candidate_median_ms": statistics.median(right),
                        "paired_delta_median_ms": statistics.median(deltas),
                        "paired_delta_mean_ms": statistics.mean(deltas),
                    }
                )
            result[field] = per_round
        by_callback[callback] = result
    return {"public": row["result"], "terminal_callbacks": by_callback}


async def run(output):
    releases, sites, proofs = qualify()
    (case,) = (c for c in engine_cases(10_000_000) if c["id"] == REGISTER["case"])
    if (ROUNDS, SAMPLES) != (2, 10) or "batch_rows" in case:
        raise ValueError("unexpected maintained sample design or workload variant")
    write_json(
        output / "qualification.json",
        {
            "case": case,
            "arms": proofs,
            "protocol_sha256": sha256_file(HERE / "protocol.json"),
            "scripts": {
                p.name: sha256_file(p) for p in (HERE / "run.py", HERE / "probe.py")
            },
            "initial_affinity": sorted(os.sched_getaffinity(0)),
        },
    )
    cpu = await _resource(output / "resources.jsonl", None)
    os.sched_setaffinity(0, {cpu})
    with patch.object(measure, "Worker", DiagnosticWorker):
        row = await guarded_measure(output, cpu, case, sites, releases)
    write_json(output / "samples.json", row)
    if row["status"] != "ok":
        raise RuntimeError(row["error"])
    write_json(output / "summary.json", summarize(row))


if __name__ == "__main__":
    out = Path(sys.argv[1]).resolve()
    out.mkdir(parents=True, exist_ok=False)
    try:
        asyncio.run(asyncio.wait_for(run(out), timeout=REGISTER["active_seconds"]))
    except BaseException as error:
        write_json(out / "failure.json", {"error": repr(error)})
        raise
