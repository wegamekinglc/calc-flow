"""One registered SMA20 worker with two outside-clock observations."""

from __future__ import annotations

import os
import sys
from pathlib import Path
from unittest.mock import patch

from benchmarks import engine_stream
from benchmarks.native_slow_sink_diagnostics import (
    _check_bounds,
    _check_health,
    _rolling_settled,
)
from scripts.benchmark_suite import worker

ROWS = 10_000_000
FINITE = ROWS - 64 * 19


def snapshot(job):
    status = job.status()
    _check_health(status)
    if len(status["rolling_metrics"]) != 1:
        raise ValueError("expected one managed rolling operator")
    fields = (
        "state",
        "terminal_cause",
        "task_errors",
        "metrics_overflowed",
        "sources",
        "operators",
        "sinks",
        "edges",
        "checkpoint",
        "rolling_metrics",
    )
    return {key: status[key] for key in fields}


def terminal_proof(status, correctness):
    _check_bounds(status, drained=True)
    if (status["state"], status["terminal_cause"]) != ("completed", "natural_end"):
        raise ValueError("sample did not finish naturally")
    if not _rolling_settled(status):
        raise ValueError("terminal callback work is unfinished")
    (source,) = status["sources"].values()
    (sink,) = status["sinks"].values()
    (rolling,) = status["rolling_metrics"].values()
    if (
        not source["ended"]
        or not sink["ended"]
        or source["data_rows"] != ROWS
        or source["data_batches"] != 10
        or sink["delivered_rows"] != ROWS
        or rolling["data"]["input_rows"] != ROWS
        or correctness["passed"] is not True
        or correctness["rows"] != ROWS
        or correctness["finite_rows"] != FINITE
    ):
        raise ValueError("incomplete maintained oracle, input or delivery evidence")


def serve(root):
    clock = engine_stream._measure_ready_clock
    dispatch = worker.dispatch
    observations = []

    async def capture(bindings, **options):
        result = await clock(bindings, **options)
        before_eof = snapshot(bindings.job)
        if any(
            before_eof["checkpoint"][key] is not None
            for key in ("current_epoch", "last_completed_epoch")
        ):
            raise ValueError("unexpected nonterminal checkpoint")
        observations.append((bindings.job, before_eof))
        return result

    def recorded(message, active, worker_root):
        response, active = dispatch(message, active, worker_root)
        if message["operation"] in ("prepare", "sample"):
            ((job, before_eof),) = observations
            observations.clear()
            ended = snapshot(job)
            warm = message["operation"] == "prepare"
            sample = response["warmup"] if warm else response
            terminal_proof(ended, sample["correctness"])
            sample = {**sample, "before_eof": before_eof, "terminal": ended}
            response = {**response, "warmup": sample} if warm else sample
        return response, active

    import calc_flow
    from calc_flow import _native

    expected = Path(os.environ["SMA20_WHEEL_SITE"]).resolve() / "calc_flow"
    if any(Path(m.__file__).resolve().parent != expected for m in (calc_flow, _native)):
        raise ValueError("worker imported a different installed package")
    with (
        patch.object(engine_stream, "_measure_ready_clock", capture),
        patch.object(worker, "dispatch", recorded),
    ):
        worker.main(root)


if __name__ == "__main__":
    serve(Path(sys.argv[1]))
