"""Seal the raw requests and environment from the completed measurement."""

from __future__ import annotations

import gzip
import hashlib
import io
import json
import tarfile
from pathlib import Path

HERE = Path(__file__).resolve().parent


def save(archive, name, data):
    rec = tarfile.TarInfo(name)
    rec.size = len(data)
    rec.mode = 0o644
    archive.addfile(rec, io.BytesIO(data))


def main():
    raw = HERE / "observed"
    paths = [
        HERE / name
        for name in (
            "protocol.json",
            "run.py",
            "probe.py",
            "README.md",
            "seal.py",
            "replay.py",
        )
    ]
    paths.extend(
        raw / name
        for name in (
            "qualification.json",
            "resources.jsonl",
            "samples.json",
            "summary.json",
        )
    )
    for r in range(2):
        for side in ("baseline", "candidate"):
            worker = raw / "measurement" / f"round-{r}" / side
            paths.extend(worker.glob("request-*.started.json"))
            paths.extend(worker.glob("request-*.completed.json"))
            paths.extend(worker.glob("worker-request-*.json"))
            paths.append(worker / "stderr.log")
    with (
        (HERE / "raw.tar.gz").open("xb") as handle,
        gzip.GzipFile(fileobj=handle, mode="wb", mtime=0) as gz,
        tarfile.open(fileobj=gz, mode="w|") as archive,
    ):
        hashes = {}
        for p in sorted(paths):
            name = p.relative_to(HERE).as_posix()
            data = p.read_bytes()
            hashes[name] = hashlib.sha256(data).hexdigest()
            save(archive, name, data)
        save(
            archive,
            "hashes.json",
            (json.dumps(hashes, indent=2, sort_keys=True) + "\n").encode(),
        )


if __name__ == "__main__":
    main()
