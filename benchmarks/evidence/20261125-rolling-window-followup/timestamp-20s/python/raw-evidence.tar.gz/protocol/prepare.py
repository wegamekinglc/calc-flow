"""Prepare a focused overlay of the maintained public comparison workload."""
from pathlib import Path
T=Path(__file__).resolve().parent
R=T.parents[1]
W=T/"worker"
(W/"benchmarks").mkdir(exist_ok=True,parents=True)
def link(src,dst):
    if not dst.is_symlink():dst.symlink_to(src)
link(R/"scripts",W/"scripts")
for src in (R/"benchmarks").glob("*.py"):
    if src.name not in {"engine_stream.py","engine_comparison.py"}:link(src,W/"benchmarks"/src.name)
stream=(R/"benchmarks/engine_stream.py").read_text()
stream=stream.replace('    exact_time,','    exact_time,\n    duration,')
stream=stream.replace('    if scenario in ("sma20", "dual_sma"):', '''    if scenario == "time_window_20s":
        value = ts.mean(quotes["price"], window=duration(20_000_000), min_periods=1)
        return quotes.with_columns(FeatureSet((("value",value),)))
    if scenario in ("sma20", "dual_sma"):''',1)
i=stream.index('async def run_stream(')
stream=stream[:i]+'''class _DurationSource(_ReadySource):
    def __init__(self):
        super().__init__()
        self.data_count = 0
        self.watermark_count = 0
        self.eof_count = 0

    async def next(self):
        event = await super().next()
        if isinstance(event, Data):
            self.data_count += 1
        elif isinstance(event, Watermark):
            self.watermark_count += 1
        elif event is None:
            self.eof_count += 1
        return event


class _DurationSink(_CollectSink):
    def __init__(self, rows):
        super().__init__(rows)
        self.closed_count = 0

    async def close(self):
        self.closed_count += 1


async def run_duration_stream(plan, events, expected_rows):
    # Let EOF release the last tick before the timed sink wait. The maintained
    # controller otherwise waits for all rows before sending EOF.
    if len(events)!=21 or events[-1] is not None:
        raise ValueError("expected ten data-watermark pairs followed by EOF")
    for data, watermark in zip(events[0:-1:2],events[1:-1:2],strict=True):
        if not isinstance(data,Data) or data.batch.num_rows!=1_000_000 or not isinstance(watermark,Watermark):
            raise ValueError("unexpected data/watermark inventory")
    source=_DurationSource()
    sink=_DurationSink(expected_rows)
    job=await StreamingRunner(plan,{"input":SourceBinding(source,watermark_policy=SourceProvidedWatermarks())},
        {"output":[SinkBinding.ordinary("duration",sink)]},None,
        config=StreamRuntimeConfig(checkpointing=False,edge_budget=EdgeBudget(max_rows=1_000_000,max_bytes=64<<20))).start_async()
    async def deliver():
        await asyncio.wait_for(source.ready.wait(),timeout=30)
        _require_ready_sources({"input":source},sink)
        started=time.perf_counter_ns()
        for event in events[:-1]:
            await source.push(event)
        before_eof=sink.rows
        await source.push(None)
        await sink.complete.wait()
        table=pa.concat_tables(sink.tables)
        elapsed=(time.perf_counter_ns()-started)/1e9
        return table,elapsed,before_eof
    try:
        table,seconds,before=await run_with_completion(deliver(),job.wait_async())
        if (table.num_rows,sink.rows,source.data_count,source.watermark_count,source.eof_count,sink.closed_count)!=(expected_rows,expected_rows,10,10,1,1):
            raise ValueError("terminal counts differ from the matching Rust fixture")
        return table,seconds,{"before_eof_enqueue_rows":before,"post_eof_rows":sink.rows,"timed_rows":table.num_rows,
            "input_batches":source.data_count,"watermarks":source.watermark_count,"eof":source.eof_count,"sink_closures":sink.closed_count,
            "output_batch_sizes":[t.num_rows for t in sink.tables]}
    finally:
        await job.cancel_async()


'''+stream[i:]
# This isolated adapter runs only the duration case on both endpoints.
lo=stream.index('        micros = int(pc.max(part["event_time"]).value) + 1')
hi=stream.index('        events.append(',lo)
stream=stream[:lo]+'''        micros = int(pc.max(part["event_time"]).value) - 1
'''+stream[hi:]
(W/"benchmarks/engine_stream.py").write_text(stream)
comp=(R/"benchmarks/engine_comparison.py").read_text().replace('    run_stream,','    run_stream,\n    run_duration_stream,')
comp=comp.replace('    table = pa.Table.from_batches(table.to_batches(max_chunksize=TABLE_BATCH_ROWS))','''    if scenario == "time_window_20s":
        ticks = sequence.astype(np.int64)//64
        micros=1767225600000000+(ticks+ticks//7)*1_000_000
        table=table.set_column(0,table.schema.field("event_time"),pa.array(micros,type=pa.timestamp("us",tz="UTC")))
    table = pa.Table.from_batches(table.to_batches(max_chunksize=TABLE_BATCH_ROWS))''')
pos=comp.index('    if scenario in table_oracles:')
comp=comp[:pos]+'''    if scenario == "time_window_20s":
        ts=table["event_time"].cast(pa.int64()).to_numpy()[::64]
        left=np.searchsorted(ts,ts-20_000_000,side="right")
        ticks=np.arange(len(ts),dtype=np.int64)
        if int(np.isin(ts-20_000_000,ts,assume_unique=True).sum())!=133914 or int((np.diff(left)==2).sum())!=22319 or (ticks-left+1)[[17,18,21]].tolist()!=[18,18,17]:
            raise ValueError("duration boundaries differ from native fixture")
        expectation=np.empty(len(sequence),dtype=np.float64)
        for key in range(64):
            exact=800+sequence[key::64].astype(np.int64)%257+key
            prefix=np.empty(len(exact)+1,dtype=np.int64)
            prefix[0]=0
            np.cumsum(exact,out=prefix[1:])
            expectation[key::64]=(prefix[1:]-prefix[left])/((ticks+1-left)*8)
        return table.append_column(pa.field("value",pa.float64(),nullable=True),pa.array(expectation))
'''+comp[pos:]
comp=comp.replace('        if scenario not in CAPABILITIES[backend]:','        if scenario != "time_window_20s" or backend != "calc-flow-stream-1t":')
comp=comp.replace('        plan = stream_plan(self.case["scenario"], self.data.table, self.data.dimension)','''        plan = stream_plan(self.case["scenario"], self.data.table, self.data.dimension)
        if self.case["scenario"]=="time_window_20s":
            return self.loop.run_until_complete(run_duration_stream(plan,self.events,self.expected.num_rows))''')
comp=comp.replace('        if set(result.column_names) != set(self.expected.column_names):','''        if self.case["scenario"]=="time_window_20s":
            if not result.schema.equals(self.expected.schema) or not result["sequence"].equals(self.expected["sequence"]):
                raise ValueError("duration output schema or physical sequence differs")
        if set(result.column_names) != set(self.expected.column_names):''')
(W/"benchmarks/engine_comparison.py").write_text(comp)
