# Frozen Rust duration20 main

The candidate is the initial merge of #740 into main, e1d9ccd3fd72cb20668e06891cb49e1fbfd4d75a, tree fb5f4eeeef699f50797324645f566225b9c70b7e and core source 88d23ed6e61efb207cafbf660460a9bc54f48b1c. The baseline is release 7012b5b409553df04e29e6d7f9a11abf919cbf93. Both use the same duration20 adapter frozen before either build. See protocol.md for the single registered acquisition and oracle.
