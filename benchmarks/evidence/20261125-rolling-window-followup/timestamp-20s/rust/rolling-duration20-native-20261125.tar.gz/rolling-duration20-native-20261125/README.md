# Native Rust duration mean

The public StreamingRunner receives ten one-million-row batches under an interleaved 64-key clock with a gap every seven ticks. The rolling interval is (current timestamp minus 20 seconds, current timestamp], min_periods one. The timed operation spans first source delivery through final output delivery. See protocol.md for boundary geometry, resource rules and the capped release-to-main comparison.

To replay from sealed sources in a disposable checkout, use the same checkout and CARGO_TARGET_DIR for both arms with CARGO_BUILD_JOBS=2. Set PYTHONPATH to the repository revision given in harness-environment.json with the exact maintained scripts. Use a Python installation with psutil. Keep the original evidence immutable and replay in a clean scratch folder.

```sh
candidate=$(cat "$CASE_ROOT/candidate.txt")
for rev in 7012b5b409553df04e29e6d7f9a11abf919cbf93 "$candidate"
do
  git -C "$BUILD_CHECKOUT" switch --detach "$rev"
  python "$CASE_ROOT/build.py" "$BUILD_CHECKOUT" "$rev" duration20
done
python "$CASE_ROOT/measure.py" duration20 "$candidate" 7012b5b409553df04e29e6d7f9a11abf919cbf93
python "$CASE_ROOT/summarize.py"
```
