from pathlib import Path
import shutil
import sys
here = Path(__file__).resolve().parent
shutil.copy2(here / "stage_duration20.rs", Path(sys.argv[1]) / "crates/calc-flow/examples/stage_duration20.rs")
