set -eu
while test ! -f bound.json || test ! -f ../asof-combined-watermark-10m-nov25/run.exit; do sleep 5; done
sha256sum --quiet -c registered.sha256
head=$(python3 -c 'import json;print(json.load(open("bound.json"))["candidate"])')
parent=$(git -C parent-source rev-parse HEAD)
release=7012b5b409553df04e29e6d7f9a11abf919cbf93
source=$(realpath ../rolling-average-native-nov25/source)
export CARGO_TARGET_DIR=$(realpath ../rolling-average-native-nov25/cargo)
export CARGO_BUILD_JOBS=2
candidate=$(realpath ../rolling-unique-state-nov25)
test "$(git -C "$candidate" rev-parse HEAD)" = "$head"
test "$(git -C "$candidate" rev-parse HEAD^^)" = "$parent"
for rev in "$release" "$parent" "$head"; do
 git -C "$source" diff --quiet
 git -C "$source" switch -q --detach "$rev"
 python3 build.py "$source" "$rev" unique64
done
bench=$1
py=$2
harness=$3
native_scripts=$4
products="$harness/../main-src/target/products"
for arm in parent candidate; do
 if test "$arm" = parent; then wsrc=$PWD/parent-source; else wsrc="$candidate"; fi
 out=$PWD/$arm-wheel
 mkdir -p "$out"
 ln -s "$(realpath "$products/../cargo")" "$out/cargo"
 touch "$wsrc/crates/calc-flow/src/lib.rs" "$wsrc/crates/calc-flow-python/src/lib.rs"
 PYTHONPATH="$wsrc" "$bench" -m scripts.benchmark_suite build --source "$wsrc" --output "$out" >"$out/build-driver.log" 2>&1
done
while ps -e -o stat=,comm= | awk '$2 ~ /^(rustc|rust-lld|cargo-clippy|clippy-driver)$/ && $1 !~ /^[TZ]/ {found=1} END {exit !found}'; do sleep 2; done
export PYTHONPATH="$native_scripts"
for arm in release main; do
 if test "$arm" = release; then base="$release"; else base="$parent"; fi
 rc=0
 "$py" measure.py unique64 "$head" "$base" >"native-$arm.log" 2>&1 || rc=$?
 echo "$rc" >"native-$arm.exit"
done
"$py" summarize.py >native-summary.log
export PYTHONPATH="$harness"
scope="$harness/target/unique-rows-10m"
for arm in main release; do
 if test "$arm" = main; then base="$PWD/parent-wheel/release.json"; else base="$products/release-1114/release.json"; fi
 cmp "wheel-$arm.py" "$scope/${arm}_compare.py"
 rc=0
 "$bench" "$scope/${arm}_compare.py" unique64 --baseline "$base" --candidate "$PWD/candidate-wheel/release.json" --candidate-source "$candidate" --output "$PWD/public-$arm" --sha "$head" >"public-$arm.log" 2>&1 || rc=$?
 echo "$rc" >"public-$arm.exit"
done
