"""Replay and seal both rolling Unique64 entry points against release and parent."""
import hashlib,json,statistics,tarfile
from pathlib import Path
from scripts.benchmark_suite.report import _paired_verdict
from scripts.benchmark_suite.statistics import paired_round
from scripts.toolkit import linear_percentile

r=Path(__file__).resolve().parent
read=lambda p:json.loads(p.read_text())
lines=lambda p:[json.loads(s) for s in p.read_text().splitlines()]
summary=read(r/'summary.json')
binding=read(r/'bound.json')
proof={'native':summary,'python':{}}
files=set()
for pat in ('*.py','*.rs','*.sh','*.md','*.sha256','*.json','*.txt','*.exit','*.stderr'):
    files.update(r.glob(pat))
files = {p for p in files if not p.name.startswith('ci-') and p.name not in ('recover-pr-ci.py','file-hashes.txt')}
for p in r.glob('obs-unique64-*'):files.update(x for x in p.glob('*.json*') if x.is_file())
for p in r.glob('*-wheel'): files.update(x for x in p.glob('*') if x.is_file() and x.suffix in ('.json','.log'))
rows=[]
def num(v):return f'{v:.3f}' if v is not None else '—'
for base in ['release','main']:
    val=summary[base]
    stats=val.get('pooled_ms',{})
    rows.append(('Rust',base,*[stats.get(side,{}).get(q) for q in ('p50','p95') for side in ('base','head')],val.get('verdict','stopped')))
    d=r/('public-'+base);out=read(d/'outcome.json');detail={'outcome':out};proof['python'][base]=detail
    files.update(f for f in d.rglob('*') if f.is_file() and 'site' not in f.relative_to(d).parts and f.suffix in ('.json','.jsonl','.log'))
    observations={'prepare':0,'sample':0}
    def check(x):
        assert x['seconds']>0 and x['correctness']==dict(passed=True,rows=10_000_000,finite_rows=10_000_000,max_abs_error=0.)
    for f in (d/'measurement').rglob('*.completed.json'):
        req=read(f);res=req.get('response',{});v=res.get('warmup',res)
        if 'seconds' in v and 'correctness' in v:
            check(v);observations[req['operation']]+=1
    detail['accepted']=observations
    if out['state']!='completed':
        rows.append(('Python',base,None,None,None,None,'stopped'));continue
    data=read(d/'samples.json');res=read(d/'result.json');detail['result']=res
    assert observations=={'prepare':4,'sample':40}
    assert res['oracle_checked_executions']==44 and res['largest_reported_absolute_error']==0 and len(res['cpus'])==1
    assert all(all(x['suitable'] for x in v['cores']) for v in lines(d/'resources.jsonl'))
    series={s:[] for s in ('baseline','candidate')};ci=[]
    for ev in data['evidence']:
        assert ev['environment']['cpu_affinity']==res['cpus']
        vs={}
        for side in series:
            values=ev['samples'][side];assert len(values)==10
            for v in values:check(v)
            vs[side]=[v['seconds'] for v in values];series[side]+=vs[side]
        ci.append(paired_round(vs['baseline'],vs['candidate']))
    assert ci==res['round_intervals'] and _paired_verdict(ci)==res['verdict']
    q=[statistics.median(v) for v in series.values()]+[linear_percentile(v,.95) for v in series.values()]
    assert q==[res[k] for k in ('base_p50','head_p50','base_p95','head_p95')]
    rows.append(('Python',base,*[x*1e3 for x in q],res['verdict']))
dest=r/'product-export';dest.mkdir(exist_ok=True)
p=r/'results.json';p.write_text(json.dumps(proof,indent=2,allow_nan=False)+'\n');files.add(p)
h=lambda f:hashlib.file_digest(f,'sha256').hexdigest()
manifest=r/'file-hashes.txt'
manifest.write_text(''.join(h(p.open('rb'))+'  '+str(p.relative_to(r))+'\n' for p in sorted(files)));files.add(manifest)
archive=dest/'unique64-10m-raw.tar.gz'
with tarfile.open(archive,'w:gz') as z:
    for f in sorted(files):z.add(f,arcname=str(f.relative_to(r)),recursive=False)
with tarfile.open(archive) as z:
    assert all(h(z.extractfile(str(f.relative_to(r))))==h(f.open('rb')) for f in files)
cells=[['Surface','Baseline','Baseline p50','Candidate p50','Baseline p95','Candidate p95','Paired verdict']]
for surface,base,*times,verdict in rows:
    cells.append([surface,{'release':'11.14','main':'parent'}[base],*[num(t) for t in times],verdict])
widths=[max(map(len,col)) for col in zip(*cells)]
line=lambda row:'| '+' | '.join(v.ljust(w) for v,w in zip(row,widths))+' |'
table=[line(cells[0]),'|'+'|'.join('-'*(w+2) for w in widths)+'|',*[line(row) for row in cells[1:]]]
markdown=['# Rolling distinct count at 10 million rows','','Single worker, 64 interleaved string keys, 64-row Float64 distinct-count window. Release 7012b5b4 and pre-PR parent '+binding['comparison_parent']+' were compared separately against '+binding['candidate']+'. All timings are in milliseconds. Rust uses the native runner with checkpointing off and validates physical sequence, source fields, every UInt64 output and terminal closure. The independently installed Python products use the default managed stream and validate all rows and values after sorting by sequence. Its clock covers ready enqueue through Arrow delivery. Each completed group contains four excluded warmups and two rounds of ten adjacent paired observations.','',*table,'',f'[Raw resource and correctness evidence, controllers, source identities and replay]({archive.name}), SHA-256 '+h(archive.open('rb'))+'.','']
(dest/'README.md').write_text('\n'.join(markdown));(dest/'results.json').write_bytes(p.read_bytes())
