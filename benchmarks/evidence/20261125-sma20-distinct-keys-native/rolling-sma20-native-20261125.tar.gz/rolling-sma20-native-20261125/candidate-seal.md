# Frozen SMA20 candidate

The candidate is product #738 commit 6916514e06dcf8361f44574e08874781cbc26c1d, tree 082c6b5701fbb1fc0d21cbfab0e33b21522f613f. Compare it to release 7012b5b409553df04e29e6d7f9a11abf919cbf93 and pre-change main e87b138fc37aae4d21d8e498833dca5b9e3b99e1. The two source baselines and all samples and validation scopes were fixed in protocol.md before this commit was sealed.
