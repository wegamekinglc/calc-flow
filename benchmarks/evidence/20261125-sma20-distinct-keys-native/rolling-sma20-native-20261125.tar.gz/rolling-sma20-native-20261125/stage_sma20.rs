// Adapted from calc-flow's benches/core.rs public StreamingRunner source and sink.
// Input and oracle follow benchmarks/engine_comparison.py and benchmarks/warm_stream.py.
use async_trait::async_trait;
use calc_flow::{
    Batch, BatchMetadata, Cursor, DeliveryGuarantee, EdgeBudget, EventTime, JobState,
    NativeWatermarkCapability, PipelineBuilder, ReplayPositioning, Result, RollingOperator,
    RollingSpec, SinkBinding, SourceBinding, SourceCapabilities, SourceDeliveryCapability,
    SourceEvent, SourceSchema, StreamRequirements, StreamRuntimeConfig, StreamSink, StreamSource,
    StreamingRunner, UdfRegistry,
};
use datafusion::arrow::{
    array::{Array, Float64Array, StringArray, TimestampMicrosecondArray, UInt64Array},
    datatypes::{DataType, Field, Schema, SchemaRef, TimeUnit},
    record_batch::RecordBatch,
};
use serde_json::json;
use std::{
    collections::{BTreeMap, VecDeque},
    sync::{Arc, Mutex, OnceLock},
    time::Instant,
};

const BATCH_ROWS: usize = 1_000_000;
const ROWS: usize = 10_000_000;
const WINDOW: usize = 20;
const KEYS: usize = 64;
const BASE: i64 = 1_767_225_600_000_000;
const BYTES: usize = 64 << 20;

fn timestamp(row: usize) -> i64 {
    BASE + (row / KEYS) as i64 * 1_000_000
}
fn price(row: usize) -> f64 {
    100.0 + (row % 257) as f64 / 8.0 + (row % KEYS) as f64 / 8.0
}

fn fixture() -> (SchemaRef, VecDeque<Batch>) {
    let names = (0..KEYS)
        .map(|key| format!("S{key:03}"))
        .collect::<Vec<_>>();
    let schema = Arc::new(Schema::new(vec![
        Field::new(
            "event_time",
            DataType::Timestamp(TimeUnit::Microsecond, Some("UTC".into())),
            false,
        ),
        Field::new("sequence", DataType::UInt64, false),
        Field::new("symbol", DataType::Utf8, false),
        Field::new("price", DataType::Float64, false),
    ]));
    let batches = (0..ROWS)
        .step_by(BATCH_ROWS)
        .map(|start| {
            let range = start..(start + BATCH_ROWS).min(ROWS);
            let record = RecordBatch::try_new(
                schema.clone(),
                vec![
                    Arc::new(
                        TimestampMicrosecondArray::from_iter_values(range.clone().map(timestamp))
                            .with_timezone("UTC"),
                    ),
                    Arc::new(UInt64Array::from_iter_values(
                        range.clone().map(|row| row as u64),
                    )),
                    Arc::new(StringArray::from_iter_values(
                        range.clone().map(|row| names[row % KEYS].as_str()),
                    )),
                    Arc::new(Float64Array::from_iter_values(range.map(price))),
                ],
            )
            .unwrap();
            Batch::table(vec![record], BatchMetadata::default()).unwrap()
        })
        .collect();
    (schema, batches)
}

struct Source {
    batches: VecDeque<Batch>,
    emitted: usize,
    schema: SchemaRef,
    watermark: Option<EventTime>,
    start: Arc<OnceLock<Instant>>,
}
#[async_trait]
impl StreamSource for Source {
    fn capabilities(&self) -> SourceCapabilities {
        SourceCapabilities {
            replay_positioning: ReplayPositioning::Unsupported,
            delivery: SourceDeliveryCapability::Lossy,
            max_batch_rows: BATCH_ROWS,
            max_batch_bytes: BYTES,
            schema: SourceSchema::Exact(self.schema.clone()),
            native_watermarks: NativeWatermarkCapability::EmitsNative,
        }
    }
    async fn open(&mut self, cursor: Option<Cursor>) -> Result<()> {
        assert!(cursor.is_none());
        Ok(())
    }
    async fn next(&mut self) -> Result<Option<SourceEvent>> {
        if let Some(mark) = self.watermark.take() {
            return Ok(Some(SourceEvent::Watermark(mark)));
        }
        let Some(batch) = self.batches.pop_front() else {
            return Ok(None);
        };
        if self.emitted == 0 {
            self.start.set(Instant::now()).unwrap();
        }
        self.emitted += batch.num_rows();
        let cursor = Cursor::unbound(
            (self.emitted as u64).to_be_bytes().to_vec(),
            BTreeMap::new(),
        )?;
        self.watermark = Some(EventTime::from_micros(timestamp(self.emitted - 1) - 1));
        Ok(Some(SourceEvent::Data { batch, cursor }))
    }
    async fn close(&mut self) -> Result<()> {
        Ok(())
    }
}
#[derive(Default)]
struct Output {
    rows: usize,
    batches: Vec<Batch>,
    end: Option<Instant>,
}
struct Sink(Arc<Mutex<Output>>);
#[async_trait]
impl StreamSink for Sink {
    async fn open(&mut self) -> Result<()> {
        Ok(())
    }
    async fn write(&mut self, batch: &Batch) -> Result<()> {
        let mut output = self.0.lock().unwrap();
        output.rows += batch.num_rows();
        output.batches.push(batch.clone());
        if output.rows == ROWS {
            assert!(output.end.replace(Instant::now()).is_none());
        }
        Ok(())
    }
    async fn close(&mut self) -> Result<()> {
        Ok(())
    }
}

#[tokio::main(flavor = "current_thread")]
async fn main() {
    let (schema, batches) = fixture();
    let mut fields = schema.fields().to_vec();
    fields.push(Arc::new(Field::new("value", DataType::Float64, true)));
    let expected_schema = Schema::new(fields);
    let spec: RollingSpec = serde_json::from_value(json!({
        "configuration_version":1,"state_layout_version":2,
        "partition_by":["symbol"],"event_time":"event_time","sequence_by":["sequence"],
        "outputs":[{"kind":"mean","frame":{"kind":"rows","size":WINDOW},"primitive_version":1,"input":"price","output":"value","min_periods":WINDOW}],
        "allowed_lateness_micros":0,"late_policy":{"kind":"error","scope":"envelope"},
        "value_policy":"stateful_numeric_v1"
    })).unwrap();
    let plan = PipelineBuilder::new("rolling-sma20")
        .unwrap()
        .add_node(
            "rolling",
            Box::new(RollingOperator::new("rolling", schema.clone(), spec).unwrap()),
        )
        .unwrap()
        .compile_stream(
            &UdfRegistry::new().snapshot(),
            &StreamRequirements {
                delivery: BTreeMap::from([("output".into(), DeliveryGuarantee::BestEffort)]),
            },
        )
        .unwrap();
    let start = Arc::new(OnceLock::new());
    let output = Arc::new(Mutex::new(Output::default()));
    let source = Source {
        batches,
        emitted: 0,
        schema,
        watermark: None,
        start: start.clone(),
    };
    let runner = StreamingRunner::without_checkpoints(
        plan,
        BTreeMap::from([("input".into(), SourceBinding::new(source))]),
        BTreeMap::from([(
            "output".into(),
            vec![SinkBinding::ordinary("collector", Sink(output.clone())).unwrap()],
        )]),
    )
    .unwrap()
    .with_runtime_config(StreamRuntimeConfig {
        checkpointing: false,
        edge_budget: EdgeBudget::new(BATCH_ROWS, BYTES).unwrap(),
        ..Default::default()
    })
    .unwrap();
    let job = runner.start().await.unwrap();
    let outcome = job.wait().await;
    assert_eq!(outcome.state, JobState::Completed, "{outcome:?}");
    let observed = output.lock().unwrap();
    assert_eq!(observed.rows, ROWS);
    let seconds = observed
        .end
        .unwrap()
        .duration_since(*start.get().unwrap())
        .as_secs_f64();
    let symbols: Vec<_> = (0..KEYS).map(|key| format!("S{key:03}")).collect();
    // The fixture prices are exact eighths. Sum integer units independently
    // and remove the quote exactly twenty entity ticks back, even across batches.
    let units = |row: usize| (800 + row % 257 + row % KEYS) as u64;
    let mut sums = [0_u64; KEYS];
    let mut nulls = 0;
    let mut rows = 0;
    for batch in &observed.batches {
        for record in batch.table_payload().unwrap().batches() {
            assert_eq!(record.schema().as_ref(), &expected_schema);
            let seq = record
                .column(1)
                .as_any()
                .downcast_ref::<UInt64Array>()
                .unwrap();
            let time = record
                .column(0)
                .as_any()
                .downcast_ref::<TimestampMicrosecondArray>()
                .unwrap();
            let keys = record
                .column(2)
                .as_any()
                .downcast_ref::<StringArray>()
                .unwrap();
            let quotes = record
                .column(3)
                .as_any()
                .downcast_ref::<Float64Array>()
                .unwrap();
            let means = record
                .column(4)
                .as_any()
                .downcast_ref::<Float64Array>()
                .unwrap();
            assert!(
                [
                    seq.null_count(),
                    time.null_count(),
                    keys.null_count(),
                    quotes.null_count()
                ]
                .iter()
                .all(|&n| n == 0)
            );
            nulls += means.null_count();
            for i in 0..record.num_rows() {
                let key = rows % KEYS;
                let tick = rows / KEYS;
                assert_eq!(seq.value(i), rows as u64);
                assert_eq!(time.value(i), timestamp(rows));
                assert_eq!(keys.value(i), symbols[key].as_str());
                assert_eq!(quotes.value(i).to_bits(), price(rows).to_bits());
                sums[key] += units(rows);
                if tick >= WINDOW {
                    sums[key] -= units(rows - KEYS * WINDOW);
                }
                if tick < WINDOW - 1 {
                    assert!(means.is_null(i), "premature SMA at row {rows}");
                } else {
                    assert!(means.is_valid(i), "missing SMA at row {rows}");
                    let expected = sums[key] as f64 / (8 * WINDOW) as f64;
                    assert!(
                        (means.value(i) - expected).abs() <= 1e-10 + 1e-10 * expected.abs(),
                        "SMA at row {rows}"
                    );
                }
                rows += 1;
            }
        }
    }
    assert_eq!(rows, ROWS);
    assert_eq!(nulls, KEYS * (WINDOW - 1));
    println!(
        "{}",
        json!({"seconds":seconds,"validated_all_rows":true,"output_rows":rows,
        "validated_schema":true,"validated_input_columns":true,"warmup_nulls":nulls,"valid_output_rows":ROWS-nulls,"keys":KEYS,"input_batches": ROWS / BATCH_ROWS, "input_batch_rows": BATCH_ROWS,"emitted_batches":observed.batches.len(),"closed":true})
    );
}
