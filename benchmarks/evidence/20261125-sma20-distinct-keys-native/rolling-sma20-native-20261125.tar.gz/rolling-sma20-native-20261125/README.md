# Native Rust SMA20

This experiment uses the public single-threaded StreamingRunner with an unmodified, normal RollingOperator. Input schema, names, exact-eighth prices, 64-way interleaving, UTC times, raw sequences and minimum periods match the maintained public SMA20 scenario. The Rust plan appends a nullable Float64 result to the original four columns and pushes ten batches of one million rows with native watermarks. It measures first source delivery through the final output received at the Arrow sink.

Open protocol.md and candidate-seal.md for the budgets, revision identities and exact workload. After each worker clock, the independent integer oracle checks the five-field schema, all ten million raw input rows, all 1,216 expected null positions and all 9,998,784 valid means.

## Rebuild and replay

Use a disposable worktree for product builds and the same path across all three revisions. Keep build outputs below target/. On an idle host use a Python with psutil and the maintained statistics/resource scripts from the recorded revision on PYTHONPATH. Keep immutable originals separate from fresh observation directories. The build receipts identify the uninstrumented ordinary core, fixed adapter, compiler, frozen dependencies, flags and resulting binaries.

```sh
export CARGO_BUILD_JOBS=2
export CARGO_TARGET_DIR="$CASE_ROOT/cargo"
candidate=$(cat "$CASE_ROOT/candidate.txt")
for rev in 7012b5b409553df04e29e6d7f9a11abf919cbf93 e87b138fc37aae4d21d8e498833dca5b9e3b99e1 "$candidate"
do
  git -C "$BUILD_CHECKOUT" switch --detach "$rev"
  python "$CASE_ROOT/build.py" "$BUILD_CHECKOUT" "$rev" sma20
done

export PYTHONPATH="$SCRIPT_CHECKOUT"
python "$CASE_ROOT/measure.py" sma20 "$candidate" 7012b5b409553df04e29e6d7f9a11abf919cbf93
python "$CASE_ROOT/measure.py" sma20 "$candidate" e87b138fc37aae4d21d8e498833dca5b9e3b99e1
python "$CASE_ROOT/summarize.py"
```
