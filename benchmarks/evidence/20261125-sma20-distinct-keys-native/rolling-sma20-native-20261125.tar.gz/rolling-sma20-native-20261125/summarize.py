"""Recompute two independent public Rust rolling SMA20 comparisons from the raw records."""

from __future__ import annotations

import json
import statistics
from pathlib import Path

from scripts.benchmark_suite.report import _paired_verdict
from scripts.benchmark_suite.statistics import paired_round
from scripts.toolkit import linear_percentile

ROOT = Path(__file__).resolve().parent
BASELINES = {
    "release": "7012b5b409553df04e29e6d7f9a11abf919cbf93",
    "main": "e87b138fc37aae4d21d8e498833dca5b9e3b99e1",
}
HEAD = (ROOT / "candidate.txt").read_text().strip()
assert len(HEAD) == 40


def read_rows(path):
    return [json.loads(line) for line in path.read_text().splitlines()]


def comparison(base):
    folder = ROOT / f"obs-sma20-{base[:10]}-{HEAD[:10]}"
    outcome = json.loads((folder / "outcome.json").read_text())
    if outcome["state"] != "complete":
        return outcome
    rows = read_rows(folder / "observations.jsonl")
    assert len(rows) == 44
    for rnd in (1, 2):
        for pair in range(11):
            subset = [r for r in rows if r["round"] == rnd and r["pair"] == pair]
            assert [r["side"] for r in subset] == (
                ["base", "head"] if pair == 0 or pair % 2 else ["head", "base"]
            )
            for row in subset:
                result = row["result"]
                assert result["validated_all_rows"] and result["closed"]
                assert result["output_rows"] == 10_000_000 and result["keys"] == 64
                assert result["input_batches"] == 10 and result["input_batch_rows"] == 1_000_000
                assert result["validated_schema"] and result["validated_input_columns"]
                assert result["warmup_nulls"] == 1_216 and result["valid_output_rows"] == 9_998_784

    def values(side, rnd=None):
        return [
            r["result"]["seconds"] * 1000 for r in rows
            if r["side"] == side and r["pair"] and (rnd is None or rnd == r["round"])
        ]

    rounds = [paired_round(values("base", rnd), values("head", rnd)) for rnd in (1, 2)]
    pooled = {
        side: {"p50": statistics.median(values(side)), "p95": linear_percentile(values(side), 0.95)}
        for side in ("base", "head")
    }
    assert rounds == outcome["rounds"] and pooled == outcome["pooled_ms"]
    assert _paired_verdict(rounds) == outcome["verdict"]
    for side, commit in [("base", base), ("head", HEAD)]:
        receipt = json.loads((folder / (side + ".receipt.json")).read_text())
        assert receipt["commit"] == commit and receipt["case"] == "sma20"
    resources = read_rows(folder / "resources.jsonl")
    return {
        "base": base, "head": HEAD, "cpu": outcome["cpu"],
        "pooled_ms": pooled, "rounds": rounds, "verdict": outcome["verdict"],
        "resource_intervals": len(resources), "formal_pairs": 20,
        "wall_seconds": outcome.get("wall_seconds"),
    }


if __name__ == "__main__":
    summary = {label: comparison(rev) for label, rev in BASELINES.items()}
    (ROOT / "summary.json").write_text(json.dumps(summary, indent=2, allow_nan=False) + "\n")
