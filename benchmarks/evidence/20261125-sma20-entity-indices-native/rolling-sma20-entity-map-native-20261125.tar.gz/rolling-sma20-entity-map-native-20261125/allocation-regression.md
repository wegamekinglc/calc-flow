# Allocation test for rolling slabs

The four-key numeric slab test constructs routing outside the allocation counter and measures the normal fill_slab_rows call, including its single nullable Float64 builder. Each run validates its complete output before rollback. At the #740 parent, 4,096 rows allocated 95,764 bytes and 32,768 rows allocated 669,204 bytes. For those 28,672 additional rows, the increment was exactly 20 bytes per row.

The same test passes on candidate tree c2a07bbe6355d2b317e5c2f65a9306aaf0a0c22f under a growth bound of nine bytes per row. The production change removes a 12-byte EntityId for each row from this path. The local row indices already exist before the measured boundary, and the resolved table now retains one ID per touched key. The allocation test covers work and memory; the independent 10-million-row paired acquisitions report elapsed time.
