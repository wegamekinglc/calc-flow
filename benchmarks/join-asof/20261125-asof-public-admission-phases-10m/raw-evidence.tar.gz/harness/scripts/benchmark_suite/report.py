"""Complete Markdown tables and explicitly scoped regression decisions."""

from __future__ import annotations

import math
import statistics
from collections import Counter
from dataclasses import dataclass

from scripts.benchmark_suite.catalog import (
    CAPABILITIES,
    INTERVAL_MAX_ROWS,
    INTERVAL_SCOPE,
    REPORT_CASES,
    STREAM_ASOF_MAX_ROWS,
    STREAM_JOIN_MAX_ROWS,
    STREAM_SCOPE,
    STREAM_WINDOW_MAX_ROWS,
)
from scripts.benchmark_suite.statistics import paired_round
from scripts.toolkit import linear_percentile

THRESHOLD_PERCENT = 5.0
ROUNDS = 2
SAMPLES = 10


def validate_shards(expected: list[str], received: list[str]) -> None:
    if Counter(expected) != Counter(received):
        missing = sorted((Counter(expected) - Counter(received)).elements())
        extra = sorted((Counter(received) - Counter(expected)).elements())
        raise ValueError(
            f"benchmark shards missing={missing}, duplicate/unexpected={extra}"
        )


def checked_samples(rounds: list[list[float]], *, minimum: int = 1) -> list[float]:
    if len(rounds) != ROUNDS or any(len(values) < minimum for values in rounds):
        raise ValueError(
            f"expected two complete rounds with at least {minimum} samples"
        )
    samples = [value for values in rounds for value in values]
    _validate_observations(samples)
    return samples


def _validate_observations(samples: list[float]) -> None:
    if any(type(value) not in (int, float) for value in samples):
        raise ValueError("benchmark samples must be numeric")
    if any(not math.isfinite(value) or value <= 0 for value in samples):
        raise ValueError("benchmark samples must be finite and positive")


def _paired_verdict(intervals: list[dict]) -> str:
    # Protect the exact +5% endpoint from ratio/subtraction roundoff.
    threshold = THRESHOLD_PERCENT + 1e-12
    if all(interval["low"] > threshold for interval in intervals):
        return "regression"
    if any(interval["high"] > threshold for interval in intervals):
        return "inconclusive"
    if all(interval["high"] < -threshold for interval in intervals):
        return "improved"
    return "no-confirmed-regression"


def _head_statistics(case: dict, head: list[float]) -> dict:
    median = statistics.median(head)
    return {
        "head_p50": median,
        "head_p95": linear_percentile(head, 0.95),
        "head_min": min(head),
        "head_max": max(head),
        "rows_per_second": case["rows"] / median if case.get("rows") else None,
        "samples": len(head),
        "base_p50": None,
        "change_percent": None,
        "round_changes": [],
        "round_min_changes": [],
        "round_intervals": [],
    }


def comparison(case: dict, *, minimum_samples: int | None = None) -> dict:
    if case.get("correctness") is not True:
        raise ValueError(f"{case['id']}: correctness was not established")
    kind = case["comparison"]
    if minimum_samples is not None:
        minimum = minimum_samples
    else:
        minimum = SAMPLES if kind == "interleaved" else 1
    head = checked_samples(case["candidate"], minimum=minimum)
    result = _head_statistics(case, head)
    if not case["baseline"]:
        labels = {"external": "external-reference", "new": "new-coverage"}
        if kind not in labels:
            raise ValueError("missing baseline is not an implicit performance pass")
        return _checked_statistics({**result, "verdict": labels[kind]})
    if kind not in ("interleaved", "suite-blocks"):
        raise ValueError("unexpected historical comparison kind")
    return _historical_statistics(case, result, minimum)


def _historical_statistics(case: dict, result: dict, minimum: int) -> dict:
    kind = case["comparison"]
    base = checked_samples(case["baseline"], minimum=minimum)
    if kind == "interleaved" and [len(r) for r in case["baseline"]] != [
        len(r) for r in case["candidate"]
    ]:
        raise ValueError("paired sample counts differ")
    changes = [
        100 * (min(right) / min(left) - 1)
        for left, right in zip(case["baseline"], case["candidate"], strict=True)
    ]
    return _checked_statistics(
        {
            **result,
            "base_p50": statistics.median(base),
            "change_percent": 100 * (result["head_p50"] / statistics.median(base) - 1),
            "round_min_changes": changes,
            **_round_statistics(case, changes),
        }
    )


def _round_statistics(case: dict, minima: list[float]) -> dict:
    if case["comparison"] == "suite-blocks":
        slow = all(change > THRESHOLD_PERCENT + 1e-12 for change in minima)
        return {
            "round_changes": minima,
            "round_intervals": [],
            "verdict": "informational-slowdown" if slow else "informational",
        }
    intervals = [
        paired_round(left, right)
        for left, right in zip(case["baseline"], case["candidate"], strict=True)
    ]
    return {
        "round_changes": [interval["median"] for interval in intervals],
        "round_intervals": intervals,
        "verdict": _paired_verdict(intervals),
    }


def _checked_statistics(result: dict) -> dict:
    values = [value for value in result.values() if type(value) in (int, float)]
    values.extend(result["round_changes"])
    values.extend(result["round_min_changes"])
    values.extend(
        value for item in result["round_intervals"] for value in item.values()
    )
    if any(not math.isfinite(value) for value in values):
        raise ValueError("derived benchmark statistics are nonfinite")
    return result


def _cell(value: object) -> str:
    return str(value).replace("|", "\\|").replace("\n", " ").replace("\r", " ")


def table(headers: list[str], rows: list[list[object]]) -> str:
    cells = [[_cell(value) for value in row] for row in [headers, *rows]]
    widths = [max(len(row[i]) for row in cells) for i in range(len(headers))]
    lines = [
        "| " + " | ".join(c.ljust(w) for c, w in zip(row, widths, strict=True)) + " |"
        for row in cells
    ]
    lines.insert(1, "|" + "|".join("-" * (width + 2) for width in widths) + "|")
    return "\n".join(lines)


def _milliseconds(value: float | None) -> str:
    return "—" if value is None else f"{value * 1000:.6f}"


def _result_row(case: dict, result: dict | None) -> list[object]:
    dimensions = f"N={case.get('rows', '—')}"
    if "history_rows" in case:
        dimensions += f", H0={case['history_rows']}"
    scope = case["scope"]
    if "dependency_migration" in case.get("metadata", {}):
        scope += " (cross-dependency release)"
    prefix = [case["id"], dimensions, scope]
    if result is None:
        return [
            *prefix,
            *(["—"] * 7),
            "error",
        ]
    changes = (
        ", ".join(f"{value:+.2f}%" for value in result["round_min_changes"]) or "—"
    )
    change = result["change_percent"]
    throughput = result["rows_per_second"]
    return [
        *prefix,
        _milliseconds(result["base_p50"]),
        _milliseconds(result["head_p50"]),
        _milliseconds(result["head_p95"]),
        f"{throughput:,.0f}" if throughput is not None else "—",
        f"{change:+.2f}%" if change is not None else "—",
        changes,
        _paired_cell(result["round_intervals"]),
        result["verdict"],
    ]


def _paired_cell(intervals: list[dict]) -> str:
    return (
        "; ".join(
            f"{item['median']:+.2f}% [{item['low']:+.2f}%, {item['high']:+.2f}%]"
            for item in intervals
        )
        or "—"
    )


@dataclass(frozen=True)
class BenchmarkReport:
    markdown: str
    evidence_errors: list[str]
    regressions: list[str]

    @property
    def errors(self) -> list[str]:
        """Keep the complete list of blocking reasons for summary.json consumers."""
        return [
            *self.evidence_errors,
            *(f"{name}: repeated regression exceeds +5%" for name in self.regressions),
        ]


def render_report(
    cases: list[dict],
    errors: list[str],
    baseline: str | None = None,
    rust_baseline: str | None = None,
) -> str:
    return build_report(cases, errors, baseline, rust_baseline).markdown


def build_report(
    cases: list[dict],
    errors: list[str],
    baseline: str | None = None,
    rust_baseline: str | None = None,
) -> BenchmarkReport:
    rows = []
    metrics = []
    regressions = []
    failures = list(errors)
    for case in sorted(cases, key=lambda item: item["id"]):
        target = metrics if case.get("kind") == "metric" else rows
        formatted, problem, regressed = _format_case(case)
        target.append(formatted)
        if regressed:
            regressions.append(case["id"])
        if problem is not None:
            failures.append(problem)
    failures = list(dict.fromkeys(failures))
    parts = [
        *_result_tables(cases, rows, metrics, baseline, rust_baseline),
        *_variant_sections(cases),
        *_finding_section("Confirmed performance regressions", regressions),
        *_finding_section("Incomplete or invalid evidence", failures),
    ]
    return BenchmarkReport("\n".join(parts) + "\n", failures, regressions)


def _finding_section(title: str, items: list[str]) -> list[str]:
    if not items:
        return []
    return ["", f"## {title}", "", *(f"- {_cell(item)}" for item in items)]


def _result_tables(
    cases: list[dict],
    rows: list,
    metrics: list,
    baseline: str | None,
    rust_baseline: str | None,
) -> list[str]:
    header = [
        "Case",
        "Dimensions",
        "Timed scope",
        "Base P50 ms",
        "Head P50 ms",
        "P95 ms",
        "Rows/s",
        "Change",
        "Round min changes",
        "Paired median [CI]",
        "Result",
    ]
    annotations = []
    if baseline:
        annotations.extend([f"Baseline: {baseline}", ""])
    if rust_baseline:
        annotations.extend([f"Rust shard baseline: {rust_baseline}", ""])
    parts = [
        "# Complete benchmark results",
        "",
        *annotations,
        f"{len(rows) + len(metrics)} result rows; positive changes mean slower. "
        "No top-N filtering.",
        "",
        "Historical engine/warm gates use two rounds of ten interleaved samples; "
        "both paired-median confidence lower bounds must exceed +5% to fail. "
        "The conservative exact 95% order-statistic interval has 97.85% coverage "
        "at ten pairs under the iid assumption. Intervals crossing +5% are "
        "inconclusive, not proof of equivalence. Round minima remain diagnostic.",
        "Existing suite-block comparisons and cross-library references "
        "are informational.",
        "",
        table(header, rows),
    ]
    if metrics:
        parts.extend(
            [
                "",
                "## Allocation metrics",
                "",
                table(["Case", "Metric", "Base", "Head", "Delta", "Result"], metrics),
            ]
        )
    cross_library = _cross_library_table(cases)
    if cross_library:
        parts.extend(
            [
                "",
                "## Cross-library comparison",
                "",
                "Head P50 milliseconds, same input and materialized Arrow output. "
                "Native streaming starts with empty rolling state on a ready runner "
                "and excludes runner startup and shutdown; enqueue, tasks/channels, "
                "rolling, watermarks and Arrow materialization remain timed. "
                "Other columns "
                "use their declared execute-to-Arrow boundaries. This is not a "
                "kernel-only ranking. Ten-row SMA cases have no full-window outputs.",
                "",
                cross_library,
            ]
        )
    return parts


def _variant_sections(cases: list[dict]) -> list[str]:
    parts = []
    for variant, title in (
        ("small-batch", "Small-batch native variants"),
        ("checkpoint-recovery", "Checkpoint lifecycle variants"),
    ):
        selected = [case for case in cases if case.get("variant") == variant]
        if selected:
            rows = [
                [
                    case["rows"],
                    case["scenario"],
                    case["batch_rows"],
                    _head_p50_cell(case),
                    case["scope"],
                ]
                for case in selected
            ]
            parts.extend(
                [
                    "",
                    f"## {title}",
                    "",
                    (
                        "Checkpoint lifecycle timing includes its declared 100 ms "
                        "delay, durable epoch acknowledgement, cancellation, "
                        "manifest recovery and runner restart. "
                        "It is separate from throughput timing."
                    )
                    if variant == "checkpoint-recovery"
                    else (
                        "Ready native execution with 1,024-row batches "
                        "and exact-cursor sources."
                    ),
                    "",
                    table(
                        ["Rows", "Scenario", "Batch rows", "Head P50 ms", "Scope"], rows
                    ),
                ]
            )
    return parts


def _format_case(case: dict) -> tuple[list[object], str | None, bool]:
    metric = case.get("kind") == "metric"
    if case["status"] == "ok":
        try:
            if metric:
                return _metric_row(case), None, False
            result = comparison(case)
            return _result_row(case, result), None, result["verdict"] == "regression"
        except (KeyError, TypeError, ValueError) as error:
            problem = str(error)
    else:
        problem = case.get("error", "failed")
    invalid = {**case, "status": "error"}
    row = _metric_row(invalid) if metric else _result_row(invalid, None)
    return row, f"{case['id']}: {problem}", False


def _metric_row(case: dict) -> list[object]:
    if case["status"] != "ok":
        return [case["id"], case.get("metric", "unknown"), "—", "—", "—", "error"]
    base, head = case["baseline_value"], case["candidate_value"]
    validate_metric(case)
    return [
        case["id"],
        case["metric"],
        f"{base:g}",
        f"{head:g}",
        f"{head - base:+g}",
        "informational",
    ]


def validate_metric(case: dict) -> None:
    if case.get("correctness") is not True:
        raise ValueError("allocation correctness was not established")
    for value in (case["baseline_value"], case["candidate_value"]):
        if type(value) not in (int, float) or not math.isfinite(value) or value < 0:
            raise ValueError("invalid allocation metric")


def _head_p50_cell(case: dict) -> str:
    if case["status"] != "ok":
        return "error"
    try:
        return _milliseconds(comparison(case)["head_p50"])
    except (KeyError, TypeError, ValueError):
        return "invalid"


def _reference_cell(case: dict | None) -> str:
    if case is None:
        return "missing"
    if (
        case["status"] == "ok"
        and case.get("backend", "").startswith("calc-flow-stream")
        and case.get("scope")
        != (INTERVAL_SCOPE if case.get("scenario") == "interval_join" else STREAM_SCOPE)
    ):
        return "invalid scope"
    return _head_p50_cell(case)


def _cross_library_table(cases: list[dict]) -> str:
    selected = [
        case
        for case in cases
        if case.get("family") == "engines" and not case.get("variant")
    ]
    if not selected:
        return ""
    index = {
        (case["rows"], case["scenario"], case["backend"]): case for case in selected
    }
    rows = [
        _cross_library_row(size, scenario, index)
        for size in sorted({case["rows"] for case in selected})
        for scenario in REPORT_CASES
    ]
    return table(
        [
            "Rows",
            "Scenario",
            "Native stream (ready, 1T)",
            "Native stream (ready, 4T)",
            "Calc Flow SQL (1T)",
            "Calc Flow SQL (4T)",
            "DataFusion (4T)",
            "Polars (4T)",
            "Polars (1T)",
            "TA-Lib",
            "Finance-Python",
        ],
        rows,
    )


def _cross_library_row(size: int, scenario: str, index: dict) -> list[object]:
    backends = (
        "calc-flow-stream-1t",
        "calc-flow-stream",
        "calc-flow-sql-1t",
        "calc-flow-sql",
        "datafusion",
        "polars",
        "polars-1t",
        "ta-lib",
        "finance-python",
    )

    def cell(backend: str) -> object:
        cap = {
            "join": STREAM_JOIN_MAX_ROWS,
            "asof_join": STREAM_ASOF_MAX_ROWS,
            "window_sum": STREAM_WINDOW_MAX_ROWS,
        }.get(scenario)
        if (
            scenario not in CAPABILITIES[backend]
            or scenario == "interval_join"
            and size > INTERVAL_MAX_ROWS
            or (
                backend.startswith("calc-flow-stream")
                and cap is not None
                and size > cap
            )
        ):
            return "unsupported"
        return _reference_cell(index.get((size, scenario, backend)))

    return [size, scenario, *(cell(backend) for backend in backends)]
