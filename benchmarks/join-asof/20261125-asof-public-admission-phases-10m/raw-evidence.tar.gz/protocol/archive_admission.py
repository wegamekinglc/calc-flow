"""Seal verified public 10M admission traces with their ordinary reference and patches."""
import hashlib
import io
import json
from pathlib import Path
import statistics
import sys
import tarfile

from admission_trace_validate import BY_ARM, counts
from scripts.benchmark_suite.report import table
from scripts.toolkit import linear_percentile, sha256_file, write_json

R = Path(__file__).resolve().parent
O = R / "observed-admission-asof"
D = R / "publications/benchmarks/join-asof/20261125-asof-public-admission-phases-10m"
D.mkdir(parents=True, exist_ok=True)
P = R.parent.parent / "main-src/target/products"
patches = Path(sys.argv[1])
read = lambda path: json.loads(path.read_text())
reg = read(R / "admission-registration.json")
state = read(O / "outcome.json")
elapsed = float((R / "elapsed-admission.txt").read_text())
assert elapsed <= 240
files = {"protocol/" + p.name:p for p in (R / "archive_admission.py",R / "admission-registration.json",*R.glob("unbuilt-d5606edf-*.json"))}
for name, digest in reg["harness_sha256"].items():
    p=R.parent / name
    assert sha256_file(p) == digest
    files["harness/"+name] = p
for name, digest in reg["calibration_hashes"].items():
    p=R / "observed-asof-release" / name
    assert sha256_file(p) == digest
    files["ordinary/"+name] = p
for asset in reg["clean_diagnostic_builds"]:
    side=asset["side"]
    item=reg["endpoints"][side]; p=patches / item["file"]
    assert sha256_file(p)==item["patch"]
    files["patches/"+p.name]=p
    loc=P/("round5-admission-"+side)
    manifest=read(loc/"release.json")
    assert manifest["git_clean"] and manifest["git_sha"]==asset["sha"] and sha256_file(loc/manifest["wheel"])==manifest["wheel_sha256"]
    for n in ("release.json","build.json","build.log","build-driver.log"):files["builds/"+side+"/"+n]=loc/n
for n in ("prepare.py","protocol.md","admit_clock.rs"):files["patches/"+n]=patches/n
files["superseded-release/unbuilt.patch"]=R/"unbuilt-d5606edf-release.patch"
for n in ("build.log","build-driver.log"):
    files["superseded-release/"+n]=P/"round5-admission-release-unbuilt-d5606edf"/n
for p in O.rglob("*"):
    if p.is_file() and "site" not in p.relative_to(O).parts:files["observation/"+p.relative_to(O).as_posix()]=p
for n in ("elapsed-admission.txt","admission-controller.log"):files["observation/"+n]=R/n
rows=[]
for p in sorted((O/"measurement").rglob("*.completed.json")):
    r=read(p)
    if r["operation"] not in ("prepare","sample"):continue
    x=r["response"].get("warmup",r["response"])
    assert x["correctness"]=={"passed":True,"rows":10_000_000,"finite_rows":10_000_000,"max_abs_error":0}
    fin=x["stream_evidence"]["terminal_asof_status"]
    assert x["stream_evidence"]["post_eof_output_rows"]==10_000_000
    for s in ("left","right"):
        assert fin[s]["accepted_rows"]==10_000_000 and fin[s]["ended"] and fin[s]["late_rows"]==fin[s]["duplicate_rows"]==0
    assert fin["emitted_left_rows"]==fin["evicted_right_rows"]==fin["matched_rows"]==10_000_000 and fin["state_rows"]==0
    arm=p.parent.name
    t=x["trace_range"]
    assert r["operation"]==t["operation"] and r["request_id"]==t["request_id"]
    with (p.parent/t["trace"]).open("rb") as f:
        f.seek(t["byte_start"]); body=f.read(t["byte_end"]-t["byte_start"])
    records=[json.loads(line) for line in body.splitlines()]
    assert len(records)==t["records"] and counts(records,t["pid"],arm)==t["stages"]
    rows.append({"arm":arm,"request":r["request_id"],"operation":r["operation"],"round":r["context"]["round"],"sample":r["context"]["sample"],"seconds":x["seconds"],"stages":t["stages"]})
rs=[json.loads(x) for x in (O/"resources.jsonl").read_text().splitlines()] if (O/"resources.jsonl").exists() else []
warm=sum(x["operation"]=="prepare" for x in rows);formal=len(rows)-warm
out={"state":state,"elapsed":elapsed,"completed_warmups":warm,"completed_formal_single_arm_samples":formal,"resource_intervals":len(rs),"bad_intervals":[x for x in rs if not all(c["suitable"] for c in x["cores"])],"requests":rows}
lines=["# Managed ASOF admission at ten million rows per side","","The fixed four-thread case matched 64 keys at zero tolerance, with ten batches of one million rows per side. The ordinary reference and the diagnostic used the same public entry point, machine, reserved physical CPU set, interpreter, fixture and source-to-Arrow clock. Diagnostic wheels added admission counters to 11.14 (7012b5b4) and the left-retirement revision (dce77f04).",""]
if state["state"]=="completed":
    assert (warm,formal)==(4,40) and not out["bad_intervals"]
    do=read(O/"samples.json");ordinary=read(R/"observed-asof-release/samples.json")
    ranks={}; common={}; cal={}
    for side in BY_ARM:
        mat=[sorted((x for x in rows if x["arm"]==side and x["operation"]=="sample" and x["round"]==i),key=lambda x:x["sample"]) for i in range(2)]
        assert [[x["seconds"] for x in sub] for sub in mat]==do[side] and all(len(sub)==10 for sub in mat)
        def stats(vals):
            return {"p50_ms":statistics.median(vals),"p95_ms":linear_percentile(vals,0.95)}
        outer={n:stats([1000*v for sub in d[side] for v in sub]) for n,d in (("ordinary",ordinary),("diagnostic",do))}
        drift={k:(v/outer["ordinary"][k]-1)*100 for k,v in outer["diagnostic"].items()}
        cal[side]={**outer,"level_drift_percent":drift,"instrument_sensitive":abs(drift["p50_ms"])>10}
        ranks[side]={}
        for scope in ("both","left","right"):
            ranks[side][scope]={}
            for name in ("wall_ns",*BY_ARM[side]):
                raw=[[x["stages"][scope][name]/1e6 for x in sub] for sub in mat]
                ranks[side][scope][name]=stats(sum(raw,[]))
                if name in ("wall_ns","ingress_validation"):common.setdefault(scope,{}).setdefault(name,{})[side]=raw
    for scope,summary in common.items():
        for name,data in summary.items():
            a,b=data["baseline"],data["candidate"]
            summary[name]={"baseline":stats(sum(a,[])),"candidate":stats(sum(b,[])),"paired_median_difference_ms":[statistics.median(y-x for x,y in zip(u,v)) for u,v in zip(a,b)]}
    out.update(calibration=cal,common=common,within_arm=ranks)
    lines+=["## Public clock calibration","",table(["Wheel","Ordinary P50 ms","Diagnostic P50 ms","P50 change","Ordinary P95 ms","Diagnostic P95 ms","P95 change"],[[s,f"{d['ordinary']['p50_ms']:.2f}",f"{d['diagnostic']['p50_ms']:.2f}",f"{d['level_drift_percent']['p50_ms']:+.2f}%",f"{d['ordinary']['p95_ms']:.2f}",f"{d['diagnostic']['p95_ms']:.2f}",f"{d['level_drift_percent']['p95_ms']:+.2f}%"] for s,d in cal.items()]),"","Each level compares independent observations at different times. Absolute P50 drift over 10% flags the diagnostic's stage magnitudes as instrument-sensitive.","","## Common elapsed boundaries","",table(["Side","Boundary","Release P50 ms","Candidate P50 ms","Release P95 ms","Candidate P95 ms","Round 1 paired Δ ms","Round 2 paired Δ ms"], [[scope,name,f"{d['baseline']['p50_ms']:.2f}",f"{d['candidate']['p50_ms']:.2f}",f"{d['baseline']['p95_ms']:.2f}",f"{d['candidate']['p95_ms']:.2f}",*(f"{v:+.2f}" for v in d["paired_median_difference_ms"])] for scope,summary in common.items() for name,d in summary.items()]),""]
    for side in BY_ARM:
        ordered=sorted(((k,v) for k,v in ranks[side]["both"].items() if k!="wall_ns"),key=lambda kv:-kv[1]["p50_ms"])
        lines+=["## "+side.capitalize()+" admission breakdown","","The total covers twenty admission callbacks per request. Phases follow the boundaries implemented by this revision.","",table(["Phase","Combined P50 ms","Combined P95 ms"],[[name,f"{d['p50_ms']:.3f}",f"{d['p95_ms']:.3f}"] for name,d in ordered]),""]
else:
    from collections import Counter
    vals=[x for x in rows if x["operation"]=="sample"]
    by={(r,arm):{x["sample"]:x for x in vals if x["round"]==r and x["arm"]==arm} for r in range(2) for arm in BY_ARM}
    keys={r:sorted(set(by[r,"baseline"])&set(by[r,"candidate"])) for r in range(2)}
    ordinary=read(R/"observed-asof-release/samples.json")
    def descr(v):
        return {"p50_ms":statistics.median(v),"p95_ms":linear_percentile(v,0.95),"n":len(v)} if v else {}
    part={"paired_sample_counts":[len(keys[r]) for r in range(2)],"per_arm":{},"round_common_boundaries":{}}
    for arm,names in BY_ARM.items():
        subset=[x for x in vals if x["arm"]==arm]
        outcal=descr([1000*x["seconds"] for x in subset])
        normalized=descr([1000*s for sub in ordinary[arm] for s in sub])
        drift={k:(outcal[k]/normalized[k]-1)*100 for k in ["p50_ms","p95_ms"]} if outcal else {}
        part["per_arm"][arm]={"ordinary_complete":normalized,"diagnostic_incomplete":outcal,"level_drift_pct":drift,"instrument_sensitive":abs(drift["p50_ms"])>10 if drift else None,"per_side":{side:{k:descr([x["stages"][side][k]/1e6 for x in subset]) for k in ("wall_ns",*names)} for side in ["both","left","right"]}}
    for side in ("both","left","right"):
        part["round_common_boundaries"][side]={}
        for k in ("wall_ns","ingress_validation"):
            diffs=[[ (by[r,"candidate"][i]["stages"][side][k]-by[r,"baseline"][i]["stages"][side][k])/1e6 for i in keys[r]] for r in range(2)]
            part["round_common_boundaries"][side][k]=[statistics.median(sub) if sub else None for sub in diffs]
    out["incomplete_exploratory_only"]=part
    lines += [f"Stopped with {warm} accepted warmups and {formal} accepted formal measurements. The raw request logs and resource data preserve the stop condition. The fixed comparison is inconclusive.",""]
    if all(keys.values()):
        a,b=(part["per_arm"][arm] for arm in BY_ARM)
        lines += ["## Incomplete diagnostic observations","",f"The first round supplied {len(keys[0])} complete pairs and the second supplied {len(keys[1])}. The arm medians below cover {a['diagnostic_incomplete']['n']} release and {b['diagnostic_incomplete']['n']} candidate executions accepted before the stop. These are exploratory stage observations.","",table(["Elapsed","11.14 P50 ms","Candidate P50 ms"],[[label,f"{a['per_side']['both'][k]['p50_ms']:.2f}",f"{b['per_side']['both'][k]['p50_ms']:.2f}"] for label,k in (("Total admission","wall_ns"),("Ingress validation","ingress_validation"))]),"",table(["Candidate phase","Combined P50 ms","Combined P95 ms"],[[name,f"{val['p50_ms']:.2f}",f"{val['p95_ms']:.2f}"] for name,val in sorted(b["per_side"]["both"].items(), key=lambda kv:-kv[1]["p50_ms"]) if name!="wall_ns"]),"",f"Release's composite preparation and installation measured {a['per_side']['both']['release_prepare_admission']['p50_ms']:.2f} and {a['per_side']['both']['release_install_admission']['p50_ms']:.2f} ms P50. They cover different code boundaries from the candidate's phases. Compared with the complete ordinary run, the incomplete release and candidate end-to-end P50 changes were {a['level_drift_pct']['p50_ms']:+.2f}% and {b['level_drift_pct']['p50_ms']:+.2f}%. The published results JSON retains per-arm P95, per-side breakdowns and the descriptive differences from complete pairs in each round.",""]

lines += [f"The controller took {elapsed:.2f} seconds, including interpreter and worker startup, fixture creation, warmups, correctness verification and cleanup. The archive preserves native callback sequences and elapsed times for each request, per-side row counts, terminal gauges, exact source patches and build identities. The trace timestamps bracket synchronous admission inside the Rust operator. Source transport, watermark finalization, Arrow delivery and post-clock tracing have different boundaries. [Summary](result.json) · [Original evidence](raw-evidence.tar.gz) · [Receipt](receipt.json)",""]
(D/"README.md").write_text("\n".join(lines));write_json(D/"result.json",out)
members={}
with tarfile.open(D/"raw-evidence.tar.gz","w:gz",compresslevel=9) as t:
    for n,p in sorted(files.items()):
        body=p.read_bytes();i=tarfile.TarInfo(n);i.size=len(body);t.addfile(i,io.BytesIO(body));members[n]={"bytes":len(body),"sha256":hashlib.sha256(body).hexdigest()}
with tarfile.open(D/"raw-evidence.tar.gz") as t:
    assert set(t.getnames())==set(files)
    for i in t:assert t.extractfile(i).read()==files[i.name].read_bytes()
write_json(D/"receipt.json",{"members":members,"archive_sha256":sha256_file(D/"raw-evidence.tar.gz")})
print(D,len(files),warm,formal)
