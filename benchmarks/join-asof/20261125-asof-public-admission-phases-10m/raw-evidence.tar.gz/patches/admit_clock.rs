// Temporary diagnostic module for recording one successful data callback.
use std::{cell::RefCell, fs::OpenOptions, io::Write, time::Instant};

pub(super) struct Clock {
    start: Instant,
    last: Instant,
    times: [u128; 14],
}

impl Clock {
    pub(super) fn new() -> Self {
        let start = Instant::now();
        Self { start, last: start, times: [0; 14] }
    }

    pub(super) fn mark(&mut self, index: usize) {
        let now = Instant::now();
        self.times[index] += now.duration_since(self.last).as_nanos();
        self.last = now;
    }

    pub(super) fn write(&self, side: &str, rows: usize, accepted: u64, sequence: u64) {
        const NAMES: [&str; 14] = ["ingress_validation", "envelope_record", "late_mask",
            "budget_preflight", "compact_payload", "encode_sequences", "route_keys", "build_run",
            "validate_locators", "project_charge", "install_indexes", "residual",
            "release_prepare_admission", "release_install_admission"];
        let elapsed = self.last.duration_since(self.start).as_nanos();
        assert_eq!(elapsed, self.times.iter().sum::<u128>());
        let phases = NAMES.into_iter().zip(self.times).collect::<std::collections::BTreeMap<_, _>>();
        if let Some(path) = std::env::var_os("CALC_FLOW_ASOF_ADMISSION_TRACE") {
            let item = serde_json::json!({"pid": std::process::id(), "side":side, "rows":rows,
                "accepted":accepted, "sequence":sequence, "wall_ns":elapsed, "phases_ns":phases});
            writeln!(OpenOptions::new().create(true).append(true).open(path).unwrap(), "{item}").unwrap();
        }
    }
}

#[allow(dead_code)]
pub(super) mod sync {
    use super::{Clock, RefCell};

    thread_local! {
        static ACTIVE: RefCell<Option<Clock>> = const { RefCell::new(None) };
    }

    pub(in super::super) fn start(clock: Clock) {
        ACTIVE.with(|c| assert!(c.replace(Some(clock)).is_none()));
    }

    pub(in super::super) fn take() -> Clock {
        ACTIVE.with(|c| c.take().expect("synchronous ASOF admission clock"))
    }

    pub(in super::super) fn mark(index: usize) {
        ACTIVE.with(|c| {
            if let Some(clock) = c.borrow_mut().as_mut() {
                clock.mark(index);
            }
        });
    }
}
