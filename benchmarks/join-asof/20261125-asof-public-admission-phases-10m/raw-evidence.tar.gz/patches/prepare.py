from pathlib import Path
import subprocess
import sys

root = Path(__file__).resolve().parent
sha = {"main":"dce77f04b24cd62ae5c725ba33c0e335b2637ec9","release":"7012b5b409553df04e29e6d7f9a11abf919cbf93"}
side = sys.argv[1]
src = root / f"source-{side}"

def one(s, a, b):
    if s.count(a) != 1:
        raise ValueError((a, s.count(a)))
    return s.replace(a, b)

def splice(text, start, end, pairs):
    first = text.index(start)
    last = text.index(end, first)
    block = text[first:last]
    for a, b in pairs:
        block = one(block, a, b)
    return text[:first] + block + text[last:]

assert subprocess.check_output(["git","rev-parse","HEAD"],cwd=src,text=True).strip()==sha[side]
op = src / "crates/calc-flow/src/operator/asof"
p = op / "mod.rs"
s = subprocess.check_output(["git","show","HEAD:"+str(p.relative_to(src))],cwd=src,text=True)
s = one(s, "mod admission;", "mod admission;\nmod admit_clock;")
start = "    async fn admit_batch("
end = "\n    async fn install_admission(" if side=="release" else "\n    fn prepare_record"
pairs = [
("        let prepared = match", "        let mut clock = admit_clock::Clock::new();\n        let prepared = match"),
("        let validated = self.validate_admission_with_facts(ingress, batch, prepared)?;", "        let validated = self.validate_admission_with_facts(ingress, batch, prepared)?;\n        clock.mark(0);")]
if side=="main":
    pairs.extend([
    ("        let admitted = self.state.admit(", "        clock.mark(1);\n        admit_clock::sync::start(clock);\n        let admitted = self.state.admit("),
    ("        let summary = match admitted", "        let mut clock = admit_clock::sync::take();\n        let summary = match admitted"),
    ("        self.refresh_state_gauges();", "        self.refresh_state_gauges();\n        clock.mark(11);\n        clock.write(ingress, batch.num_rows(), summary.accepted, batch.metadata().sequence());")])
else:
    pairs.extend([
    ("        if admission.len() == 0", "        let accepted = u64::try_from(admission.len()).expect(\"accepted rows fit u64\");\n        clock.mark(12);\n        if admission.len() == 0"),
    ("        self.install_admission(ingress, admission, validated, context)\n            .await", "        let result = self.install_admission(ingress, admission, validated, context).await;\n        clock.mark(13);\n        if result.is_ok() { clock.write(ingress, batch.num_rows(), accepted, batch.metadata().sequence()); }\n        result")])
s = splice(s,start,end,pairs)
p.write_text(s)
(op/"admit_clock.rs").write_bytes((root/"admit_clock.rs").read_bytes())
if side=="main":
    p = op/"columnar/state.rs"
    s=subprocess.check_output(["git","show","HEAD:"+str(p.relative_to(src))],cwd=src,text=True)
    def mark_before(n,line):
        return line, f"        crate::operator::asof::admit_clock::sync::mark({n});\n"+line
    s=splice(s,"    fn admit_attempt(","    fn prepare_run(",[mark_before(2,"        let prepared = self.prepare_run(")])
    s=splice(s,"    fn prepare_run(","    fn install_prepared_run(",[
        mark_before(3,"        let compacted = compact_accepted("),mark_before(4,"        let sequences = SequenceColumn::from_names("),
        mark_before(5,"        let key_arrays = declaration"),mark_before(6,"        let times = admission::times("),
        mark_before(7,"        Ok(PreparedRun {")])
    s=splice(s,"    fn install_prepared_run(","    fn contains_duplicate_for_budget(",[
        mark_before(8,"        let _workspace = self.admission_workspace("),
        mark_before(9,"        self.rebuild_key_order()?;"),mark_before(10,"        Ok(())")])
    p.write_text(s)
