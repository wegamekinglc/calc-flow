"""Package the pre-registered second round of public Join regressions."""
from __future__ import annotations
import hashlib
import io
import json
import sys
import tarfile
import zipfile
from pathlib import Path

from scripts.benchmark_suite.report import comparison, table
from scripts.toolkit import linear_percentile, sha256_file, write_json

R=Path(__file__).resolve().parent
BUILDS=R.parents[2]/"main-src"/"target"/"products"
kind=sys.argv[1]; mode=sys.argv[2]
assert kind=="asof" and mode in ("preceding","release")
case="join" if kind=="join" else "asof_join"
OBS=R/f"observed-{kind}-{mode}"
name=f"benchmarks/join-asof/20261125-asof-dense-charge-public-10m"
DEST=R/"publications"/name
if mode=="release":DEST=DEST/"release-baseline"
DEST.mkdir(parents=True,exist_ok=True)
reg=R/"protocol.json"
binding=R/"candidate.json"
read=lambda p:json.loads(p.read_text())
plan=read(reg); bound=read(binding); outcome=read(OBS/"outcome.json");res=read(OBS/"result.json") if (OBS/"result.json").is_file() else None
source_sha=plan["cases"]["release" if mode=="release" else "preceding_product"]["git_sha"]
files={}
for p in OBS.rglob("*"):
    if p.is_file() and "site" not in p.relative_to(OBS).parts:
        files["observation/"+p.relative_to(OBS).as_posix()]=p
cn=mode+"_compare.py"
outer=R/f"elapsed-{kind}-{mode}.txt"
assert 0 < float(outer.read_text()) <= 165
files["observation/controller-wall-seconds.txt"]=outer
for p in [R/cn,R.parent/"setup_sites.py",reg,binding,R/"archive.py",R/"wheel-binding.json",R/f"log-asof-{mode}.txt",R.parent/"post-timer-worker/benchmarks/engine_stream.py",R.parent/"post-timer-worker/benchmarks/engine_comparison.py"]:
    files["protocol/"+p.name]=p
assert sha256_file(R/cn)==bound["controller_sha256"][mode]
wheels={}
for arm,dirname,sha in (("baseline","release-1114" if mode=="release" else "round11-asof",source_sha),("candidate","round13-"+kind,bound["sha"])):
    loc=BUILDS/dirname;m=read(loc/"release.json");wh=loc/m["wheel"]
    assert m["git_sha"]==sha and sha256_file(wh)==m["wheel_sha256"] and m["git_clean"]
    with zipfile.ZipFile(wh) as z:
        members={p:hashlib.sha256(z.read(p)).hexdigest() for p in z.namelist() if not p.endswith("/")}
    wheels[arm]={**{k:m[k] for k in ("wheel_sha256","native_sha256","git_sha","source_sha256","cargo_lock_sha256","rustc","python")},"members":members}
    for f in ("release.json","build.json","build.log","build-driver.log"):
        files[f"builds/{arm}/{f}"]=loc/f
write_json(DEST/"wheel-identities.json",wheels)
resources=[json.loads(l) for l in (OBS/"resources.jsonl").read_text().splitlines()] if (OBS/"resources.jsonl").exists() else []
states=[v for r in resources for v in r['cores']];bad=[v for v in states if not v['suitable']]
checks=[read(p) for p in (OBS/"measurement").rglob("*.completed.json")]
child_only=[]
for p in (OBS/"measurement").rglob("worker-request-*.json"):
    if not p.with_name(p.name.replace("worker-request-","request-").replace(".json",".completed.json")).is_file():
        response=read(p).get("response") or {}
        if isinstance(response,dict) and ("warmup" in response or "seconds" in response):
            child_only.append(str(p.relative_to(OBS)))

warm=sum(c.get("operation")=="prepare" for c in checks);formal=sum(c.get("operation")=="sample" for c in checks)
charge={"controller_wall_including_interpreter_seconds":float(outer.read_text()),"worker_results_without_controller_acceptance":child_only,"intervals":len(resources),"bad_intervals":sum(not all(v['suitable'] for v in r['cores']) for r in resources),"completed_warmups":warm,"completed_formal_single_arm_samples":formal}
write_json(DEST/"result.json",{"result":res,"outcome":outcome,"resources":charge})
raw=DEST/"raw-evidence.tar.gz"
digests={}
with tarfile.open(raw,"w:gz",compresslevel=9) as tar:
    for name,p in sorted(files.items()):
        b=p.read_bytes();h=tarfile.TarInfo(name);h.size=len(b);h.mode=0o644;h.mtime=0;tar.addfile(h,io.BytesIO(b));digests[name]={"bytes":len(b),"sha256":hashlib.sha256(b).hexdigest()}
with tarfile.open(raw,"r:gz") as tar:
    assert sorted(tar.getnames())==sorted(files)
    for m in tar:
        assert tar.extractfile(m).read()==files[m.name].read_bytes()
write_json(DEST/"receipt.json",{"sha256":sha256_file(raw),"original_members":len(files),"members":digests})
title="static dimension Join" if kind=="join" else "zero-tolerance ASOF Join"
desc="a sealed 64-row dimension with a million fact rows" if kind=="join" else "ten million timestamped rows on each side across 64 symbols, with exact-time matches"
lines=[f"# Public 4-thread {title}", "", f"The scheduled workload joined {desc}. CPU timings cover ready enqueue through delivery and final Arrow concatenation. The elapsed values below are wall-clock measurements. Baseline `{source_sha}` and candidate `{bound['sha']}` used independently built portable release wheels, the same Rust compiler, Python interpreter, Python dependencies and four-thread settings. [Wheels and build identities](wheel-identities.json)",""]
lines[2]=lines[2].replace("CPU timings cover","The timing window covers").replace("The scheduled workload joined", "The scheduled workload joins")
if kind == "join":
    lines.extend(["This fixture preloads and seals the 64-row right dimension before the timer starts. It exercises the product projection that reads a contiguous fact-side value range directly and copies sequence identifiers into the returned Arrow buffer. It also includes probing, multiplication, queueing and delivery.", ""])
else:
    lines.extend(["Left and right input events enter the managed stream during the timed interval. The candidate specializes projected resident charge accounting for fresh dense ASOF admission. Both sides use ten one-million-row input batches and the maintained interleaved watermarks and sink-progress waits. The measured path also includes state ingestion, Arrow output, queueing and delivery.", ""])
if mode=="preceding":
    lines += [f"The preceding-product comparison intentionally uses the uninstrumented #741 wheel. Its recorded full tree is {plan['cases']['preceding_product']['tree']}. The new candidate's product parent is {bound['parent']}. The archive records their merge base and source differences.", ""]
if mode=="release":
    lines+=["This comparison tests the complete candidate product against the unmodified 11.14 release. Each native product uses its original Cargo.lock. Versions of form_urlencoded, url and libz-sys changed, and the core added a direct edge to the already-locked smallvec. The preceding-product comparison has matching Cargo.lock.",""]
if res:
    row=read(OBS/"samples.json");statistics=comparison(row)
    assert res['round_intervals']==statistics['round_intervals'] and res['verdict']==statistics['verdict']
    assert res['base_p95']==linear_percentile([s for r in row['baseline'] for s in r],0.95)
    assert warm==4 and formal==40 and not bad
    states=[]
    for record in checks:
        if record["operation"] not in ("prepare","sample"):
            continue
        item=record["response"].get("warmup",record["response"])
        assert item["correctness"]=={"passed":True,"rows":10_000_000,"finite_rows":10_000_000,"max_abs_error":0.0}
        st=item["stream_evidence"]["terminal_asof_status"]
        for side in ("left","right"):
            assert st[side]["accepted_rows"]==10_000_000 and st[side]["ended"] and not st[side]["late_rows"] and not st[side]["duplicate_rows"]
        assert all(st[k]==10_000_000 for k in ("matched_rows","emitted_left_rows","evicted_right_rows"))
        assert all(st[k]==0 for k in ("pending_left_rows","retained_right_rows","identity_only_rows","state_rows","unmatched_rows","state_limit_failures","workspace_limit_failures","output_limit_failures"))
        states.append(st)
    assert len(states)==44
    lines.extend(["Each execution also checked physical output sequence against the full original sequence before the maintained sorted oracle. After EOF, both sides had accepted and ended with all ten million rows; ten million outputs matched, ten million right rows were evicted, the left and right state was empty and all three limit-failure counters were zero. Each complete native status is in its original worker response.", ""])
    lines+=[table(["Clock","Baseline","Candidate"], [["P50",f"{1000*res['base_p50']:.3f} ms",f"{1000*res['head_p50']:.3f} ms"], ["P95",f"{1000*res['base_p95']:.3f} ms",f"{1000*res['head_p95']:.3f} ms"]]),"",table(["Round","Paired median","Exact interval"],[[str(i),f"{v['median']:+.2f}%",f"[{v['low']:+.2f}%, {v['high']:+.2f}%]"] for i,v in enumerate(res['round_intervals'],1)]),"",f"The maintained verdict was **{res['verdict']}**. Two rounds each completed ten alternating AB/BA pairs after four excluded warmups. Every invocation validated the full ten million sequence identities and finite values outside timing. Maximum absolute error was zero.",""]
else:
    detail=f"The stop interval recorded {bad[-1]['major_faults']} major faults, {bad[-1]['swap_pages']} swapped pages and {bad[-1]['sibling_busy']:.1f}% sibling utilization." if bad else "The stored outcome preserves the stop reason."
    lines += [f"The acquisition stopped after {warm} completed warmups and {formal} formal single-arm samples. {detail} No paired verdict was established. The original archive retains any worker-local responses completed during cancellation.",""]
lines+=[f"The Linux WSL2 host exposed 32 logical CPUs and 16 SMT groups. Each worker retained four CPU cores from different groups, chosen during the three-second preflight. Each one-second interval checked every selected core's SMT sibling, host utilization, memory, swap and major faults. This run recorded {len(resources)} intervals and took {outcome['elapsed']:.3f} seconds within the controller and {float(outer.read_text()):.2f} seconds including interpreter startup and exit, against the 165-second limit. [Result and resources](result.json)","",f"Each public comparison reserved 165 seconds including product qualification, installation, runtime and worker startup, fixture preparation, all oracle checks and cleanup. Release builds were accounted separately. The [original evidence archive](raw-evidence.tar.gz) contains every recorded worker response, condition, qualification record, build manifest and build log. Its [receipt](receipt.json) includes a hash and byte count for each original file.",""]
if res:
    lines+=["To reproduce the verdict from the archive on the harness checkout, extract it at the checkout root, then run","","\u0060\u0060\u0060bash","python - <<'PY'","import json","from pathlib import Path","from scripts.benchmark_suite.report import comparison","print(comparison(json.loads(Path('observation/samples.json').read_text())))","PY","\u0060\u0060\u0060",""]
if mode=="preceding":lines+=["[Ten-million-row comparison against the 11.14 release](release-baseline/README.md)",""]
(DEST/"README.md").write_text("\n".join(lines))
print(DEST.relative_to(R/"publications"), len(files), sha256_file(raw))
