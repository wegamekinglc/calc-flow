"""Archive original instrumented worker traces and matched per-request summaries."""
from __future__ import annotations
import hashlib
import io
import json
import statistics
import sys
import tarfile
from pathlib import Path

from diagnostic_validate import FIELDS, counts
from scripts.benchmark_suite.report import comparison, table
from scripts.toolkit import linear_percentile, sha256_file, write_json

R=Path(__file__).resolve().parent
O=R/"observed-instrument-asof"
D=R/"publications/benchmarks/join-asof/20261125-asof-public-watermark-phases"
D.mkdir(parents=True,exist_ok=False)
INSTR=Path(sys.argv[1]);P=R.parent.parent/"main-src/target/products"
read=lambda p:json.loads(p.read_text())
reg=read(R/"instrument-registration.json")
files={"protocol/"+n:R/n for n in ("instrument-registration.json","diagnostic-patch-proof.json","diagnostic_compare.py","diagnostic_validate.py","attach_asof_trace.py","setup_sites.py","archive_instrument.py")}
for n,h in reg["hashes"].items():
    assert sha256_file(R.parent/n)==h,n
st=read(O/"outcome.json")
resources=[json.loads(x) for x in (O/"resources.jsonl").read_text().splitlines()] if (O/"resources.jsonl").is_file() else []
rows=[]
for p in O.rglob("*"):
    if p.is_file() and "site" not in p.relative_to(O).parts:
        files["observation/"+p.relative_to(O).as_posix()]=p
for n in ("elapsed-instrument.txt","instrument-controller.log"):
    files["observation/"+n]=R/n
outer=float((R/"elapsed-instrument.txt").read_text())
assert outer<=120
for asset in reg["endpoints"]:
    side=asset["side"]
    p=INSTR/(side+".patch")
    assert sha256_file(p)==asset["patch"]
    files["patches/"+p.name]=p
    b=P/("round4-instrument-"+side)
    bi=read(b/"release.json")
    assert bi["git_sha"]==asset["sha"] and sha256_file(b/bi["wheel"])==bi["wheel_sha256"]
    for n in ("build.json","release.json","build.log","build-driver.log"):
        files["builds/"+side+"/"+n]=b/n
expected={"passed":True,"rows":1_000_000,"finite_rows":1_000_000,"max_abs_error":0.0}
for p in sorted((O/"measurement").rglob("*.completed.json")):
    r=read(p);op=r["operation"]
    if op not in ("prepare","sample"):continue
    item=r["response"].get("warmup",r["response"])
    assert item["correctness"]==expected
    ix=item["trace_range"]
    assert ix["request_id"]==r["request_id"] and ix["operation"]==op
    with (p.parent/ix["trace"]).open("rb") as f:
        f.seek(ix["byte_start"]);chunk=f.read(ix["byte_end"]-ix["byte_start"])
    group=[json.loads(line) for line in chunk.splitlines()]
    assert len(group)==ix["records"] and counts(group,ix["pid"])==ix["stages"]
    rows.append({"round":int(p.parent.parent.name.removeprefix("round-")),"side":p.parent.name,
                 "request":r["request_id"],"op":op,"total_ms":item["seconds"]*1000,"counts":ix["stages"]})
result={"outcome":st,"outer_elapsed":outer,"resources":len(resources),"bad_intervals":sum(not all(c["suitable"] for c in t["cores"]) for t in resources),
        "completed_warmups":sum(d["op"]=="prepare" for d in rows),"completed_formal_samples":sum(d["op"]=="sample" for d in rows),"rows":rows}
lines=["# Public ASOF watermark phases", "", "This diagnostic compares the original 11.14 release (7012b5b4) with main (72072c1d) on the managed four-thread public ASOF workload. Both sides received one million rows covering the same 64 symbols, matched with zero tolerance. The two diagnostic wheels were built independently after adding the task-local phase clocks to their respective source trees. The exact patches, reconstructed source trees, build and interpreter identities are stored in the archive.", ""]
if st["state"]=="completed":
    assert result["completed_warmups"]==4 and result["completed_formal_samples"]==40 and result["bad_intervals"]==0
    row=read(O/"samples.json")
    assert tuple(map(len,row["baseline"]))==(10,10) and tuple(map(len,row["candidate"]))==(10,10)
    result["outer_clock"]=comparison(row)
    rs=range(2); sides=("baseline","candidate")
    by={(r,s):sorted((x for x in rows if x["round"]==r and x["side"]==s and x["op"]=="sample"),key=lambda x:x["request"]) for r in rs for s in sides}
    for (r,s),vs in by.items():assert len(vs)==10 and [x["total_ms"] for x in vs]==[1000*v for v in row[s][r]]
    qa={}
    for group in ("all","emitting","other"):
        qa[group]={}
        for k in ("wall_ns",*FIELDS,"emitted_delta","matched_delta","evicted_delta","callbacks",*(f"tickets_{i}" for i in range(6))):
            def value(rec):
                agg=rec["counts"][group]
                if k.startswith("tickets_"):return agg["tickets"][int(k[-1])]
                return agg[k]/1e6 if k.endswith("_ns") else agg[k]
            arm={s:[[value(x) for x in by[r,s]] for r in rs] for s in sides}
            per={s:{"p50":statistics.median(sum(v,[])),"p95":linear_percentile(sum(v,[]),0.95),"min":min(sum(v,[])),"max":max(sum(v,[]))} for s,v in arm.items()}
            deltas=[[h-b for b,h in zip(br,hr)] for br,hr in zip(arm["baseline"],arm["candidate"])]
            qa[group][k]={**per,"paired_median_delta_per_round":[statistics.median(v) for v in deltas],"paired_pooled_median_delta":statistics.median(sum(deltas,[]))}
    result["phase_summary"]=qa
    names={"wall_ns":"Finalization total","matching_ns":"Matching","arrow_output_ns":"Arrow output","left_commit_ns":"Left state commit","right_eviction_ns":"Right eviction","emit_ns":"Emit and await","residual_ns":"Other finalization"}
    for group,title in (("all","All finalization callbacks"),("emitting","Callbacks that emitted rows")):
        lines+=["## "+title,"","Times and differences are milliseconds. Each round's last column pair reports the median of ten main-minus-release differences. P50 and P95 pool the twenty formal samples per arm.",""]
        trs=[]
        for k,lab in names.items():
            d=qa[group][k]; r=d["baseline"];h=d["candidate"];d1,d2=d["paired_median_delta_per_round"]
            trs.append([lab,f"{r['p50']:.3f}",f"{h['p50']:.3f}",f"{r['p95']:.3f}",f"{h['p95']:.3f}",f"{d1:+.3f}",f"{d2:+.3f}"])
        lines += [table(["Elapsed","11.14 P50","Main P50","11.14 P95","Main P95","Round 1 Δ","Round 2 Δ"],trs),""]
    oc=result["outer_clock"]
    lines += [f"The instrumented public ready-to-Arrow P50 was {1000*oc['base_p50']:.3f} ms for release and {1000*oc['head_p50']:.3f} ms for main. All 44 executions validated the full one-million-row output with zero maximum absolute error. Each request's finalize trace matched and emitted exactly one million rows.",""]
else:
    lines += [f"The benchmark stopped with {result['completed_warmups']} controller-accepted warmups and {result['completed_formal_samples']} controller-accepted formal samples. No paired stage comparison was established. The original outcome records the stop reason.",""]
lines += ["The exclusive native clocks follow the ASOF operator task across awaits. They measure matching, Arrow materialization, left-state commit, right-side eviction, emit/await and other finalization. The six times sum exactly to each callback's wall clock. Before/after state gauges, emitted/matched/evicted deltas and actual successful gather-ticket counts are preserved by callback and request. All callbacks include pre-watermark and EOF work, some of which can lie outside the ordinary public ready-to-Arrow interval. Input admission is outside these native stage clocks. Parallel release fragments can perform embedded planning work inside worker waits. Trace serialization occurs after the native callback clock. Its overhead can affect the enclosing instrumented run.","",f"The acquisition took {outer:.2f} seconds including interpreter startup and exit, within the 120-second budget. The protocol and original evidence preserve worker-local trace offsets, worker responses, measured intervals, managed interpreter and wheel identities, exact source patches, resource telemetry and stop information. [Summary and per-request data](result.json) · [Original evidence](raw-evidence.tar.gz) · [Receipt](receipt.json)",""]
(D/"README.md").write_text("\n".join(lines));write_json(D/"result.json",result)
digests={}
with tarfile.open(D/"raw-evidence.tar.gz","w:gz",compresslevel=9) as tar:
    for n,p in sorted(files.items()):
        buf=p.read_bytes();t=tarfile.TarInfo(n);t.size=len(buf);t.mode=0o644;tar.addfile(t,io.BytesIO(buf));digests[n]={"bytes":len(buf),"sha256":hashlib.sha256(buf).hexdigest()}
with tarfile.open(D/"raw-evidence.tar.gz") as tar:
    assert set(tar.getnames())==set(files)
    for member in tar:assert tar.extractfile(member).read()==files[member.name].read_bytes()
write_json(D/"receipt.json",{"archive_sha256":sha256_file(D/"raw-evidence.tar.gz"),"members":digests})
print(D, result["completed_warmups"],result["completed_formal_samples"])
