"""Two diagnostic intervals within one managed ASOF execution."""
from __future__ import annotations

import asyncio
import time

import pyarrow as pa

_record = None


def take_record():
    global _record
    if _record is None:
        raise ValueError("missing diagnostic split")
    record, _record = _record, None
    return record


async def measure_ready(sources, sink, streams, job, *, static_join=False):
    from benchmarks import engine_stream as adapter

    global _record
    rows = 1_000_000
    names = ("reference.input", "quotes.input")
    if tuple(streams) != names or static_join or _record is not None or sink.expected_rows != rows:
        raise ValueError("unexpected retained diagnosis shape")
    for events in streams.values():
        if len(events) != 2 or not isinstance(events[0], adapter.Data) or not isinstance(events[1], adapter.Watermark):
            raise ValueError("expected exactly one Data and one watermark per side")
        if events[0].batch.num_rows != rows:
            raise ValueError("both sides require a million-row Data")
    if streams[names[0]][1].at != streams[names[1]][1].at:
        raise ValueError("watermarks differ")
    shape = {n: [streams[n][0].batch.num_rows, streams[n][1].at.isoformat()] for n in names}
    await asyncio.wait_for(asyncio.gather(*(s.ready.wait() for s in sources.values())), 30)
    adapter._require_ready_sources(sources, sink)
    pushes = []
    polls = []
    sleeps = []
    def state():
        (node,) = job.status()["stream_asof_joins"].values()
        return node
    first = state()
    if any(first[s]["accepted_rows"] for s in ("left","right")) or first["emitted_left_rows"]:
        raise ValueError("ASOF was not empty and ready")
    now = time.perf_counter_ns
    async def push(i):
        for name in names:
            begin = now()
            await sources[name].push(streams[name][i])
            end = now()
            pushes.append([name, "Data" if i == 0 else "Watermark", begin, end])
    start = now()
    await push(0)
    while True:
        begin = now()
        snap = state()
        end = now()
        l, r = (snap[s]["accepted_rows"] for s in ("left","right"))
        polls.append([begin, end, l, r, snap["pending_left_rows"], snap["retained_right_rows"], sink.rows])
        if sink.rows or snap["emitted_left_rows"] or any(snap[s]["watermark_micros"] is not None for s in ("left","right")):
            raise ValueError("watermark or output before admission barrier")
        if l == rows and r == rows:
            if snap["pending_left_rows"] != rows or snap["retained_right_rows"] != rows:
                raise ValueError("retained state differs from admitted rows")
            break
        before_sleep = now()
        await asyncio.sleep(0.001)
        sleeps.append(now() - before_sleep)
    boundary = now()
    await push(1)
    await asyncio.wait_for(sink.complete.wait(), 30)
    if sink.rows != rows:
        raise ValueError("unexpected delivered row count")
    table = pa.concat_tables(sink.tables)
    ended = now()
    _record = {
        "input_shape": shape, "pushes": pushes, "start_ns": start, "boundary_ns": boundary, "end_ns": ended,
        "admission_ns": boundary-start, "delivery_ns": ended-boundary,
        "polls": polls, "poll_sleep_ns": sleeps, "poll_active_ns": sum(p[1]-p[0] for p in polls),
        "initial": first, "before_watermarks": snap, "sink_rows_at_boundary": polls[-1][-1],
        "post_delivery_status": state(), "delivered_rows": sink.rows, "delivered_batches": len(sink.tables),
    }
    return table, (ended-start)/1e9
