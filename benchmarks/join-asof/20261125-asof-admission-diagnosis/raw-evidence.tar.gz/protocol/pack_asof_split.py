from pathlib import Path
import hashlib,io,json,tarfile
r=Path("target"); obs=r/"observed-asof-phase"; dest=r/"publications/benchmarks/join-asof/20261125-asof-admission-diagnosis"
dest.mkdir(parents=True,exist_ok=False)
d=lambda p:json.loads(p.read_text())
m=lambda b:hashlib.sha256(b).hexdigest()
files={}
for p in obs.rglob("*"):
 if p.is_file() and "site" not in p.relative_to(obs).parts:
  files["observation/"+str(p.relative_to(obs))]=p
for name in ("asof_phase_control.py","asof-phase-registration.json","asof-phase-run.log","pack_asof_split.py"):
 files["protocol/"+name]=r/name
for name in ("engine_comparison.py","engine_stream.py","asof_phase_split.py"):
 files["overlay/benchmarks/"+name]=r/"asof-phase-worker/benchmarks"/name
for arm,k in (("baseline","release-1114"),("candidate","round2-asof")):
 for name in ("build.log","build-driver.log","release.json","build.json"):
  files[f"builds/{arm}/{name}"]=Path("../main-src/target/products")/k/name
reg=d(r/"asof-phase-registration.json")
for name,sha in reg["hashes"].items():
 assert m(Path(name).read_bytes())==sha
report=d(obs/"outcome.json"); resources=[json.loads(s) for s in (obs/"resources.jsonl").read_text().splitlines()]
completed=[d(p) for p in (obs/"measurement").rglob("*.completed.json")]
worker=d(obs/"measurement/round-0/baseline/worker-request-0002.json")["response"]["warmup"]
clock=worker["phase_split"]
counts={s:clock["before_watermarks"][s]["accepted_rows"] for s in ("left","right")}
assert report["state"]=="stopped" and all(i["operation"]=="hello" for i in completed)
assert all(v==1_000_000 for v in counts.values()) and clock["sink_rows_at_boundary"]==0 and worker["correctness"]["max_abs_error"]==0
status={"outcome":report,"controller_completed_warmups":0,"completed_formal_samples":0,"worker_only_baseline_warmup":{"eligible_for_comparison":False,"accepted_counts":counts,"sink_rows_at_boundary":0,"oracle":worker["correctness"]},"resources":resources,"verdict":"inconclusive"}
(dest/"result.json").write_text(json.dumps(status,indent=2)+"\n")
(dest/"README.md").write_text("""# Managed ASOF admission and watermark diagnosis

The 11.14 release and candidate 6269bda3 had no qualified paired timing for this diagnosis. The three-second preflight passed. The first subsequent resource interval recorded 418 major faults against a limit of 256, 1 swap-in page and 2.55% host CPU utilization. The controller stopped after 7.038 seconds of the 120-second budget. Zero formal samples completed, and neither the relative cost of admission nor the relative cost of output delivery was established. [Outcome and resource intervals](result.json)

The release worker independently recorded an excluded warmup while the controller was cancelling it. Before either watermark, this observation contained one million accepted and pending left rows, one million accepted and retained right rows, and zero emitted or delivered rows. Its final output passed the full sorted sequence and value oracle with zero maximum absolute error. No candidate warmup or paired observations are available. The single discarded warmup is preserved in the original journal.

The registered schedule used the existing managed 4-thread ASOF EngineCase, one million rows per side, 64 symbols and zero tolerance. From a ready empty runner it pushed reference Data then quotes Data, observed operator acceptance on both sides, then pushed the same reference and quotes watermarks, awaited full delivery and concatenated the Arrow batches. Every status call and its timestamp, requested 1 ms polling sleeps, actual publication order, phase boundaries and queue-to-delivery row counts were included in the worker record. Polling was charged to the admission clock. The altered publication schedule makes these phase clocks diagnostic. The original scheduled comparison uses its own independently recorded throughput clock.

The protocol required two rounds of ten alternating pairs and four excluded warmups, reused the independently sealed release wheels, and checked all outputs and all four SMT groups against the same public-case resource limits. The archive contains the original telemetry, failed request, warmup, manifests, release hashes and registered diagnostic code. [Original evidence](raw-evidence.tar.gz) · [File hashes](receipt.json)

The harness checkout is 983f57435639037f40fb8a9d30aa1f33567ccd16. The protocol requires a worker directory containing its original scripts and benchmarks, with the three files under overlay/benchmarks from the archive supplied in its benchmarks directory. The full harness and controller fingerprints, exact wheels, commands and resource policy are recorded in the archive. The prior scheduled timing and the failed main comparison were never repeated.
""")
digest={}
with tarfile.open(dest/"raw-evidence.tar.gz","w:gz",compresslevel=9) as t:
 for n,p in sorted(files.items()):
  blob=p.read_bytes();i=tarfile.TarInfo(n);i.size=len(blob);i.mode=0o644;t.addfile(i,io.BytesIO(blob));digest[n]={"bytes":len(blob),"sha256":m(blob)}
with tarfile.open(dest/"raw-evidence.tar.gz") as t:
 assert set(t.getnames())==set(files)
 for i in t:assert t.extractfile(i).read()==files[i.name].read_bytes()
(dest/"receipt.json").write_text(json.dumps({"files":digest,"archive_sha256":m((dest/"raw-evidence.tar.gz").read_bytes())},indent=2)+"\n")
print(dest,len(files))
