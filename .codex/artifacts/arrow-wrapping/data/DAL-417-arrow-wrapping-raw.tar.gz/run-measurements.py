from __future__ import annotations
import json
import subprocess
import threading
import signal
import time
from pathlib import Path
import psutil

work = Path('target/arrow-wrapping').resolve()
script = Path('.codex/artifacts/arrow-wrapping/collect.py').resolve()
python = str(Path('target/stream-dispatch/env-head/bin/python').resolve())

def active_compilers():
    return [p.info for p in psutil.process_iter(['pid', 'name', 'status'])
            if p.info['name'] in {'cargo', 'rustc', 'maturin'}
            and p.info['status'] != psutil.STATUS_ZOMBIE]

initial = active_compilers()
if initial:
    raise RuntimeError(f'builds still active: {initial}')
stopped = threading.Event()
observations = []
active_process = None
started = time.monotonic()

def monitor():
    while not stopped.is_set():
        builds = active_compilers()
        if builds:
            observations.append({'elapsed_s':time.monotonic()-started,'builds':builds})
            child = active_process
            if child is not None and child.poll() is None:
                child.send_signal(signal.SIGINT)
            return
        stopped.wait(0.1)

thread = threading.Thread(target=monitor)
thread.start()
try:
    for name, extra in [('diagnostic-head',['--diagnostic-side','head']), ('preflight',['--preflight']), ('results',[])]:
        command=['taskset','-c','0-1',python,str(script),'--seals',str(work/'seals.json'),
                 '--budget',str(work/'budget.json'),'--output',str(work/name),*extra]
        if observations:
            raise RuntimeError('build contention observed')
        active_process = subprocess.Popen(command)
        if active_process.wait() != 0:
            raise RuntimeError('collector failed; observations retained')
finally:
    stopped.set()
    thread.join()
    (work/'build-quiet.json').write_text(json.dumps({'poll_interval_s':0.1,'elapsed_s':time.monotonic()-started,'compiler_observations':observations},indent=2)+'\n')
if observations:
    raise RuntimeError('build contention observed; retained samples do not establish an uncontended comparison')
