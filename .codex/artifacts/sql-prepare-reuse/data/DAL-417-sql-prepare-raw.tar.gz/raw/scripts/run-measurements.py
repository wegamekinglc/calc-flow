from __future__ import annotations
import json
import subprocess
import threading
import time
from pathlib import Path
import psutil

work = Path('target/sql-prepare-reuse').resolve()
script = Path('.codex/artifacts/sql-prepare-reuse/collect.py').resolve()
python = str(work / 'env-base/bin/python')

def active_compilers():
    return [p.info for p in psutil.process_iter(['pid', 'name', 'status'])
            if p.info['name'] in {'cargo', 'rustc', 'maturin'}
            and p.info['status'] != psutil.STATUS_ZOMBIE]

initial = active_compilers()
if initial:
    raise RuntimeError(f'builds still active: {initial}')
stopped = threading.Event()
observations = []
started = time.monotonic()

def monitor():
    while not stopped.is_set():
        builds = active_compilers()
        if builds:
            observations.append({'elapsed_s':time.monotonic()-started,'builds':builds})
        stopped.wait(0.1)

thread = threading.Thread(target=monitor)
thread.start()
try:
    for name, extra in [('preflight',['--preflight']), ('results',[])]:
        command=['taskset','-c','0-1',python,str(script),'--seals',str(work/'seals.json'),
                 '--budget',str(work/'budget.json'),'--output',str(work/name),*extra]
        subprocess.run(command,check=True)
finally:
    stopped.set()
    thread.join()
    (work/'build-quiet.json').write_text(json.dumps({'poll_interval_s':0.1,'elapsed_s':time.monotonic()-started,'compiler_observations':observations},indent=2)+'\n')
if observations:
    raise RuntimeError('build contention observed; retained samples do not establish an uncontended comparison')
