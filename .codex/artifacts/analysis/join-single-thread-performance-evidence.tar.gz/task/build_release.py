"""Seal the exact clean-source release for this join performance comparison."""

from __future__ import annotations

import hashlib
import json
import os
import platform
import subprocess
import sys
import time
import zipfile
from pathlib import Path

ROOT = Path(__file__).resolve().parents[3]
OUT = Path(__file__).resolve().parent / "releases" / sys.argv[1]
SOURCE = ROOT / "target/worktrees" / (
    "join-single-thread-baseline" if sys.argv[1] == "base"
    else "join-single-thread-candidate-sealed"
)
PYTHON = ROOT / ".venv/bin/python"


def git(*args):
    return subprocess.check_output(["git", *args], cwd=SOURCE, text=True).strip()


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


assert sys.argv[1] in {"base", "candidate"}
assert not git("status", "--porcelain", "--untracked-files=no")
OUT.mkdir(parents=True, exist_ok=False)
env = dict(os.environ, CARGO_TARGET_DIR=str(ROOT / "target"), CARGO_BUILD_JOBS="2",
           PYO3_PYTHON=str(PYTHON))
env.pop("RUSTFLAGS", None)
command = [str(PYTHON), "-m", "maturin", "build", "--release", "--locked", "--out", str(OUT / "wheel")]
record = {
    "command": command, "source": str(SOURCE), "source_sha": git("rev-parse", "HEAD"),
    "source_tree": git("rev-parse", "HEAD^{tree}"), "tracked_source_clean": True,
    "profile": "release", "features": ["default"], "python": platform.python_version(),
    "cargo_lock_sha256": digest(SOURCE / "Cargo.lock"),
    "rustc_verbose": subprocess.check_output(["rustc", "--version", "--verbose"], text=True),
    "environment": {key: env.get(key) for key in ("CARGO_TARGET_DIR", "CARGO_BUILD_JOBS", "PYO3_PYTHON", "RUSTFLAGS")},
    "started_unix": time.time(),
}
(OUT / "build.json").write_text(json.dumps(record, indent=2) + "\n")
started = time.monotonic()
with (OUT / "build.log").open("w") as log:
    subprocess.run(["cargo", "clean", "-p", "calc-flow", "--release"], cwd=SOURCE, env=env, check=True, stdout=log, stderr=subprocess.STDOUT)
    code = subprocess.run(command, cwd=SOURCE, env=env, stdout=log, stderr=subprocess.STDOUT).returncode
record.update(exit_code=code, elapsed_seconds=time.monotonic() - started)
assert git("rev-parse", "HEAD") == record["source_sha"]
assert not git("status", "--porcelain", "--untracked-files=no")
if code == 0:
    assert "Compiling calc-flow v" in (OUT / "build.log").read_text()
    wheels = list((OUT / "wheel").glob("*.whl"))
    assert len(wheels) == 1
    wheel = wheels[0]
    site = OUT / "site"
    site.mkdir()
    with zipfile.ZipFile(wheel) as archive:
        archive.extractall(site)
    natives = list((site / "calc_flow").glob("_native*.so"))
    assert len(natives) == 1
    native = natives[0]
    record.update(wheel=str(wheel), wheel_sha256=digest(wheel), native=str(native),
                  native_sha256=digest(native), modified_core_recompiled=True)
(OUT / "build.json").write_text(json.dumps(record, indent=2) + "\n")
print(json.dumps(record, indent=2), flush=True)
raise SystemExit(code)
