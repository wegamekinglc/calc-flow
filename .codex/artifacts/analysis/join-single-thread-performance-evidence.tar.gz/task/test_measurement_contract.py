"""Validate the bounded acquisition without importing or starting native work."""

from __future__ import annotations

import ast
import copy
import json
import sys
import tempfile
import unittest
from pathlib import Path

import pyarrow as pa
from measurement_contract import frozen_schema, identity_order_sha256, validate_output
from prepare_plan import INVENTORY, validate_fixed_plan, workload

from scripts.benchmark_suite import catalog

ROOT = Path(__file__).resolve().parent


def worker_function(name):
    tree = ast.parse((ROOT / "measure_worker.py").read_text())
    function = next(
        node
        for node in tree.body
        if isinstance(node, ast.FunctionDef) and node.name == name
    )
    namespace = {"catalog": catalog}
    exec(
        compile(ast.Module(body=[function], type_ignores=[]), "worker-check", "exec"),
        namespace,
    )
    return namespace[name]


def table(scenario, columns):
    return pa.Table.from_arrays(columns, schema=frozen_schema(scenario))


def geometry(definition):
    case = definition["case"]
    scenario, rows, batch = case["scenario"], case["rows"], definition["batch_rows"]
    names = (
        ("quotes.input", "reference.input")
        if scenario == "asof_join"
        else ("left", "right")
    )
    return {
        "case": case,
        "batch_rows": batch,
        "stream_entities": 64,
        "expected_rows": 11 * rows - 1920 if scenario == "interval_join" else rows,
        "actual_stream_batches": {
            name: [
                {"envelope_rows": length, "record_batch_rows": [length]}
                for length in (
                    [64]
                    if name == "right" and scenario == "join"
                    else [min(batch, rows - start) for start in range(0, rows, batch)]
                )
            ]
            for name in names
        },
    }


class OracleTests(unittest.TestCase):
    def test_join_and_asof_reject_wrong_identity_value_or_sequence_order(self):
        for scenario in ("join", "asof_join"):
            expected = table(scenario, [[0, 1, 2], [100.0, 100.125, 100.25]])
            self.assertTrue(validate_output(scenario, expected, expected, 3)["passed"])
            invalids = (
                expected.take(pa.array([2, 0, 1])),
                expected.take(pa.array([0, 0, 2])),
                table(scenario, [[0, 1, 3], [100.0, 100.125, 100.25]]),
                table(scenario, [[0, 1, 2], [100.0, 100.125, 999.0]]),
                table(scenario, [[0, 1, 2], [100.0, None, 100.25]]),
            )
            for invalid in invalids:
                with self.subTest(scenario=scenario), self.assertRaises(ValueError):
                    validate_output(scenario, invalid, expected, 3)

    def test_schema_nullability_metadata_and_types_are_exact(self):
        for scenario in ("join", "asof_join", "interval_join"):
            columns = [[0, 1], [100.0, 100.125]]
            if scenario == "interval_join":
                columns.insert(1, [1, 1])
            expected = table(scenario, columns)
            changed = expected.set_column(0, "sequence", pa.array([0, 1]))
            for invalid in (
                expected.replace_schema_metadata({"unexpected": "metadata"}),
                pa.table({name: expected[name] for name in expected.column_names}),
                changed,
            ):
                with self.subTest(scenario=scenario), self.assertRaises(ValueError):
                    validate_output(scenario, invalid, expected, 2)

    def test_interval_checks_all_pairs_multiplicity_values_and_records_order(self):
        expected = table("interval_join", [[0, 0, 1], [0, 1, 1], [2.0, 3.0, 4.0]])
        reordered = expected.take(pa.array([2, 0, 1]))
        proof = validate_output("interval_join", reordered, expected, 2)
        self.assertTrue(proof["passed"])
        self.assertNotEqual(
            proof["identity_order_sha256"], identity_order_sha256(expected)
        )
        for invalid in (
            expected.take(pa.array([0, 0, 2])),
            table("interval_join", [[0, 0, 1], [0, 2, 1], [2.0, 3.0, 4.0]]),
            table("interval_join", [[0, 0, 1], [0, 1, 1], [2.0, 3.0, 5.0]]),
            expected.slice(0, 2),
        ):
            with self.assertRaises(ValueError):
                validate_output("interval_join", invalid, expected, 2)

    def test_order_hash_uses_visible_rows_and_ignores_arrow_chunk_boundaries(self):
        source = table("interval_join", [[99, 0, 1, 2, 88], [9, 2, 1, 0, 8], [1.0] * 5])
        visible = source.slice(1, 3)
        segmented = pa.concat_tables(
            [visible.slice(0, 1), visible.slice(1, 1), visible.slice(2, 1)]
        )
        copied = visible.take(pa.array([0, 1, 2]))
        self.assertEqual(
            identity_order_sha256(segmented), identity_order_sha256(copied)
        )
        self.assertEqual(identity_order_sha256(visible), identity_order_sha256(copied))

    def test_all_five_geometries_reject_record_fragmentation(self):
        check = worker_function("validate_engine_geometry")
        for dimensions in INVENTORY:
            value = geometry(workload(*dimensions))
            check(value)
            name = sorted(value["actual_stream_batches"])[0]
            fragmented = copy.deepcopy(value)
            size = fragmented["actual_stream_batches"][name][0]["envelope_rows"]
            fragmented["actual_stream_batches"][name][0]["record_batch_rows"] = [
                size // 2,
                size - size // 2,
            ]
            with (
                self.subTest(dimensions=dimensions),
                self.assertRaisesRegex(ValueError, "physical Arrow geometry"),
            ):
                check(fragmented)

    def test_geometry_rejects_dimension_size_tail_or_adapter_drift(self):
        check = worker_function("validate_engine_geometry")
        base = geometry(workload("join", 1, 64_000))
        self.assertEqual(len(base["actual_stream_batches"]["left"]), 16)
        self.assertEqual(
            base["actual_stream_batches"]["left"][-1]["envelope_rows"], 40_000
        )
        for name in ("left", "right"):
            changed = copy.deepcopy(base)
            changed["actual_stream_batches"][name][-1]["envelope_rows"] -= 1
            with self.assertRaises(ValueError):
                check(changed)
        changed = geometry(workload("asof_join", 1, 1_000_000))
        changed["case"]["batch_rows"] = 1_000_000
        with self.assertRaisesRegex(ValueError, "bounded-feed"):
            check(changed)

    def test_interval_status_requires_progress_and_no_resource_failures(self):
        check = worker_function("validate_stream_evidence")
        case = workload("interval_join", 1, 1_000_000)["case"]
        side = {
            "watermark_micros": 1,
            "retained_rows": 320,
            "evicted_rows": 999680,
            "late_rows": 0,
            "null_event_time_rows": 0,
            "null_key_rows": 0,
        }
        status = {
            "emitted_match_rows": 10_998_080,
            "state_limit_failures": 0,
            "match_limit_failures": 0,
            "left": dict(side),
            "right": dict(side),
        }
        sample = {
            "stream_evidence": {
                **catalog.stream_dimensions("interval_join", 1_000_000, False),
                "nonterminal_epochs": [],
                "recovery": "not-requested",
                "interval_join": {"join": status},
            }
        }
        self.assertEqual(
            check(sample, case)["completion_contract"],
            "maintained-run_with_completion/completed",
        )
        for key, value in (
            ("watermark_micros", None),
            ("evicted_rows", 0),
            ("retained_rows", 0),
            ("late_rows", 1),
        ):
            changed = copy.deepcopy(sample)
            changed["stream_evidence"]["interval_join"]["join"]["left"][key] = value
            with self.subTest(key=key), self.assertRaises(ValueError):
                check(changed, case)
        changed = copy.deepcopy(sample)
        changed["stream_evidence"]["interval_join"]["join"]["state_limit_failures"] = 1
        with self.assertRaises(ValueError):
            check(changed, case)

    def test_static_join_status_requires_sealed_left_and_all_output(self):
        check = worker_function("validate_stream_evidence")
        case = workload("join", 1, 64_000)["case"]
        sample = {
            "stream_evidence": {
                **catalog.stream_dimensions("join", 64_000, False),
                "nonterminal_epochs": [],
                "recovery": "not-requested",
                "interval_join": {},
                "lookup_join": {
                    "left": {"retained_rows": 0},
                    "emitted_match_rows": 1_000_000,
                    "state_limit_failures": 0,
                    "match_limit_failures": 0,
                },
            }
        }
        check(sample, case)
        changed = copy.deepcopy(sample)
        changed["stream_evidence"]["lookup_join"]["left"]["retained_rows"] = 1
        with self.assertRaises(ValueError):
            check(changed, case)

    def test_plan_rejects_budget_samples_workloads_or_baseline_changes(self):
        plan = json.loads((ROOT / "plan.json").read_text())
        validate_fixed_plan(plan)
        for field in (
            "budget_seconds",
            "formal_acquisition_seconds",
            "samples_per_arm_per_round",
            "formal_observations",
            "warmups_per_worker",
        ):
            changed = copy.deepcopy(plan)
            changed[field] += 1
            with self.subTest(field=field), self.assertRaises(ValueError):
                validate_fixed_plan(changed)
        changed = copy.deepcopy(plan)
        changed["workloads"][-1] = changed["workloads"][0]
        with self.assertRaises(ValueError):
            validate_fixed_plan(changed)
        changed = copy.deepcopy(plan)
        changed["revisions"]["base"] = "0" * 40
        with self.assertRaises(ValueError):
            validate_fixed_plan(changed)

    def test_visible_compiler_and_external_worker_rejected_owned_worker_ignored(self):
        import measure

        with tempfile.TemporaryDirectory(dir=ROOT) as directory:
            entry = Path(directory) / "999999999"
            entry.mkdir()
            (entry / "comm").write_text("rustc\n")
            (entry / "cmdline").write_bytes(b"rustc\x00--crate-name\x00example\x00")
            fields = ["R", *("0" for _ in range(19))]
            (entry / "stat").write_text("999999999 (rustc) " + " ".join(fields))
            (entry / "cwd").symlink_to(ROOT, target_is_directory=True)
            self.assertEqual(measure.visible_interference(entry)["reason"], "compiler")
            (entry / "comm").write_text("python\n")
            (entry / "cmdline").write_bytes(
                b"python\x00/another/task/measure_worker.py\x00"
            )
            self.assertEqual(
                measure.visible_interference(entry)["reason"],
                "known external CPU workload",
            )
            measure.OWNED_PIDS.add(int(entry.name))
            try:
                self.assertIsNone(measure.visible_interference(entry))
            finally:
                measure.OWNED_PIDS.remove(int(entry.name))

    def test_pure_checks_never_load_native_engine(self):
        self.assertNotIn("calc_flow", sys.modules)
        self.assertNotIn("calc_flow._native", sys.modules)


if __name__ == "__main__":
    unittest.main()
