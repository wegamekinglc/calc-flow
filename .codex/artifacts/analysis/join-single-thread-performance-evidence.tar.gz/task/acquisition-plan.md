# Fixed join performance acquisition plan

Recorded before execution on 2026-10-20. Baseline is a clean default-feature
release of main `78b75724f408f9d46a479488b4ecc76ea17aec68`; candidate is the
source-frozen feature commit, sealed before acquisition. Both use identical
dependencies, compiler, flags, workload bytes and maintained EngineCase harness.
Separate build estimate: about 600 seconds per release, sequential builds.

Five cases, each with 1,000,000 workload rows:

1. Join, 1 CPU, 1M source batch: source-width and string/key work.
2. ASOF, 1 CPU, 1M source batch: compact right output indices.
3. Interval, 1 CPU, 1M source batch: retained chunk reuse and run fill.
4. Interval, 32 logical CPUs, 1M source batch: multicore regression control.
5. Join, 1 CPU, 64k source batch: source segmentation control.

Each case has two rounds of ten adjacent alternating AB/BA pairs, reversing
the leading arm in round two. Exactly one excluded warmup per worker (20 total),
200 formal observations. No sample expansion or favorable retries. Set explicit
Tokio workers to the selected affinity count in BOTH arms; keep BLAS/OpenMP at1.
This isolates algorithm changes; native auto-worker defaults are unchanged.

One 600-second acquisition budget includes manifests, process startup, fixtures,
preflight, warmup, complete correctness oracles, EOF/lifecycle, and cleanup.
Reserve30 seconds for cleanup; stop acquisition at570 seconds. No new profile
acquisition budget. End-to-end timer remains ready-source enqueue through Arrow
output. Preserve exact maintained workload and output oracle. Record source,
tree, wheel/native, harness hashes, affinity, dependencies, actual source
geometry, thread settings, completion status, raw timings and peak RSS.

Use maintained report.comparison paired-median confidence intervals: both
round lower bounds above+5% confirm regression; any upper bound above+5% is
inconclusive; both upper bounds below-5% establish improvement; otherwise no
confirmed regression. Report all outcomes, missing paths and uncertainty.
Quiet-host preflight must reject competing compilers or benchmark workloads.
Never reuse historical PR482 timings as current-main measurements.
