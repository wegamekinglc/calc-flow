"""Five fixed join configurations with maintained paired statistics."""

from __future__ import annotations

import hashlib
import json
import math
import os
import select
import signal
import statistics
import subprocess
import sys
import time
import zipfile
from contextlib import suppress
from pathlib import Path

ACQUISITION_STARTED = time.monotonic()
ROOT = Path(__file__).resolve().parent
PLAN_PATH = ROOT / "plan.json"
REPORT_ROOT = ROOT / "reports"
PLAN = json.loads(PLAN_PATH.read_text())
OWNED_PIDS = {os.getpid()}
SOURCE = Path(PLAN["source"])
sys.path.insert(0, str(SOURCE))

from prepare_plan import HELPERS, MAINTAINED, validate_fixed_plan  # noqa: E402

from scripts.benchmark_suite.process import child_environment  # noqa: E402
from scripts.benchmark_suite.report import comparison  # noqa: E402
from scripts.toolkit import linear_percentile  # noqa: E402


def sha256(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def release_site(build: dict) -> Path:
    return Path(build["native"]).parent.parent


def git_output(source: Path, *arguments: str) -> str:
    return subprocess.check_output(
        ["git", "-c", f"lfs.storage={ROOT / 'git-lfs-cache'}", *arguments],
        cwd=source,
        text=True,
        env={**os.environ, "GIT_OPTIONAL_LOCKS": "0"},
    )


def write(report: dict) -> None:
    (REPORT_ROOT / "measurement.json").write_text(
        json.dumps(report, indent=2, allow_nan=False) + "\n"
    )


def visible_interference(entry: Path) -> dict | None:
    if int(entry.name) in OWNED_PIDS:
        return None
    name = (entry / "comm").read_text().strip()
    argv = [
        item.decode(errors="replace")
        for item in (entry / "cmdline").read_bytes().split(b"\0")
        if item
    ]
    executable = Path(argv[0]).name if argv else ""
    guard = PLAN["environment_guard"]
    reason = (
        "compiler"
        if name in guard["compiler_comm_names"]
        else "known external CPU workload"
        if (
            executable in guard["external_executable_basenames"]
            or any(
                Path(argument).name in guard["external_argument_basenames"]
                for argument in argv
            )
        )
        else None
    )
    if reason is None:
        return None
    stat = (entry / "stat").read_text()
    fields = stat.rsplit(")", 1)[1].split()
    if fields[0] in {"Z", "X"}:
        return None
    return {
        "pid": entry.name,
        "name": name,
        "reason": reason,
        "argv": argv,
        "cwd": os.readlink(entry / "cwd"),
        "state": fields[0],
        "cpu_ticks": int(fields[11]) + int(fields[12]),
        "start_ticks": int(fields[19]),
        "stat": stat,
    }


def require_suitable_environment(report: dict) -> None:
    competing = []
    for entry in Path("/proc").iterdir():
        if not entry.name.isdigit():
            continue
        try:
            if interference := visible_interference(entry):
                competing.append(interference)
        except (FileNotFoundError, PermissionError, ProcessLookupError):
            continue
    if competing:
        report["interference"] = competing
        raise RuntimeError("unsuitable environment: concurrent build or CPU workload")


def close(process) -> None:
    try:
        with suppress(BrokenPipeError):
            process.stdin.close()
        if process.poll() is not None:
            return
        try:
            process.wait(timeout=2)
        except subprocess.TimeoutExpired:
            with suppress(ProcessLookupError):
                os.killpg(process.pid, signal.SIGTERM)
            try:
                process.wait(timeout=2)
            except subprocess.TimeoutExpired:
                with suppress(ProcessLookupError):
                    os.killpg(process.pid, signal.SIGKILL)
                process.wait(timeout=1)
    finally:
        process.stdout.close()


def settle(workers: dict, logs: list) -> list[dict]:
    errors = []
    for label, process in workers.items():
        try:
            close(process)
        except BaseException as error:
            errors.append({"resource": "worker", "label": label, "error": repr(error)})
    for index, log in enumerate(logs):
        try:
            log.close()
        except BaseException as error:
            errors.append({"resource": "log", "index": index, "error": repr(error)})
    return errors


def validate_sample(sample: dict) -> None:
    value = sample["seconds"]
    if type(value) not in (int, float) or not math.isfinite(value) or value <= 0:
        raise ValueError("sample duration must be finite and positive")
    if (
        sample["correctness"].get("passed") is not True
        or sample["correctness"].get("max_abs_error") != 0.0
    ):
        raise ValueError("strict all-row identity/value/schema oracle failed")
    if sample.get("completion_contract") != "maintained-run_with_completion/completed":
        raise ValueError("missing maintained job completion evidence")


def round_identity(current: dict) -> dict:
    return {
        name: current["identity"]["A"]["identities"][name]
        for name in ("machine", "dependency")
    } | {"workload": current["prepare"]["A"]["workload"]}


def descriptive(result: dict, label: str) -> dict:
    samples = [
        sample["seconds"] for r in result["rounds"] for sample in r["samples"][label]
    ]
    return {
        "p50_seconds": statistics.median(samples),
        "min_seconds": min(samples),
        "max_seconds": max(samples),
        "p95_seconds": linear_percentile(samples, 0.95),
        "samples": len(samples),
    }


def run() -> None:
    if PLAN["readiness"] != "frozen-ready" or not PLAN["execution_authorized"]:
        raise RuntimeError("plan is not frozen with an exact candidate release")
    if (REPORT_ROOT / "measurement.json").exists():
        raise RuntimeError(
            "run evidence already exists; refusing to overwrite or retry"
        )
    REPORT_ROOT.mkdir(parents=True, exist_ok=True)
    started = ACQUISITION_STARTED
    deadline = started + PLAN["budget_seconds"] - PLAN["cleanup_reserve_seconds"]
    report = {
        "status": "running",
        "started_unix": time.time(),
        "plan": PLAN,
        "plan_sha256": sha256(PLAN_PATH),
        "harness_hashes": {
            str(path): sha256(path)
            for path in (
                *(ROOT / name for name in HELPERS),
                *(SOURCE / name for name in MAINTAINED),
            )
        },
        "cases": [],
        "loadavg_before": os.getloadavg(),
    }
    write(report)
    transcripts = {}

    def request(process, message):
        remaining = deadline - time.monotonic()
        if remaining <= 0:
            raise TimeoutError("measurement budget exhausted; cleanup reserve retained")
        process.stdin.write(json.dumps(message) + "\n")
        process.stdin.flush()
        if not select.select([process.stdout], [], [], remaining)[0]:
            raise TimeoutError("worker exceeded acquisition deadline")
        line = process.stdout.readline()
        if not line:
            raise RuntimeError(f"worker exited with code {process.poll()}")
        transcripts[process.pid].write(line)
        transcripts[process.pid].flush()
        response = json.loads(line)
        if "warmup" in response:
            validate_sample(response["warmup"])
        elif "seconds" in response:
            validate_sample(response)
        return response

    try:
        require_suitable_environment(report)
        validate_fixed_plan(PLAN)
        if sha256(ROOT / "acquisition-plan.md") != PLAN["text_plan_sha256"]:
            raise ValueError("predeclared text plan changed after preparation")
        if report["harness_hashes"] != PLAN["prepared_harness_sha256"]:
            raise ValueError("measurement harness changed after plan preparation")
        if git_output(SOURCE, "rev-parse", "HEAD").strip() != PLAN["source_sha"]:
            raise ValueError("candidate harness source revision changed")
        if (
            git_output(SOURCE, "rev-parse", "HEAD^{tree}").strip()
            != PLAN["source_tree"]
        ):
            raise ValueError("candidate harness source tree changed")
        if git_output(SOURCE, "status", "--porcelain", "--untracked-files=no"):
            raise ValueError("candidate harness snapshot is not tracked-source clean")
        allowed = sorted(os.sched_getaffinity(0))
        topology = {}
        for cpu in allowed:
            directory = Path(f"/sys/devices/system/cpu/cpu{cpu}/topology")
            physical = tuple(
                (directory / name).read_text().strip()
                for name in ("physical_package_id", "core_id")
            )
            topology.setdefault(physical, cpu)
        cores = list(topology.values())
        if not cores or len(allowed) < 32:
            raise ValueError("predeclared 1/32 logical CPU resource set unavailable")
        affinities = {1: cores[:1], 32: allowed[:32]}
        builds = {
            side: json.loads(Path(path).read_text())
            for side, path in PLAN["builds"].items()
        }
        for side, build in builds.items():
            if (
                sha256(Path(PLAN["builds"][side]))
                != PLAN["build_manifest_sha256"][side]
            ):
                raise ValueError(f"{side} manifest changed after plan freeze")
            if build["source_sha"] != PLAN["revisions"][side]:
                raise ValueError(f"wrong {side} source revision")
            expected_tree = (
                PLAN["baseline_source_tree"] if side == "base" else PLAN["source_tree"]
            )
            if build["source_tree"] != expected_tree:
                raise ValueError(f"wrong {side} source tree")
            source = Path(build["source"])
            actual_source = git_output(
                source, "rev-parse", "HEAD", "HEAD^{tree}"
            ).splitlines()
            if actual_source != [build["source_sha"], build["source_tree"]]:
                raise ValueError(f"{side} build source no longer matches its manifest")
            if git_output(source, "status", "--porcelain", "--untracked-files=no"):
                raise ValueError(
                    f"{side} build source is no longer tracked-source clean"
                )
            if (
                build["exit_code"] != 0
                or build["profile"] != "release"
                or build["tracked_source_clean"] is not True
                or build["modified_core_recompiled"] is not True
            ):
                raise ValueError(f"{side} is not a verified exact-source release build")
            if sha256(source / "Cargo.lock") != build["cargo_lock_sha256"]:
                raise ValueError(f"{side} dependency lock differs from its build")
            for artifact in ("wheel", "native"):
                if sha256(Path(build[artifact])) != build[f"{artifact}_sha256"]:
                    raise ValueError(f"{side} {artifact} differs from its sealed build")
            with zipfile.ZipFile(build["wheel"]) as archive:
                site = release_site(build)
                for name in archive.namelist():
                    if (
                        name.startswith("calc_flow/")
                        and name.endswith(".py")
                        and hashlib.sha256(archive.read(name)).hexdigest()
                        != sha256(site / name)
                    ):
                        raise ValueError(f"{side} extracted Python package changed")
        if any(build["features"] != ["default"] for build in builds.values()):
            raise ValueError("diagnostic features cannot enter formal samples")
        for name in ("cargo_lock_sha256", "rustc_verbose", "python", "features"):
            if builds["base"][name] != builds["candidate"][name]:
                raise ValueError(f"paired release {name} differs")
        if builds["base"]["environment"].get("RUSTFLAGS") != builds["candidate"][
            "environment"
        ].get("RUSTFLAGS"):
            raise ValueError("paired release RUSTFLAGS differs")
        report.update(
            builds=builds,
            build_manifest_hashes={
                name: sha256(Path(path)) for name, path in PLAN["builds"].items()
            },
            worker_cpu_affinity=affinities,
            allowed_cpu_affinity=allowed,
            wsl_reported_core_groups=[
                {"socket": key[0], "core": key[1], "first_cpu": value}
                for key, value in topology.items()
            ],
        )
        write(report)
        for workload in PLAN["workloads"]:
            case_result = {"workload": workload, "comparisons": []}
            report["cases"].append(case_result)
            for pairing in workload["pairs"]:
                result = {"pairing": pairing, "rounds": []}
                case_result["comparisons"].append(result)
                labels = ("A", "B")
                for round_id in range(PLAN["rounds"]):
                    workers, logs = {}, []
                    current = {
                        "identity": {},
                        "prepare": {},
                        "samples": {label: [] for label in labels},
                        "order": [],
                        "completion": {},
                    }
                    result["rounds"].append(current)
                    try:
                        for label in labels:
                            arm = pairing[label]
                            count = arm["cpus"]
                            side = arm["release"]
                            root = (
                                REPORT_ROOT
                                / "workers"
                                / workload["id"]
                                / pairing["id"]
                                / f"round-{round_id + 1}-{label}"
                            )
                            root.mkdir(parents=True, exist_ok=False)
                            build_path = Path(PLAN["builds"][side])
                            env = child_environment(
                                release_site(builds[side]),
                                source=SOURCE,
                                polars_threads=count,
                            )
                            env["TOKIO_WORKER_THREADS"] = str(count)
                            log = (root / "stderr.log").open("w")
                            logs.append(log)
                            argv = [
                                "taskset",
                                "-c",
                                ",".join(map(str, affinities[count])),
                                sys.executable,
                                str(ROOT / "measure_worker.py"),
                                str(build_path),
                                str(root),
                            ]
                            process = subprocess.Popen(
                                argv,
                                cwd=SOURCE,
                                env=env,
                                stdin=subprocess.PIPE,
                                stdout=subprocess.PIPE,
                                stderr=log,
                                text=True,
                                bufsize=1,
                                start_new_session=True,
                            )
                            workers[label] = process
                            OWNED_PIDS.add(process.pid)
                            transcript = (root / "stdout.jsonl").open("w")
                            transcripts[process.pid] = transcript
                            logs.append(transcript)
                            hello = request(process, {"operation": "hello"})
                            if (
                                hello["identities"]["machine"]["identity"]["affinity"]
                                != affinities[count]
                            ):
                                raise ValueError("worker affinity differs from plan")
                            if (
                                hello["proof"]["native_sha256"]
                                != builds[side]["native_sha256"]
                            ):
                                raise ValueError(
                                    "loaded native differs from sealed release"
                                )
                            for path in hello["loaded_harness"]:
                                if not Path(path).is_relative_to(SOURCE):
                                    raise ValueError(
                                        "worker imported a different harness"
                                    )
                            current["identity"][label] = {"argv": argv, **hello}
                            current["prepare"][label] = request(
                                process,
                                {
                                    "operation": "prepare",
                                    "workload": workload,
                                },
                            )
                        for name in ("dependency", "machine"):
                            if (
                                current["identity"]["A"]["identities"][name]
                                != current["identity"]["B"]["identities"][name]
                            ):
                                raise ValueError(f"paired {name} fingerprints differ")
                        if (
                            current["prepare"]["A"]["workload"]
                            != current["prepare"]["B"]["workload"]
                        ):
                            raise ValueError("paired workload fingerprints differ")
                        actual_identity = round_identity(current)
                        if round_id == 0:
                            result["matched_identity"] = actual_identity
                        elif result["matched_identity"] != actual_identity:
                            raise ValueError("identity changed between paired rounds")
                        for sample_id in range(PLAN["samples_per_arm_per_round"]):
                            require_suitable_environment(report)
                            order = (
                                labels
                                if (sample_id + round_id) % 2 == 0
                                else labels[::-1]
                            )
                            current["order"].append(list(order))
                            for label in order:
                                sample = request(
                                    workers[label], {"operation": "sample"}
                                )
                                current["samples"][label].append(sample)
                                report["elapsed_seconds"] = time.monotonic() - started
                                write(report)
                            require_suitable_environment(report)
                        for label, process in workers.items():
                            completion = request(process, {"operation": "finish"})
                            current["completion"][label] = completion
                            if completion["state"] != "completed":
                                raise ValueError(f"{label} did not complete")
                    finally:
                        acquisition_error = sys.exc_info()[1]
                        cleanup_errors = settle(workers, logs)
                        OWNED_PIDS.difference_update(
                            process.pid for process in workers.values()
                        )
                        if cleanup_errors:
                            current["cleanup_errors"] = cleanup_errors
                            report.setdefault("cleanup_errors", []).append(
                                {
                                    "workload": workload["id"],
                                    "pair": pairing["id"],
                                    "round": round_id + 1,
                                    "errors": cleanup_errors,
                                }
                            )
                            if acquisition_error is None:
                                raise RuntimeError(
                                    "worker/log cleanup failed; see cleanup_errors"
                                )
                    write(report)
                result["descriptive"] = {
                    label: descriptive(result, label) for label in labels
                }
                if pairing["kind"] == "version":
                    result["statistics"] = comparison(
                        {
                            "id": f"{workload['id']}/{pairing['id']}",
                            "rows": workload["case"]["rows"],
                            "correctness": True,
                            "comparison": "interleaved",
                            "baseline": [
                                [sample["seconds"] for sample in r["samples"]["A"]]
                                for r in result["rounds"]
                            ],
                            "candidate": [
                                [sample["seconds"] for sample in r["samples"]["B"]]
                                for r in result["rounds"]
                            ],
                        }
                    )
                print(
                    json.dumps(
                        {
                            "workload": workload["id"],
                            "pair": pairing["id"],
                            "statistics": result["statistics"],
                        }
                    ),
                    flush=True,
                )
                write(report)
        report["status"] = "completed"
    except BaseException as error:
        report.update(
            status="budget-exhausted"
            if isinstance(error, TimeoutError)
            else "environment-unsuitable"
            if report.get("interference")
            else "failed",
            error=repr(error),
        )
        raise
    finally:
        report["elapsed_seconds"] = time.monotonic() - started
        report["loadavg_after"] = os.getloadavg()
        report["completed_cases"] = [
            case["workload"]["id"]
            for case in report["cases"]
            if case["comparisons"]
            and all("statistics" in result for result in case["comparisons"])
        ]
        report["uncompleted_cases"] = [
            case["id"]
            for case in PLAN["workloads"]
            if case["id"] not in report["completed_cases"]
        ]
        report["total_budget_respected"] = (
            report["elapsed_seconds"] <= PLAN["budget_seconds"]
        )
        write(report)


if __name__ == "__main__":
    run()
