"""Freeze the predeclared five-case plan after root seals both releases."""

from __future__ import annotations

import argparse
import hashlib
import json
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent
REPOSITORY = ROOT.parents[2]
SOURCE = REPOSITORY / "target/worktrees/join-single-thread-candidate-sealed"
BASELINE_SOURCE = REPOSITORY / "target/worktrees/join-single-thread-baseline"
BASELINE_SHA = "78b75724f408f9d46a479488b4ecc76ea17aec68"
INVENTORY = (
    ("join", 1, 1_000_000),
    ("asof_join", 1, 1_000_000),
    ("interval_join", 1, 1_000_000),
    ("interval_join", 32, 1_000_000),
    ("join", 1, 64_000),
)
sys.path.insert(0, str(SOURCE))

from scripts.benchmark_suite.catalog import (  # noqa: E402
    engine_cases,
    stream_dimensions,
)

HELPERS = (
    "measure.py",
    "measure_worker.py",
    "measurement_contract.py",
    "prepare_plan.py",
)
MAINTAINED = (
    "benchmarks/engine_comparison.py",
    "benchmarks/engine_stream.py",
    "benchmarks/native_memory_profile.py",
    "benchmarks/engine_lifecycle.py",
    "benchmarks/interval_acceptance.py",
    "benchmarks/join_asof_acceptance.py",
    "scripts/benchmark_suite/catalog.py",
    "scripts/benchmark_suite/process.py",
    "scripts/benchmark_suite/diagnostics.py",
    "scripts/toolkit.py",
    "scripts/benchmark_suite/report.py",
    "scripts/benchmark_suite/statistics.py",
    "scripts/benchmark_suite/issue406_measurement.py",
)


def sha256(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def workload(scenario: str, cpus: int, batch_rows: int) -> dict:
    rows = 1_000_000
    case = next(
        case
        for case in engine_cases(rows)
        if case["backend"] == "calc-flow-stream"
        and case["scenario"] == scenario
        and "/small-batch/" not in case["id"]
        and case.get("batch_rows", rows) == rows
    )
    # The existing exact-cursor adapter supports the explicit segmentation
    # control without changing catalog defaults or the sealed-dimension timer.
    if batch_rows != rows:
        case = {
            **case,
            "id": f"{case['id']}/feature-control-batch-{batch_rows}",
            **stream_dimensions(scenario, batch_rows, False),
        }
    rationales = {
        (
            "join",
            1,
            1_000_000,
        ): "Single-CPU default transport: source-width cache and short string keys.",
        (
            "asof_join",
            1,
            1_000_000,
        ): "Single-CPU default transport: compact right output positions.",
        (
            "interval_join",
            1,
            1_000_000,
        ): "Single-CPU default transport: retained chunk reuse and run appends.",
        (
            "interval_join",
            32,
            1_000_000,
        ): "Multicore regression control for retained lookup and run appends.",
        (
            "join",
            1,
            64_000,
        ): "Same 1M quote workload, 64k transport segmentation control.",
    }
    return {
        "id": f"{scenario}-{rows}-batch{batch_rows}-cpu{cpus}",
        "kind": "engine",
        "case": case,
        "batch_rows": batch_rows,
        "rationale": rationales[scenario, cpus, batch_rows],
        "pairs": [
            {
                "id": f"current-main-vs-candidate-{cpus}cpu",
                "kind": "version",
                "A": {"release": "base", "cpus": cpus},
                "B": {"release": "candidate", "cpus": cpus},
            }
        ],
    }


def release(path: Path, source: Path) -> dict:
    build = json.loads(path.read_text())
    if (
        build.get("exit_code") != 0
        or build.get("features") != ["default"]
        or build.get("profile") != "release"
        or build.get("tracked_source_clean") is not True
        or build.get("modified_core_recompiled") is not True
        or Path(build["source"]).resolve() != source
    ):
        raise ValueError("both arms require exact clean-source default release builds")
    return build


def validate_fixed_plan(plan: dict) -> None:
    fixed = {
        "budget_seconds": 600,
        "formal_acquisition_seconds": 570,
        "cleanup_reserve_seconds": 30,
        "warmups_per_worker": 1,
        "formal_observations": 200,
        "excluded_formal_warmups": 20,
        "rounds": 2,
        "samples_per_arm_per_round": 10,
        "diagnostics": {"enabled": False, "budget_seconds": 0},
    }
    if any(plan.get(name) != value for name, value in fixed.items()):
        raise ValueError("fixed samples, budget or diagnostic inventory changed")
    if plan["workloads"] != [workload(*dimensions) for dimensions in INVENTORY]:
        raise ValueError("predeclared five-case inventory changed")
    if plan["revisions"]["base"] != BASELINE_SHA:
        raise ValueError("predeclared baseline revision changed")


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--baseline-build", type=Path)
    parser.add_argument("--candidate-build", type=Path)
    args = parser.parse_args()
    if (ROOT / "reports/measurement.json").exists():
        raise RuntimeError("acquisition exists; refusing to replace its plan")
    baseline = (
        release(args.baseline_build, BASELINE_SOURCE) if args.baseline_build else None
    )
    candidate = release(args.candidate_build, SOURCE) if args.candidate_build else None
    if baseline is not None and baseline["source_sha"] != BASELINE_SHA:
        raise ValueError("baseline must be the predeclared current-main revision")
    ready = baseline is not None and candidate is not None
    files = [
        *(ROOT / name for name in HELPERS),
        *(SOURCE / name for name in MAINTAINED),
    ]
    plan = {
        "schema": "calc-flow.join-single-thread-feature-plan.v1",
        "readiness": "frozen-ready" if ready else "awaiting-sealed-releases",
        "execution_authorized": ready,
        "source": str(SOURCE),
        "source_sha": candidate["source_sha"] if candidate else None,
        "source_tree": candidate["source_tree"] if candidate else None,
        "baseline_source_tree": baseline["source_tree"] if baseline else None,
        "revisions": {
            "base": BASELINE_SHA,
            "candidate": candidate["source_sha"] if candidate else None,
        },
        "builds": {
            "base": str(args.baseline_build.resolve()) if baseline else None,
            "candidate": str(args.candidate_build.resolve()) if candidate else None,
        },
        "build_manifest_sha256": {
            "base": sha256(args.baseline_build) if baseline else None,
            "candidate": sha256(args.candidate_build) if candidate else None,
        },
        "text_plan_sha256": sha256(ROOT / "acquisition-plan.md"),
        "measurement_contract": (
            "Focused maintained EngineCase ready-enqueue-through-Arrow-concat. "
            "Two rounds of ten adjacent alternating AB/BA pairs, opposite round "
            "leads, maintained paired-median confidence intervals. No whole-suite "
            "verdict; cross-CPU and cross-adapter ratios descriptive only."
        ),
        "rounds": 2,
        "samples_per_arm_per_round": 10,
        "warmups_per_worker": 1,
        "formal_observations": 200,
        "excluded_formal_warmups": 20,
        "budget_seconds": 600,
        "formal_acquisition_seconds": 570,
        "cleanup_reserve_seconds": 30,
        "budget_includes": [
            "release preflight",
            "fixture construction",
            "process startup",
            "warmups",
            "full oracle checks",
            "EOF",
            "progress observation",
            "cleanup",
        ],
        "builds_budgeted_separately": True,
        "build_estimate_seconds_per_release": 600,
        "baseline_default_release_reused": False,
        "diagnostics": {"enabled": False, "budget_seconds": 0},
        "workloads": [workload(*dimensions) for dimensions in INVENTORY],
        "fixture": {
            "entities": 64,
            "rows_parameter": (
                "1M quotes; ASOF and interval replay the same 1M rows on "
                "each side; static join has 64 dimension rows."
            ),
            "physical_geometry": (
                "Coalesce maintained immutable input before EngineCase "
                "creates events. Each event owns exactly one RecordBatch; "
                "1M transport has one event per quote side; 64k has 15 "
                "full events and a 40k tail. No catalog defaults change."
            ),
            "asof": (
                "Maintained zero-tolerance bounded feeds; "
                "AsofStateLimits(2*N+128,1GiB); N exact identity/value "
                "rows."
            ),
            "interval": (
                "Maintained inclusive +/-5-second exact-cursor replay; "
                "JoinStateLimits(6*N+768,1GiB,11*N); 11*N-1920 exact "
                "pairs."
            ),
            "join": (
                "Maintained sealed static dimension preload outside "
                "timer; 1M uses bounded feed, 64k uses exact-cursor "
                "replay; both retain zero quotes at accepted cut."
            ),
            "edge_budget": "Maintained case batch rows; 64MiB.",
            "schemas": (
                "Join sequence:uint64/value:float64 nonnull; ASOF "
                "sequence:uint64 nonnull/value:float64 nullable; interval "
                "sequence/right_sequence:uint64 and value:float64 "
                "nonnull; metadata exact."
            ),
            "state_lifecycle": (
                "Fresh checkpoint path for every invocation; maintained "
                "run_with_completion, EOF delivery count, and awaited "
                "cancellation cleanup."
            ),
            "order": (
                "Join/ASOF input sequence order is checked. Interval "
                "exact pair/multiplicity oracle retains its "
                "order-independent cross-input contract; normalized "
                "identity-order SHA-256 is descriptive only, recorded "
                "outside timer, and is never a global acceptance gate "
                "because cross-input scheduling may legitimately change "
                "emission order. Focused Rust tests prove per-probe run "
                "append order on both input sides."
            ),
        },
        "environment_guard": {
            "compiler_comm_names": [
                "cargo",
                "rustc",
                "rustdoc",
                "ld.lld",
                "clippy-driver",
                "cc1",
                "cc1plus",
                "maturin",
            ],
            "external_executable_basenames": [
                "p2-ci-repair-baseline-quote-risk",
                "perf",
                "samply",
            ],
            "external_argument_basenames": [
                "measure.py",
                "measure_worker.py",
                "native_memory_profile.py",
                "diagnostic_worker.py",
                "engine_worker.py",
                "warm_worker.py",
            ],
            "policy": (
                "Root must launch with host /proc visibility after owned "
                "builds settle. Reject visible competing compilers or "
                "benchmark workloads; never signal external processes. "
                "WSL host power and host-wide quiet cannot be "
                "established."
            ),
        },
        "resource_interpretation": (
            "Whole-sample CPU includes untimed oracles/lifecycle and "
            "cannot be divided by ready wall time. Excluded warmup "
            "PhaseClock is ready-window CPU only and can include lazy "
            "startup. No diagnostic build/profiling or actual "
            "worker-concurrency claim."
        ),
        "unmeasured": [
            "ASOF multicore",
            "join multicore",
            "other scales",
            "skewed/wide/nested payload timings",
            "sparse long-lived state",
            "checkpoint/recovery timings",
            "external-engine comparisons",
        ],
        "prepared_harness_sha256": {str(path): sha256(path) for path in files},
        "no_automatic_retry_expansion_or_budget_extension": True,
    }
    (ROOT / "plan.json").write_text(json.dumps(plan, indent=2, allow_nan=False) + "\n")
    print(
        json.dumps(
            {
                "path": str(ROOT / "plan.json"),
                "readiness": plan["readiness"],
                "cases": len(plan["workloads"]),
            }
        )
    )


if __name__ == "__main__":
    main()
