from __future__ import annotations
import json
import os
import subprocess
import sysconfig
from pathlib import Path
ROOT=Path(__file__).resolve().parents[3]
SOURCE=ROOT/'target/worktrees/join-cpu-pipeline'
OUT=Path(__file__).resolve().parent
ENV=dict(os.environ,CARGO_TARGET_DIR=str(ROOT/'target'),CARGO_BUILD_JOBS='2',PYO3_PYTHON=str(ROOT/'.venv/bin/python'))
ENV['LD_LIBRARY_PATH']=str(sysconfig.get_config_var('LIBDIR'))+os.pathsep+ENV.get('LD_LIBRARY_PATH','')
command=['cargo','test','-p','calc-flow-python','--lib','--features','benchmark-internals','benchmark_dispatch_trace_methods_follow_feature_gate','--','--test-threads=1']
with (OUT/'final-binding-feature.log').open('w') as log:
 result=subprocess.run(command,cwd=SOURCE,env=ENV,stdout=log,stderr=subprocess.STDOUT)
print((OUT/'final-binding-feature.log').read_text()[-12000:],flush=True)
raise SystemExit(result.returncode)
