"""Fixed coalesced ASOF/interval inputs with strict maintained lifecycle checks."""

from __future__ import annotations

import hashlib
import json
import os
import platform
import resource
import sys
import time
from dataclasses import replace
from importlib.metadata import version
from pathlib import Path

import pyarrow as pa
from measurement_contract import frozen_schema, validate_output

import benchmarks.engine_comparison as engines
import benchmarks.engine_stream as streams
import calc_flow
import scripts.benchmark_suite.catalog as catalog
from benchmarks.engine_lifecycle import interleaved_events
from benchmarks.join_asof_acceptance import _runtime_event_fields
from benchmarks.native_memory_profile import prove_release
from calc_flow import Data, _native
from scripts.benchmark_suite.issue406_measurement import PhaseClock

ENGINE_CLOCK = streams._measure_ready_clock
ENGINE_WORKLOAD = engines.workload
CATALOG_BATCH_ROWS = catalog.BATCH_ROWS


def digest(value: object) -> str:
    return hashlib.sha256(
        json.dumps(value, sort_keys=True, separators=(",", ":")).encode()
    ).hexdigest()


def identity(manifest: dict) -> dict:
    raw = {
        "machine": {
            "platform": platform.platform(),
            "hostname": platform.node(),
            "affinity": sorted(os.sched_getaffinity(0)),
            "logical_cpus": os.cpu_count(),
            "power_mode": "Host power mode is not observable from WSL",
            "thread_environment": {
                key: os.environ.get(key)
                for key in (
                    "TOKIO_WORKER_THREADS",
                    "POLARS_MAX_THREADS",
                    "OMP_NUM_THREADS",
                    "OPENBLAS_NUM_THREADS",
                    "MKL_NUM_THREADS",
                    "JAX_PLATFORMS",
                )
            },
        },
        "dependency": {
            "python": platform.python_version(),
            "numpy": version("numpy"),
            "pyarrow": version("pyarrow"),
            "polars": version("polars"),
            "cargo_lock_sha256": manifest["cargo_lock_sha256"],
            "rustc_verbose": manifest["rustc_verbose"],
            "profile": manifest["profile"],
            "features": manifest["features"],
            "rustflags": manifest["environment"].get("RUSTFLAGS"),
        },
    }
    return {
        name: {"identity": value, "sha256": digest(value)}
        for name, value in raw.items()
    }


def engine_warmup(active: engines.EngineCase) -> tuple[dict, list[dict]]:
    original = streams._measure_ready_clock
    observed, jobs = [], []

    async def measured(bindings, **kwargs):
        before_status = {}

        def clock(scope):
            before_status.update(bindings.job.status())
            return PhaseClock(scope)

        kwargs["phase_clock"] = clock
        result = await original(bindings, **kwargs)
        observed.append(
            {
                "scope": "existing engine warmup only; excluded from formal samples",
                "lifecycle": "fresh job; lazy native startup may enter ready timer",
                "phase": result[2],
                "before_status": before_status,
                "ready_status": bindings.job.status(),
                "sink_geometry": {
                    "envelopes": len(bindings.sink.tables),
                    "tables": [
                        {
                            "rows": table.num_rows,
                            "record_batch_rows": [
                                batch.num_rows for batch in table.to_batches()
                            ],
                            "column_chunks": {
                                name: table[name].num_chunks
                                for name in table.column_names
                            },
                        }
                        for table in bindings.sink.tables
                    ],
                },
            }
        )
        jobs.append(bindings.job)
        return result

    streams._measure_ready_clock = measured
    try:
        sample = active.sample()
    finally:
        streams._measure_ready_clock = original
    for entry, job in zip(observed, jobs, strict=True):
        entry["terminal_status"] = job.status()
    return sample, observed


def table_sha256(table) -> str:
    sink = pa.BufferOutputStream()
    with pa.ipc.new_stream(sink, table.schema) as writer:
        writer.write_table(table)
    return hashlib.sha256(sink.getvalue()).hexdigest()


def coalesced_workload(*args, **kwargs):
    data = ENGINE_WORKLOAD(*args, **kwargs)
    return replace(data, table=data.table.combine_chunks())


def validate_engine_geometry(value: dict) -> None:
    case = value["case"]
    scenario, rows, batch_rows = case["scenario"], case["rows"], value["batch_rows"]
    sources = (
        {"left", "right"}
        if scenario == "interval_join"
        else {"quotes.input", "reference.input"}
    )
    dimensions = (262144, 262144) if scenario == "interval_join" else (1000000, 1000000)
    if (
        case["backend"] != "calc-flow-stream"
        or scenario not in {"interval_join", "asof_join"}
        or (rows, batch_rows) != dimensions
        or value["stream_entities"] != 64
        or set(value["actual_stream_batches"]) != sources
        or value["expected_rows"]
        != (11 * rows - 1920 if scenario == "interval_join" else rows)
    ):
        raise ValueError("join workload differs from the five-configuration plan")
    for observed in value["actual_stream_batches"].values():
        if observed != [{"envelope_rows": rows, "record_batch_rows": [rows]}]:
            raise ValueError("join physical Arrow geometry differs from the plan")
    if scenario == "interval_join":
        dimensions = catalog.stream_dimensions(scenario, batch_rows, False)
        if any(case.get(name) != expected for name, expected in dimensions.items()):
            raise ValueError("interval exact-cursor throughput dimensions changed")
    elif "batch_rows" in case:
        raise ValueError("ASOF must preserve its maintained bounded-feed adapter")


def engine_workload(active, batch_rows) -> dict:
    event_order = []
    timed = {name: events[:-1] for name, events in active.streams.items()}
    if any(events[-1] is not None for events in active.streams.values()):
        raise ValueError("missing owned EOF marker")
    positions = dict.fromkeys(timed, 0)
    for name, event in interleaved_events(timed):
        fields, batches = _runtime_event_fields(
            event, positions[name], "unexpected join event"
        )
        if batches is not None:
            positions[name] += len(batches)
        event_order.append({"input": name, **fields})
    value = {
        "case": active.case,
        "measurement_scope": "coalesced-asof-interval-cpu-pipeline-v1",
        "batch_rows": batch_rows,
        "maintained_scope": active.case["scope"],
        "stream_entities": active.data.entities,
        "explicit_edge_budget": {
            "max_rows": batch_rows,
            "max_bytes": 64 << 20,
        },
        "expected_rows": active.expected.num_rows,
        "oracle_schema": str(frozen_schema(active.case["scenario"])),
        "explicit_state_budget_bytes": 1 << 30,
        "input_ipc_sha256": table_sha256(active.data.table),
        "expected_output_ipc_sha256": table_sha256(active.expected),
        "submission_order": event_order,
        "source_cursor": (
            "maintained stream_events cumulative row/event_index cursor; "
            "ASOF bounded feeds, interval exact replay"
        ),
        "actual_stream_batches": {
            name: [
                {
                    "envelope_rows": event.batch.num_rows,
                    "record_batch_rows": [
                        batch.num_rows
                        for batch in event.batch.to_pyarrow().to_batches()
                    ],
                }
                for event in events
                if isinstance(event, Data)
            ]
            for name, events in active.streams.items()
        },
    }
    validate_engine_geometry(value)
    return {"identity": value, "sha256": digest(value)}


def prepare_case(definition: dict, state: Path):
    state.mkdir(parents=True, exist_ok=False)
    engines.workload = coalesced_workload
    try:
        active = engines.EngineCase(definition, state)
    finally:
        engines.workload = ENGINE_WORKLOAD
    try:
        schema = frozen_schema(definition["scenario"])
        expected = active.expected
        if (
            expected.column_names != schema.names
            or [field.type for field in expected.schema]
            != [field.type for field in schema]
            or any(column.null_count for column in expected.columns)
        ):
            raise ValueError(
                "maintained expected output differs from frozen declaration"
            )
        # Immutable source declaration: required left identity; ASOF right is nullable.
        active.expected = pa.Table.from_arrays(expected.columns, schema=schema)
        active.validate = lambda result: validate_output(
            definition["scenario"], result, active.expected, definition["rows"]
        )
        return active
    except BaseException:
        active.close()
        raise


def validate_stream_evidence(sample: dict, case: dict) -> dict:
    if case["scenario"] == "asof_join":
        if "stream_evidence" in sample:
            raise ValueError("ASOF changed its maintained bounded-feed lifecycle")
        return {
            **sample,
            "completion_contract": "maintained-run_with_completion/completed",
        }
    evidence = sample["stream_evidence"]
    dimensions = catalog.stream_dimensions("interval_join", case["batch_rows"], False)
    if any(evidence.get(key) != value for key, value in dimensions.items()):
        raise ValueError("sample stream contract differs from its frozen case")
    if (
        evidence.get("nonterminal_epochs") != []
        or evidence.get("recovery") != "not-requested"
    ):
        raise ValueError("unexpected periodic checkpoint/recovery sample")
    statuses = list(evidence["interval_join"].values())
    if len(statuses) != 1:
        raise ValueError("sample must expose one interval join observation")
    status = statuses[0]
    if (
        status["emitted_match_rows"] != 11 * case["rows"] - 1920
        or status["state_limit_failures"] != 0
        or status["match_limit_failures"] != 0
    ):
        raise ValueError("interval output/resource status differs from the oracle")
    for side in ("left", "right"):
        current = status[side]
        if (
            current["watermark_micros"] is None
            or current["retained_rows"] != 320
            or type(current["evicted_rows"]) is not int
            or not 0 <= current["evicted_rows"] <= case["rows"] - 320
            or (
                case["batch_rows"] >= case["rows"]
                and current["evicted_rows"] != case["rows"] - 320
            )
            or any(
                current[key] != 0
                for key in ("late_rows", "null_event_time_rows", "null_key_rows")
            )
        ):
            raise ValueError("accepted interval watermark/eviction evidence changed")
    # EngineCase returns only after run_with_completion accepts the native outcome.
    return {**sample, "completion_contract": "maintained-run_with_completion/completed"}


def require_original_timers() -> None:
    if streams._measure_ready_clock is not ENGINE_CLOCK:
        raise RuntimeError("warmup clock wrapper leaked into formal sampling")
    if engines.workload is not ENGINE_WORKLOAD:
        raise RuntimeError("fixture construction wrapper leaked beyond preparation")
    if any(
        module.BATCH_ROWS != CATALOG_BATCH_ROWS
        for module in (catalog, engines, streams)
    ):
        raise RuntimeError("maintained global BATCH_ROWS changed")


def main() -> None:
    build_path, root = map(Path, sys.argv[1:3])
    manifest = json.loads(build_path.read_text())
    proof = prove_release(manifest, Path(_native.__file__))
    site = Path(manifest["native"]).parent.parent
    if not all(
        Path(module.__file__).is_relative_to(site) for module in (calc_flow, _native)
    ):
        raise ValueError("Python and native package must both come from sealed site")
    active = None
    try:
        for line in sys.stdin:
            message = json.loads(line)
            if message["operation"] == "hello":
                response = {
                    "pid": os.getpid(),
                    "proof": proof,
                    "identities": identity(manifest),
                    "loaded_harness": [
                        str(Path(module.__file__).resolve())
                        for module in (engines, streams, catalog)
                    ],
                }
            elif message["operation"] == "prepare":
                if active is not None:
                    raise ValueError("worker already owns a workload")
                workload = message["workload"]
                if workload["kind"] != "engine":
                    raise ValueError(
                        "only the frozen join engine workloads are supported"
                    )
                active = prepare_case(workload["case"], root / "state")
                facts = engine_workload(active, workload["batch_rows"])
                if (active.root / f"sample-{active.count + 1}").exists():
                    raise ValueError("warmup state already exists")
                sample, diagnostics = engine_warmup(active)
                response = {
                    "workload": facts,
                    "warmup": validate_stream_evidence(sample, active.case),
                    "warmup_diagnostics": diagnostics,
                }
                require_original_timers()
            elif message["operation"] == "sample":
                if active is None:
                    raise ValueError("sample requested before preparation")
                require_original_timers()
                if (active.root / f"sample-{active.count + 1}").exists():
                    raise ValueError("sample state already exists")
                started = time.process_time_ns()
                response = validate_stream_evidence(active.sample(), active.case)
                response["whole_sample_cpu_seconds"] = (
                    time.process_time_ns() - started
                ) / 1e9
                response["lifetime_peak_rss_kb"] = resource.getrusage(
                    resource.RUSAGE_SELF
                ).ru_maxrss
            elif message["operation"] == "finish":
                if active is None:
                    raise ValueError("finish requested before preparation")
                response = active.finish()
                active.close()
                active = None
            else:
                raise ValueError("unsupported worker operation")
            print(json.dumps(response, allow_nan=False), flush=True)
    finally:
        if active is not None:
            active.close()


if __name__ == "__main__":
    main()
