"""Reject changes hidden behind a source-only release manifest relocation."""

from __future__ import annotations

import copy
import json
import sys
from pathlib import Path

import measure
import pytest

BASELINE = Path(__file__).parent / "releases/base-relocated/build.json"


def test_original_release_accepts_only_the_recorded_source_relocation():
    build = json.loads(BASELINE.read_text())
    original = copy.deepcopy(build)
    measure.validate_baseline_relocation(build, build["source_relocation"])
    assert build == original
    assert "calc_flow" not in sys.modules
    assert "calc_flow._native" not in sys.modules


@pytest.mark.parametrize(
    "field",
    ["source", "source_sha", "native_sha256", "wheel_sha256", "command"],
)
def test_source_relocation_does_not_permit_other_release_changes(field):
    build = json.loads(BASELINE.read_text())
    changed = {**build, field: "changed"}
    with pytest.raises(ValueError, match="relocation"):
        measure.validate_baseline_relocation(changed, build["source_relocation"])


def test_source_relocation_requires_the_original_manifest_hash():
    build = json.loads(BASELINE.read_text())
    provenance = {**build["source_relocation"], "original_manifest_sha256": "0" * 64}
    changed = {**build, "source_relocation": provenance}
    with pytest.raises(ValueError, match="original manifest"):
        measure.validate_baseline_relocation(changed, provenance)


def test_source_relocation_keeps_the_original_source_identity():
    build = json.loads(BASELINE.read_text())
    provenance = {**build["source_relocation"], "original_source": "relabelled"}
    changed = {**build, "source_relocation": provenance}
    with pytest.raises(ValueError, match="original source"):
        measure.validate_baseline_relocation(changed, provenance)
