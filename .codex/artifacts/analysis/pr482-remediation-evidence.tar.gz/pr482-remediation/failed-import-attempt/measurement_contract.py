"""Strict oracles shared by the thin join worker and native-free tests."""

from __future__ import annotations

import sys
from pathlib import Path

import pyarrow as pa

SOURCE = Path(__file__).resolve().parents[2] / "worktrees/join-cpu-pipeline"
sys.path.insert(0, str(SOURCE))

from benchmarks.interval_acceptance import validate_interval_output  # noqa: E402
from benchmarks.join_asof_acceptance import validate_one_to_one_output  # noqa: E402


def frozen_schema(scenario: str) -> pa.Schema:
    if scenario == "asof_join":
        return pa.schema(
            [
                pa.field("sequence", pa.uint64(), nullable=False),
                pa.field("value", pa.float64(), nullable=True),
            ]
        )
    if scenario == "interval_join":
        return pa.schema(
            [
                pa.field("sequence", pa.uint64(), nullable=False),
                pa.field("right_sequence", pa.uint64(), nullable=False),
                pa.field("value", pa.float64(), nullable=False),
            ]
        )
    raise ValueError("workload is outside the fixed ASOF/interval inventory")


def validate_output(scenario, actual, expected, rows):
    schema = frozen_schema(scenario)
    if not expected.schema.equals(schema, check_metadata=True):
        raise ValueError("expected table differs from the independently frozen schema")
    if not actual.schema.equals(schema, check_metadata=True):
        raise ValueError("actual table differs from the independently frozen schema")
    if scenario == "interval_join":
        return validate_interval_output(actual, expected, rows)
    return validate_one_to_one_output(actual, expected)


def validate_trace(trace, job_id, fingerprint, required_stages):
    clock = trace.get("thread_cpu_clock")
    expected_clock = "CLOCK_THREAD_CPUTIME_ID" if sys.platform == "linux" else None
    if (
        trace.get("schema") != "calc-flow.join-cpu-trace.v1"
        or trace.get("job_id") != job_id
        or trace.get("compiled_plan_fingerprint") != fingerprint
        or not fingerprint
        or trace.get("overflowed") is not False
        or trace.get("capacity") != 16_384
        or trace.get("time_origin") != "capture-start"
        or "thread_cpu_clock" not in trace
        or clock != expected_clock
        or not isinstance(required_stages, list)
        or not required_stages
    ):
        raise ValueError("trace identity, seal or required stage inventory is invalid")
    events = trace.get("events")
    if not isinstance(events, list) or not 2 < len(events) <= trace["capacity"]:
        raise ValueError("trace event inventory is incomplete")
    for event in events:
        for name in ("start_ns", "end_ns", "rows", "units", "bytes"):
            if type(event.get(name)) is not int or event[name] < 0:
                raise ValueError("trace has an unfinished or negative event bound")
        if (
            event["end_ns"] < event["start_ns"]
            or type(event.get("worker")) is not bool
            or not isinstance(event.get("operator"), str)
            or not event["operator"]
            or not isinstance(event.get("stage"), str)
            or not event["stage"]
        ):
            raise ValueError("trace event scope is invalid")
        cpu = event.get("thread_cpu_ns")
        if cpu is not None and (
            clock is None or not event["worker"] or type(cpu) is not int or cpu < 0
        ):
            raise ValueError("trace thread CPU has an invalid scope or duration")
    markers = {}
    for label in ("ready_timer_start", "ready_timer_end"):
        selected = [
            event
            for event in events
            if event["operator"] == "runtime" and event["stage"] == label
        ]
        if len(selected) != 1:
            raise ValueError("trace needs exactly one marker at each timer boundary")
        event = selected[0]
        if (
            event.get("reason") != "marker"
            or event["end_ns"] != event["start_ns"]
            or event["worker"]
            or any(event[name] != 0 for name in ("rows", "units", "bytes"))
        ):
            raise ValueError("trace marker contains unexpected work")
        markers[label] = event["start_ns"]
    start, end = markers["ready_timer_start"], markers["ready_timer_end"]
    if start >= end:
        raise ValueError("trace ready timer markers are reversed or empty")
    stages = sorted({event["stage"] for event in events})
    if any(stage not in stages for stage in required_stages):
        raise ValueError("trace is missing a required instrumented parent stage")
    workers = [event for event in events if event["worker"]]
    maximum = trace.get("max_active_workers")
    if type(maximum) is not int or not 0 <= maximum <= len(workers):
        raise ValueError("trace maximum active worker count is invalid")
    return {
        "ready_timer_start_ns": start,
        "ready_timer_end_ns": end,
        "required_stages": required_stages,
        "observed_stages": stages,
        "worker_cpu_clock_available": clock is not None,
        "worker_cpu_complete": clock is not None
        and all(event["thread_cpu_ns"] is not None for event in workers),
        "ready_overlap_event_indices": [
            index
            for index, event in enumerate(events)
            if event["end_ns"] > start and event["start_ns"] < end
        ],
        "qualification": (
            "Stage wall times and worker spans can overlap and must not be added. "
            "Ready-overlap indices need boundary clipping; retain EOF separately."
        ),
    }
