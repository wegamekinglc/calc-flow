"""Freeze the fixed local plan after root seals the final candidate release."""

from __future__ import annotations

import argparse
import hashlib
import json
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent
REPOSITORY = ROOT.parents[2]
SOURCE = REPOSITORY / "target/worktrees/join-cpu-pipeline"
BASELINE = ROOT / "releases/base-relocated/build.json"
sys.path.insert(0, str(SOURCE))

from scripts.benchmark_suite.catalog import (  # noqa: E402
    engine_cases,
    stream_dimensions,
)


def sha256(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def workload(scenario, rows, cpus):
    case = next(
        case
        for case in engine_cases(rows)
        if case["backend"] == "calc-flow-stream"
        and case["scenario"] == scenario
        and "/small-batch/" not in case["id"]
        and case.get("batch_rows", rows) in (rows, 1_000_000)
    )
    if scenario == "interval_join":
        case = {**case, **stream_dimensions(scenario, rows, False)}
    return {
        "id": f"{scenario}-{rows}-batch{rows}-cpu{cpus}",
        "kind": "engine",
        "case": case,
        "batch_rows": rows,
        "rationale": (
            (
                "ASOF helper refactors in segment matching/output-plan, shared "
                "output and prefix workspace; same 1M-row single-batch input "
                "as the prior measured release, with a single-core control "
                "and a 32-CPU parallel case. Copied row gather is not covered."
            )
            if scenario == "asof_join"
            else (
                "Interval main integration and helper refactors in retained-state "
                "admission, key dictionary, morsel envelopes and funding; "
                "same fixed multiplicity at 1, 8 and 32 logical CPUs."
            )
        ),
        "pairs": [
            {
                "id": f"remediation-vs-61aab0e-{cpus}cpu",
                "kind": "version",
                "A": {"release": "base", "cpus": cpus},
                "B": {"release": "candidate", "cpus": cpus},
            }
        ],
    }


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--candidate-build", type=Path)
    args = parser.parse_args()
    if (ROOT / "reports/measurement.json").exists():
        raise RuntimeError("acquisition exists; refusing to replace its plan")
    baseline = json.loads(BASELINE.read_text())
    recovery_path = ROOT / "import-recovery.json"
    recovery = json.loads(recovery_path.read_text())
    candidate = (
        json.loads(args.candidate_build.read_text()) if args.candidate_build else None
    )
    if candidate is not None and (
        candidate.get("exit_code") != 0
        or candidate.get("features") != ["default"]
        or candidate.get("tracked_source_clean") is not True
        or candidate.get("modified_core_recompiled") is not True
        or Path(candidate["source"]).resolve() != SOURCE
    ):
        raise ValueError("candidate must be the exact clean default release")
    files = [
        ROOT / name
        for name in ("measure.py", "measure_worker.py", "measurement_contract.py")
    ]
    files += [
        SOURCE / name
        for name in (
            "benchmarks/engine_comparison.py",
            "benchmarks/engine_stream.py",
            "benchmarks/native_memory_profile.py",
            "benchmarks/engine_lifecycle.py",
            "benchmarks/interval_acceptance.py",
            "benchmarks/join_asof_acceptance.py",
            "scripts/benchmark_suite/catalog.py",
            "scripts/benchmark_suite/process.py",
            "scripts/benchmark_suite/diagnostics.py",
            "scripts/toolkit.py",
            "scripts/benchmark_suite/report.py",
            "scripts/benchmark_suite/statistics.py",
            "scripts/benchmark_suite/issue406_measurement.py",
        )
    ]
    plan = {
        "schema": "calc-flow.pr482-remediation-feature-plan.v1",
        "readiness": "frozen-ready"
        if candidate
        else "awaiting-final-candidate-release",
        "execution_authorized": candidate is not None,
        "source": str(SOURCE),
        "source_sha": candidate["source_sha"] if candidate else None,
        "source_tree": candidate["source_tree"] if candidate else None,
        "baseline_source_tree": baseline["source_tree"],
        "baseline_relocation": baseline["source_relocation"],
        "revisions": {
            "base": baseline["source_sha"],
            "candidate": candidate["source_sha"] if candidate else None,
        },
        "builds": {
            "base": str(BASELINE),
            "candidate": str(args.candidate_build.resolve()) if candidate else None,
        },
        "build_manifest_sha256": {
            "base": sha256(BASELINE),
            "candidate": sha256(args.candidate_build) if candidate else None,
        },
        "measurement_contract": (
            "Focused maintained EngineCase "
            "ready-enqueue-through-Arrow-concat. Version comparisons use two "
            "rounds of ten adjacent alternating AB/BA pairs and maintained "
            "paired-median confidence intervals. No whole-suite verdict; "
            "cross-CPU ratios descriptive only."
        ),
        "rounds": 2,
        "samples_per_arm_per_round": 10,
        "warmups_per_worker": 1,
        "formal_observations": 200,
        "excluded_formal_warmups": 20,
        "budget_seconds": recovery["remaining_total_budget_seconds"],
        "formal_acquisition_seconds": recovery["remaining_formal_acquisition_seconds"],
        "cleanup_reserve_seconds": 30,
        "combined_acquisition_budget_seconds": 600,
        "technical_import_recovery": {
            "journal": str(recovery_path),
            "sha256": sha256(recovery_path),
        },
        "budget_includes": [
            "release preflight",
            "fixture construction",
            "process startup",
            "warmups",
            "full oracle checks",
            "EOF",
            "progress observation",
            "cleanup",
        ],
        "builds_budgeted_separately": True,
        "build_estimate_seconds_per_release": 600,
        "baseline_default_release_reused": True,
        "baseline_default_build_manifest_sha256": sha256(BASELINE),
        "diagnostics": {"enabled": False, "budget_seconds": 0},
        "workloads": [
            workload("asof_join", 1_000_000, 1),
            workload("asof_join", 1_000_000, 32),
            workload("interval_join", 262_144, 1),
            workload("interval_join", 262_144, 8),
            workload("interval_join", 262_144, 32),
        ],
        "fixture": {
            "entities": 64,
            "physical_geometry": (
                "Input table combine_chunks before maintained EngineCase "
                "constructs events; exactly one RecordBatch per side per sample."
            ),
            "asof": (
                "Maintained zero-tolerance bounded feeds; "
                "AsofStateLimits(2*N+128, 1GiB); N exact identity/value rows."
            ),
            "interval": (
                "Maintained inclusive +/-5-second exact-cursor replay; "
                "JoinStateLimits(6*N+768,1GiB,11*N); 11*N-1920 exact row pairs."
            ),
            "edge_budget": "case batch rows; 64MiB",
            "schemas": (
                "ASOF sequence:uint64 nonnull,value:float64 nullable; interval "
                "sequence/right_sequence:uint64 nonnull,value:float64 nonnull; "
                "metadata exact."
            ),
            "state_lifecycle": (
                "Fresh checkpoint path for every invocation; maintain "
                "run_with_completion, EOF delivery count and owned cancellation "
                "cleanup."
            ),
            "outside_ready_timer_inside_budget": (
                "Full independent oracle, watermarks, EOF, cancellation, process "
                "startup and cleanup."
            ),
        },
        "environment_guard": {
            "compiler_comm_names": [
                "rustc",
                "rustdoc",
                "ld.lld",
                "clippy-driver",
                "cc1",
                "cc1plus",
            ],
            "external_executable_basenames": ["p2-ci-repair-baseline-quote-risk"],
            "policy": (
                "Stop for visible competing builds/workloads; never signal "
                "external processes. WSL host power and host-wide quiet cannot "
                "be established."
            ),
        },
        "resource_interpretation": (
            "Whole-sample CPU includes untimed oracle/lifecycle work and "
            "cannot be divided by ready wall time. Excluded warmup "
            "PhaseClock is ready-window CPU only and includes lazy startup. "
            "No separately instrumented diagnostic build is measured in "
            "this task; actual worker concurrency is not established here."
        ),
        "unmeasured": [
            "ASOF 8 CPU",
            "small inputs",
            "skewed/wide/nested payload timing",
            "ASOF copied row gather",
            "rolling entity-parallel and diagnostic-only helper timing",
            "long-running state",
            "checkpoint/recovery timing",
        ],
        "prepared_harness_sha256": {str(path): sha256(path) for path in files},
        "no_automatic_retry_expansion_or_budget_extension": True,
    }
    path = ROOT / "plan.json"
    path.write_text(json.dumps(plan, indent=2, allow_nan=False) + "\n")
    print(
        json.dumps(
            {
                "path": str(path),
                "readiness": plan["readiness"],
                "cases": len(plan["workloads"]),
            }
        )
    )


if __name__ == "__main__":
    main()
