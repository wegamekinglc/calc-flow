"""Build an exact clean-source streaming comparison release."""

from __future__ import annotations

import argparse
import hashlib
import json
import os
import platform
import subprocess
import time
import zipfile
from pathlib import Path

ROOT = Path(__file__).resolve().parents[3]
SOURCE = None
OUT = None
PYTHON = ROOT / ".venv/bin/python"


def git(*arguments):
    return subprocess.check_output(["git", *arguments], cwd=SOURCE, text=True).strip()


def main():
    global SOURCE, OUT
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("variant", choices=("diagnostic-base", "diagnostic-candidate", "candidate"))
    args = parser.parse_args()
    diagnostic = args.variant.startswith("diagnostic-")
    SOURCE = ROOT / "target/worktrees" / ("join-cpu-pipeline-diagnostic-base" if args.variant == "diagnostic-base" else "join-cpu-pipeline")
    OUT = ROOT / "target/performance/pr482-remediation/releases" / args.variant
    assert not git("status", "--porcelain", "--untracked-files=no")
    OUT.mkdir(parents=True, exist_ok=False)
    environment = dict(
        os.environ,
        CARGO_TARGET_DIR=str(ROOT / "target"),
        CARGO_BUILD_JOBS="2",
        PYO3_PYTHON=str(PYTHON),
    )
    environment.pop("RUSTFLAGS", None)
    subprocess.run(["cargo", "clean", "-p", "calc-flow", "--release"], cwd=SOURCE, env=environment, check=True)
    command = [
        str(PYTHON),
        "-m",
        "maturin",
        "build",
        "--release",
        "--locked",
        "--out",
        str(OUT / "wheel"),
    ]
    if diagnostic:
        command += ["--features", "benchmark-internals"]
    record = dict(
        command=command,
        source=str(SOURCE),
        source_sha=git("rev-parse", "HEAD"),
        source_tree=git("rev-parse", "HEAD^{tree}"),
        tracked_source_clean=True,
        profile="release",
        features=["benchmark-internals"] if diagnostic else ["default"],
        cargo_lock_sha256=hashlib.sha256(
            (SOURCE / "Cargo.lock").read_bytes()
        ).hexdigest(),
        rustc_verbose=subprocess.check_output(
            ["rustc", "--version", "--verbose"], text=True
        ),
        python=platform.python_version(),
        environment={
            key: environment.get(key)
            for key in (
                "CARGO_TARGET_DIR",
                "CARGO_BUILD_JOBS",
                "PYO3_PYTHON",
                "RUSTFLAGS",
            )
        },
        started_unix=time.time(),
    )
    (OUT / "build.json").write_text(json.dumps(record, indent=2) + "\n")
    started = time.monotonic()
    with (OUT / "build.log").open("w") as log:
        process = subprocess.run(
            command, cwd=SOURCE, env=environment, stdout=log, stderr=subprocess.STDOUT
        )
    record.update(
        exit_code=process.returncode, elapsed_seconds=time.monotonic() - started
    )
    assert git("rev-parse", "HEAD") == record["source_sha"] and not git(
        "status", "--porcelain", "--untracked-files=no"
    )
    if process.returncode == 0:
        assert "Compiling calc-flow v" in (OUT / "build.log").read_text()
        wheels = list((OUT / "wheel").glob("*.whl"))
        assert len(wheels) == 1
        wheel = wheels[0]
        site = OUT / "site"
        site.mkdir()
        with zipfile.ZipFile(wheel) as archive:
            archive.extractall(site)
        natives = list((site / "calc_flow").glob("_native*.so"))
        assert len(natives) == 1
        native = natives[0]
        record.update(
            wheel=str(wheel),
            wheel_sha256=hashlib.sha256(wheel.read_bytes()).hexdigest(),
            native=str(native),
            native_sha256=hashlib.sha256(native.read_bytes()).hexdigest(),
            modified_core_recompiled=True,
        )
    (OUT / "build.json").write_text(json.dumps(record, indent=2) + "\n")
    print(json.dumps(record, indent=2), flush=True)
    raise SystemExit(process.returncode)


if __name__ == "__main__":
    main()
