from __future__ import annotations

import json
import os
import subprocess
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[3]
SOURCE = ROOT / "target/worktrees/join-cpu-pipeline"
OUT = Path(__file__).resolve().parent


def main():
    phase, *filters = sys.argv[1:]
    env = dict(os.environ, CARGO_TARGET_DIR=str(ROOT / "target"), CARGO_BUILD_JOBS="2")
    jsonl = OUT / f"{phase}-build.jsonl"
    build_log = OUT / f"{phase}-build.log"
    with jsonl.open("w") as stdout, build_log.open("w") as stderr:
        build = subprocess.run(
            [
                "cargo",
                "test",
                "-p",
                "calc-flow",
                "--lib",
                "--features",
                "benchmark-internals",
                "--no-run",
                "--message-format=json",
            ],
            cwd=SOURCE,
            env=env,
            stdout=stdout,
            stderr=stderr,
        )
    messages = [
        json.loads(s) for s in jsonl.read_text().splitlines() if s.startswith("{")
    ]
    if build.returncode:
        print(build_log.read_text()[-12000:])
        for msg in messages:
            if (
                msg.get("reason") == "compiler-message"
                and msg["message"]["level"] == "error"
            ):
                print(msg["message"]["rendered"])
        raise SystemExit(build.returncode)
    artifacts = [
        m
        for m in messages
        if m.get("reason") == "compiler-artifact"
        and m.get("executable")
        and m.get("target", {}).get("name") == "calc_flow"
    ]
    assert len(artifacts) == 1
    artifact = artifacts[0]
    assert Path(artifact["manifest_path"]) == SOURCE / "crates/calc-flow/Cargo.toml"
    assert not artifact["fresh"], (
        "changed source must compile; cross-worktree Cargo freshness is insufficient"
    )
    exe = artifact["executable"]
    (OUT / "test-executable.json").write_text(json.dumps(dict(path=exe)) + "\n")
    command = [exe, *filters, "--test-threads=1"]
    log = OUT / f"{phase}.log"
    with log.open("w") as output:
        result = subprocess.run(
            command, cwd=SOURCE, env=env, stdout=output, stderr=subprocess.STDOUT
        )
    report = log.read_text()
    assert "running 0 tests" not in report
    (OUT / f"{phase}-execution.json").write_text(
        json.dumps(
            dict(
                command=command,
                source=str(SOURCE),
                cargo_fresh=artifact["fresh"],
                exit_code=result.returncode,
            ),
            indent=2,
        )
        + "\n"
    )
    print(report[-24000:], flush=True)
    raise SystemExit(result.returncode)


if __name__ == "__main__":
    main()
