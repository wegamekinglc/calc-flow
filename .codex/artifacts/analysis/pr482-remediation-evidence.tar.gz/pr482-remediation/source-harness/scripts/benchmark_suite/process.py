"""Bounded subprocess ownership shared by measurement and legacy adapters."""

from __future__ import annotations

import asyncio
import json
import os
import shutil
import sys
from pathlib import Path

from scripts.benchmark_suite.catalog import THREADS
from scripts.benchmark_suite.diagnostics import checkpoint_summary, observe, persist
from scripts.toolkit import write_json

ROOT = Path(__file__).resolve().parents[2]


def child_environment(
    site: Path | None = None, *, source: Path = ROOT, polars_threads: int = THREADS
) -> dict[str, str]:
    return {
        **os.environ,
        "PYTHONPATH": os.pathsep.join(str(p) for p in (site, source) if p is not None),
        "PYTHONDONTWRITEBYTECODE": "1",
        "TOKIO_WORKER_THREADS": str(THREADS),
        "POLARS_MAX_THREADS": str(polars_threads),
        "OMP_NUM_THREADS": "1",
        "OPENBLAS_NUM_THREADS": "1",
        "MKL_NUM_THREADS": "1",
        "JAX_PLATFORMS": "cpu",
        "UV_CACHE_DIR": os.environ.get("UV_CACHE_DIR", str(ROOT / "target/uv-cache")),
    }


async def command(
    argv: list[str],
    *,
    cwd: Path,
    log: Path,
    env: dict | None = None,
    timeout: float = 7200,
) -> None:
    log.parent.mkdir(parents=True, exist_ok=True)
    record = {
        "argv": argv,
        "cwd": str(cwd),
        "exit_code": None,
        "threads": {
            key: (env or os.environ).get(key)
            for key in (
                "TOKIO_WORKER_THREADS",
                "POLARS_MAX_THREADS",
                "OMP_NUM_THREADS",
                "OPENBLAS_NUM_THREADS",
                "MKL_NUM_THREADS",
                "JAX_PLATFORMS",
            )
        },
    }
    manifest = log.with_suffix(".command.json")
    write_json(manifest, record)
    try:
        executable = shutil.which(argv[0])
        if executable is None:
            raise ValueError(f"benchmark executable is unavailable: {argv[0]}")
        with log.open("wb") as output:
            creation = asyncio.create_task(
                asyncio.create_subprocess_exec(  # nosemgrep
                    str(Path(executable).absolute()),
                    *argv[1:],
                    cwd=cwd,
                    env=env,
                    shell=False,
                    stdout=output,
                    stderr=asyncio.subprocess.STDOUT,
                )
            )
            process = None
            try:
                process = await asyncio.shield(creation)
                code = await asyncio.wait_for(process.wait(), timeout=timeout)
            except BaseException as error:
                try:
                    await _stop_command(creation, process)
                except BaseException as cleanup_error:
                    record = {
                        **record,
                        "ownership_unsettled": True,
                        "cleanup_error": (
                            f"{type(cleanup_error).__name__}: {cleanup_error}"
                        ),
                    }
                    _raise_command_error(error, cleanup_error)
                raise
        record = {**record, "exit_code": code}
        if code:
            raise RuntimeError(f"command exited {code}; see {log}")
    except BaseException as error:
        record = {**record, "error": f"{type(error).__name__}: {error}"}
        _write_command_failure(manifest, record, error)
        raise
    write_json(manifest, record)


async def _complete_owned(task: asyncio.Task):
    """Finish a privately owned task before propagating its caller's failure."""
    while True:
        try:
            return await asyncio.shield(task)
        except asyncio.CancelledError:
            if task.done():
                return task.result()


async def _stop_command(creation: asyncio.Task, process) -> None:
    if process is None:
        process = await _complete_owned(creation)
    await _complete_owned(asyncio.create_task(stop(process)))


def _raise_command_error(error: BaseException, cleanup_error: BaseException) -> None:
    if cleanup_error is error:
        raise error
    raise error from cleanup_error


def _write_command_failure(manifest: Path, record: dict, error: BaseException) -> None:
    try:
        write_json(manifest, record)
    except Exception as journal_error:
        journal_error.__cause__ = error.__cause__
        raise error from journal_error


async def stop(process: asyncio.subprocess.Process) -> None:
    if process.returncode is not None:
        return
    process.terminate()
    try:
        await asyncio.wait_for(process.wait(), timeout=10)
    except TimeoutError:
        process.kill()
        await process.wait()


async def install(release: dict, root: Path) -> Path:
    site = root / "site"
    await command(
        [
            "uv",
            "pip",
            "install",
            "--python",
            sys.executable,
            "--no-deps",
            "--target",
            str(site),
            release["wheel_path"],
        ],
        cwd=ROOT,
        log=root / "install.log",
        env=child_environment(),
    )
    return site


class Worker:
    def __init__(self, process: asyncio.subprocess.Process, log) -> None:
        self.process, self.log = process, log
        self.root = Path(log.name).parent
        self.request_count = 0

    @classmethod
    async def start(
        cls, site: Path, root: Path, *, source: Path, polars_threads: int = THREADS
    ):
        root.mkdir(parents=True, exist_ok=True)
        log = (root / "stderr.log").open("wb")
        try:
            process = await asyncio.create_subprocess_exec(
                sys.executable,
                "-m",
                "scripts.benchmark_suite",
                "worker",
                "--root",
                str(root),
                cwd=source,
                env=child_environment(
                    site, source=source, polars_threads=polars_threads
                ),
                stdin=asyncio.subprocess.PIPE,
                stdout=asyncio.subprocess.PIPE,
                stderr=log,
            )
        except BaseException:
            log.close()
            raise
        return cls(process, log)

    async def request(self, **message) -> dict:
        self.request_count += 1
        message = {**message, "request_id": self.request_count}
        path = self.root / f"request-{self.request_count:04d}"
        persist(path.with_suffix(".started.json"), message)
        try:
            response = await self._exchange(message)
        except BaseException as error:
            error.add_note(
                "worker request context: "
                + str(
                    observe(
                        lambda: json.dumps(message.get("context", {}), sort_keys=True)
                    )
                )
            )
            persist(
                path.with_suffix(".failed.json"),
                {
                    **message,
                    "error": f"{type(error).__name__}: {error}",
                    "worker_pid": self.process.pid,
                    "worker_returncode": self.process.returncode,
                    "in_process_state": (
                        "see worker failure-before-cancel snapshot; "
                        "unavailable if IPC is unresponsive"
                    ),
                    "checkpoint": observe(lambda: checkpoint_summary(self.root)),
                },
                error,
            )
            raise
        persist(path.with_suffix(".completed.json"), {**message, "response": response})
        return response

    async def _exchange(self, message: dict) -> dict:
        self.process.stdin.write((json.dumps(message) + "\n").encode())
        await self.process.stdin.drain()
        line = await asyncio.wait_for(self.process.stdout.readline(), timeout=900)
        if not line:
            raise RuntimeError(f"benchmark worker exited; see {self.log.name}")
        response = json.loads(line)
        if not isinstance(response, dict) or "error" in response:
            raise RuntimeError(f"invalid worker result: {response}")
        return response

    async def close(self) -> None:
        try:
            if self.process.returncode is None:
                self.process.stdin.close()
                try:
                    await asyncio.wait_for(self.process.wait(), timeout=10)
                except TimeoutError:
                    await stop(self.process)
        finally:
            self.log.close()
