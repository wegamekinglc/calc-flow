# PR #482 remediation performance acquisition plan

The root agent owns Cargo/native builds, tests and acquisition launch. The final
default release is sealed. This plan records one reviewed technical recovery
after the original attempt failed before hello, warmup or formal observations.
No native module or engine workload is run while preparing this adapter.

## Fixed scope and relation to the change

The candidate includes the main integration at `3aa0d57a` and the PR's helper
refactors. The sealed candidate source is
`25e8b4c33114f1f85a8473136bf3c1f7991873e5`, tree
`39920b4d44ba5b2bcf6111320c0df0187eb17b27`. This includes the
`cfg(test)` deadline-projection repair in `join/output_gather/owned.rs`, which
uses the injected watch deadline consistently with `GatherStop`, and the ASOF
`resolve_route` Clippy repair borrowing `&mut Option<Route>` instead of
`Option<&mut Route>`. The deadline change is test-only; the borrow adjustment
preserves the matching work and reference handling.

| Scenario  | Rows per side | Batches per side | Logical CPUs | Connection to changed behavior                           |
|-----------|---------------|------------------|--------------|----------------------------------------------------------|
| ASOF      | 1,000,000     | 1                | 1            | Single-core control for segment/prefix/shared helpers    |
| ASOF      | 1,000,000     | 1                | 32           | Preserve fused matching/output-plan parallel behavior    |
| Interval  | 262,144       | 1                | 1            | Single-core retained/key-dictionary/morsel control       |
| Interval  | 262,144       | 1                | 8            | Preserve the previously improved eight-CPU configuration |
| Interval  | 262,144       | 1                | 32           | Check the same previously uncertain 32-CPU configuration |

These are exactly the prior five workload configurations; only new-versus-old
version comparisons are paired. No scale, payload, CPU or checkpoint matrix is
added. The ASOF fixture does not establish copied row-gather performance, and
rolling entity-parallel, diagnostic-only helpers, small/skewed/wide/nested inputs,
long-lived state and checkpoint/recovery timing remain unmeasured.

## Baseline and source-only manifest relocation

Baseline native source is `61aab0e571800df8e8a18ad2244993d0929f5247`, tree
`15932415e462de46e0612ec26b724abf78ee82ae`. It is the previous candidate's
actual default release, not a later report/documentation commit.

The original manifest at `../join-cpu-pipeline/releases/candidate/build.json`
remains byte-for-byte unchanged, SHA-256:
`2d80666e7e8238672d97f64547b52568ae278fc2be28a9648b787f5ec055dac4`.
The reused native SHA-256 is `1c1ad9934bdbb229976ff4d0d283e751d5ce65dd80fdf2e6437014a54dfe2fca`;
the wheel SHA-256 is `6dfca099e9fd0176baed387dd5c10b9e55eca7afa329ebefed61abede362cf3a`.

The original manifest's source path now holds the remediation worktree. A new
manifest at `releases/base-relocated/build.json` changes only `source` to the
clean detached `target/worktrees/pr482-performance-base61` checkout and adds
`source_relocation` provenance. It preserves the original source path, original
manifest SHA, original source/tree and every build/artifact field. A raw copy
is retained at `releases/base-relocated/original-build.json`; original artifacts
are reused in place. This is not a rebuild or a relabeling of their source.

The controller revalidates the original manifest bytes and exact relocated
mapping, the detached source SHA/tree/cleanliness, Cargo.lock, native/wheel bytes,
and each worker's imported release. Git checks use optional locks disabled and
an LFS cache under this directory, so hydrated historical fixtures do not write
under `.git` in the managed sandbox. Source contents are not changed.

Both arms run the same final candidate benchmark harness. The main integration
adds failure/lifecycle diagnostics outside the ready timer; these and
`scripts/toolkit.py` are included in the frozen harness hashes. The original
`measure_worker.py` and `measurement_contract.py` are copied without changes.
The candidate must have the same default features, release profile, Cargo.lock,
Rust/Python toolchain and RUSTFLAGS as the baseline. Any mismatch is invalid or
inconclusive evidence, not a timing verdict.

## Timing, resource scope and correctness

The maintained timer starts at ready-source submission and ends after expected
output delivery and Arrow concat. The original adapters remain: ASOF bounded
feeds and interval exact-cursor replay. Each side is coalesced to one physical
RecordBatch before timing, with 64 entities and the existing 1 GiB state budget.
ASOF uses zero tolerance and `AsofStateLimits(2*N+128, 1 GiB)`; interval uses
inclusive +/-5 seconds and `JoinStateLimits(6*N+768, 1 GiB, 11*N)`. Edge limits
remain the case batch size and 64 MiB. No state/resource budget is increased.

ASOF checks every sequence exactly once and every value exactly, with its frozen
schema. Interval checks the full pair multiset, multiplicity, exact values and
schema; it expects `11*262144-1920 = 2,881,664` rows. Every invocation owns a new
checkpoint directory. Maintained natural completion/EOF delivered-count checks,
watermark/eviction and zero late/null/resource-failure evidence remain enabled.
Compile/startup, fixture creation, full oracle, progress, EOF and cleanup are
outside the ready timer but inside the total acquisition budget.

CPU affinity follows the existing controller: one first logical CPU from each
reported core-ID group for 1/8 CPU and all 32 available logical CPUs for 32 CPU.
WSL's reported groups do not establish the host's physical-core/SMT topology.
Host-wide quiet and power mode are not observable. Stop on visible competing
build/workload processes; do not signal processes owned by others. The restricted
tool sandbox hides some sibling processes, so its process list cannot establish
quiet. The root must launch the controller with host `/proc` visibility, inspect
host competition, and settle all owned builds/tests before acquisition. The
existing interference guard then sees host compiler/workload processes; even
that visibility does not establish host-wide quiet or power mode.

## Fixed observations and budget

Per configuration: two fresh worker pairs; ten adjacent baseline/candidate pairs
per round, alternating AB/BA and reversing the first pair in round two. Each
worker warms once. Total inventory is exactly **200 formal observations and 20
excluded warmups**. Historical timing observations are not reused.

The total acquisition limit is **600 seconds**: at most 570 seconds to issue
work, plus a 30-second owned-process cleanup reserve. This includes preflight,
fixture creation, startup, warmup, oracles, progress, EOF and normal cleanup.
The first import failure consumed **2.265888925 seconds**, including owned-worker
cleanup, leaving **597.734111075 seconds** for the one authorized recovery:
**567.734111075 seconds** to issue work and the same **30-second cleanup reserve**.
The combined limit remains 600 seconds; no samples or warmups were produced by
the failed attempt.
Builds are separate, estimated at approximately 600 seconds per new release;
the baseline release is reused without rebuilding.

There are **no diagnostic-feature runs** in this task. The unchanged excluded
warmup still records its existing PhaseClock evidence; this is not a new
profile or formal sample. Whole-call CPU includes untimed work and cannot be
divided by ready wall time to claim concurrency.

The controller does not overwrite a prior result, add cases/samples, or retry
for a desired verdict. Stop at budget exhaustion or an unsuitable environment,
settle owned workers and preserve partial/failed evidence. A technical failure
must be settled and explicitly reviewed before any additional attempt.

## Prespecified statistics and decision

Require equal machine, dependency and workload fingerprints for each version
pair and across both rounds. Use the final maintained
`scripts.benchmark_suite.report.comparison` without changing its gate: both
paired-median interval lower bounds above +5% confirm regression; both upper
bounds below -5% confirm improvement; retain its `inconclusive` and
`no-confirmed-regression` outcomes exactly. Ten pairs use the maintained
order-statistic median intervals; do not substitute minima or impose an
additional equivalence rule.

Report each arm's P50 over 20 formal observations, **nearest-rank descriptive
P95**, all paired intervals, percentage change and maintained verdict. The
maintained `statistics.head_p95` linear-interpolation field remains available
as raw output but is not substituted for the declared descriptive P95.
Cross-CPU ratios, if reported, are descriptive and calculated separately for
each version. An inconclusive result does not prove no regression, equivalence
or a speedup; any sustained regression must be escalated to the root for a fix.

## Preparation and root-owned launch

Eight focused provenance tests first failed because the relocation validator
was absent, then passed after implementation. They cover acceptance without
mutation and rejection of source/native/wheel/command relabeling, original
manifest tampering and original source identity changes. They import no
`calc_flow` native module. Timer/worker/oracle code remains unchanged.

The initial attempt derived the package site from the relocated manifest's
directory. That directory contains provenance only, so the worker imported a
different native module and correctly rejected it before hello. Exact failed
report, stdout/stderr, plan, controller and manifest bytes are preserved under
`failed-import-attempt/`, with hashes in its `inventory.json`. The failure is
retained as evidence and is not a timing observation.

The narrow fix derives the site from the sealed manifest's `native` path. Both
arms retain the same wheel/native bytes and strict imported-native hash checks;
no symlink or manifest relabeling is used. `import-recovery.json` binds the failed
report/plan/inventory hashes, zero accepted samples, and consumed/remaining
budget. Two site-path tests and three recovery-budget tests recorded expected
failures before implementation. All 13 provenance/recovery tests then passed
without importing `calc_flow`. The worker, timing, oracles, samples and workloads
remain unchanged. The root must review the frozen amendment before launching;
any further failure ends this acquisition without another automatic attempt.

The sealed technical amendment is frozen with:

```bash
.venv/bin/python target/performance/pr482-remediation/prepare_plan.py \
  --candidate-build target/performance/pr482-remediation/releases/candidate/build.json
```

After build/test processes are settled, the root launches the single authorized
acquisition:

```bash
.venv/bin/python target/performance/pr482-remediation/measure.py \
  > target/performance/pr482-remediation/formal-measurement.log 2>&1
```

The result is `reports/measurement.json`, with all raw worker stdout/stderr,
per-invocation state directories, source/build/harness seals and lifecycle proof.
Only an offline analysis follows completion; no extra measurement is implied.
