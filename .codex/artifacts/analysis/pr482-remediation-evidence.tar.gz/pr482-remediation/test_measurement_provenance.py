"""Reject changes hidden behind a source-only release manifest relocation."""

from __future__ import annotations

import copy
import json
import os
import sys
from pathlib import Path

import measure
import pytest

BASELINE = Path(__file__).parent / "releases/base-relocated/build.json"


@pytest.mark.parametrize(
    ("manifest", "expected_site"),
    [
        (
            BASELINE,
            Path(__file__).parent.parent / "join-cpu-pipeline/releases/candidate/site",
        ),
        (
            Path(__file__).parent / "releases/candidate/build.json",
            Path(__file__).parent / "releases/candidate/site",
        ),
    ],
)
def test_release_environment_uses_the_sealed_native_site(manifest, expected_site):
    build = json.loads(manifest.read_text())
    environment = measure.child_environment(
        measure.release_site(build), source=measure.SOURCE, polars_threads=1
    )
    site = Path(environment["PYTHONPATH"].split(os.pathsep)[0])
    assert site == expected_site
    assert (site / "calc_flow/__init__.py").is_file()
    native = site / "calc_flow" / Path(build["native"]).name
    assert measure.sha256(native) == build["native_sha256"]
    assert "calc_flow" not in sys.modules
    assert "calc_flow._native" not in sys.modules


def recovery_plan():
    root = Path(__file__).parent
    journal_path = root / "import-recovery.json"
    journal = json.loads(journal_path.read_text())
    return {
        **json.loads((root / "failed-import-attempt/plan.json").read_text()),
        "budget_seconds": journal["remaining_total_budget_seconds"],
        "formal_acquisition_seconds": journal["remaining_formal_acquisition_seconds"],
        "technical_import_recovery": {
            "journal": str(journal_path),
            "sha256": measure.sha256(journal_path),
        },
    }


def test_import_recovery_deducts_the_failed_attempt_before_zero_sample_recovery():
    plan = recovery_plan()
    measure.validate_import_recovery(plan)
    assert plan["budget_seconds"] == 597.7341110749985
    assert plan["formal_acquisition_seconds"] == 567.7341110749985


@pytest.mark.parametrize("field", ["budget_seconds", "formal_acquisition_seconds"])
def test_import_recovery_rejects_a_reset_budget(field):
    plan = recovery_plan()
    plan[field] += 2.265888925001491
    with pytest.raises(ValueError, match="recovery budget"):
        measure.validate_import_recovery(plan)


def test_original_release_accepts_only_the_recorded_source_relocation():
    build = json.loads(BASELINE.read_text())
    original = copy.deepcopy(build)
    measure.validate_baseline_relocation(build, build["source_relocation"])
    assert build == original
    assert "calc_flow" not in sys.modules
    assert "calc_flow._native" not in sys.modules


@pytest.mark.parametrize(
    "field",
    ["source", "source_sha", "native_sha256", "wheel_sha256", "command"],
)
def test_source_relocation_does_not_permit_other_release_changes(field):
    build = json.loads(BASELINE.read_text())
    changed = {**build, field: "changed"}
    with pytest.raises(ValueError, match="relocation"):
        measure.validate_baseline_relocation(changed, build["source_relocation"])


def test_source_relocation_requires_the_original_manifest_hash():
    build = json.loads(BASELINE.read_text())
    provenance = {**build["source_relocation"], "original_manifest_sha256": "0" * 64}
    changed = {**build, "source_relocation": provenance}
    with pytest.raises(ValueError, match="original manifest"):
        measure.validate_baseline_relocation(changed, provenance)


def test_source_relocation_keeps_the_original_source_identity():
    build = json.loads(BASELINE.read_text())
    provenance = {**build["source_relocation"], "original_source": "relabelled"}
    changed = {**build, "source_relocation": provenance}
    with pytest.raises(ValueError, match="original source"):
        measure.validate_baseline_relocation(changed, provenance)
