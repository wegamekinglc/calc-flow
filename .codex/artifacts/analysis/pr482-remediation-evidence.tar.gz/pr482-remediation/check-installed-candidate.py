from __future__ import annotations
import hashlib
import json
import sys
from pathlib import Path
ROOT = Path(__file__).resolve().parents[3]
OUT = Path(__file__).resolve().parent
SOURCE = ROOT / "target/worktrees/join-cpu-pipeline"
build = json.loads((OUT / "releases/candidate/build.json").read_text())
assert build["exit_code"] == 0 and build["features"] == ["default"]
sys.path.insert(0, str(Path(build["native"]).parent.parent))
import calc_flow._native as native
import pytest
proof = {"native": native.__file__, "sha256": hashlib.sha256(Path(native.__file__).read_bytes()).hexdigest()}
assert proof["native"] == build["native"]
assert proof["sha256"] == build["native_sha256"]
for method in ("_benchmark_start_join_cpu_trace", "_benchmark_mark_join_cpu_trace", "_benchmark_take_join_cpu_trace"):
    assert not hasattr(native._StreamingJob, method)
proof["diagnostics_absent"] = True
paths = [str(SOURCE / "python/tests/test_symbolic_stream_join_acceptance.py"), str(SOURCE / "python/tests/test_stream_budget_defaults.py")]
code = pytest.main([*paths, "-q"])
proof.update(exit_code=int(code), tests=paths)
(OUT / "installed-candidate-proof.json").write_text(json.dumps(proof, indent=2) + "\n")
raise SystemExit(code)
