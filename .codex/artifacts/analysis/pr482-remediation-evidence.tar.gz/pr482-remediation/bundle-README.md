# PR #482 remediation evidence packet

This packet freezes the five-case measurement of baseline 61aab0e571800df8e8a18ad2244993d0929f5247 against candidate 25e8b4c33114f1f85a8473136bf3c1f7991873e5. It includes 200 formal observations and 20 excluded warmups, plus the exact evidence of the first failed import attempt, which produced no accepted samples. The combined acquisition elapsed time is 122.67738912400091 seconds against the original 600-second budget.

The maintained paired rule returns four inconclusive results and one no-confirmed-regression result. This does not establish global absence of regression, equivalence or a speedup. The report performance-summary.md records P50, prespecified nearest-rank P95, both paired intervals, provenance, limitations and coverage advice.

The root agent's remediation-scope.json is included at its audit-passed, CI-pending freeze. Later remote checks or commits are not part of this packet. Failed native-test/lint and interrupted sandbox-installed logs are retained alongside their subsequent targeted successful evidence; an earlier failure is not silently relabeled as green.

All payload files are exact original bytes. The index gives each archive member's SHA-256, byte size and original local source path. Absolute paths embedded in raw reports/build manifests remain unchanged; use the index member mapping for offline review. All archive paths are relative, regular files under pr482-remediation/, with no symlinks.

The source-harness/ tree preserves the maintained Python measurement/statistics modules named by the frozen plan, plus Cargo.lock. Local controller, worker, contract and plan files are at the packet root. Existing baseline build provenance and log also appear under reused-baseline/. The full repository, Python environment, wheel/native bytes and checkpoint payloads are intentionally not bundled. Their hashes and source identities remain in raw evidence, and formal-offline-audit.json records the verified state-directory inventory. The packet supports portable evidence review and recomputing statistics; it is not a runnable replacement for the source/environment.

The external SHA-256 file seals the gzip archive. The external index is byte-identical to the index stored inside the archive. The external bundle-verification JSON records an independent in-memory readback of every archived member, checksum and raw statistics. The verification file and archive cannot include their own final SHA-256 recursively.

For extraction, use a standard tar reader on pr482-remediation-evidence.tar.gz. The first directory is pr482-remediation/. Review reports/measurement.json for raw observations; failed-import-attempt/ for the original failure; import-recovery.json and import-recovery-offline-audit.json for the bounded recovery; formal-offline-audit.json for the complete audit; and performance-summary.md for the human-readable report. No new native build or acquisition was performed to construct this packet.
