"""Compile once and run the native filters affected by the PR556 merge."""

from __future__ import annotations

import hashlib
import json
import os
import subprocess
import time
from pathlib import Path

ROOT = Path(__file__).resolve().parents[3]
ITEM = Path(__file__).resolve().parent
DEV = ROOT / "target/worktrees/weekly-review-20261107"
SETTINGS = {
    "CARGO_TARGET_DIR": str(ROOT / "target/weekly-review-20261107/debug-cargo"),
    "CARGO_BUILD_JOBS": "1",
    "CARGO_INCREMENTAL": "0",
    "CARGO_PROFILE_DEV_DEBUG": "0",
}
SOURCES = (
    "crates/calc-flow/src/datafusion.rs",
    "crates/calc-flow/src/datafusion_template.rs",
    "crates/calc-flow/src/datafusion_join.rs",
    "crates/calc-flow/src/datafusion_join/planning.rs",
    "crates/calc-flow/src/pipeline/batch/input_partition_tests.rs",
    "crates/calc-flow/src/pipeline/batch/template_tests.rs",
)


def sha(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def run(name: str, argv: list[str], timeout: int) -> None:
    start = time.monotonic()
    receipt = {"argv": argv, "cwd": str(DEV), "settings": SETTINGS}
    with (ITEM / f"{name}.log").open("wb") as output:
        result = subprocess.run(
            argv,
            cwd=DEV,
            env={**os.environ, **SETTINGS},
            stdout=output,
            stderr=subprocess.STDOUT,
            timeout=timeout,
            check=False,
        )
    receipt.update(exit_code=result.returncode, elapsed_seconds=time.monotonic() - start)
    (ITEM / f"{name}.json").write_text(json.dumps(receipt, indent=2) + "\n")
    print(json.dumps({"phase": name, **receipt}), flush=True)
    if result.returncode:
        raise SystemExit(result.returncode)


before = {name: sha(DEV / name) for name in SOURCES}
run(
    "native-build",
    ["cargo", "test", "--locked", "-p", "calc-flow", "--features", "benchmark-internals", "--lib", "--no-run", "--message-format=json"],
    1800,
)
artifacts = []
for line in (ITEM / "native-build.log").read_text().splitlines():
    try:
        value = json.loads(line)
    except ValueError:
        continue
    if value.get("reason") == "compiler-artifact" and value.get("executable"):
        artifacts.append(value["executable"])
assert len(artifacts) == 1, artifacts
binary = Path(artifacts[0])
for name, selection in (
    ("partition-green", "pipeline::batch::input_partition_tests::"),
    ("template-green", "pipeline::batch::template_tests::"),
    ("join-green", "datafusion::datafusion_join::tests::"),
):
    run(name, [str(binary), selection, "--nocapture", "--test-threads=1"], 90)
after = {name: sha(DEV / name) for name in SOURCES}
assert after == before, "source changed during native verification"
receipt = {"source_files": after, "binary": str(binary), "binary_sha256": sha(binary), "all_owned_processes_settled": True}
(ITEM / "native-final-source.json").write_text(json.dumps(receipt, indent=2) + "\n")
print(json.dumps(receipt), flush=True)
