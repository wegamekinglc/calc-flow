"""Read exact-head CI and review state; save original GraphQL evidence."""

import collections
import datetime
import json
import subprocess
from pathlib import Path

head = "7a2463a89a2f4340a64cbdec90c97d7db05097ba"
query = '''query {
  repository(owner: "wegamekinglc", name: "calc-flow") {
    defaultBranchRef { target { oid } }
    pullRequest(number: 556) {
      headRefOid baseRefOid isDraft merged mergeable mergeStateStatus reviewDecision
      reviews(last: 50) { nodes { state author { login } commit { oid } } }
      reviewThreads(first: 100) { pageInfo { hasNextPage } nodes { isResolved isOutdated } }
    }
    object(expression: "7a2463a89a2f4340a64cbdec90c97d7db05097ba") {
      ... on Commit {
        oid
        statusCheckRollup {
          state contexts(first: 100) {
            totalCount pageInfo { hasNextPage }
            nodes {
              __typename
              ... on CheckRun { name status conclusion detailsUrl }
              ... on StatusContext { context state targetUrl }
            }
          }
        }
      }
    }
  }
}'''
result = subprocess.run(
    ["gh", "api", "graphql", "-f", "query=" + query],
    capture_output=True, text=True, timeout=35,
)
if result.returncode:
    print(json.dumps({"status": "read_failed", "exit_code": result.returncode, "stderr": result.stderr[:1000]}))
    raise SystemExit(result.returncode)
data = json.loads(result.stdout)
assert not data.get("errors"), data.get("errors")
repo = data["data"]["repository"]
assert repo["object"]["oid"] == repo["pullRequest"]["headRefOid"] == head
rollup = repo["object"]["statusCheckRollup"]
contexts = rollup["contexts"] if rollup else {"nodes": [], "totalCount": 0, "pageInfo": {"hasNextPage": False}}
states = collections.Counter()
remaining = []
for node in contexts["nodes"]:
    if node["__typename"] == "CheckRun":
        state = node["conclusion"] if node["status"] == "COMPLETED" else node["status"]
        name = node["name"]
    else:
        state, name = node["state"], node["context"]
    states[state] += 1
    if state != "SUCCESS":
        remaining.append({"name": name, "state": state})
stamp = datetime.datetime.now(datetime.timezone.utc).strftime("%Y%m%dT%H%M%S.%fZ")
directory = Path(__file__).resolve().parent / "ci"
directory.mkdir(exist_ok=True)
path = directory / (stamp + ".json")
path.write_text(json.dumps(data, indent=2) + "\n")
print(json.dumps({"snapshot": str(path), "head": head, "rollup": rollup["state"] if rollup else None, "contexts": contexts["totalCount"], "received": len(contexts["nodes"]), "has_next": contexts["pageInfo"]["hasNextPage"], "states": dict(states), "remaining": remaining, "main": repo["defaultBranchRef"]["target"]["oid"], "pr": repo["pullRequest"]}))
