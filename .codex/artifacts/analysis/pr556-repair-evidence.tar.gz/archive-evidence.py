"""Retain the review's small receipts, raw samples and exact local adapters."""

from __future__ import annotations

import gzip
import hashlib
import json
import tarfile
from pathlib import Path

ITEM = Path(__file__).resolve().parent
DEV = ITEM.parent.parent / "worktrees/weekly-review-20261107"
DEST = DEV / ".codex/artifacts/analysis"
NAME = "pr556-repair-evidence"
SKIP = {"cargo", "debug-cargo", "site", "installed", "__pycache__", "ci", "test-overlay"}
files = sorted(
    path
    for path in ITEM.rglob("*")
    if path.is_file()
    and not SKIP.intersection(path.relative_to(ITEM).parts)
    and path.suffix in {".json", ".log", ".txt", ".py", ".tsv"}
)
entries = [
    {
        "path": str(path.relative_to(ITEM)),
        "bytes": path.stat().st_size,
        "sha256": hashlib.sha256(path.read_bytes()).hexdigest(),
    }
    for path in files
]
archive = DEST / f"{NAME}.tar.gz"
with archive.open("wb") as raw, gzip.GzipFile(fileobj=raw, mode="wb", mtime=0) as zipped:
    with tarfile.open(fileobj=zipped, mode="w") as bundle:
        for path in files:
            info = bundle.gettarinfo(str(path), arcname=str(path.relative_to(ITEM)))
            info.mtime = info.uid = info.gid = 0
            info.uname = info.gname = ""
            with path.open("rb") as content:
                bundle.addfile(info, content)
digest = hashlib.sha256(archive.read_bytes()).hexdigest()
index = {
    "archive": archive.name,
    "sha256": digest,
    "bytes": archive.stat().st_size,
    "files": entries,
    "excluded": "Build caches, installed packages, wheels, native binaries, bytecode and later CI snapshots",
}
(DEST / f"{NAME}-index.json").write_text(json.dumps(index, indent=2) + "\n")
(DEST / f"{NAME}.tar.gz.sha256").write_text(f"{digest}  {archive.name}\n")
with tarfile.open(archive, "r:gz") as bundle:
    assert bundle.getnames() == [entry["path"] for entry in entries]
    for entry in entries:
        assert hashlib.sha256(bundle.extractfile(entry["path"]).read()).hexdigest() == entry["sha256"]
print(json.dumps({"archive": str(archive), "sha256": digest, "files": len(entries), "bytes": archive.stat().st_size}))
