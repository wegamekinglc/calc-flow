"""Own this review's sole acquisition and its original 600-second deadline."""

from __future__ import annotations

import json
import os
import signal
import subprocess
import sys
import time
from pathlib import Path

import psutil

ITEM = Path(__file__).resolve().parent


def main():
    started = time.monotonic()
    protocol = json.loads((ITEM / "performance-protocol.json").read_text())
    os.sched_setaffinity(0, {protocol["controller_cpu"]})
    deadline = started + 600
    receipt = {
        "started_monotonic": started,
        "budget_seconds": 600,
        "signals": [],
        "owned": [],
        "remaining": [],
        "exit_code": None,
    }
    known = {}
    controller = None

    def discover():
        if controller is not None:
            # The controller owns a new session; include children reparented
            # between snapshots of its direct descendant tree.
            for process in psutil.process_iter(["pid", "create_time"]):
                try:
                    if os.getsid(process.pid) == controller.pid:
                        known[process.pid] = process.info["create_time"]
                except (ProcessLookupError, PermissionError, psutil.NoSuchProcess):
                    pass
        for pid, created in list(known.items()):
            try:
                parent = psutil.Process(pid)
                if parent.create_time() != created:
                    continue
                for child in parent.children(recursive=True):
                    try:
                        known[child.pid] = child.create_time()
                    except psutil.NoSuchProcess:
                        pass
            except psutil.NoSuchProcess:
                pass

    def alive():
        survivors = []
        for pid, created in list(known.items()):
            try:
                process = psutil.Process(pid)
                if (
                    process.create_time() == created
                    and process.status() != psutil.STATUS_ZOMBIE
                ):
                    survivors.append(process)
            except psutil.NoSuchProcess:
                pass
        return survivors

    def send(sig):
        discover()
        for process in reversed(alive()):
            try:
                process.send_signal(sig)
                receipt["signals"].append(
                    {
                        "pid": process.pid,
                        "signal": sig,
                        "elapsed": time.monotonic() - started,
                    }
                )
            except psutil.NoSuchProcess:
                pass

    try:
        with (ITEM / "performance-controller.log").open("wb") as log:
            controller = subprocess.Popen(
                [sys.executable, str(ITEM / "perf-controller.py")],
                cwd=ITEM,
                env={**os.environ, "WEEKLY_REVIEW_STARTED": str(started)},
                stdout=log,
                stderr=subprocess.STDOUT,
                start_new_session=True,
            )
            known[controller.pid] = psutil.Process(controller.pid).create_time()
            receipt["controller_pid"] = controller.pid
            receipt["session_id"] = os.getsid(controller.pid)
            receipt["process_group"] = os.getpgid(controller.pid)
            while controller.poll() is None and time.monotonic() < started + 585:
                discover()
                time.sleep(min(0.1, max(0, started + 585 - time.monotonic())))
            if controller.poll() is None:
                send(signal.SIGINT)
                while controller.poll() is None and time.monotonic() < started + 595:
                    discover()
                    time.sleep(min(0.1, max(0, started + 595 - time.monotonic())))
    except BaseException as error:
        receipt["outer_error"] = f"{type(error).__name__}: {error}"
        raise
    finally:
        discover()
        if alive():
            send(signal.SIGTERM)
            end = min(deadline - 1, time.monotonic() + 1)
            while alive() and time.monotonic() < end:
                discover()
                time.sleep(min(0.05, max(0, end - time.monotonic())))
        if alive():
            send(signal.SIGKILL)
        if controller is not None:
            try:
                receipt["exit_code"] = controller.wait(
                    timeout=max(0.01, deadline - time.monotonic() - 0.2)
                )
            except subprocess.TimeoutExpired:
                receipt["wait_timeout"] = True
        while alive() and time.monotonic() < deadline - 0.1:
            discover()
            time.sleep(min(0.05, max(0, deadline - 0.1 - time.monotonic())))
        discover()
        receipt["remaining"] = [p.pid for p in alive()]
        receipt["owned"] = [{"pid": p, "create_time": t} for p, t in known.items()]
        receipt["elapsed_seconds"] = time.monotonic() - started
        receipt["within_budget"] = receipt["elapsed_seconds"] <= 600
        summary = ITEM / "performance/summary.json"
        try:
            completed = json.loads(summary.read_text()).get("complete") is True
        except (OSError, ValueError, AttributeError) as error:
            receipt["summary_error"] = f"{type(error).__name__}: {error}"
            completed = False
        receipt["accepted_acquisition"] = (
            receipt["exit_code"] == 0
            and not receipt["remaining"]
            and receipt["within_budget"]
            and not receipt["signals"]
            and "outer_error" not in receipt
            and completed
        )
        (ITEM / "performance-handoff.json").write_text(
            json.dumps(receipt, indent=2) + "\n"
        )
        print(json.dumps(receipt), flush=True)
    if not receipt["accepted_acquisition"]:
        raise SystemExit(1)


if __name__ == "__main__":
    main()
