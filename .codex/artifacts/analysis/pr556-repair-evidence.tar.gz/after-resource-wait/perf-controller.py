"""Run the four frozen review controls through the maintained paired collector."""

from __future__ import annotations

import asyncio
import json
import os
import statistics
import sys
import time
from pathlib import Path

import psutil

ITEM = Path(__file__).resolve().parent
PROTOCOL = ITEM / "performance-protocol.json"
protocol = json.loads(PROTOCOL.read_text())
COMMON = Path(protocol["common_source"])
sys.path.insert(0, str(COMMON))

from scripts.benchmark_suite.process import child_environment, command, install
from scripts.benchmark_suite.release import load_release
from scripts.benchmark_suite.release_pairs import collect_case, evaluate_case
from scripts.profile_warm_stream import source_identity
from scripts.toolkit import sha256_file, write_json


def require_no_builds():
    builds = [
        process.info
        for process in psutil.process_iter(["pid", "name"])
        if process.info["name"]
        in {
            "cargo",
            "rustc",
            "maturin",
            "rust-lld",
            "cc1plus",
            "cc1",
            "cmake",
            "ninja",
            "make",
            "gmake",
            "gcc",
            "g++",
            "clang",
            "clang++",
            "cc",
            "c++",
            "ld",
            "ld.lld",
            "collect2",
            "ctest",
        }
    ]
    if builds:
        raise RuntimeError(f"concurrent native build; no automatic retry: {builds}")


async def acquire():
    started = float(os.environ["WEEKLY_REVIEW_STARTED"])
    deadline = started + 575
    output = ITEM / "performance"
    output.mkdir(exist_ok=False)
    record = {
        "started_monotonic": started,
        "budget_seconds": 590,
        "interrupt_seconds": 575,
        "protocol_sha256": sha256_file(PROTOCOL),
        "cases": [],
        "complete": False,
        "signals": [],
        "attempts": 1,
    }
    write_json(output / "summary.json", record)
    releases = {}

    async def preflight():
        os.sched_setaffinity(0, {protocol["controller_cpu"]})
        for name, digest in protocol["source_seals"].items():
            if sha256_file(Path(name)) != digest:
                raise ValueError(f"measurement helper drift: {name}")
        for side, path in protocol["releases"].items():
            release = load_release(Path(path))
            if release["git_sha"] != protocol[side]:
                raise ValueError(f"{side} release differs from the declared revision")
            identity = await source_identity(Path(release["source"]))
            if any(identity[k] != release[k] for k in identity):
                raise ValueError(f"{side} source no longer matches its build")
            releases[side] = release
        require_no_builds()
        quiet = psutil.cpu_percent(interval=2, percpu=True)
        record["quiet_guard_cpu_percent"] = quiet
        if quiet[protocol["worker_cpu"]] > 10 or statistics.mean(quiet) > 10:
            raise RuntimeError("guest quiet guard failed; no automatic retry")
        write_json(output / "summary.json", record)

    async def postflight():
        require_no_builds()
        for name, digest in protocol["source_seals"].items():
            if sha256_file(Path(name)) != digest:
                raise ValueError(f"measurement helper drift after collection: {name}")
        for side, path in protocol["releases"].items():
            if load_release(Path(path)) != releases[side]:
                raise ValueError(f"{side} wheel changed")
            identity = await source_identity(Path(releases[side]["source"]))
            if any(identity[k] != releases[side][k] for k in identity):
                raise ValueError(f"{side} source changed after collection")

    try:
        async with asyncio.timeout_at(deadline):
            await preflight()
            sites = {
                side: await install(release, output / "installed" / side)
                for side, release in releases.items()
            }
            for case in protocol["cases"]:

                async def measure(side, destination, selected=case):
                    require_no_builds()
                    observation = destination / "worker.json"
                    await command(
                        [
                            "taskset",
                            "-c",
                            str(protocol["worker_cpu"]),
                            sys.executable,
                            str(ITEM / "perf-worker.py"),
                            "--case",
                            selected["id"],
                            "--output",
                            str(observation),
                            "--site",
                            str(sites[side]),
                            "--expected-native-sha256",
                            releases[side]["native_sha256"],
                        ],
                        cwd=COMMON,
                        log=destination / "worker.log",
                        env={
                            **child_environment(
                                sites[side],
                                source=COMMON,
                                polars_threads=1,
                                tokio_threads=1,
                            ),
                            "CALC_FLOW_BENCHMARK_SCALE": "overhead",
                            "NUMEXPR_NUM_THREADS": "1",
                            "RAYON_NUM_THREADS": "1",
                        },
                        timeout=min(90, max(0.01, deadline - time.monotonic() - 10)),
                    )
                    require_no_builds()
                    return json.loads(observation.read_text())

                pairs = await collect_case(case["id"], measure, output / case["id"])
                verdict = evaluate_case(
                    pairs, {side: r["native_sha256"] for side, r in releases.items()}
                )
                record["cases"].append({"id": case["id"], "result": verdict})
                write_json(output / "summary.json", record)
            await postflight()
        record["complete"] = True
        record["postseals_verified"] = True
    except BaseException as error:
        record["error"] = f"{type(error).__name__}: {error}"
        raise
    finally:
        record["elapsed_seconds"] = time.monotonic() - started
        record["within_budget"] = record["elapsed_seconds"] <= 590
        record["complete"] = record["complete"] and record["within_budget"]
        write_json(output / "summary.json", record)


if __name__ == "__main__":
    asyncio.run(acquire())
