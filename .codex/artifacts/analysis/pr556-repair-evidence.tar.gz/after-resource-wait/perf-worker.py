"""One fixed weekly-review observation; launched only by its sealed controller."""

from __future__ import annotations

import argparse
import asyncio
import hashlib
import os
import resource
import time
from pathlib import Path

STARTED = time.monotonic_ns()
CPU_STARTED = time.process_time()
CASE_IDS = (
    "sql-asof-1000",
    "sql-interval-1000",
    "stream-asof-10000",
    "sequence-projection-1000",
)


def _sha(path: Path) -> str:
    with path.open("rb") as source:
        return hashlib.file_digest(source, "sha256").hexdigest()


def _fixture_hash(table) -> str:
    import pyarrow as pa

    sink = pa.BufferOutputStream()
    with pa.ipc.new_stream(sink, table.schema) as writer:
        writer.write_table(table)
    return hashlib.sha256(sink.getvalue().to_pybytes()).hexdigest()


def _case(case_id: str) -> dict:
    from scripts.benchmark_suite.catalog import stream_dimensions

    if case_id == "sequence-projection-1000":
        return {
            "id": case_id,
            "family": "program-sequence-control",
            "scenario": "projection",
            "backend": "calc-flow-program-streaming",
            "rows": 1000,
            "scope": "program-execute-materialized-list-to-arrow",
            "batch_rows": 640,
            "input_form": "list-of-tables",
            "checkpoint_policy": "public-default",
        }
    streaming = case_id == "stream-asof-10000"
    scenario = "interval_join" if case_id == "sql-interval-1000" else "asof_join"
    return {
        "id": case_id,
        "family": "engines",
        "scenario": scenario,
        "backend": "calc-flow-stream-1t" if streaming else "calc-flow-sql-1t",
        "rows": 10000 if streaming else 1000,
        **(
            stream_dimensions(scenario, 1024, False)
            if streaming
            else {"scope": "prepared-calc-flow-sql-execute-to-arrow"}
        ),
    }


async def _sequence_run(program, parts):
    owner = program.execute({"events": list(parts)})
    async with owner as results:
        events = [event async for event in results]
    return events, owner


def _sequence_observations():
    import pyarrow as pa

    from benchmarks.test_program_engine import _expected, _program, _workload

    table, parts = _workload()
    if table.num_rows != 1000 or [part.num_rows for part in parts] != [640, 360]:
        raise ValueError("sequence fixture must use overhead 1000 rows, split 640/360")
    program = _program("projection", "streaming")
    expected = _expected("projection", "streaming", table, parts)
    observations = []
    for _ in range(4):
        started = time.perf_counter_ns()
        events, owner = asyncio.run(_sequence_run(program, parts))
        seconds = (time.perf_counter_ns() - started) / 1e9
        status = owner.job.status()
        if status["state"] != "completed" or status["task_count"] != 0:
            raise ValueError("sequence job did not settle all tasks")
        if [event.name for event in events] != ["result", "result"]:
            raise ValueError("sequence output names or record boundaries changed")
        if [event.table.num_rows for event in events] != [640, 360]:
            raise ValueError("sequence output row boundaries changed")
        actual = [
            value for event in events for value in event.table["value"].to_pylist()
        ]
        if actual != expected:
            raise ValueError("sequence projection differs from the complete oracle")
        observations.append(
            {
                "seconds": seconds,
                "correctness": {"passed": True, "rows": len(actual)},
                "terminal": {"state": status["state"], "task_count": 0},
                "output_rows": [event.table.num_rows for event in events],
            }
        )
    return observations, {
        "input_sha256": _fixture_hash(table),
        "expected_sha256": _fixture_hash(pa.table({"value": expected})),
        "output_rows": len(expected),
    }


def _engine_observations(case: dict, root: Path):
    from benchmarks.engine_comparison import EngineCase
    from scripts.benchmark_suite.measure import validate_sample, validate_stream_sample

    active = EngineCase(case, root)
    primary = None
    try:
        fixtures = {
            "input_sha256": _fixture_hash(active.data.table),
            "dimension_sha256": _fixture_hash(active.data.dimension),
            "expected_sha256": _fixture_hash(active.expected),
            "output_rows": active.expected.num_rows,
        }
        observations = []
        for _ in range(4):
            value = active.sample()
            validate_sample(value)
            validate_stream_sample(case, value)
            observations.append(value)
        if active.finish() != {"state": "completed"}:
            raise ValueError("engine adapter did not finish")
        return observations, fixtures
    except BaseException as error:
        primary = error
        raise
    finally:
        try:
            active.close()
        except BaseException as error:
            if primary is None:
                raise
            primary.add_note(f"adapter cleanup: {type(error).__name__}: {error}")


def _identities(case: dict, environment: dict, fixtures: dict) -> dict:
    from importlib.metadata import version

    import pyarrow as pa

    from scripts.toolkit import fingerprint_json

    raw = {
        "machine": {
            key: environment[key]
            for key in ("platform", "logical_cpus", "cpu_affinity")
        },
        "dependency": {key: environment[key] for key in ("python", "numpy", "pyarrow")},
        "workload": {
            **case,
            **fixtures,
            "scale": "overhead" if case["rows"] == 1000 else "small",
            "warmups_per_process": 1,
            "timed_samples_per_process": 3,
            "observation_reduction": "median",
            "worker_adapter_sha256": _sha(Path(__file__)),
        },
    }
    raw["machine"]["thread_environment"] = {
        name: os.environ.get(name)
        for name in (
            "TOKIO_WORKER_THREADS",
            "OMP_NUM_THREADS",
            "OPENBLAS_NUM_THREADS",
            "MKL_NUM_THREADS",
            "NUMEXPR_NUM_THREADS",
            "POLARS_MAX_THREADS",
        )
    }
    raw["machine"]["arrow_cpu_threads"] = pa.cpu_count()
    raw["machine"]["arrow_io_threads"] = pa.io_thread_count()
    raw["dependency"]["pytest"] = version("pytest")
    raw["dependency"]["pytest-benchmark"] = version("pytest-benchmark")
    return {
        key: value
        for name, identity in raw.items()
        for key, value in (
            (f"{name}_identity", identity),
            (f"{name}_fingerprint", fingerprint_json(identity)),
        )
    }


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--case", choices=CASE_IDS, required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--site", type=Path, required=True)
    parser.add_argument("--expected-native-sha256", required=True)
    args = parser.parse_args()
    if args.output.exists():
        raise ValueError("observation output must be fresh")

    import pyarrow as pa

    import calc_flow
    import calc_flow._native as native
    from scripts.benchmark_suite.measure import validate_sample
    from scripts.toolkit import worker_environment, write_json

    site = args.site.resolve()
    native_path = Path(native.__file__).resolve()
    if not native_path.is_relative_to(site) or not Path(
        calc_flow.__file__
    ).resolve().is_relative_to(site):
        raise ValueError("product was not loaded from the sealed wheel site")
    if _sha(native_path) != args.expected_native_sha256:
        raise ValueError("loaded native module differs from the sealed wheel")
    pa.set_cpu_count(1)
    pa.set_io_thread_count(1)
    environment = worker_environment()
    if environment["cpu_affinity"] != [0] or environment["tokio_worker_threads"] != "1":
        raise ValueError("worker must run on CPU 0 with one Tokio thread")
    case = _case(args.case)
    observations, fixtures = (
        _sequence_observations()
        if args.case == "sequence-projection-1000"
        else _engine_observations(case, args.output.parent / "runtime")
    )
    for value in observations:
        validate_sample(value)
    usage = resource.getrusage(resource.RUSAGE_SELF)
    observation = {
        "case": case,
        "worker": f"{os.getpid()}:{STARTED}",
        "binary_sha256": args.expected_native_sha256,
        "native_path": str(native_path),
        "product_path": str(Path(calc_flow.__file__).resolve()),
        "correctness": True,
        "samples": [value["seconds"] for value in observations[1:]],
        "warmup": observations[0],
        "raw_samples": observations[1:],
        "metadata": _identities(case, environment, fixtures),
        "environment": environment,
        "resources": {
            "peak_rss_bytes": usage.ru_maxrss * 1024,
            "process_cpu_seconds": time.process_time() - CPU_STARTED,
            "user_cpu_seconds": usage.ru_utime,
            "system_cpu_seconds": usage.ru_stime,
            "voluntary_context_switches": usage.ru_nvcsw,
            "involuntary_context_switches": usage.ru_nivcsw,
        },
        "worker_elapsed_seconds": (time.monotonic_ns() - STARTED) / 1e9,
    }
    write_json(args.output, observation)


if __name__ == "__main__":
    main()
