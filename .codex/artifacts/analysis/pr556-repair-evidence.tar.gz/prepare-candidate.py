from __future__ import annotations
import json
import os
import shutil
import subprocess
import sys
import time
from pathlib import Path

ROOT = Path(__file__).resolve().parents[3]
ITEM = Path(__file__).resolve().parent
source = ROOT / "target/weekly-review-20261107/candidate-v2-release/cargo"
output = ITEM / "candidate-v2-release"
target = output / "cargo"
started = time.monotonic()
shutil.copytree(source, target)
removed = []
for pattern in ("release/deps/libcalc_flow-*.rlib", "release/deps/libcalc_flow-*.rmeta", "release/deps/libcalc_flow_python.so", "release/libcalc_flow_python*"):
    for path in target.glob(pattern):
        path.unlink()
        removed.append(str(path.relative_to(target)))
receipt = {"complete": True, "source": str(source), "destination": str(target), "source_build_complete": True, "ordinary_copy": True, "elapsed_seconds": time.monotonic() - started, "products_removed_after_completed_copy": removed}
(ITEM / "candidate-v2-cache-copy.json").write_text(json.dumps(receipt, indent=2) + "\n")
print(json.dumps(receipt), flush=True)
argv = [sys.executable, str(ROOT / "target/weekly-review-20261107/build_release.py"), str(ROOT / "target/worktrees/pr556-repair-candidate"), str(output)]
raise SystemExit(subprocess.run(argv, env={**os.environ, "CARGO_BUILD_JOBS": "2", "CARGO_INCREMENTAL": "0"}, check=False).returncode)
