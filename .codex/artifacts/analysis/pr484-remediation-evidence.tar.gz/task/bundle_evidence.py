"""Archive this fixed task's completed acquisition and verification evidence."""

from __future__ import annotations

import gzip
import hashlib
import io
import json
import tarfile
from pathlib import Path

ROOT = Path(__file__).resolve().parent
REPOSITORY = ROOT.parents[2]
OUTPUT = (
    REPOSITORY
    / "target/worktrees/join-single-thread-performance/.codex/artifacts/analysis"
)
NAME = "pr484-remediation-evidence"


def sha256(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def main() -> None:
    report_path = ROOT / "reports/measurement.json"
    report_bytes = report_path.read_bytes()
    report = json.loads(report_bytes)
    if report["status"] == "running" or "total_budget_respected" not in report:
        raise RuntimeError("wait for root's completed acquisition and cleanup")
    if report["plan_sha256"] != sha256((ROOT / "plan.json").read_bytes()):
        raise ValueError("formal plan changed after acquisition")
    if report["plan"] != json.loads((ROOT / "plan.json").read_text()):
        raise ValueError("formal plan content differs from the saved report")
    files = {
        f"task/{path.relative_to(ROOT)}": path
        for pattern in ("*.py", "*.json", "*.log", "acquisition-plan.md")
        for path in ROOT.glob(pattern)
        if path.is_file()
    }
    for path in (ROOT / "reports").rglob("*"):
        if path.is_file() and (
            path == report_path or path.name in {"stdout.jsonl", "stderr.log"}
        ):
            files[f"task/{path.relative_to(ROOT)}"] = path
    for side in ("base", "candidate"):
        for name in ("build.json", "build.log"):
            path = Path(report["plan"]["builds"][side]).parent / name
            files[f"task/releases/{side}/{name}"] = path
    source = Path(report["plan"]["source"])
    for name, expected_hash in report["harness_hashes"].items():
        path = Path(name)
        if sha256(path.read_bytes()) != expected_hash:
            raise ValueError(f"frozen harness changed: {path}")
        member = (
            f"task/{path.relative_to(ROOT)}"
            if path.is_relative_to(ROOT)
            else f"harness/{path.relative_to(source)}"
        )
        files[member] = path
    OUTPUT.mkdir(parents=True, exist_ok=True)
    archive = OUTPUT / f"{NAME}.tar.gz"
    if archive.exists():
        raise RuntimeError("evidence archive exists; refusing to overwrite it")
    entries = []
    with (
        archive.open("xb") as raw,
        gzip.GzipFile(filename="", mode="wb", fileobj=raw, mtime=0) as zipped,
        tarfile.open(fileobj=zipped, mode="w") as tar,
    ):
        for member, path in sorted(files.items()):
            data = path.read_bytes()
            info = tarfile.TarInfo(member)
            info.size = len(data)
            info.mode = 0o644
            info.mtime = 0
            tar.addfile(info, io.BytesIO(data))
            entries.append({"path": member, "bytes": len(data), "sha256": sha256(data)})
    archive_hash = sha256(archive.read_bytes())
    index = {
        "schema": "calc-flow.pr484-remediation-evidence-index.v1",
        "archive": archive.name,
        "archive_bytes": archive.stat().st_size,
        "archive_sha256": archive_hash,
        "formal_report_status": report["status"],
        "source_revisions": report["plan"]["revisions"],
        "source_trees": {
            "base": report["plan"]["baseline_source_tree"],
            "candidate": report["plan"]["source_tree"],
        },
        "measurement_json_sha256": sha256(report_bytes),
        "members": entries,
        "exclusions": [
            "Wheel/native binaries remain in sealed release directories; "
            "their hashes and build manifests are retained.",
            "Checkpoint/runtime state directories are not timing reports; "
            "worker output and the formal all-row correctness report are retained.",
            "The earlier preparation-checks.json is an unsealed preparation "
            "snapshot. The formal report's plan and hash are authoritative.",
            "Later analysis/review Markdown is tracked separately and does not "
            "change the sealed source or archived measurement.",
        ],
    }
    (OUTPUT / f"{NAME}-index.json").write_text(
        json.dumps(index, indent=2, allow_nan=False) + "\n"
    )
    (OUTPUT / f"{NAME}.tar.gz.sha256").write_text(f"{archive_hash}  {archive.name}\n")
    print(
        json.dumps(
            {
                "archive": str(archive),
                "sha256": archive_hash,
                "members": len(entries),
                "status": report["status"],
            }
        )
    )


if __name__ == "__main__":
    main()
