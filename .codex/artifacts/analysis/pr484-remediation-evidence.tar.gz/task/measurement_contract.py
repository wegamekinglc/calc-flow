"""Strict oracles shared by the thin join worker and native-free tests."""

from __future__ import annotations

import hashlib
import sys
from pathlib import Path

import pyarrow as pa

SOURCE = Path(__file__).resolve().parents[2] / "worktrees/pr484-remediation-candidate"
sys.path.insert(0, str(SOURCE))

from benchmarks.interval_acceptance import validate_interval_output  # noqa: E402
from benchmarks.join_asof_acceptance import validate_one_to_one_output  # noqa: E402


def frozen_schema(scenario: str) -> pa.Schema:
    if scenario in {"join", "asof_join"}:
        return pa.schema(
            [
                pa.field("sequence", pa.uint64(), nullable=False),
                pa.field("value", pa.float64(), nullable=scenario == "asof_join"),
            ]
        )
    if scenario == "interval_join":
        return pa.schema(
            [
                pa.field("sequence", pa.uint64(), nullable=False),
                pa.field("right_sequence", pa.uint64(), nullable=False),
                pa.field("value", pa.float64(), nullable=False),
            ]
        )
    raise ValueError("workload is outside the fixed join inventory")


def validate_output(scenario, actual, expected, rows):
    schema = frozen_schema(scenario)
    if not expected.schema.equals(schema, check_metadata=True):
        raise ValueError("expected table differs from the independently frozen schema")
    if not actual.schema.equals(schema, check_metadata=True):
        raise ValueError("actual table differs from the independently frozen schema")
    if scenario == "interval_join":
        proof = validate_interval_output(actual, expected, rows)
    else:
        proof = validate_one_to_one_output(actual, expected)
        if not actual["sequence"].equals(expected["sequence"]):
            raise ValueError("join/ASOF sequence emission order changed")
    return {**proof, "identity_order_sha256": identity_order_sha256(actual)}


def identity_order_sha256(table: pa.Table) -> str:
    """Hash logical uint64 identities without copying or chunk framing.

    Interval hashes are descriptive only. Legitimate cross-input scheduling
    can change global emission order; exact interval multiset validation and
    focused Rust per-probe order tests supply the acceptance evidence.
    """
    digest = hashlib.sha256()
    names = ["sequence"] + (
        ["right_sequence"] if "right_sequence" in table.column_names else []
    )
    for name in names:
        digest.update(name.encode())
        column = table[name]
        if column.type != pa.uint64() or column.null_count:
            raise ValueError("order proof requires non-null uint64 identities")
        for chunk in column.chunks:
            # Arrow buffers can cover parent arrays; hash only the visible slice.
            digest.update(chunk.buffers()[1].slice(chunk.offset * 8, len(chunk) * 8))
    return digest.hexdigest()
