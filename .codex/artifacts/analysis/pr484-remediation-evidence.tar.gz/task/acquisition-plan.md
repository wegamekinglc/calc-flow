# Fixed PR #484 remediation performance plan

Recorded before any acquisition on 2026-10-20. The production change extracts
the existing Runs arm of `Selection::append_view` into a private helper. Loop
order, range clamping, index writes, source-order transitions and allocation
sites/capacity remain unchanged. The test-fixture extraction is test-only.
The plausible runtime risk is code generation/inlining at one call per fragment.
Only the two affected interval controls below will be measured.

Baseline is sealed PR #484 code X
`98012d8a91bb3d0847a50cb77d21025f13629864`, tree
`1ae0a8e48818c7464fbf51425c9931347cafa928`. Reuse its already-built, clean default
release, with original manifest at
`target/performance/join-single-thread-performance/releases/candidate/build.json`.
Native SHA-256 is
`2740ff5037253d672f52c77193cf7de45afbd29abf49779f42a5b85fea08cc60`;
wheel SHA-256 is
`5f07d5d94fd1f580971e9fbff6124718e2404f19adc4e74d38c6fedd82c32e85`.
The original sealed source remains
`target/worktrees/join-single-thread-candidate-sealed`. Do not relabel it as main
or reuse its earlier timing observations as this comparison's baseline samples.

Candidate is repair commit R `00c313ba0ab144e0f1537c7160ee323b5ccbef18`, tree
`65c98f18e09b50a18245bbbba3c99e95c7aa6683`, sealed at
`target/worktrees/pr484-remediation-candidate`. Root completes its exact default
release build and records wheel/native identities before acquisition.
Later evidence-only commit S does not inherit a separately measured native build.
Candidate build estimate is about 600 seconds, budgeted separately; baseline
does not need another native build. Root exclusively builds and acquires.

| Case                     | CPUs | Input rows per side | Source batch | Purpose                                      |
|--------------------------|------|---------------------|--------------|----------------------------------------------|
| Maintained Interval Join | 1    | 1,000,000           | 1,000,000    | Runs-view append single-CPU regression guard |
| Maintained Interval Join | 32   | 1,000,000           | 1,000,000    | Parallel owner-assembly regression guard     |

Both reuse maintained EngineCase, exact-cursor feeds, 64 keys, inclusive
five-second bounds and the full 10,998,080-pair oracle. Coalesce immutable fixture
input before event construction and record one actual physical RecordBatch per
side in both arms. Explicit state/edge budgets, source geometry, checkpoint mode,
dependencies, compiler and flags match. Product 1M/unlimited-memory defaults and
CPU-derived capacities remain unchanged.

Each case has two rounds of ten adjacent alternating AB/BA pairs, reversing
the leading arm in round two. Exactly one excluded warmup per worker gives
**80 formal observations and eight excluded warmups**. Both arms use explicit
Tokio workers equal to the selected affinity (1/32 logical CPUs), BLAS/OpenMP at
one. Do not add cases, samples, profiles, retries or budget extensions.

One **600-second** acquisition budget includes release/source preflight, startup,
fixture preparation, warmup, complete correctness oracles, progress, EOF and owned
cleanup. Stop requests at **570 seconds**, reserving 30 seconds for cleanup.
Directionally expect 130–250 seconds, with no measured-duration promise. Stop and
report incomplete/uncertain evidence at the limit or an unsuitable environment.
Root launches with host `/proc` visibility only after all native work settles;
never stop other users' processes. WSL host-wide quiet/power is not observable.

Timing remains ready-source enqueue through Arrow output concatenation.
Preserve exact pair multiplicity, values, schema/nullability, actual stream
resource/progress evidence and maintained `run_with_completion` lifecycle.
Interval identity-order hashes are descriptive only: legitimate cross-input
scheduling can change global emission order. Focused Rust tests cover guaranteed
per-probe/run order on both sides.

Only matching machine/dependency/workload fingerprints within each case permit
classification. Use maintained `report.comparison` paired-median intervals:
both round lower bounds above +5% confirm regression; any upper bound above +5%
is inconclusive; both upper bounds below -5% establish improvement; otherwise
no-confirmed-regression. Report every result, P50/P95, round intervals, raw
observations, RSS/CPU scope and limitations. There is no whole-suite, cross-CPU
scaling or universal non-regression verdict. Do not compare against main
`78b75724` or the earlier five-case timing table.
