"""Audit saved observations without importing calc_flow or acquiring timings."""

from __future__ import annotations

import hashlib
import json
import statistics
import sys
from pathlib import Path

from prepare_plan import SOURCE, validate_fixed_plan

from scripts.benchmark_suite.report import comparison

ROOT = Path(__file__).resolve().parent
EXPECTED_BASELINE = (
    "98012d8a91bb3d0847a50cb77d21025f13629864",
    "1ae0a8e48818c7464fbf51425c9931347cafa928",
)


def sha256(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def fingerprint(value: dict) -> str:
    return hashlib.sha256(
        json.dumps(value, sort_keys=True, separators=(",", ":")).encode()
    ).hexdigest()


def validate_sample(sample: dict, expected_rows: int) -> None:
    assert sample["seconds"] > 0
    assert sample["correctness"]["passed"] is True
    assert sample["correctness"]["max_abs_error"] == 0.0
    assert sample["correctness"]["rows"] == expected_rows
    assert len(sample["correctness"]["identity_order_sha256"]) == 64
    assert sample["completion_contract"] == "maintained-run_with_completion/completed"


def main() -> None:
    path = ROOT / "reports/measurement.json"
    report = json.loads(path.read_text())
    plan = json.loads((ROOT / "plan.json").read_text())
    validate_fixed_plan(plan)
    assert report["status"] == "completed"
    assert report["plan"] == plan
    assert report["plan_sha256"] == sha256(ROOT / "plan.json")
    assert report["total_budget_respected"] is True
    assert report["elapsed_seconds"] < 600
    assert report["uncompleted_cases"] == []
    assert not report.get("cleanup_errors")
    assert not report.get("interference")
    assert report["harness_hashes"] == plan["prepared_harness_sha256"]
    for name, expected in report["harness_hashes"].items():
        assert sha256(Path(name)) == expected, name
    expected_sources = {
        "base": EXPECTED_BASELINE,
        "candidate": (plan["revisions"]["candidate"], plan["source_tree"]),
    }
    for side, expected in expected_sources.items():
        build_path = Path(plan["builds"][side])
        build = json.loads(build_path.read_text())
        assert build == report["builds"][side]
        assert sha256(build_path) == plan["build_manifest_sha256"][side]
        assert (build["source_sha"], build["source_tree"]) == expected
        assert (
            sha256(Path(build["source"]) / "Cargo.lock") == build["cargo_lock_sha256"]
        )
        for artifact in ("wheel", "native"):
            assert sha256(Path(build[artifact])) == build[f"{artifact}_sha256"]
    formal_count, warmup_count, terminal_count = 0, 0, 0
    cases = []
    for case in report["cases"]:
        workload = case["workload"]
        result = case["comparisons"][0]
        expected_rows = result["matched_identity"]["workload"]["identity"][
            "expected_rows"
        ]
        assert len(result["rounds"]) == 2
        samples = {"A": [], "B": []}
        terminals = []
        for round_index, round_ in enumerate(result["rounds"]):
            assert len(round_["order"]) == 10
            for sample_index, order in enumerate(round_["order"]):
                assert order == (
                    ["A", "B"] if (sample_index + round_index) % 2 == 0 else ["B", "A"]
                )
            assert (
                round_["prepare"]["A"]["workload"] == round_["prepare"]["B"]["workload"]
            )
            for name in ("machine", "dependency"):
                assert (
                    round_["identity"]["A"]["identities"][name]
                    == round_["identity"]["B"]["identities"][name]
                )
            for label in ("A", "B"):
                identity = round_["identity"][label]
                for value in identity["identities"].values():
                    assert value["sha256"] == fingerprint(value["identity"])
                assert all(
                    Path(name).is_relative_to(SOURCE)
                    for name in identity["loaded_harness"]
                )
                side = result["pairing"][label]["release"]
                assert (
                    identity["proof"]["native_sha256"]
                    == report["builds"][side]["native_sha256"]
                )
                facts = round_["prepare"][label]["workload"]
                assert facts["sha256"] == fingerprint(facts["identity"])
                validate_sample(round_["prepare"][label]["warmup"], expected_rows)
                warmup_count += 1
                assert len(round_["samples"][label]) == 10
                for sample in round_["samples"][label]:
                    validate_sample(sample, expected_rows)
                    formal_count += 1
                samples[label].extend(round_["samples"][label])
                assert round_["completion"][label]["state"] == "completed"
                diagnostics = round_["prepare"][label]["warmup_diagnostics"]
                assert len(diagnostics) == 1
                for diagnostic in diagnostics:
                    status = diagnostic["terminal_status"]
                    assert status["state"] == "completed"
                    assert status["terminal_cause"] == "natural_end"
                    assert status["task_count"] == status["task_errors"] == 0
                    assert status["metrics_overflowed"] is False
                    assert all(
                        source["ended"] and source["errors"] == 0
                        for source in status["sources"].values()
                    )
                    assert all(
                        sink["ended"]
                        and sink["errors"] == 0
                        and sink["delivered_rows"] == expected_rows
                        for sink in status["sinks"].values()
                    )
                    assert all(
                        edge["current_rows"]
                        == edge["current_bytes"]
                        == edge["current_envelopes"]
                        == 0
                        for edge in status["edges"].values()
                    )
                    terminal_count += 1
                    terminals.append(
                        {
                            "label": label,
                            "state": status["state"],
                            "task_count": status["task_count"],
                            "task_errors": status["task_errors"],
                        }
                    )
        recomputed = comparison(
            {
                "id": f"{workload['id']}/{result['pairing']['id']}",
                "rows": workload["case"]["rows"],
                "correctness": True,
                "comparison": "interleaved",
                "baseline": [
                    [sample["seconds"] for sample in round_["samples"]["A"]]
                    for round_ in result["rounds"]
                ],
                "candidate": [
                    [sample["seconds"] for sample in round_["samples"]["B"]]
                    for round_ in result["rounds"]
                ],
            }
        )
        assert recomputed == result["statistics"]
        cases.append(
            {
                "id": workload["id"],
                "statistics": result["statistics"],
                "descriptive": result["descriptive"],
                "fingerprints": {
                    name: value["sha256"]
                    for name, value in result["matched_identity"].items()
                },
                "correct_output_rows": expected_rows,
                "resources": {
                    label: {
                        "peak_lifetime_rss_mib": max(
                            sample["lifetime_peak_rss_kb"] for sample in values
                        )
                        / 1024,
                        "whole_sample_cpu_p50_seconds": statistics.median(
                            sample["whole_sample_cpu_seconds"] for sample in values
                        ),
                        "identity_order_hashes": sorted(
                            {
                                sample["correctness"]["identity_order_sha256"]
                                for sample in values
                            }
                        ),
                    }
                    for label, values in samples.items()
                },
                "warmup_terminals": terminals,
            }
        )
    assert formal_count == 80
    assert warmup_count == terminal_count == 8
    assert "calc_flow" not in sys.modules and "calc_flow._native" not in sys.modules
    audit = {
        "schema": "calc-flow.pr484-remediation-offline-audit.v1",
        "status": "passed",
        "measurement_json_sha256": sha256(path),
        "plan_sha256": report["plan_sha256"],
        "source_revisions": plan["revisions"],
        "elapsed_acquisition_seconds": report["elapsed_seconds"],
        "formal_observations": formal_count,
        "excluded_warmups": warmup_count,
        "warmup_terminal_jobs_checked": terminal_count,
        "statistics_recomputed_exactly": True,
        "frozen_harness_and_release_artifact_hashes_verified": True,
        "native_imports": False,
        "new_measurements": False,
        "cases": cases,
    }
    (ROOT / "offline-audit.json").write_text(
        json.dumps(audit, indent=2, allow_nan=False) + "\n"
    )
    print(
        json.dumps(
            {
                key: audit[key]
                for key in (
                    "status",
                    "formal_observations",
                    "excluded_warmups",
                    "statistics_recomputed_exactly",
                    "frozen_harness_and_release_artifact_hashes_verified",
                    "native_imports",
                )
            }
        )
    )


if __name__ == "__main__":
    main()
