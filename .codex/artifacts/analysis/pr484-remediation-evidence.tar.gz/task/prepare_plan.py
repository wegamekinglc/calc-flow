"""Freeze two PR484 remediation controls after root seals both releases."""

from __future__ import annotations

import argparse
import hashlib
import json
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent
REPOSITORY = ROOT.parents[2]
SOURCE = REPOSITORY / "target/worktrees/pr484-remediation-candidate"
BASELINE_SOURCE = REPOSITORY / "target/worktrees/join-single-thread-candidate-sealed"
BASELINE_SHA = "98012d8a91bb3d0847a50cb77d21025f13629864"
CANDIDATE_SHA = "00c313ba0ab144e0f1537c7160ee323b5ccbef18"
CANDIDATE_TREE = "65c98f18e09b50a18245bbbba3c99e95c7aa6683"
INVENTORY = (
    ("interval_join", 1, 1_000_000),
    ("interval_join", 32, 1_000_000),
)
sys.path.insert(0, str(SOURCE))

from scripts.benchmark_suite.catalog import (  # noqa: E402
    engine_cases,
)

HELPERS = (
    "measure.py",
    "measure_worker.py",
    "measurement_contract.py",
    "prepare_plan.py",
)
MAINTAINED = (
    "benchmarks/engine_comparison.py",
    "benchmarks/engine_stream.py",
    "benchmarks/native_memory_profile.py",
    "benchmarks/engine_lifecycle.py",
    "benchmarks/interval_acceptance.py",
    "benchmarks/join_asof_acceptance.py",
    "scripts/benchmark_suite/catalog.py",
    "scripts/benchmark_suite/process.py",
    "scripts/benchmark_suite/diagnostics.py",
    "scripts/toolkit.py",
    "scripts/benchmark_suite/report.py",
    "scripts/benchmark_suite/statistics.py",
    "scripts/benchmark_suite/issue406_measurement.py",
)


def sha256(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def workload(scenario: str, cpus: int, batch_rows: int) -> dict:
    rows = 1_000_000
    if (scenario, cpus, batch_rows) not in INVENTORY:
        raise ValueError("workload is outside the two-case remediation inventory")
    case = next(
        case
        for case in engine_cases(rows)
        if case["backend"] == "calc-flow-stream"
        and case["scenario"] == scenario
        and case.get("batch_rows") == rows
        and case.get("checkpoint_interval_millis") is None
    )
    return {
        "id": f"{scenario}-{rows}-batch{batch_rows}-cpu{cpus}",
        "kind": "engine",
        "case": case,
        "batch_rows": batch_rows,
        "rationale": (
            "Runs-view append single-CPU regression control after extraction."
            if cpus == 1
            else "32-logical-CPU Runs-view owner-assembly regression control."
        ),
        "pairs": [
            {
                "id": f"pr484-code-x-vs-remediation-{cpus}cpu",
                "kind": "version",
                "A": {"release": "base", "cpus": cpus},
                "B": {"release": "candidate", "cpus": cpus},
            }
        ],
    }


def release(path: Path, source: Path) -> dict:
    build = json.loads(path.read_text())
    if (
        build.get("exit_code") != 0
        or build.get("features") != ["default"]
        or build.get("profile") != "release"
        or build.get("tracked_source_clean") is not True
        or build.get("modified_core_recompiled") is not True
        or Path(build["source"]).resolve() != source
    ):
        raise ValueError("both arms require exact clean-source default release builds")
    return build


def validate_fixed_plan(plan: dict) -> None:
    fixed = {
        "budget_seconds": 600,
        "formal_acquisition_seconds": 570,
        "cleanup_reserve_seconds": 30,
        "warmups_per_worker": 1,
        "formal_observations": 80,
        "excluded_formal_warmups": 8,
        "rounds": 2,
        "samples_per_arm_per_round": 10,
        "diagnostics": {"enabled": False, "budget_seconds": 0},
    }
    if any(plan.get(name) != value for name, value in fixed.items()):
        raise ValueError("fixed samples, budget or diagnostic inventory changed")
    if plan["workloads"] != [workload(*dimensions) for dimensions in INVENTORY]:
        raise ValueError("predeclared two-case inventory changed")
    if plan["revisions"]["base"] != BASELINE_SHA:
        raise ValueError("predeclared baseline revision changed")
    if plan["revisions"]["candidate"] not in (None, CANDIDATE_SHA):
        raise ValueError("predeclared repair revision changed")
    if plan["source_tree"] not in (None, CANDIDATE_TREE):
        raise ValueError("predeclared repair tree changed")


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--baseline-build", type=Path)
    parser.add_argument("--candidate-build", type=Path)
    args = parser.parse_args()
    if (ROOT / "reports/measurement.json").exists():
        raise RuntimeError("acquisition exists; refusing to replace its plan")
    baseline = (
        release(args.baseline_build, BASELINE_SOURCE) if args.baseline_build else None
    )
    candidate = release(args.candidate_build, SOURCE) if args.candidate_build else None
    if baseline is not None and baseline["source_sha"] != BASELINE_SHA:
        raise ValueError("baseline must be the predeclared PR484 code-X revision")
    if candidate is not None and (
        candidate["source_sha"] != CANDIDATE_SHA
        or candidate["source_tree"] != CANDIDATE_TREE
    ):
        raise ValueError("candidate must be the predeclared sealed repair revision")
    ready = baseline is not None and candidate is not None
    files = [
        *(ROOT / name for name in HELPERS),
        *(SOURCE / name for name in MAINTAINED),
    ]
    plan = {
        "schema": "calc-flow.pr484-remediation-feature-plan.v1",
        "readiness": "frozen-ready" if ready else "awaiting-sealed-releases",
        "execution_authorized": ready,
        "source": str(SOURCE),
        "source_sha": candidate["source_sha"] if candidate else None,
        "source_tree": candidate["source_tree"] if candidate else None,
        "baseline_source_tree": baseline["source_tree"] if baseline else None,
        "revisions": {
            "base": BASELINE_SHA,
            "candidate": candidate["source_sha"] if candidate else None,
        },
        "builds": {
            "base": str(args.baseline_build.resolve()) if baseline else None,
            "candidate": str(args.candidate_build.resolve()) if candidate else None,
        },
        "build_manifest_sha256": {
            "base": sha256(args.baseline_build) if baseline else None,
            "candidate": sha256(args.candidate_build) if candidate else None,
        },
        "text_plan_sha256": sha256(ROOT / "acquisition-plan.md"),
        "measurement_contract": (
            "Focused maintained EngineCase ready-enqueue-through-Arrow-concat. "
            "Two rounds of ten adjacent alternating AB/BA pairs, opposite round "
            "leads, maintained paired-median confidence intervals. No whole-suite "
            "verdict; cross-CPU and cross-adapter ratios descriptive only."
        ),
        "rounds": 2,
        "samples_per_arm_per_round": 10,
        "warmups_per_worker": 1,
        "formal_observations": 80,
        "excluded_formal_warmups": 8,
        "budget_seconds": 600,
        "formal_acquisition_seconds": 570,
        "cleanup_reserve_seconds": 30,
        "budget_includes": [
            "release preflight",
            "fixture construction",
            "process startup",
            "warmups",
            "full oracle checks",
            "EOF",
            "progress observation",
            "cleanup",
        ],
        "builds_budgeted_separately": True,
        "build_estimate_seconds_per_release": 600,
        "baseline_default_release_reused": True,
        "diagnostics": {"enabled": False, "budget_seconds": 0},
        "workloads": [workload(*dimensions) for dimensions in INVENTORY],
        "fixture": {
            "entities": 64,
            "rows_per_side": 1_000_000,
            "physical_geometry": (
                "One coalesced immutable 1M RecordBatch per side, "
                "actual geometry recorded in both arms."
            ),
            "interval": (
                "Maintained inclusive +/-5-second exact-cursor "
                "replay; JoinStateLimits(6*N+768,1GiB,11*N); "
                "11*N-1920 exact pairs."
            ),
            "edge_budget": "1M rows; 64MiB.",
            "schema": (
                "sequence/right_sequence:uint64 and value:float64 "
                "nonnull; metadata exact."
            ),
            "state_lifecycle": (
                "Fresh checkpoint path per invocation; "
                "run_with_completion, EOF and awaited cancellation "
                "cleanup."
            ),
            "order": (
                "Normalized identity-order hashes are descriptive "
                "only, never a global acceptance gate. Exact pair "
                "multiset plus focused per-probe order tests are "
                "authoritative."
            ),
        },
        "environment_guard": {
            "compiler_comm_names": [
                "cargo",
                "rustc",
                "rustdoc",
                "ld.lld",
                "clippy-driver",
                "cc1",
                "cc1plus",
                "maturin",
            ],
            "external_executable_basenames": [
                "p2-ci-repair-baseline-quote-risk",
                "perf",
                "samply",
            ],
            "external_argument_basenames": [
                "measure.py",
                "measure_worker.py",
                "native_memory_profile.py",
                "diagnostic_worker.py",
                "engine_worker.py",
                "warm_worker.py",
            ],
            "policy": (
                "Root must launch with host /proc visibility after owned "
                "builds settle. Reject visible competing compilers or "
                "benchmark workloads; never signal external processes. "
                "WSL host power and host-wide quiet cannot be "
                "established."
            ),
        },
        "resource_interpretation": (
            "Whole-sample CPU includes untimed oracles/lifecycle and "
            "cannot be divided by ready wall time. Excluded warmup "
            "PhaseClock is ready-window CPU only and can include lazy "
            "startup. No diagnostic build/profiling or actual "
            "worker-concurrency claim."
        ),
        "unmeasured": [
            "ASOF paths (production code unchanged by this repair)",
            "ordinary Join identity/pairs branches (existing loops unchanged)",
            "other scales, payload types and CPU settings",
            "checkpoint/recovery timings",
            "profiles and external-engine comparisons",
        ],
        "prepared_harness_sha256": {str(path): sha256(path) for path in files},
        "no_automatic_retry_expansion_or_budget_extension": True,
    }
    (ROOT / "plan.json").write_text(json.dumps(plan, indent=2, allow_nan=False) + "\n")
    print(
        json.dumps(
            {
                "path": str(ROOT / "plan.json"),
                "readiness": plan["readiness"],
                "cases": len(plan["workloads"]),
            }
        )
    )


if __name__ == "__main__":
    main()
