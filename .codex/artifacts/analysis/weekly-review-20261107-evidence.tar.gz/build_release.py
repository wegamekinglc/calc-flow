"""Invoke the maintained release builder and retain its outer cost/outcome."""
import asyncio
import json
import os
from pathlib import Path
import sys
import time

source, output = map(Path, sys.argv[1:])
sys.path.insert(0, str(source))
from scripts.benchmark_suite.release import build_release

started = time.monotonic()
record = {"source": str(source), "output": str(output), "pid": os.getpid(),
          "started_monotonic": started, "builds_separate_from_measurement": True,
          "environment": {key: os.environ.get(key) for key in
                          ("CARGO_BUILD_JOBS", "CARGO_INCREMENTAL", "RUSTFLAGS", "CARGO_PROFILE_RELEASE_DEBUG")}}
output.mkdir(parents=True, exist_ok=True)
try:
    asyncio.run(build_release(source, output))
    record["outcome"] = "success"
except BaseException as error:
    record["outcome"] = "failure"
    record["error"] = repr(error)
    raise
finally:
    record["elapsed_seconds"] = time.monotonic() - started
    (output / "outer-build.json").write_text(json.dumps(record, indent=2) + "\n")
