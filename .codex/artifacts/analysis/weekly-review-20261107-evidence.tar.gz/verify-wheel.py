"""Verify the exact review wheel through the two changed Python test modules."""

from __future__ import annotations

import asyncio
import json
import os
import sys
import time
from pathlib import Path

ITEM = Path(__file__).resolve().parent
DEV = ITEM.parent / "worktrees/weekly-review-20261107"
sys.path.insert(0, str(DEV))

from scripts.benchmark_suite.process import child_environment, command, install
from scripts.benchmark_suite.release import load_release
from scripts.toolkit import write_json


async def main():
    started = time.monotonic()
    release = load_release(ITEM / "candidate-v2-release/release.json")
    output = ITEM / "exact-wheel-tests"
    site = await install(release, output)
    verification = """
import hashlib, json, pathlib, sys
import calc_flow
import calc_flow._native as native
import pytest
site = pathlib.Path(sys.argv[1]).resolve()
module = pathlib.Path(native.__file__).resolve()
assert module.is_relative_to(site)
assert pathlib.Path(calc_flow.__file__).resolve().is_relative_to(site)
digest = hashlib.sha256(module.read_bytes()).hexdigest()
assert digest == sys.argv[2]
print(json.dumps({'package': calc_flow.__file__, 'native': str(module), 'native_sha256': digest}), flush=True)
raise SystemExit(pytest.main(['python/tests/test_arrow_stream_inputs.py', 'python/tests/test_config.py', '-q']))
"""
    receipt = {"release": release, "tests": ["test_arrow_stream_inputs.py", "test_config.py"]}
    try:
        await command(
            [sys.executable, "-c", verification, str(site), release["native_sha256"]],
            cwd=DEV,
            log=output / "pytest.log",
            env={**child_environment(site, source=DEV, tokio_threads=1), "PYTEST_ADDOPTS": ""},
            timeout=180,
        )
        receipt["outcome"] = "passed"
    except BaseException as error:
        receipt["outcome"] = "failed"
        receipt["error"] = f"{type(error).__name__}: {error}"
        raise
    finally:
        receipt["elapsed_seconds"] = time.monotonic() - started
        write_json(output / "receipt.json", receipt)
        print(json.dumps(receipt), flush=True)


if __name__ == "__main__":
    asyncio.run(main())
