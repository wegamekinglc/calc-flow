CREATE TABLE events (
      id BIGINT NOT NULL, k BIGINT NOT NULL, ts TIMESTAMP NOT NULL, x BIGINT NOT NULL,
      WATERMARK FOR ts AS (ts - INTERVAL '1 microsecond')
    ) WITH (connector = 'websocket', endpoint = 'ws://127.0.0.1:46062', format = 'json',
      framing = 'newline');
    SELECT CAST(EXTRACT(EPOCH FROM w.start) * 1000000 AS BIGINT) AS ws,
        k, total, cnt FROM (SELECT TUMBLE(INTERVAL '4 seconds') AS w,
        k, SUM(x) AS total, COUNT(*) AS cnt FROM events WHERE id >= 0 GROUP BY 1, 2);
    