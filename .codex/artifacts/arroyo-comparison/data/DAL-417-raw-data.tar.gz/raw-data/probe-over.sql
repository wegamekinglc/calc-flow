CREATE TABLE events (id BIGINT NOT NULL, k BIGINT NOT NULL, ts TIMESTAMP NOT NULL, x BIGINT NOT NULL, WATERMARK FOR ts AS (ts - INTERVAL '1 microsecond')) WITH (connector = 'websocket', endpoint = 'ws://127.0.0.1:9', format = 'json', framing = 'newline');
SELECT id, AVG(x) OVER (PARTITION BY k ORDER BY ts ROWS BETWEEN 2 PRECEDING AND CURRENT ROW) AS moving FROM events;
