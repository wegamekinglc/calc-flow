CREATE TABLE events (
      id BIGINT NOT NULL, k BIGINT NOT NULL, ts TIMESTAMP NOT NULL, x BIGINT NOT NULL,
      WATERMARK FOR ts AS (ts - INTERVAL '1 microsecond')
    ) WITH (connector = 'websocket', endpoint = 'ws://127.0.0.1:45198', format = 'json',
      framing = 'newline');
    SELECT id, x * 2 + 1 AS y FROM events WHERE id >= 0 AND k < 8;
    